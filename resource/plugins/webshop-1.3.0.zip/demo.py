# Copyright & Ownership Notice
# easy2Edit is the exclusive legal property of RST Coaching & Consultancy B.V. (RSTCC),
# owned by Ronald Stolk. All rights reserved. Any unauthorized use, copying, modification,
# reproduction, distribution, or commercial exploitation of Easy2Edit, including its source code,
# is strictly prohibited without prior written permission from Ronald Stolk or RSTCC.
# website https://rstcc.net

"""Demo-inhoud voor de webshop: groepen, categorieën, producten met meerdere foto's, varianten (kleur, maat, materiaal) met eigen prijzen en staffelprijzen.

De foto's worden getekend (kleurvlakken met de naam), zodat er geen bestanden of internet nodig zijn. Alles wat hier wordt gemaakt krijgt de markering `demo`
en kan in één keer weer worden verwijderd."""
import io
import logging
from decimal import Decimal

# een variant: (naam, kleurcode of "", prijs of None)   een staffel: (vanaf aantal, prijs per stuk)
SETS = {
    "clothing": {
        "title": "Kleding", "about": "Dames, heren en kinderen met kleuren, categorieën en staffelprijzen (vanaf 2, 3 of 6 stuks).",
        "groups": [("Dames", None, "Jurken, truien en broeken."), ("Jurken", "Dames", ""), ("Truien", "Dames", ""), ("Broeken", "Dames", ""), ("Heren", None, "Shirts, jassen en meer."),
                   ("Shirts", "Heren", ""), ("Jassen", "Heren", ""), ("Kinderen", None, "Kleding voor de kleintjes."), ("Accessoires", None, "Sjaals, petten en tassen.")],
        "products": [
            ("Zomerjurk Bloom", "Jurken", "49.95", "Luchtige jurk van viscose, tot op de knie. Maten XS–XL.", [("Rood", "#c0392b", None), ("Blauw", "#2c6fbb", None), ("Zwart", "#222222", "54.95")], [(2, "44.95")], 25),
            ("Wollen trui Nordic", "Truien", "59.95", "Warme trui van merinowol met ronde hals. Maten S–XXL.", [("Grijs", "#8a8f98", None), ("Marine", "#1f3a5f", None), ("Mosterd", "#d4a017", "64.95")], [(2, "54.95")], 40),
            ("Skinny jeans Dames", "Broeken", "69.95", "Stretch denim met hoge taille. Maten 26–34.", [("Blauw", "#3b5b8c", None), ("Zwart", "#1c1c1c", None)], [(2, "64.95")], 30),
            ("Basic T-shirt Heren", "Shirts", "14.95", "Ronde hals, 100% biologisch katoen. Hoe meer, hoe goedkoper.", [("Wit", "#f4f4f4", None), ("Zwart", "#222222", None), ("Grijs", "#9aa0a6", None), ("Rood", "#c0392b", None)], [(3, "12.95"), (6, "10.95")], 200),
            ("Winterjas Alpine", "Jassen", "129.95", "Gewatteerde jas met capuchon, waterafstotend. Maten S–XXL.", [("Zwart", "#1c1c1c", None), ("Olijf", "#5b6b3a", None), ("Marine", "#1f3a5f", "139.95")], [], 15),
            ("Hoodie Kids", "Kinderen", "34.95", "Zachte hoodie met zak. Maten 104–164.", [("Groen", "#2e8b57", None), ("Geel", "#e6b800", None), ("Roze", "#e07aa0", None)], [(2, "29.95")], 60),
            ("Sjaal Cosy", "Accessoires", "19.95", "Grof gebreide sjaal, 180 cm.", [("Rood", "#b03a2e", None), ("Grijs", "#8a8f98", None)], [], 80),
            ("Pet Classic", "Accessoires", "16.95", "Katoenen pet met verstelbare band.", [("Zwart", "#222222", None), ("Beige", "#c8b08a", None)], [(5, "12.95")], 120),
        ],
    },
    "furniture": {
        "title": "Meubels", "about": "Woonkamer, slaapkamer en kantoor met materialen en maten (eigen prijzen per variant) en staffels voor stoelen.",
        "groups": [("Woonkamer", None, "Banken, tafels en stoelen."), ("Banken", "Woonkamer", ""), ("Tafels", "Woonkamer", ""), ("Stoelen", "Woonkamer", ""), ("Slaapkamer", None, "Bedden en kasten."),
                   ("Bedden", "Slaapkamer", ""), ("Kasten", "Slaapkamer", ""), ("Kantoor", None, "Werken in comfort.")],
        "products": [
            ("Hoekbank Nova", "Banken", "899.00", "Ruime hoekbank met losse kussens, in elkaar te zetten zonder gereedschap.", [("Antraciet", "#3a3f47", None), ("Beige", "#cdbfa6", None), ("Groen", "#4d6b57", "949.00")], [], 6),
            ("Eettafel Oak", "Tafels", "449.00", "Massief eiken eettafel voor 6 personen, 180 × 90 cm.", [("Eiken", "#b08a57", None), ("Walnoot", "#6b4a32", "499.00"), ("Wit", "#eeeeee", None)], [], 8),
            ("Eetkamerstoel Lisa", "Stoelen", "79.00", "Gestoffeerde stoel met houten poten. Koop meer, betaal minder.", [("Grijs", "#8a8f98", None), ("Zwart", "#222222", None), ("Cognac", "#a0522d", "89.00")], [(4, "69.00"), (6, "64.00")], 48),
            ("Salontafel Duo", "Tafels", "159.00", "Set van twee ronde salontafels, metaal met houten blad.", [], [], 20),
            ("Boekenkast Rio", "Kasten", "229.00", "Open kast met 5 planken, 80 × 200 cm.", [("Wit", "#eeeeee", None), ("Eiken", "#b08a57", None)], [], 14),
            ("Tweepersoonsbed Luna", "Bedden", "549.00", "Bed met hoofdbord en lattenbodem.", [("160 × 200", "#7a6f9b", None), ("180 × 200", "#5d5380", "609.00")], [], 5),
            ("Bureau Flex", "Kantoor", "299.00", "Zit-sta bureau, elektrisch in hoogte te verstellen.", [("Wit", "#eeeeee", None), ("Zwart", "#222222", None)], [(3, "269.00")], 12),
            ("Bureaustoel Ergo", "Kantoor", "189.00", "Ergonomische stoel met lendensteun en verstelbare armleuningen.", [], [(5, "169.00")], 30),
        ],
    },
    "grocery": {
        "title": "Supermarkt", "about": "Boodschappen met het lage btw-tarief en staffelprijzen (vanaf 3, 6 of 12 stuks).",
        "groups": [("Groente & fruit", None, "Vers van de dag."), ("Zuivel & eieren", None, ""), ("Brood & banket", None, ""), ("Dranken", None, ""), ("Voorraadkast", None, "")],
        "vat_key": "laag",
        "products": [
            ("Appels Elstar 1 kg", "Groente & fruit", "2.49", "Knapperig en zoet.", [], [(3, "2.19"), (6, "1.99")], None),
            ("Bananen 1 kg", "Groente & fruit", "1.89", "Fairtrade bananen.", [], [(3, "1.69")], None),
            ("Tomaten 500 g", "Groente & fruit", "1.79", "Trostomaten uit Nederland.", [], [], 200),
            ("Halfvolle melk 1 L", "Zuivel & eieren", "1.15", "Houdbare halfvolle melk.", [], [(6, "1.05")], None),
            ("Scharreleieren 10 stuks", "Zuivel & eieren", "2.99", "Vrije uitloop.", [("Maat M", "#e8d9b5", None), ("Maat L", "#e0c58f", "3.29")], [], 150),
            ("Volkorenbrood", "Brood & banket", "1.99", "Vers gebakken, gesneden.", [], [], 60),
            ("Croissants 4 stuks", "Brood & banket", "2.29", "Boterachtig en luchtig.", [], [(3, "1.99")], 80),
            ("Sinaasappelsap 1 L", "Dranken", "2.19", "100% vruchtensap.", [], [(6, "1.89")], 120),
            ("Cola 1,5 L", "Dranken", "1.99", "Koud het lekkerst.", [], [(6, "1.69"), (12, "1.49")], 300),
            ("Spaghetti 500 g", "Voorraadkast", "1.29", "Durumtarwe.", [], [(5, "1.09")], 400),
            ("Pindakaas 350 g", "Voorraadkast", "2.49", "Van 100% pinda's.", [("Naturel", "#c8a46a", None), ("Crunchy", "#b8893f", "2.69")], [], 90),
        ],
    },
    "standard": {
        "title": "Standaard producten", "about": "Zes neutrale voorbeeldproducten met drie foto's, een product met maten en staffelprijzen.",
        "groups": [("Nieuw", None, "De nieuwste producten."), ("Populair", None, "Wat andere klanten kopen."), ("Aanbiedingen", None, "Nu extra voordelig.")],
        "products": [
            ("Voorbeeldproduct A", "Nieuw", "19.95", "Een eenvoudig voorbeeldproduct met drie foto's.", [], [], 50),
            ("Voorbeeldproduct B", "Nieuw", "24.95", "Met staffelprijs: vanaf 3 stuks goedkoper.", [], [(3, "21.95"), (10, "18.95")], 80),
            ("Voorbeeldproduct C (maten)", "Populair", "19.95", "Beschikbaar in drie maten met eigen prijs.", [("Klein", "#6fa8dc", None), ("Middel", "#3d85c6", "24.95"), ("Groot", "#0b5394", "29.95")], [], 40),
            ("Voorbeeldproduct D", "Populair", "39.00", "Een duurder voorbeeldproduct.", [], [], 20),
            ("Voorbeeldproduct E", "Aanbiedingen", "9.95", "Nu in de aanbieding.", [], [(2, "8.95")], 100),
            ("Voorbeeldproduct F", "Aanbiedingen", "14.95", "Onbeperkt op voorraad.", [], [], None),
        ],
    },
}
# per product: the names of the two choices and what they offer. sizes = [(label, extra price)]; variants (only where given) replace the colours of the set
CLOTH = ("Kleur", "Maat")
OPTS = {
    "Zomerjurk Bloom": {"labels": CLOTH, "sizes": [("XS", 0), ("S", 0), ("M", 0), ("L", 0), ("XL", 2.5)]}, "Wollen trui Nordic": {"labels": CLOTH, "sizes": [("S", 0), ("M", 0), ("L", 0), ("XL", 0), ("XXL", 3)]},
    "Skinny jeans Dames": {"labels": CLOTH, "sizes": [("26", 0), ("28", 0), ("30", 0), ("32", 0), ("34", 0)]}, "Basic T-shirt Heren": {"labels": CLOTH, "sizes": [("S", 0), ("M", 0), ("L", 0), ("XL", 0), ("XXL", 1)]},
    "Winterjas Alpine": {"labels": CLOTH, "sizes": [("S", 0), ("M", 0), ("L", 0), ("XL", 0), ("XXL", 5)]}, "Hoodie Kids": {"labels": CLOTH, "sizes": [("104", 0), ("116", 0), ("128", 0), ("140", 0), ("152", 2), ("164", 2)]},
    "Sjaal Cosy": {"labels": ("Kleur", "Lengte"), "sizes": [("160 cm", 0), ("180 cm", 0), ("200 cm", 3)]}, "Pet Classic": {"labels": ("Kleur", "Maat"), "sizes": [("S/M", 0), ("L/XL", 0)]},
    # furniture: colours and fabrics
    "Hoekbank Nova": {"labels": ("Kleur", "Stof"), "sizes": [("Katoen", 0), ("Linnen", 50), ("Fluweel", 90), ("Leer", 250)]}, "Eetkamerstoel Lisa": {"labels": ("Kleur", "Stof"), "sizes": [("Katoen", 0), ("Fluweel", 10), ("Leer", 35)]},
    "Tweepersoonsbed Luna": {"labels": ("Maat", "Stof hoofdbord"), "sizes": [("Katoen", 0), ("Fluweel", 60), ("Leer", 140)]}, "Bureaustoel Ergo": {"labels": ("Kleur", "Stof"), "variants": [("Zwart", "#222222", None), ("Grijs", "#8a8f98", None), ("Blauw", "#2c6fbb", None)], "sizes": [("Mesh", 0), ("Stof", 0), ("Leer", 40)]},
    "Bureau Flex": {"labels": ("Kleur", "Blad"), "sizes": [("120 × 60", 0), ("140 × 70", 30), ("160 × 80", 60)]},
    # supermarket: packaging and weight
    "Appels Elstar 1 kg": {"labels": ("Verpakking", "Gewicht"), "variants": [("Los", "", None), ("Zakje", "", "0.20"), ("Krat", "", "0.50")], "sizes": [("500 g", -1), ("1 kg", 0), ("2 kg", 2.2)]},
    "Bananen 1 kg": {"labels": ("Verpakking", "Gewicht"), "variants": [("Los", "", None), ("Trosje in folie", "", "0.10")], "sizes": [("500 g", -0.9), ("1 kg", 0), ("2 kg", 1.7)]},
    "Tomaten 500 g": {"labels": ("Verpakking", "Gewicht"), "variants": [("Schaaltje", "", None), ("Zakje", "", "-0.10")], "sizes": [("250 g", -0.9), ("500 g", 0), ("1 kg", 1.6)]},
    "Halfvolle melk 1 L": {"labels": ("Verpakking", "Inhoud"), "variants": [("Pak", "", None), ("Fles", "", "0.30")], "sizes": [("0,5 L", -0.6), ("1 L", 0), ("2 L", 1.0)]},
    "Spaghetti 500 g": {"labels": ("Verpakking", "Gewicht"), "variants": [("Pak", "", None), ("Doos 6 pakken", "", "6.50")], "sizes": [("500 g", 0), ("1 kg", 1.1)]},
    "Pindakaas 350 g": {"labels": ("Verpakking", "Gewicht"), "variants": [("Naturel", "", None), ("Crunchy", "", "0.20")], "sizes": [("350 g", 0), ("650 g", 1.7)]},
    "Cola 1,5 L": {"labels": ("Verpakking", "Inhoud"), "variants": [("Fles", "", None), ("Krat 6 flessen", "", "7.00")], "sizes": [("1,5 L", 0), ("2 L", 0.6)]},
    "Sinaasappelsap 1 L": {"labels": ("Verpakking", "Inhoud"), "variants": [("Pak", "", None), ("Fles", "", "0.30")], "sizes": [("0,5 L", -0.9), ("1 L", 0)]},
}
PALETTE = ["#4a6fa5", "#c0692b", "#4d8b6f", "#8e5ea2", "#b5485d", "#6b7a8f"]


def stock_demo(ctx, p, i, stock):
    """Voorraad per combinatie: meeste op voorraad, enkele bijna op, uitverkocht (met of zonder nabestellen) en bestelde voorraad bij de leverancier."""
    vs = [v["key"] for v in p.variants] or [""]
    ss = [s["key"] for s in p.sizes] or [""]
    combos = [(v + "|" + s) if (v and s) else (v or s) for v in vs for s in ss]
    if len(combos) > 1:
        m = {}
        for n, k in enumerate(combos):
            r = (n * 7 + i * 3) % 10
            have = 0 if r == 0 else (2 if r == 1 else 6 + r * 2)
            m[k] = {"stock": have, "ordered": (12 if r in (0, 1) else 0)}
        p.stock_per_option, p.stock_map = True, m
    else:
        p.stock = stock
    if i % 4 == 1:  # deze producten blijven verkoopbaar bij geen voorraad
        p.backorder = True
    if i % 5 == 2:
        p.ordered, p.ordered_eta = 25, "volgende week"
    p.save()


def sets():
    return [{"key": k, "title": v["title"], "about": v["about"], "products": len(v["products"])} for k, v in SETS.items()]


def png(title, sub, hex_color, style):
    """A product picture: a coloured plane with a shape, the name and (for a variant) its name."""
    from PIL import Image, ImageDraw, ImageFont

    w, h = 900, 700
    base = tuple(int(hex_color[i:i + 2], 16) for i in (1, 3, 5))
    img = Image.new("RGB", (w, h), base)
    d = ImageDraw.Draw(img)
    dark = tuple(max(0, c - 40) for c in base)
    light = tuple(min(255, c + 45) for c in base)
    for y in range(0, h, 4):  # soft gradient
        k = y / h
        d.rectangle([0, y, w, y + 4], fill=tuple(int(base[i] * (1 - k * .25)) for i in range(3)))
    if style == 0:
        d.ellipse([w * .2, h * .1, w * .8, h * .78], fill=light)
        d.ellipse([w * .32, h * .22, w * .68, h * .66], fill=dark)
    elif style == 1:
        for x in range(-h, w, 70):
            d.polygon([(x, h), (x + 36, h), (x + 36 + h, 0), (x + h, 0)], fill=light)
        d.rounded_rectangle([w * .12, h * .62, w * .88, h * .9], radius=24, fill=dark)
    else:
        d.rounded_rectangle([w * .14, h * .14, w * .86, h * .7], radius=40, fill=light)
        for i in range(5):
            d.ellipse([w * (.2 + i * .14), h * .76, w * (.26 + i * .14), h * .84], fill=dark)
    lum = .299 * base[0] + .587 * base[1] + .114 * base[2]
    ink = (20, 20, 20) if lum > 150 else (255, 255, 255)
    try:
        big, small = ImageFont.load_default(size=44), ImageFont.load_default(size=30)
    except TypeError:  # an old Pillow
        big = small = ImageFont.load_default()
    d.text((w / 2, h * .9 if style == 1 else h * .92), title[:34], fill=ink, font=big, anchor="mm")
    if sub:
        d.text((w / 2, h * .08), sub[:30], fill=ink, font=small, anchor="mm")
    buf = io.BytesIO()
    img.save(buf, "PNG", optimize=True)
    return buf.getvalue()


PARTS = ("products", "images", "designs", "orders", "users")  # what can be removed, one by one


def counts(ctx):
    o = ctx.orders()
    return {"products": ctx.Product.objects.filter(demo=True).count(), "images": ctx.MediaItem.objects.filter(source="shop-demo").count(), "designs": ctx.Design.objects.filter(demo=True).count(),
            "orders": o.demo_count() if o else 0, "users": ctx.User.objects.filter(username__startswith="fake_shop_").count(),
            "media_demo": ctx.MediaItem.objects.filter(source="media-demo", kind="image").count()}


def remove(ctx, what=None):
    """Remove what the demo made: `what` = a list of PARTS (default: everything). Returns the number removed per part."""
    from django.core.files.storage import default_storage

    what, done = set(what or PARTS), {}
    if "orders" in what and ctx.orders():
        done["orders"] = ctx.orders().remove_demo()
    if "users" in what:
        users = ctx.User.objects.filter(username__startswith="fake_shop_")
        done["users"] = users.count()
        if ctx.orders():
            ctx.orders().detach_users(list(users.values_list("id", flat=True)))  # orders of these users stay (without the person)
        users.delete()
    if "products" in what:
        done["products"] = ctx.Product.objects.filter(demo=True).count()
        ctx.Image.objects.filter(product__demo=True).delete()
        ctx.Product.objects.filter(demo=True).delete()
        ctx.Group.objects.filter(demo=True).update(parent=None)
        ctx.Group.objects.filter(demo=True).delete()
    if "designs" in what:
        done["designs"] = ctx.Design.objects.filter(demo=True).count()
        ctx.Design.objects.filter(demo=True).delete()
        ctx.sync_objects()
    if "images" in what:
        n = 0
        for item in ctx.MediaItem.objects.filter(source="shop-demo"):
            try:
                default_storage.delete(item.key)
            except Exception:  # noqa: BLE001
                pass
            ctx.MediaItem.objects.filter(pk=item.pk).delete()
            n += 1
        done["images"] = n
    return done


FAKE = [("Jan", "de Vries", "Kerkstraat 12", "1011AB", "Amsterdam"), ("Sanne", "Bakker", "Lindelaan 5", "3511CD", "Utrecht"), ("Mohamed", "El Amrani", "Havenweg 88", "3011EF", "Rotterdam"), ("Lisa", "Jansen", "Molenstraat 3", "5611GH", "Eindhoven")]


def make_orders(ctx):
    """Four example orders that were placed (and paid) some days ago, one for each of four demo users (the demo users of the site; when there are none, fake customers are made)."""
    prods = list(ctx.Product.objects.filter(demo=True).order_by("id"))
    if not prods or ctx.orders().demo_count() >= 4:  # (four is enough: more example shops do not add more orders)
        return {"orders": 0, "users": 0}
    users = list(ctx.User.objects.filter(is_staff=False, is_superuser=False, email__startswith="demo-", email__endswith="@example.com").order_by("id")[:4])
    users += list(ctx.User.objects.filter(username__startswith="fake_shop_").order_by("id")[: 4 - len(users)])
    made_users = 0
    have = {u.username for u in users}
    for n, (first, last, street, zipc, city) in enumerate(FAKE):
        if len(users) >= 4:
            break
        if f"fake_shop_{n + 1}" in have:
            continue
        u = ctx.User(username=f"fake_shop_{n + 1}", email=f"fake-shop-{n + 1}@example.com", first_name=first, last_name=last, address=street, postal_code=zipc, city=city, country="NL", is_active=True)
        u.set_unusable_password()
        u.save()
        users.append(u)
        made_users += 1
    method = ctx.Method.objects.filter(active=True).order_by("order").first()
    states = ["completed", "shipped", "paid", "completed"]  # all four were placed and paid already
    ago = [21, 12, 6, 2]  # days ago
    made = 0
    for n in range(4):
        u = users[n % len(users)]
        data = {"name": f"{u.first_name} {u.last_name}".strip() or u.username, "email": u.email or f"klant{n}@example.com", "phone": "", "street": u.address or "Demostraat 1", "postal_code": u.postal_code or "1000AA",
                "city": u.city or "Amsterdam", "country": (u.country or "NL")[:2], "note": "Demo-bestelling"}
        order = None
        for attempt in range(12):  # a product or variant that is sold out is skipped: the next one is taken
            start = n * len(prods) // 4 + attempt  # spread over all the example shops that are there
            items = []
            for k, p in enumerate([prods[start % len(prods)], prods[(start + 1) % len(prods)]]):
                it = {"product": p.id, "quantity": [1, 2, 3, 6][(n + k) % 4] if attempt < 6 else 1}
                key = p.variants[(n + k + attempt) % len(p.variants)]["key"] if p.variants else ""
                if p.sizes:
                    key += "|" + p.sizes[(n + k + attempt) % len(p.sizes)]["key"]
                if key:
                    it["variant"] = key
                items.append(it)
            try:
                order = ctx.create_order(data, items, method.id if method else None, "", u)
                break
            except ValueError as e:
                logging.getLogger(__name__).info("Demo-bestelling %s: poging %s mislukt (%s)", n + 1, attempt + 1, e)
        if order is None:
            continue
        ctx.orders().mark_demo(order, states[n], ago[n])
        made += 1
    return {"orders": made, "users": made_users}


def build(ctx, key, replace=False, use_media=False, designs=True, orders=True):
    """Make the demo set `key`. Returns {products, groups, images, designs}. use_media: the pictures of the media demo (Media -> Systeemobjecten) are used instead of drawing new ones."""
    from django.core.files.base import ContentFile
    from django.core.files.storage import default_storage
    from apps.medialib import areas

    spec = SETS[key]
    if replace:
        remove(ctx)
    made = {"groups": 0, "products": 0, "images": 0}
    groups = {}
    pool = list(ctx.MediaItem.objects.filter(source="media-demo", kind="image").order_by("id")) if use_media else []
    cursor = [0]

    def save_png(slug, n, data, label, tags=()):
        if pool:  # an example picture that is already in the library: used again (and not removed with this demo)
            item = pool[cursor[0] % len(pool)]
            cursor[0] += 1
            made["images_used"] = made.get("images_used", 0) + 1
            return item
        name = default_storage.save(areas.site_path("library", f"shop-demo/{slug}-{n}.png"), ContentFile(data()))
        item = ctx.MediaItem.objects.get(key=name)
        item.name, item.source, item.tags = f"{label}.png"[:255], "shop-demo", list(dict.fromkeys(["demo", "webshop", *[str(t)[:30] for t in tags if t]]))
        item.save(update_fields=["name", "source", "tags"])
        made["images"] += 1
        return item

    for order, (name, parent, desc) in enumerate(spec["groups"]):
        slug = ctx.unique_slug(ctx.Group, name)
        g = ctx.Group.objects.create(name=name, slug=slug, description=desc, parent=groups.get(parent), order=order, demo=True)
        groups[name] = g
        made["groups"] += 1
        if parent is None:  # a picture for a main group
            g.media = save_png(f"groep-{slug}", 0, lambda: png(name, "", PALETTE[order % len(PALETTE)], 2), f"Groep {name}", ("groep", ctx.slugify(name)))
            g.save(update_fields=["media"])
    for i, (name, group, price, text, variants, tiers, stock) in enumerate(spec["products"]):
        slug = ctx.unique_slug(ctx.Product, name)
        opt = OPTS.get(name, {})
        vsrc = opt.get("variants", variants)
        pv = [{"key": ctx.slugify(v[0]) or f"v{n}", "label": v[0], "color": v[1] if v[1].startswith("#") and len(v[1]) == 7 else "", "price": (str(Decimal(price) + Decimal(str(v[2]))) if (v[2] and opt.get("variants")) else v[2]), "sku": f"DEMO-{i + 1:02d}-{n + 1}"} for n, v in enumerate(vsrc)]
        p = ctx.Product.objects.create(
            name=name, slug=slug, sku=f"DEMO-{i + 1:02d}", summary=text[:300], description=f"<p>{text}</p><p>Dit is demo-inhoud: je kunt dit product aanpassen of verwijderen.</p>", price=Decimal(price), stock=stock,
            vat_key=spec.get("vat_key", ""), group=groups.get(group), variants=pv, sizes=[{"key": ctx.slugify(x[0]) or f"m{k}", "label": x[0], "extra": str(Decimal(str(x[1])))} for k, x in enumerate(opt.get("sizes", []))], variant_label=(opt.get("labels") or ("Kleur", "Maat"))[0] if (vsrc or opt) else "", size_label=(opt.get("labels") or ("", "Maat"))[1] if opt.get("sizes") else "", tiers=[{"min": m, "price": pr} for m, pr in tiers], demo=True)
        made["products"] += 1
        stock_demo(ctx, p, i, stock)
        base = PALETTE[i % len(PALETTE)]
        pics = [(v["color"] or base, v["label"], 0) for v in pv] or [(base, "", 0)]
        pics += [(pics[0][0], "detail", 1), (pics[-1][0], "sfeer", 2)]  # always more than one picture
        for n, (col, sub, style) in enumerate(pics[:6]):
            item = save_png(f"{slug}-{n + 1}", n, lambda: png(name, sub if sub else "", col, style), f"{name} {n + 1}", ("product", ctx.slugify(spec["title"]), ctx.slugify(group), ctx.slugify(name)[:28]))
            ctx.Image.objects.create(product=p, media=item, alt=f"{name} {sub}".strip(), order=n)
    # voorbeeld-systeemobjecten: ontwerpen van het productenoverzicht die je in de bewerkmodus op een pagina zet
    first_group = next((g for g in spec["groups"] if g[1] is None), None)
    designs_list = [("Demo: tegels", {"layout": "grid", "size": "md", "ratio": "4/3", "style": "card", "title": "Onze producten", "button": "Bekijk"}),
               ("Demo: lijst", {"layout": "rows", "size": "sm", "style": "flat", "show_summary": True, "search": True, "switch": False, "title": "Alle producten"}),
               ("Demo: uitgelicht (4 nieuwste)", {"layout": "grid", "size": "lg", "ratio": "1/1", "style": "outline", "align": "center", "title": "Nieuw binnen", "sort": "new", "limit": 4, "search": False, "chips": False, "pager": False, "switch": False})]
    designs_list += [("Demo: productvinder (filters)", {"layout": "finder", "size": "md", "style": "card", "title": "Vind jouw product", "pager": False, "chips": False, "switch": False, "search": False}),
                ("Demo: productcarrousel", {"layout": "carousel", "size": "md", "style": "card", "title": "Populaire producten", "autoplay": True, "limit": 8, "sort": "new", "search": False, "chips": False, "switch": False, "pager": False, "hover": "zoom"})]
    if first_group:
        designs_list.append((f"Demo: {first_group[0]}", {"layout": "grid", "size": "md", "style": "card", "title": first_group[0], "group": groups[first_group[0]].slug, "chips": False}))
    for n, (name, data) in enumerate(designs_list if designs else []):
        ctx.Design.objects.create(name=name, slug=ctx.unique_slug(ctx.Design, name)[:48], data=ctx.design_data(data), active=True, order=n, demo=True)
        made["designs"] = made.get("designs", 0) + 1
    ctx.sync_objects()
    ctx.make_example_carriers()  # PostNL, DHL en FedEx met labelinstellingen en retourbeleid
    if not ctx.Method.objects.exists():
        c = {x.name: x for x in ctx.Carrier.objects.all()}
        ctx.Method.objects.create(name="Standaard verzending", carrier=c.get("PostNL"), description="Met track & trace", delivery_time="1-2 werkdagen", price=Decimal("4.95"), free_from=Decimal("50.00"), order=0)
        ctx.Method.objects.create(name="Pakket", carrier=c.get("DHL"), description="Met track & trace", delivery_time="1-2 werkdagen", price=Decimal("5.95"), free_from=Decimal("60.00"), order=1)
        ctx.Method.objects.create(name="Express", carrier=c.get("FedEx"), description="Volgende werkdag", delivery_time="Morgen", price=Decimal("12.50"), order=2)
        ctx.Method.objects.create(name="Afhalen", description="Gratis ophalen", delivery_time="Vandaag", price=Decimal("0.00"), order=3)
    if not ctx.Discount.objects.filter(code="DEMO10").exists():
        ctx.Discount.objects.create(code="DEMO10", description="Demo: 10% korting", kind="percent", value=Decimal("10"), min_subtotal=Decimal("0"))
    if orders and ctx.orders():  # example orders (the plugin Orders is needed anyway)
        made.update(make_orders(ctx))
    return made
