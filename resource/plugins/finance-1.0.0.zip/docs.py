"""Documents of an order as PDF: invoice (factuur), credit invoice (creditfactuur), packing slip (pakbon) and return form (retourbon).

A document is drawn from two things: the DATA (a snapshot saved when the document was made: seller, customer, lines, totals, so an invoice never changes
afterwards) and the LAYOUT (what the superadmin made in Instellingen → Layout editor: which blocks, in which order, how wide, texts, colour, font).
`render(snap, t, layout, logo)` returns the bytes of the PDF."""
import io
import re
from decimal import Decimal

from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.platypus import Image, KeepTogether, Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle

KINDS = ("quote", "invoice", "credit", "packing", "return")
TITLES = {"quote": "Offerte", "invoice": "Factuur", "credit": "Creditfactuur", "packing": "Pakbon", "return": "Retourbon"}
FONTS = {"Helvetica": ("Helvetica", "Helvetica-Bold"), "Times": ("Times-Roman", "Times-Bold"), "Courier": ("Courier", "Courier-Bold")}
ALL = KINDS
# every block there is: id -> (label, the documents that have it, can the text be edited?)
BLOCKS = {
    "logo": ("Logo", ALL, False), "company": ("Bedrijfsgegevens", ALL, False), "title": ("Titel", ALL, True), "customer": ("Klantgegevens", ALL, False), "meta": ("Nummer en datum", ALL, False),
    "intro": ("Inleiding", ALL, True), "lines": ("Regels", ALL, False), "totals": ("Totalen", ("quote", "invoice", "credit"), False), "terms": ("Voorwaarden en geldigheid", ("quote",), True), "payment": ("Betaalgegevens", ("invoice", "credit"), True),
    "finance": ("Financiële gegevens (KvK, btw, IBAN)", ALL, False), "shipping": ("Verzending en opmerking", ("packing",), False),
    "reasons": ("Reden van retour", ("return",), False), "wish": ("Wat wil de klant?", ("return",), False), "remarks": ("Toelichting (invulvak)", ("return",), False),
    "barcode": ("Barcode voor de vervoerder", ("return",), False), "return_to": ("Retouradres", ("return",), True), "signature": ("Datum en handtekening", ("quote", "return"), False), "footer": ("Voettekst (onderaan elke pagina)", ALL, True),
}
TEXT_PREFIX = "text-"  # free text blocks: text-1, text-2 ...
DEFAULT_TEXT = {
    "terms": {"quote": "Deze offerte is geldig tot {geldig_tot}. Prijzen zijn inclusief btw, tenzij anders vermeld. Na akkoord leveren wij zo snel mogelijk."},
    "intro": {"quote": "Bedankt voor je aanvraag. Hierbij ontvang je onze offerte {nummer} voor bestelling {bestelling}.", "invoice": "Hierbij ontvang je de factuur voor je bestelling {bestelling}.", "credit": "Hierbij ontvang je de creditfactuur bij factuur {factuur}.", "packing": "", "return": "Wil je iets terugsturen? Vul dit formulier in en stuur het mee met je pakket."},
    "payment": {"invoice": "Wij verzoeken je het bedrag van {bedrag} binnen {dagen} dagen te betalen onder vermelding van {nummer}.", "credit": "Het bedrag van {bedrag} wordt aan je terugbetaald."},
    "return_to": {"return": "Stuur dit formulier mee met je pakket naar:"},
    "footer": {k: "" for k in ALL},
}


BARCODE_FORMATS = ("code128", "code39", "qr")
BARCODE_DEFAULT = {"format": "code128", "content": "{nummer}", "height": 28, "width": 120, "text": True}


def clean_barcodes(raw):
    """Per transporter: how the barcode on the return form looks and what it says. "default" is for every transporter without its own."""
    out = {}
    for k, v in list((raw if isinstance(raw, dict) else {}).items())[:30]:
        if not isinstance(v, dict) or not str(k).strip():
            continue
        try:
            h, w = max(10, min(70, int(v.get("height", 28)))), max(30, min(170, int(v.get("width", 120))))
        except (TypeError, ValueError):
            h, w = 28, 120
        out[str(k)[:60]] = {"format": v["format"] if v.get("format") in BARCODE_FORMATS else "code128", "content": str(v.get("content") or "{nummer}")[:120], "height": h, "width": w, "text": bool(v.get("text", True))}
    out.setdefault("default", dict(BARCODE_DEFAULT))
    return out


def _row(i, on=True, w="full", text=None):
    return {"id": i, "on": on, "w": w, **({"text": text} if text is not None else {})}


def default_layout(kind):
    common_top = [_row("logo", True, "half"), _row("company", True, "half"), _row("title"), _row("customer", True, "half"), _row("meta", True, "half"), _row("intro", kind != "packing", "full", DEFAULT_TEXT["intro"][kind])]
    if kind == "quote":
        rest = [_row("lines"), _row("totals"), _row("terms", True, "full", DEFAULT_TEXT["terms"]["quote"]), _row("signature"), _row("finance", False)]
    elif kind == "invoice":
        rest = [_row("lines"), _row("totals"), _row("payment", True, "full", DEFAULT_TEXT["payment"]["invoice"]), _row("finance", False)]
    elif kind == "credit":
        rest = [_row("lines"), _row("totals"), _row("payment", True, "full", DEFAULT_TEXT["payment"]["credit"]), _row("finance", False)]
    elif kind == "packing":
        rest = [_row("lines"), _row("shipping"), _row("finance", False)]
    else:
        rest = [_row("lines"), _row("reasons"), _row("wish"), _row("remarks"), _row("return_to", True, "full", DEFAULT_TEXT["return_to"]["return"]), _row("barcode", False), _row("signature"), _row("finance", False)]
    return {"title": TITLES[kind], "barcodes": {"default": dict(BARCODE_DEFAULT)}, "vat_mode": "incl", "vat_lines": True, "vat_totals": True, "accent": "#0f172a", "font": "Helvetica", "size": 9.5, "logo_w": 38, "logo_align": "left", "blocks": common_top + rest + [_row("footer", True, "full", "")]}


def known(kind, bid):
    return (bid in BLOCKS and kind in BLOCKS[bid][1]) or (bid.startswith(TEXT_PREFIX) and bid[len(TEXT_PREFIX):].isdigit())


def clean_layout(kind, raw):
    """What the editor sends -> a safe layout (known blocks only, texts cut, colour checked). A block that is missing is added at the end (switched off)."""
    base = default_layout(kind)
    raw = raw if isinstance(raw, dict) else {}
    out = {"title": str(raw.get("title") or base["title"])[:40], "accent": raw["accent"] if re.fullmatch(r"#[0-9a-fA-F]{6}", str(raw.get("accent") or "")) else base["accent"],
           "font": raw["font"] if raw.get("font") in FONTS else base["font"], "logo_align": raw["logo_align"] if raw.get("logo_align") in ("left", "center", "right") else "left"}
    try:
        out["size"] = max(8.0, min(12.0, float(raw.get("size", base["size"]))))
        out["logo_w"] = max(15, min(170, int(raw.get("logo_w", base["logo_w"]))))
    except (TypeError, ValueError):
        out["size"], out["logo_w"] = base["size"], base["logo_w"]
    out["vat_mode"] = "excl" if raw.get("vat_mode") == "excl" else "incl"  # amounts including VAT (VAT stated under the total) or excluding VAT (VAT added up per tariff)
    out["vat_lines"] = bool(raw.get("vat_lines", True))  # the VAT percentage on every line
    out["vat_totals"] = bool(raw.get("vat_totals", True))  # the VAT amounts per tariff under the total
    out["barcodes"] = clean_barcodes(raw.get("barcodes") if raw.get("barcodes") else base["barcodes"])
    seen, blocks = set(), []
    for b in (raw.get("blocks") if isinstance(raw.get("blocks"), list) else [])[:40]:
        if not isinstance(b, dict) or not known(kind, str(b.get("id"))) or b["id"] in seen:
            continue
        seen.add(b["id"])
        row = {"id": b["id"], "on": bool(b.get("on", True)), "w": "half" if b.get("w") == "half" else "full", "align": b["align"] if b.get("align") in ("left", "center", "right") else "left"}
        if b["id"] == "company" and b.get("bottom"):
            row["bottom"] = True  # the company data at the bottom of the page, above the footer line
        if "text" in b or b["id"].startswith(TEXT_PREFIX) or BLOCKS.get(b["id"], ("", (), False))[2]:
            row["text"] = str(b.get("text") or "")[:1200]
        blocks.append(row)
    for b in base["blocks"]:  # a block that the editor did not send comes back switched off (a newer block of the plugin)
        if b["id"] not in seen:
            blocks.append({**b, "on": False})
    out["blocks"] = blocks
    return out


def merged(kind, stored):
    """The layout in use: what was saved, else the standard."""
    return clean_layout(kind, stored) if stored else default_layout(kind)


def _money(v, cur="EUR"):
    sign = "€ " if cur == "EUR" else cur + " "
    return f"{sign}{Decimal(str(v or 0)):,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")


def _pct(v):
    return f"{Decimal(str(v)).normalize():f}"


def _esc(s):
    return str(s or "").replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def sample(kind, company):  # noqa: C901
    """Example data for the preview of the editor: two VAT tariffs."""
    lines = [("Zomerjurk Bloom – Rood / M", "KL-001", 1, "49.95", "21"), ("Basic T-shirt Heren – Wit / L", "KL-004", 3, "14.95", "21"), ("Pet Classic – Zwart", "KL-008", 2, "16.95", "9")]
    sign = Decimal("-1") if kind == "credit" else Decimal("1")
    items, vr, br, total = [], {}, {}, Decimal("0")
    for n, s_, q, p, v in lines:
        lt = Decimal(p) * q
        va = (lt * Decimal(v) / (100 + Decimal(v))).quantize(Decimal("0.01"))
        items.append({"name": n, "sku": s_, "quantity": q, "unit_price": str(Decimal(p) * sign), "vat_rate": v, "line_total": str(lt * sign), "vat_amount": str(va * sign)})
        vr[v] = vr.get(v, Decimal("0")) + va * sign
        br[v] = br.get(v, Decimal("0")) + (lt - va) * sign
        total += lt
    ship = Decimal("4.95")
    sv = (ship * 21 / 121).quantize(Decimal("0.01"))
    vr["21"] = vr.get("21", Decimal("0")) + sv * sign
    br["21"] = br.get("21", Decimal("0")) + (ship - sv) * sign
    total += ship
    return {"kind": kind, "number": {"quote": "O2026-00004", "invoice": "F2026-00012", "credit": "C2026-00003"}.get(kind, "RT-2026-00012" if kind == "return" else "PB-2026-00012"), "date": "23-10-2026", "currency": "EUR",
            "ref": "F2026-00012" if kind == "credit" else None, "carrier": "postnl", "payment_terms": "", "paid": False, "payment_days": 14, "valid_until": "22-11-2026", "seller": company,
            "customer": {"name": "Sanne Bakker", "email": "sanne@example.com", "phone": "", "street": "Lindelaan 5", "postal_code": "3511 CD", "city": "Utrecht", "country": "NL"},
            "order": {"number": "2026-00012", "created": "20-10-2026", "note": "Graag bellen als je er bent."}, "items": items,
            "shipping": str(ship * sign), "shipping_vat": str(sv * sign), "shipping_method": "PostNL", "discount": "0", "discount_code": "", "vat_total": str(sum(vr.values())),
            "vat_by_rate": {k: str(v) for k, v in vr.items()}, "base_by_rate": {k: str(v) for k, v in br.items()}, "total": str(total * sign)}


def render(snap, t=lambda s, *a: s.format(*a) if a else s, layout=None, logo=None):
    kind = snap["kind"]
    lay = layout or default_layout(kind)
    cur = snap.get("currency") or "EUR"
    reg_font, bold_font = FONTS.get(lay.get("font"), FONTS["Helvetica"])
    accent = colors.HexColor(lay.get("accent") or "#0f172a")
    size = float(lay.get("size") or 9.5)
    INK, MUTED, LINE = colors.HexColor("#0f172a"), colors.HexColor("#64748b"), colors.HexColor("#cbd5e1")
    base = getSampleStyleSheet()["Normal"]
    st0 = st = ParagraphStyle("n", parent=base, fontName=reg_font, fontSize=size, leading=size * 1.38, textColor=INK)
    small0 = small = ParagraphStyle("s", parent=st, fontSize=size - 1.2, leading=(size - 1.2) * 1.35, textColor=MUTED)
    bold0 = bold = ParagraphStyle("b", parent=st, fontName=bold_font)
    h10 = h1 = ParagraphStyle("h", parent=st, fontName=bold_font, fontSize=size + 11, leading=size + 15, textColor=accent)
    right = ParagraphStyle("r", parent=st, alignment=2)
    rbold = ParagraphStyle("rb", parent=right, fontName=bold_font)
    P = lambda s, style=st: Paragraph(s, style)  # noqa: E731
    seller, c = snap["seller"], snap["customer"]
    cur_total = snap.get("total")
    fill = lambda text: _esc(text or "").replace("\n", "<br/>").replace("{nummer}", _esc(snap["number"])).replace("{bestelling}", _esc(snap["order"]["number"])).replace("{klant}", _esc(c.get("name"))).replace("{datum}", _esc(snap["date"])).replace("{bedrag}", _esc(_money(abs(Decimal(str(cur_total or 0))), cur))).replace("{dagen}", _esc(snap.get("payment_days") or 14)).replace("{factuur}", _esc(snap.get("ref") or "")).replace("{geldig_tot}", _esc(snap.get("valid_until") or ""))  # noqa: E731

    seller_lines = [x for x in [seller.get("name"), *(seller.get("address") or "").splitlines(), seller.get("email"), seller.get("phone"), seller.get("website")] if x]
    fin = [(t("KvK"), seller.get("kvk")), (t("Btw-nummer"), seller.get("vat_id")), (t("IBAN"), seller.get("iban")), (t("BIC"), seller.get("bic")), (t("Ten name van"), seller.get("holder")), (t("Bank"), seller.get("bank"))]
    fin = [(a, b) for a, b in fin if b]

    def table(rows, widths, align_right=()):
        tb = Table(rows, colWidths=widths, repeatRows=1)
        style = [("FONTNAME", (0, 0), (-1, -1), reg_font), ("FONTSIZE", (0, 0), (-1, -1), size - 0.5), ("TEXTCOLOR", (0, 0), (-1, -1), INK), ("VALIGN", (0, 0), (-1, -1), "MIDDLE"), ("LINEBELOW", (0, 0), (-1, -1), 0.4, LINE),
                 ("TOPPADDING", (0, 0), (-1, -1), 5), ("BOTTOMPADDING", (0, 0), (-1, -1), 5), ("LEFTPADDING", (0, 0), (-1, -1), 3), ("RIGHTPADDING", (0, 0), (-1, -1), 3),
                 ("FONTNAME", (0, 0), (-1, 0), bold_font), ("TEXTCOLOR", (0, 0), (-1, 0), MUTED), ("FONTSIZE", (0, 0), (-1, 0), size - 1.5), ("LINEBELOW", (0, 0), (-1, 0), 0.8, accent)]
        style += [("ALIGN", (i, 0), (i, -1), "RIGHT") for i in align_right]
        tb.setStyle(TableStyle(style))
        return tb

    items = snap["items"]
    name = lambda i: P(_esc(i["name"]) + (f"<br/><font color='#64748b' size='{size - 1.5:g}'>{_esc(i['sku'])}</font>" if i.get("sku") else ""), st)  # noqa: E731

    def build(bid, b, width):
        """The flowables of one block. `width` in points (a half block gets half the page)."""
        w = width
        al = {"left": 0, "center": 1, "right": 2}.get(b.get("align"), 0)
        ha = ("LEFT", "CENTER", "RIGHT")[al]
        st, small, bold, h1 = (ParagraphStyle(x.name + "a", parent=x, alignment=al) for x in (st0, small0, bold0, h10))  # (every block has its own alignment)
        P = lambda t_, style=None: Paragraph(t_, style or st)  # noqa: E731
        if bid == "logo":
            if not logo:
                return []
            from reportlab.lib.utils import ImageReader

            ir = ImageReader(io.BytesIO(logo))
            iw, ih = ir.getSize()
            lw = min(float(lay.get("logo_w") or 38) * mm, w)
            box = Table([[Image(io.BytesIO(logo), width=lw, height=lw * ih / iw)]], colWidths=[w])  # a cell: the logo left, in the middle or right
            box.setStyle(TableStyle([("ALIGN", (0, 0), (0, 0), ha if b.get("align") in ("center", "right") else (lay.get("logo_align") or "left").upper()), ("LEFTPADDING", (0, 0), (-1, -1), 0), ("RIGHTPADDING", (0, 0), (-1, -1), 0), ("TOPPADDING", (0, 0), (-1, -1), 0), ("BOTTOMPADDING", (0, 0), (-1, -1), 0)]))
            return [box]
        if bid == "company":
            return [P("<br/>".join([f"<b>{_esc(seller_lines[0])}</b>"] + [_esc(x) for x in seller_lines[1:]]) if seller_lines else "", st)]
        if bid == "title":
            return [P(_esc(b.get("text") or lay.get("title") or t(TITLES[kind])), h1)]
        if bid == "customer":
            addr = [_esc(c.get("name")), _esc(c.get("street")), _esc(f"{c.get('postal_code', '')} {c.get('city', '')}".strip()), _esc(c.get("country"))]
            return [P(t("Aan") if kind != "return" else t("Klant"), small), P("<br/>".join(x for x in addr if x) + (f"<br/>{_esc(c.get('email'))}" if c.get("email") else ""), st)]
        if bid == "meta":
            rows = [[P(t("Nummer"), small), P(_esc(snap["number"]), bold)], [P(t("Datum"), small), P(_esc(snap["date"]), st)], [P(t("Bestelling"), small), P(_esc(snap["order"]["number"]), st)]]
            if kind == "invoice":
                rows.append([P(t("Betaling"), small), P(t("Betaald") if snap.get("paid") else t("Nog te betalen"), st)])
            if kind == "quote":
                rows.append([P(t("Geldig tot"), small), P(_esc(snap.get("valid_until") or ""), st)])
            if kind == "credit" and snap.get("ref"):
                rows.append([P(t("Bij factuur"), small), P(_esc(snap["ref"]), st)])
            tb = Table(rows, colWidths=[28 * mm, max(20 * mm, w - 28 * mm)], hAlign=ha)
            tb.setStyle(TableStyle([("TOPPADDING", (0, 0), (-1, -1), 1), ("BOTTOMPADDING", (0, 0), (-1, -1), 1), ("LEFTPADDING", (0, 0), (-1, -1), 0)]))
            return [tb]
        if bid == "intro" or bid.startswith(TEXT_PREFIX):
            return [P(fill(b.get("text")), st)] if (b.get("text") or "").strip() else []
        if bid == "lines":
            if kind in ("quote", "invoice", "credit"):
                excl, vl = lay.get("vat_mode") == "excl", lay.get("vat_lines", True)
                head = [t("Omschrijving"), t("Aantal"), t("Prijs excl. btw") if excl else t("Prijs")] + ([t("Btw")] if vl else []) + [t("Totaal excl. btw") if excl else t("Totaal")]

                def money_line(i, field):
                    if not excl:
                        return _money(i[field], cur)
                    ex = Decimal(str(i["line_total"])) - Decimal(str(i.get("vat_amount") or 0))
                    return _money(ex if field == "line_total" else ex / max(1, int(i["quantity"])), cur)

                rows = [head]
                rows += [[name(i), str(i["quantity"]), money_line(i, "unit_price")] + ([f"{_pct(i['vat_rate'])}%"] if vl else []) + [money_line(i, "line_total")] for i in items]
                pad = [""] * (len(head) - 2)
                ship = Decimal(str(snap.get("shipping") or 0))
                if ship or snap.get("shipping_method"):
                    shown = ship - (Decimal(str(snap.get("shipping_vat") or 0)) if excl else 0)
                    rows.append([P(t("Verzending") + (f" ({_esc(snap['shipping_method'])})" if snap.get("shipping_method") and snap["shipping_method"] != "-" else ""), st)] + pad + [_money(shown, cur)])
                d = Decimal(str(snap.get("discount") or 0))
                if d:
                    rows.append([P(t("Korting") + (f" {_esc(snap['discount_code'])}" if snap.get("discount_code") else ""), st)] + pad + [("-" if d > 0 else "") + _money(abs(d), cur)])
                k = w / (170 * mm)
                widths = [68 * mm * k, 18 * mm * k, 30 * mm * k] + ([16 * mm * k] if vl else []) + [(38 if vl else 54) * mm * k]
                return [table(rows, widths, align_right=tuple(range(1, len(head))))]
            if kind == "packing":
                rows = [[t("Aantal"), t("Artikel"), t("Gepakt")]] + [[str(i["quantity"]), name(i), "[   ]"] for i in items]
                k = w / (170 * mm)
                return [table(rows, [22 * mm * k, 125 * mm * k, 23 * mm * k], align_right=(0,))]
            rows = [[t("Besteld"), t("Artikel"), t("Aantal retour"), t("Reden")]] + [[str(i["quantity"]), name(i), "", ""] for i in items]
            k = w / (170 * mm)
            return [table(rows, [20 * mm * k, 70 * mm * k, 28 * mm * k, 52 * mm * k], align_right=(0,))]
        if bid == "totals":
            vr, br = snap.get("vat_by_rate") or {}, snap.get("base_by_rate") or {}
            tag = lambda r: f"{t('Btw')} {_pct(r)}%"  # noqa: E731
            label = t("Totaal") if kind != "credit" else t("Totaal gecrediteerd")
            if lay.get("vat_mode") == "excl":
                ex = Decimal(str(snap["total"])) - Decimal(str(snap["vat_total"]))
                tot = [[P(t("Totaal excl. btw"), st), P(_money(ex, cur), right)]]
                tot += [[P(tag(r) + (f" <font color='#64748b'>{t('over')} {_money(br[r], cur)}</font>" if r in br else ""), small), P(_money(v, cur), right)] for r, v in vr.items()]
                tot.append([P(label + " " + t("incl. btw"), bold), P(_money(snap["total"], cur), rbold)])
            else:
                tot = [[P(label, bold), P(_money(snap["total"], cur), rbold)]]
                if lay.get("vat_totals", True):
                    tot += [[P(t("Waarvan") + " " + tag(r).lower() + (f" <font color='#64748b'>{t('over')} {_money(br[r], cur)}</font>" if r in br else ""), small), P(_money(v, cur), right)] for r, v in vr.items()]
                    if len(vr) > 1:
                        tot.append([P(t("Totaal btw"), small), P(_money(snap["vat_total"], cur), right)])
            tt = Table(tot, colWidths=[78 * mm, 35 * mm], hAlign="RIGHT")
            style = [("TOPPADDING", (0, 0), (-1, -1), 2), ("BOTTOMPADDING", (0, 0), (-1, -1), 2), ("LINEABOVE", (0, -1 if lay.get("vat_mode") == "excl" else 0), (-1, -1 if lay.get("vat_mode") == "excl" else 0), 0.8, accent)]
            tt.setStyle(TableStyle(style))
            return [tt]
        if bid == "terms":
            return [P(fill(b.get("text")), st)] if (b.get("text") or "").strip() else []
        if bid == "payment":
            out = [P(fill(b.get("text")), st)] if (b.get("text") or "").strip() and not (kind == "invoice" and snap.get("paid")) else ([P(t("Wij danken je voor je betaling."), st)] if kind == "invoice" and snap.get("paid") else [])
            if snap.get("payment_terms") and kind in ("invoice", "quote") and not (kind == "invoice" and snap.get("paid")):
                out.append(P(fill(snap["payment_terms"]), small))
            if kind == "invoice" and not snap.get("paid") and seller.get("iban"):
                out.append(P(f"{t('IBAN')} <b>{_esc(seller['iban'])}</b>" + (f" · {t('BIC')} {_esc(seller['bic'])}" if seller.get("bic") else "") + (f" · {t('ten name van')} {_esc(seller.get('holder') or seller.get('name'))}" if seller.get("holder") or seller.get("name") else ""), st))
            return out
        if bid == "finance":
            return [P(" · ".join(f"<font color='#64748b'>{_esc(a)}</font> {_esc(v)}" for a, v in fin), st)] if fin else []
        if bid == "shipping":
            rows = [[P(t("Verzending"), small), P(_esc(snap.get("shipping_method") if snap.get("shipping_method") not in (None, "", "-") else "-"), st)]]
            if snap["order"].get("note"):
                rows.append([P(t("Opmerking van de klant"), small), P(_esc(snap["order"]["note"]), st)])
            et = Table(rows, colWidths=[40 * mm, max(20 * mm, w - 40 * mm)], hAlign=ha)
            et.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "TOP"), ("LEFTPADDING", (0, 0), (0, -1), 0)]))
            return [et]
        if bid == "reasons":
            return [P(t("Reden van retour (kies één)"), bold), P("[  ] " + t("Past niet") + "&nbsp;&nbsp;[  ] " + t("Niet naar wens") + "&nbsp;&nbsp;[  ] " + t("Beschadigd of defect") + "&nbsp;&nbsp;[  ] " + t("Verkeerd artikel ontvangen") + "&nbsp;&nbsp;[  ] " + t("Anders"), st)]
        if bid == "wish":
            return [P(t("Wat wil je?"), bold), P("[  ] " + t("Terugbetaling") + "&nbsp;&nbsp;[  ] " + t("Omruilen voor ander artikel/maat") + "&nbsp;&nbsp;[  ] " + t("Tegoed"), st)]
        if bid == "remarks":
            return [P(t("Toelichting"), bold), Table([[""]], colWidths=[w], rowHeights=[22 * mm], style=[("BOX", (0, 0), (-1, -1), 0.5, LINE)])]
        if bid == "barcode":
            from reportlab.graphics.barcode import createBarcodeDrawing

            bc = (lay.get("barcodes") or {})
            cfg = bc.get(snap.get("carrier") or "") or bc.get("default") or BARCODE_DEFAULT
            value = re.sub(r"\s+", "", fill(cfg.get("content")).replace("<br/>", "").replace("&amp;", "&").replace("&lt;", "<").replace("&gt;", ">")).replace("{postcode}", re.sub(r"\s+", "", c.get("postal_code") or "")) or snap["number"]
            fmt = cfg.get("format") or "code128"
            if fmt == "code39":
                value = re.sub(r"[^A-Z0-9\-\. $/+%]", "", value.upper()) or "RETOUR"
            try:
                if fmt == "qr":
                    side = min(float(cfg.get("height") or 28) * 2.2, 80) * mm
                    d = createBarcodeDrawing("QR", value=value, width=side, height=side)
                else:
                    d = createBarcodeDrawing("Code128" if fmt == "code128" else "Standard39", value=value, barHeight=float(cfg.get("height") or 28) * mm, humanReadable=False, quiet=False)
                    sx = min(float(cfg.get("width") or 120) * mm, w) / d.width
                    d.scale(sx, 1)
                    d.width, d.height = d.width * sx, d.height
            except Exception:  # noqa: BLE001 - a value that this barcode cannot hold
                d = createBarcodeDrawing("Code128", value=re.sub(r"[^\x20-\x7e]", "", value) or "RETOUR", barHeight=28 * mm, humanReadable=False, quiet=False)
            d.hAlign = ha
            out = [P(t("Retourlabel voor de vervoerder"), small), d]
            if cfg.get("text", True):
                out.append(P(_esc(value), bold))
            return out
        if bid == "return_to":
            return [P(fill(b.get("text") or t("Stuur dit formulier mee met je pakket naar:")), bold), P("<br/>".join(_esc(x) for x in seller_lines), st),
                    Spacer(1, 2 * mm), P(t("Stuur de artikelen ongebruikt en met label terug in de originele verpakking. Zodra we het pakket hebben ontvangen en gecontroleerd, krijg je bericht en wordt het bedrag teruggestort."), small)]
        if bid == "signature":
            tb = Table([[P(t("Datum"), small), P(t("Voor akkoord (handtekening)") if kind == "quote" else t("Handtekening"), small)], ["", ""]], colWidths=[w * 0.35, w * 0.65], rowHeights=[None, 14 * mm])
            tb.setStyle(TableStyle([("LINEBELOW", (0, 1), (-1, 1), 0.5, INK), ("LEFTPADDING", (0, 0), (-1, -1), 0)]))
            return [tb]
        return []

    flow, blocks, i = [], [b for b in lay["blocks"] if b.get("on") and b["id"] != "footer" and not (b["id"] == "company" and b.get("bottom"))], 0
    total_w = 170 * mm
    while i < len(blocks):
        b = blocks[i]
        if b.get("w") == "half" and i + 1 < len(blocks) and blocks[i + 1].get("w") == "half":
            left, rgt = build(b["id"], b, total_w / 2 - 3 * mm), build(blocks[i + 1]["id"], blocks[i + 1], total_w / 2 - 3 * mm)
            pair = Table([[left or "", rgt or ""]], colWidths=[total_w / 2, total_w / 2])
            pair.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "TOP"), ("LEFTPADDING", (0, 0), (-1, -1), 0), ("RIGHTPADDING", (0, 0), (0, 0), 3 * mm), ("LEFTPADDING", (1, 0), (1, 0), 3 * mm), ("RIGHTPADDING", (1, 0), (1, 0), 0)]))
            if len(blocks[i + 1]["id"]) and blocks[i + 1]["id"] in ("company", "meta") and b["id"] in ("logo", "customer"):
                pass
            flow += [pair, Spacer(1, 5 * mm)]
            i += 2
            continue
        if b.get("w") == "half":  # a half block alone: it takes the left half
            out = build(b["id"], b, total_w / 2 - 3 * mm)
            if out:
                solo = Table([[out, ""]], colWidths=[total_w / 2, total_w / 2])
                solo.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "TOP"), ("LEFTPADDING", (0, 0), (-1, -1), 0)]))
                flow += [solo, Spacer(1, 5 * mm)]
        else:
            out = build(b["id"], b, total_w)
            if out:
                flow += [KeepTogether(out) if b["id"] in ("totals", "payment", "reasons", "wish", "signature") else out[0]] + (out[1:] if b["id"] not in ("totals", "payment", "reasons", "wish", "signature") else []) + [Spacer(1, 5 * mm)]
        i += 1

    foot = next((b for b in lay["blocks"] if b["id"] == "footer" and b.get("on")), None)

    bottom = next((b for b in lay["blocks"] if b["id"] == "company" and b.get("on") and b.get("bottom")), None)

    def on_page(canvas, doc):
        if bottom:  # the company data above the footer line
            for f in build("company", bottom, A4[0] - 40 * mm):
                _w, h = f.wrap(A4[0] - 40 * mm, 40 * mm)
                f.drawOn(canvas, 20 * mm, 21 * mm)
        if not foot:
            return
        canvas.saveState()
        canvas.setStrokeColor(LINE)
        canvas.line(20 * mm, 17 * mm, A4[0] - 20 * mm, 17 * mm)
        canvas.setFont(reg_font, size - 2)
        canvas.setFillColor(MUTED)
        auto = " · ".join(f"{a} {v}" for a, v in fin if a in (t("KvK"), t("Btw-nummer"), t("IBAN"), t("BIC")))
        lines = [x for x in [(foot.get("text") or "").replace("{nummer}", snap["number"]).strip(), auto] if x]
        for n, txt in enumerate(lines[:3]):
            canvas.drawCentredString(A4[0] / 2, 12.5 * mm - n * 3.8 * mm + (3.8 * mm if len(lines) > 1 else 0), txt[:160])
        canvas.restoreState()

    buf = io.BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=A4, leftMargin=20 * mm, rightMargin=20 * mm, topMargin=16 * mm, bottomMargin=(44 if bottom else 24) * mm, title=f"{t(TITLES[kind])} {snap['number']}", author=seller.get("name", ""))
    doc.build(flow or [Spacer(1, 1)], onFirstPage=on_page, onLaterPages=on_page)
    return buf.getvalue()
