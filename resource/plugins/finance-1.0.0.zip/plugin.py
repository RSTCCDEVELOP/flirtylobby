"""Financieel (plugin). Alles voor geld op één plek: betalen (voorwaarden en koppelingen met Stripe, Mollie), de btw-tarieven, de verzendopties en de layout van facturen, offertes, pakbonnen en retourbonnen.

De plugin is nodig voor alles waar betaald wordt: Orders, Betalen en de Webshop vragen hem (zie "requires" in plugin.json). De gegevens staan in de database van het systeem
(tabel plg_finance_settings). Andere plugins vragen om hulp via `system.provide("finance", ...)`: zie de klasse Finance onderaan.
De btw-tarieven staan in deze plugin (tabel plg_finance_vatrate); de verzendmethoden en transporteurs in de Webshop (die ze nodig heeft); deze plugin is het scherm waar je ze beheert.

Routes: /api/plugins/run/finance/<pad>. Beheer: admin/settings, admin/layout/preview, admin/media, admin/connections."""
import logging
from decimal import Decimal

from django.db import models
from django.db.models import Q
from rest_framework.response import Response

logger = logging.getLogger(__name__)

DEFAULTS = {"pay_online": True, "pay_invoice": True, "currency": "EUR", "payment_days": 14, "quote_days": 30, "payment_terms": "", "company": {}, "logo": {"mode": "theme", "data": "", "media": None}, "layouts": {}}


def register(system):
    from apps.accounts.access import level

    label = system.app_label

    def table(name, **extra):
        return type("Meta", (), {"app_label": label, "db_table": system.db_prefix + name, **extra})

    class FinanceSettings(models.Model):
        data = models.JSONField(default=dict, blank=True)
        Meta = table("settings")

    class VatRate(models.Model):
        """A VAT tariff (btw-tarief): one table for everything that has prices (orders, webshop, subscriptions, donations)."""
        key = models.SlugField(max_length=40, unique=True)
        name = models.CharField(max_length=60)
        rate = models.DecimalField(max_digits=5, decimal_places=2, default=21)
        order = models.PositiveSmallIntegerField(default=0)
        Meta = table("vatrate", ordering=["order", "id"])

    class VatConfig(models.Model):
        """Singleton (pk=1): the standard tariff, the tariff of the shipping costs and whether the prices that are entered include VAT."""
        default_key = models.CharField(max_length=40, blank=True)
        shipping_key = models.CharField(max_length=40, blank=True)
        prices_include_vat = models.BooleanField(default=True)
        Meta = table("vatconfig")

    system.sync_models(FinanceSettings, VatRate, VatConfig)

    def body(request):
        return request.data if isinstance(request.data, dict) else {}

    def bad(text, code=400):
        return Response({"detail": text}, status=code)

    def lv(request):
        return 3 if request.user.is_staff else level(request.user, "orders")

    # ── settings: what Orders kept until now is taken over once ──
    def legacy():
        from django.db import connection

        try:
            if "plg_orders_settings" not in connection.introspection.table_names():
                return {}
            with connection.cursor() as c:
                c.execute("SELECT data FROM plg_orders_settings WHERE id = 1")
                row = c.fetchone()
            import json

            data = row[0] if row else {}
            data = json.loads(data) if isinstance(data, str) else (data or {})
            return {k: data[k] for k in ("pay_online", "payment_days", "quote_days", "company", "logo", "layouts") if k in data}
        except Exception:  # noqa: BLE001
            return {}

    def settings():
        obj = FinanceSettings.objects.filter(pk=1).first()
        if obj is None:
            obj = FinanceSettings.objects.create(pk=1, data=legacy())
        d = dict(DEFAULTS)
        d.update(obj.data or {})
        d["payment_days"], d["quote_days"] = int(d.get("payment_days") or 14), int(d.get("quote_days") or 30)
        return d


    # ── btw: the tariffs of the whole system live here ──
    DEFAULT_TARIFFS = [("hoog", "Hoog tarief", "21"), ("laag", "Laag tarief", "9"), ("nul", "Geen btw", "0")]

    def vat_seed():
        """The standard tariffs (high 21%, low 9%, none) when there are none yet; the ones of an older version (system table or Orders settings) are taken over."""
        if VatRate.objects.exists():
            return
        from django.db import connection

        rows, cfg_old = [], {}
        try:
            names = connection.introspection.table_names()
            if "vat_vatrate" in names:
                with connection.cursor() as c:
                    c.execute("SELECT key, name, rate FROM vat_vatrate ORDER BY \"order\", id")
                    rows = [(k, n, str(r)) for k, n, r in c.fetchall()]
                    c.execute("SELECT default_key, shipping_key, prices_include_vat FROM vat_vatconfig WHERE id = 1")
                    one = c.fetchone()
                    cfg_old = {"default_key": one[0], "shipping_key": one[1], "prices_include_vat": bool(one[2])} if one else {}
        except Exception:  # noqa: BLE001
            rows = []
        rows = rows or DEFAULT_TARIFFS
        for n, (k, name, rate) in enumerate(rows):
            VatRate.objects.create(key=k, name=name, rate=Decimal(str(rate)), order=n)
        keys = [r[0] for r in rows]
        cfg, _ = VatConfig.objects.get_or_create(pk=1)
        cfg.default_key = cfg_old.get("default_key") if cfg_old.get("default_key") in keys else keys[0]
        cfg.shipping_key = cfg_old.get("shipping_key") if cfg_old.get("shipping_key") in keys else cfg.default_key
        cfg.prices_include_vat = cfg_old.get("prices_include_vat", True)
        cfg.save()

    def vat_tariffs():
        vat_seed()
        return [{"key": r.key, "name": r.name, "rate": format(r.rate.normalize(), "f")} for r in VatRate.objects.all()]

    def vat_settings():
        """What Orders and the Webshop read: vat_tariffs, default_tariff, shipping_tariff, default_vat, shipping_vat, vat_rates, prices_include_vat."""
        vat_seed()
        cfg, _ = VatConfig.objects.get_or_create(pk=1)
        t = vat_tariffs()
        by = {x["key"]: x for x in t}
        default = by.get(cfg.default_key) or t[0]
        ship = by.get(cfg.shipping_key) or default
        return {"vat_tariffs": t, "default_tariff": default["key"], "shipping_tariff": ship["key"], "default_vat": default["rate"], "shipping_vat": ship["rate"],
                "vat_rates": sorted({x["rate"] for x in t}, key=Decimal, reverse=True), "prices_include_vat": cfg.prices_include_vat}

    def vat_save(incoming):
        """{tariffs: [{key?, name, rate}], default: key, shipping: key, prices_include_vat: bool}. Raises ValueError with a message for the screen."""
        from django.db import transaction
        from django.utils.text import slugify

        rows, seen = [], set()
        for x in (incoming.get("tariffs") if isinstance(incoming.get("tariffs"), list) else [])[:20]:
            if not isinstance(x, dict):
                continue
            name = str(x.get("name") or "").strip()[:60]
            if not name:
                raise ValueError(system.t("Elk btw-tarief heeft een naam."))
            try:
                rate = Decimal(str(x.get("rate")).replace(",", "."))
            except Exception:  # noqa: BLE001
                raise ValueError(system.t("Ongeldig percentage bij “{0}”.", name))
            if not 0 <= rate <= 50:
                raise ValueError(system.t("Een btw-percentage ligt tussen 0 en 50."))
            key = str(x.get("key") or "") or slugify(name)[:40] or "tarief"
            base, n = key, 2
            while key in seen:
                key, n = f"{base}-{n}", n + 1
            seen.add(key)
            rows.append((key, name, rate))
        if not rows:
            raise ValueError(system.t("Minimaal één btw-tarief."))
        with transaction.atomic():
            VatRate.objects.exclude(key__in=[r[0] for r in rows]).delete()
            for n, (key, name, rate) in enumerate(rows):
                VatRate.objects.update_or_create(key=key, defaults={"name": name, "rate": rate, "order": n})
            cfg, _ = VatConfig.objects.get_or_create(pk=1)
            keys = [r[0] for r in rows]
            cfg.default_key = incoming.get("default") if incoming.get("default") in keys else (cfg.default_key if cfg.default_key in keys else keys[0])
            cfg.shipping_key = incoming.get("shipping") if incoming.get("shipping") in keys else (cfg.shipping_key if cfg.shipping_key in keys else cfg.default_key)
            if "prices_include_vat" in incoming:
                cfg.prices_include_vat = bool(incoming["prices_include_vat"])
            cfg.save()
        return vat_settings()

    @system.route("GET", "vat/rates")
    def vat_rates(request):
        """The tariffs for the pages that have a price (a choice list): every logged-in user may read them."""
        if not request.user.is_authenticated:
            return bad(system.t("Inloggen is nodig."), 401)
        s = vat_settings()
        return {"tariffs": s["vat_tariffs"], "default": s["default_tariff"], "shipping": s["shipping_tariff"], "prices_include_vat": s["prices_include_vat"]}

    @system.route("GET", "admin/vat")
    def vat_admin(request):
        if lv(request) < 1:
            return bad(system.t("Geen toegang."), 403)
        s = vat_settings()
        return {"tariffs": s["vat_tariffs"], "default": s["default_tariff"], "shipping": s["shipping_tariff"], "prices_include_vat": s["prices_include_vat"], "level": min(3, lv(request))}

    @system.route("PUT", "admin/vat")
    def vat_put(request):
        if lv(request) < 3:
            return bad(system.t("Geen toegang."), 403)
        try:
            vat_save(body(request))
        except ValueError as e:
            return bad(str(e))
        return vat_admin(request)

    def docs_module():
        import importlib.util

        spec = importlib.util.spec_from_file_location("finance_docs", system.dir / "docs.py")
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        return mod

    COMPANY_FIELDS = {"name": 80, "street": 80, "house_number": 12, "postal_code": 10, "city": 80, "email": 120, "phone": 40, "website": 120, "kvk": 30, "vat_id": 30, "iban": 40, "bic": 20, "holder": 80, "bank": 60}

    def clean_company(raw):
        """The basic data of the shop for the documents. A field that is empty takes the basic data of the website (Admin → Basisgegevens)."""
        raw = raw if isinstance(raw, dict) else {}
        return {k: str(raw.get(k) or "").strip()[:n] for k, n in COMPANY_FIELDS.items() if str(raw.get(k) or "").strip()}

    def clean_logo(raw, old):
        """The logo of the documents: the logo of the theme (standard), a picture of the media library, an own file, or none."""
        raw = raw if isinstance(raw, dict) else {}
        mode = raw.get("mode") if raw.get("mode") in ("theme", "media", "own", "none") else "theme"
        data = (old or {}).get("data", "") if "data" not in raw else str(raw.get("data") or "")
        if data:
            import base64
            import binascii

            head, _, b64 = data.partition(",")
            if not head.startswith("data:image/") or len(b64) > 700_000:
                raise ValueError(system.t("Het logo is geen geldige afbeelding of te groot (max 500 KB)."))
            try:
                base64.b64decode(b64, validate=True)
            except (binascii.Error, ValueError):
                raise ValueError(system.t("Het logo is geen geldige afbeelding."))
        media = raw.get("media") if "media" in raw else (old or {}).get("media")
        try:
            media = int(media) if media else None
        except (TypeError, ValueError):
            media = None
        if media:
            from apps.medialib.models import MediaItem

            if not MediaItem.objects.filter(pk=media, kind="image").exists():
                raise ValueError(system.t("Dat plaatje staat niet (meer) in de mediabibliotheek."))
        if mode == "own" and not data:
            mode = "theme"
        if mode == "media" and not media:
            mode = "theme"
        return {"mode": mode, "data": data, "media": media}

    def company_resolved():
        """The data of the seller on the documents: what is filled in here, else the basic data of the website."""
        from apps.core import system as core_system

        site, own = core_system.get(), settings().get("company") or {}
        pick = lambda k, *fallback: own.get(k) or next((site.get(f) for f in fallback if site.get(f)), "")  # noqa: E731
        part = {k: pick(k, k) for k in ("street", "house_number", "postal_code", "city")}  # the address is always in parts
        address = "\n".join(x for x in (" ".join(y for y in (part["street"], part["house_number"]) if y), " ".join(y for y in (part["postal_code"], part["city"]) if y)) if x)
        return {"name": pick("name", "company_name", "site_name"), "address": address, **part, "email": pick("email", "contact_email"), "phone": pick("phone", "phone"), "website": own.get("website") or site.get("frontend_url") or "",
                "kvk": pick("kvk", "kvk"), "vat_id": pick("vat_id", "vat_id"), "iban": own.get("iban", ""), "bic": own.get("bic", ""), "holder": own.get("holder", ""), "bank": own.get("bank", "")}

    def theme_logo_file():
        """The logo of the theme in use (for a light background): the file of its logo set (frontend/public/logos/<brand>/logo.png); else the logo of Logo's & beeld."""
        from pathlib import Path

        from django.conf import settings as dj

        try:
            from apps.core import themepacks

            brand = themepacks.current_values().get("brand_logo") or ""
        except Exception:  # noqa: BLE001
            brand = ""
        f = Path(dj.BASE_DIR).parent / "frontend" / "public" / "logos" / brand / "logo.png" if brand and brand.replace("_", "").isalnum() else None
        if f and f.is_file():
            return f.read_bytes(), brand
        try:
            from apps.branding.models import SiteAsset

            a = SiteAsset.objects.filter(slot="logo").first()
            if a and not str(a.image.name).lower().endswith(".svg"):
                with a.image.open("rb") as fh:
                    return fh.read(), ""
        except Exception:  # noqa: BLE001
            pass
        return None, brand

    def logo_bytes():
        """The logo for the documents as PNG bytes (an SVG cannot be drawn on a PDF), or none."""
        import base64
        import io

        cfg = settings().get("logo") or {}
        mode, raw = ("theme" if cfg.get("mode") in (None, "", "site") else cfg.get("mode")), None
        try:
            if mode == "own" and cfg.get("data"):
                raw = base64.b64decode(cfg["data"].partition(",")[2])
            elif mode == "media" and cfg.get("media"):
                from django.core.files.storage import default_storage

                from apps.medialib.models import MediaItem

                m = MediaItem.objects.filter(pk=cfg["media"], kind="image").first()
                if m and not m.encrypted and not m.key.lower().endswith(".svg"):
                    with default_storage.open(m.key, "rb") as fh:
                        raw = fh.read()
            elif mode == "theme":
                raw = theme_logo_file()[0]
            if not raw:
                return None
            from PIL import Image as PILImage

            im = PILImage.open(io.BytesIO(raw))
            im.thumbnail((900, 900))
            out = io.BytesIO()
            im.convert("RGBA").save(out, "PNG")
            return out.getvalue()
        except Exception:  # noqa: BLE001 - a logo that cannot be read must not stop a document
            logger.warning("Finance: the logo could not be read", exc_info=True)
            return None


    def save_settings(incoming):
        stored = dict(settings())
        for k in ("pay_online", "pay_invoice"):
            if k in incoming:
                stored[k] = bool(incoming[k])
        if "payment_terms" in incoming:
            stored["payment_terms"] = str(incoming["payment_terms"] or "").strip()[:1000]
        if "company" in incoming:
            stored["company"] = clean_company(incoming["company"])
        if "payment_days" in incoming:
            try:
                stored["payment_days"] = max(0, min(365, int(incoming["payment_days"])))
            except (TypeError, ValueError):
                raise ValueError(system.t("Betaaltermijn in dagen."))
        if "quote_days" in incoming:
            try:
                stored["quote_days"] = max(1, min(365, int(incoming["quote_days"])))
            except (TypeError, ValueError):
                raise ValueError(system.t("Geldigheid van een offerte in dagen."))
        if "logo" in incoming:
            stored["logo"] = clean_logo(incoming["logo"], stored.get("logo"))
        if "layouts" in incoming and isinstance(incoming["layouts"], dict):
            lay = dict(stored.get("layouts") or {})
            for k, v in incoming["layouts"].items():
                if k in docs_module().KINDS:
                    if v is None:
                        lay.pop(k, None)  # back to the standard
                    else:
                        lay[k] = docs_module().clean_layout(k, v)
            stored["layouts"] = lay
        obj, _ = FinanceSettings.objects.get_or_create(pk=1)
        obj.data = stored
        obj.save()
        return settings()

    def connections():
        """The links with payment services (Admin → API keys): which are set up and on."""
        from apps.integrations.models import Integration

        names = {"stripe": "Stripe", "mollie": "Mollie"}
        have = {i.provider: i for i in Integration.objects.filter(provider__in=list(names))}
        return [{"provider": k, "label": v, "linked": k in have, "enabled": bool(k in have and have[k].enabled)} for k, v in names.items()]

    def catalog_carriers():
        try:
            from apps.commerce import catalog

            return catalog.carriers()
        except Exception:  # noqa: BLE001
            return []

    def layout_info():
        """For the editor: the blocks there are, the standard and the layout in use per document, what the website gives as standard."""
        dm = docs_module()
        stored = settings().get("layouts") or {}
        from apps.core import system as core_system

        site = core_system.get()
        theme_file, brand = theme_logo_file()
        pick = None
        lg = settings().get("logo") or {}
        if lg.get("media"):
            from django.core.files.storage import default_storage

            from apps.medialib.models import MediaItem

            m = MediaItem.objects.filter(pk=lg["media"]).first()
            pick = {"id": m.id, "name": m.name, "url": default_storage.url(m.key)} if m else None
        return {"doc_kinds": [{"kind": k, "label": dm.TITLES[k]} for k in dm.KINDS],
                "blocks": {k: {"label": v[0], "kinds": list(v[1]), "text": v[2]} for k, v in dm.BLOCKS.items()},
                "layouts_in_use": {k: dm.merged(k, stored.get(k)) for k in dm.KINDS}, "layout_defaults": {k: dm.default_layout(k) for k in dm.KINDS}, "layout_custom": {k: k in stored for k in dm.KINDS},
                "company_site": {"name": site.get("company_name") or site.get("site_name") or "", "street": site.get("street") or "", "house_number": site.get("house_number") or "", "postal_code": site.get("postal_code") or "", "city": site.get("city") or "", "email": site.get("contact_email") or "", "phone": site.get("phone") or "", "kvk": site.get("kvk") or "", "vat_id": site.get("vat_id") or "", "website": site.get("frontend_url") or ""},
                "carriers": catalog_carriers(), "theme_logo": bool(theme_file), "theme_logo_path": f"/logos/{brand}/logo.png" if brand and theme_file else "", "logo_media": pick}

    @system.route("GET", "admin/media")
    def media_pick(request):
        """The pictures of the media library to choose a logo from (no svg: it cannot be drawn on a pdf)."""
        if lv(request) < 2:
            return bad(system.t("Geen toegang."), 403)
        from django.core.files.storage import default_storage

        from apps.medialib.models import MediaItem

        qs = MediaItem.objects.filter(kind="image", encrypted=False).exclude(key__iendswith=".svg")
        if q := request.query_params.get("q"):
            qs = qs.filter(Q(name__icontains=q) | Q(tags__icontains=q))
        out = []
        for m in qs[:60]:
            u = default_storage.url(m.key)
            out.append({"id": m.id, "name": m.name, "url": request.build_absolute_uri(u) if str(u).startswith("/") else u})
        return out

    @system.route("POST", "admin/layout/preview")
    def layout_preview(request):
        """A sample PDF of the layout as it is on the screen (not saved yet): the answer is a short-lived link."""
        if lv(request) < 1:
            return bad(system.t("Geen toegang."), 403)
        from django.core import signing

        b = body(request)
        dm = docs_module()
        if b.get("kind") not in dm.KINDS:
            return bad(system.t("Onbekend document."))
        lay = dm.clean_layout(b["kind"], b.get("layout"))
        return {"path": "/api/plugins/run/finance/preview/" + signing.dumps({"k": b["kind"], "l": lay}, salt="finance-preview", compress=True)}

    @system.route("GET", "preview/<token>", public=True)
    def layout_preview_pdf(request, token):
        from django.core import signing
        from django.http import HttpResponse

        try:
            p = signing.loads(token, salt="finance-preview", max_age=600)
        except signing.BadSignature:
            return HttpResponse(status=404)
        dm = docs_module()
        try:
            pdf = dm.render(dm.sample(p["k"], company_resolved()), system.t, dm.clean_layout(p["k"], p["l"]), logo_bytes())
        except Exception:  # noqa: BLE001
            logger.exception("Finance: the sample could not be made")
            return HttpResponse(system.t("Het voorbeeld kon niet worden gemaakt."), status=500)
        r = HttpResponse(pdf, content_type="application/pdf")
        r["Content-Disposition"] = 'inline; filename="voorbeeld.pdf"'
        r["Cache-Control"] = "private, no-store"
        return r


    @system.route("GET", "admin/settings")
    def settings_get(request):
        if lv(request) < 1:
            return bad(system.t("Geen toegang."), 403)
        return {**settings(), "level": min(3, max(0, lv(request))), "connections": connections(), "vat": vat_settings(), **layout_info()}

    @system.route("PUT", "admin/settings")
    def settings_put(request):
        if lv(request) < 2:
            return bad(system.t("Geen toegang."), 403)
        try:
            save_settings(body(request))
        except (ValueError, ArithmeticError) as e:
            return bad(str(e))
        return settings_get(request)

    # ── what the other plugins may ask ──
    class Finance:
        @staticmethod
        def settings():
            return settings()

        @staticmethod
        def save_settings(incoming):
            return save_settings(incoming)

        @staticmethod
        def vat():
            return vat_settings()

        @staticmethod
        def vat_default_key():
            return vat_settings()["default_tariff"]

        @staticmethod
        def company():
            return company_resolved()

        @staticmethod
        def logo():
            return logo_bytes()

        @staticmethod
        def document_layout(kind):
            dm = docs_module()
            return dm.merged(kind, (settings().get("layouts") or {}).get(kind))

        @staticmethod
        def render(snap, translate=None):
            """The PDF (bytes) of a document from its snapshot, in the layout of the settings."""
            dm = docs_module()
            return dm.render(snap, translate or system.t, dm.merged(snap["kind"], (settings().get("layouts") or {}).get(snap["kind"])), logo_bytes())

        @staticmethod
        def kinds():
            return list(docs_module().KINDS)

    system.provide("finance", Finance())

    # ── betalen: online betalen via Stripe of Mollie (in de sandbox gesimuleerd), vroeger de plugin Betalen ──
    from apps.sandbox import service as sandbox
    from apps.sandbox.models import SandboxPayment

    def provider_name():
        """The payment link that is used: the choice in the settings (Betaalmethode), else Stripe when linked, else Mollie."""
        chosen = str(system.config.get("provider") or "auto")
        return chosen if chosen in ("stripe", "mollie") else sandbox.payment_provider()

    class Payments:
        @staticmethod
        def available():
            """True when a payment can be made now (the sandbox simulates it until a real provider is linked)."""
            return bool(sandbox.active("payments")) and bool(settings().get("pay_online", True))

        @staticmethod
        def provider():
            return provider_name()

        @staticmethod
        def create(amount, currency="EUR", description="", return_url=""):
            return sandbox.create_payment(amount, currency, description, provider_name(), return_url)

        @staticmethod
        def settle(payment, return_url=""):
            """With 'betalingen meteen als betaald afronden' (sandbox) the payment is finished at once: returns the address to go to, or ''."""
            return sandbox.settle(payment, return_url)

        @staticmethod
        def checkout_path(payment):
            return f"/sandbox/checkout/{payment.ref}"

        @classmethod
        def pay_order(cls, order, return_url="", fallback_url=""):
            """Start the payment of an order and link it: returns the address where the customer pays (or comes back when it is paid at once)."""
            payment = cls.create(order.total, order.currency, f"Bestelling {order.number}", return_url)
            order.status, order.payment_ref = "pending_payment", payment.ref
            order.save(update_fields=["status", "payment_ref"])
            done = cls.settle(payment, return_url or fallback_url)
            return done or cls.checkout_path(payment)

    system.provide("payments", Payments())

    @system.route("GET", "admin/payments")
    def admin_payments(request):
        if lv(request) < 1:
            return bad(system.t("Geen toegang."), 403)
        return {"provider": provider_name(), "available": Payments.available(), "payments": [
            {"ref": p.ref, "provider": p.provider, "amount": str(p.amount), "currency": p.currency, "description": p.description, "status": p.status, "created_at": p.created_at}
            for p in SandboxPayment.objects.all()[:200]]}
