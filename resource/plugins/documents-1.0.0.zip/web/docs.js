"use strict";
/* Documentbeheer: het programma van de hoofdpagina en de beheerpagina. Teksten gaan door t("…") zodat elke taal ze krijgt. */
var ROUTE = "/plugins/run/documents/";
var t = function () { return system.t.apply(system, arguments); };
var LEVEL = { 1: "Bekijken", 2: "Bewerken", 3: "Beheren" };
/* teksten die via een variabele worden getoond, hier opgesomd zodat elke taal ze krijgt:
   t("Bekijken") t("Bewerken") t("Beheren") t("Alle gebruikers") t("Naam") t("Nieuwste eerst") t("Grootte") */
var app = document.getElementById("app");
var S = { mode: "main", folder: null, q: "", tag: null, sort: "name", cfg: null, data: null, busy: false, msg: null, apiBase: "" };

function h(tag, props) {
  var el = document.createElement(tag), kids = Array.prototype.slice.call(arguments, 2);
  Object.keys(props || {}).forEach(function (k) {
    var v = props[k];
    if (k === "class") el.className = v; else if (k.indexOf("on") === 0) el.addEventListener(k.slice(2), v);
    else if (k === "style") el.style.cssText = v; else if (k === "value") el.value = v; else if (v === true) el.setAttribute(k, ""); else if (v !== false && v != null) el.setAttribute(k, v);
  });
  (function add(list) { list.forEach(function (c) { if (Array.isArray(c)) add(c); else if (c != null && c !== false) el.appendChild(typeof c === "object" ? c : document.createTextNode(String(c))); }); })(kids);
  return el;
}
var call = function (path, method, body) { return system.api(ROUTE + path, { method: method || "GET", body: body }); };
var lang = function () { return document.documentElement.lang || "nl"; };
function size(n) { n = Number(n) || 0; return n < 1024 ? n + " B" : n < 1048576 ? (n / 1024).toFixed(n < 10240 ? 1 : 0) + " KB" : n < 1073741824 ? (n / 1048576).toFixed(1) + " MB" : (n / 1073741824).toFixed(1) + " GB"; }
function when(iso) { return new Date(iso).toLocaleDateString(lang(), { day: "numeric", month: "short", year: "numeric" }); }
function ext(name) { var m = /\.([A-Za-z0-9]{1,5})$/.exec(name || ""); return m ? m[1].toUpperCase() : "BEST"; }
function fail(e) { S.msg = { ok: false, text: e && e.message ? e.message : String(e) }; draw(); }
function modal(content, wide) {
  var ov = h("div", { class: "overlay", onclick: function (ev) { if (ev.target === ov) close(); } }, h("div", { class: "modal" + (wide ? " wide" : "") }, content));
  function close() { ov.remove(); }
  document.body.appendChild(ov);
  return close;
}
function tagChip(tg, onclick, on) { return h("span", { class: "tag c-" + tg.color + (onclick ? " pick" : "") + (on ? " on" : ""), onclick: onclick || null }, tg.name, tg.count != null && onclick ? h("small", { style: "opacity:.7" }, tg.count) : null); }

// ── loading ──
function load() {
  var q = "browse?sort=" + S.sort + (S.folder ? "&folder=" + S.folder : "") + (S.q ? "&q=" + encodeURIComponent(S.q) : "") + (S.tag ? "&tag=" + S.tag : "");
  var go = function () { return Promise.all([call(q), call("config")]); };
  return go().catch(function () { return new Promise(function (ok) { setTimeout(ok, 800); }).then(go); }).then(function (r) { S.data = r[0]; S.cfg = r[1]; draw(); }).catch(function (e) {  // once more: a plugin that has just been switched on is ready a moment later
    if (S.folder) { S.folder = null; return load(); }
    fail(e);
  });
}

// ── actions ──
function download(d) {
  call("documents/" + d.id + "/link").then(function (r) {
    var a = h("a", { href: S.apiBase + r.path, download: d.filename, target: "_blank", rel: "noopener" });
    document.body.appendChild(a); a.click(); a.remove();
  }).catch(fail);
}
function newFolder() {
  var name = h("input", { maxlength: "120", placeholder: t("Naam van de map"), autofocus: true });
  var err = h("div", { class: "alert", style: "display:none" });
  var close = modal([h("h2", {}, t("Nieuwe map")), h("label", {}, t("Naam"), name), err, h("div", { class: "row", style: "justify-content:flex-end" },
    h("button", { onclick: function () { close(); } }, t("Annuleren")),
    h("button", { class: "primary", onclick: function () {
      call("folders", "POST", { name: name.value, parent: S.folder }).then(function () { close(); load(); }).catch(function (e) { err.textContent = e.message; err.style.display = ""; });
    } }, t("Maken")))]);
  setTimeout(function () { name.focus(); }, 30);
}
function renameFolder(f) {
  var name = h("input", { maxlength: "120", value: f.name });
  var err = h("div", { class: "alert", style: "display:none" });
  var close = modal([h("h2", {}, t("Map hernoemen")), h("label", {}, t("Naam"), name), err, h("div", { class: "row", style: "justify-content:flex-end" },
    h("button", { onclick: function () { close(); } }, t("Annuleren")),
    h("button", { class: "primary", onclick: function () {
      call("folders/" + f.id, "PATCH", { name: name.value }).then(function () { close(); load(); }).catch(function (e) { err.textContent = e.message; err.style.display = ""; });
    } }, t("Opslaan")))]);
}
function deleteFolder(f) {
  var all = f.documents || f.folders;
  system.confirm(all ? t("De map “{0}” en alles wat erin zit verwijderen?", f.name) : t("De map “{0}” verwijderen?", f.name), { danger: true, okLabel: t("Verwijderen") }).then(function (ok) {
    if (ok) call("folders/" + f.id + (all ? "?all=1" : ""), "DELETE").then(load).catch(fail);
  });
}
function deleteDoc(d) {
  system.confirm(t("Het document “{0}” verwijderen?", d.title), { danger: true, okLabel: t("Verwijderen") }).then(function (ok) {
    if (ok) call("documents/" + d.id, "DELETE").then(load).catch(fail);
  });
}

// tags as a field: chips of the chosen tags and a box to add one (with the existing tags as a suggestion)
function tagField(chosen) {
  var box = h("div", { class: "tags" }), input = h("input", { placeholder: t("Tag toevoegen en Enter"), list: "taglist" });
  var list = h("datalist", { id: "taglist" }, (S.cfg.tags || []).map(function (x) { return h("option", { value: x.name }); }));
  function paint() {
    box.innerHTML = "";
    chosen.forEach(function (n, i) {
      var known = (S.cfg.tags || []).filter(function (x) { return x.name.toLowerCase() === n.toLowerCase(); })[0];
      box.appendChild(h("span", { class: "tag c-" + (known ? known.color : "blue") }, n, h("span", { style: "cursor:pointer;margin-left:.2rem", onclick: function () { chosen.splice(i, 1); paint(); } }, "×")));
    });
  }
  function add() {
    var v = input.value.replace(/,/g, "").trim();
    if (v && !chosen.some(function (n) { return n.toLowerCase() === v.toLowerCase(); })) chosen.push(v);
    input.value = ""; paint();
  }
  input.addEventListener("keydown", function (e) { if (e.key === "Enter" || e.key === ",") { e.preventDefault(); add(); } });
  input.addEventListener("change", add);
  paint();
  return { el: h("div", { class: "stack", style: "gap:.4rem" }, box, input, list), flush: add };
}

function editDoc(d) {
  var title = h("input", { value: d.title, maxlength: "200" }), fname = h("input", { value: d.filename, maxlength: "120" }), ver = h("input", { value: d.version, maxlength: "20" }), desc = h("textarea", { rows: "3" }, d.description || "");
  var chosen = d.tags.map(function (x) { return x.name; }), tf = tagField(chosen);
  var where = h("select", {}, h("option", { value: "" }, t("(hoofdmap)")));
  call("folders").then(function (r) { r.folders.forEach(function (f) { where.appendChild(h("option", { value: f.id, selected: d.folder === f.id }, f.path)); }); });
  var err = h("div", { class: "alert", style: "display:none" });
  var close = modal([h("h2", {}, t("Document bewerken")), h("label", {}, t("Titel"), title), h("label", {}, t("Bestandsnaam"), fname), h("label", {}, t("Versienummer"), ver), h("label", {}, t("Omschrijving"), desc),
    h("label", {}, t("Map"), where), h("label", {}, t("Tags"), tf.el), err,
    h("div", { class: "row", style: "justify-content:flex-end" }, h("button", { onclick: function () { close(); } }, t("Annuleren")),
      h("button", { class: "primary", onclick: function () {
        tf.flush();
        call("documents/" + d.id, "PATCH", { title: title.value, filename: fname.value, version: ver.value, description: desc.value, folder: where.value ? Number(where.value) : null, tags: chosen })
          .then(function () { close(); load(); }).catch(function (e) { err.textContent = e.message; err.style.display = ""; });
      } }, t("Opslaan")))]);
}

// rights per user or group (for a document or a folder)
function share(kind, obj, name) {
  var entries = [], inherited = [], owner = "", list = h("div", { class: "stack", style: "gap:.4rem" }), sug = h("div", {}), q = h("input", { placeholder: t("Zoek een gebruiker of groep…") });
  var err = h("div", { class: "alert", style: "display:none" });
  function paint() {
    list.innerHTML = "";
    inherited.forEach(function (e) { list.appendChild(h("div", { class: "entry" }, h("span", { class: "grow" }, e.name, h("small", { class: "muted" }, " · " + t("via map {0}", e.from_folder))), h("span", { class: "pill" }, t(LEVEL[e.level])))); });
    entries.forEach(function (e, i) {
      var sel = h("select", { onchange: function () { e.level = Number(sel.value); } }, [1, 2, 3].map(function (n) { return h("option", { value: n, selected: e.level === n }, t(LEVEL[n])); }));
      list.appendChild(h("div", { class: "entry" }, h("span", { class: "grow" }, (e.type === "group" ? "👥 " : e.type === "everyone" ? "🌐 " : e.type === "public" ? "🌍 " : "👤 ") + e.name, e.email ? h("small", { class: "muted" }, " · " + e.email) : null), e.type === "public" ? h("span", { class: "pill" }, t("Bekijken")) : sel,
        h("button", { class: "sm danger", onclick: function () { entries.splice(i, 1); paint(); } }, "×")));
    });
    if (!entries.length && !inherited.length) list.appendChild(h("p", { class: "muted", style: "margin:0" }, t("Alleen jij (en de beheerders) hebben toegang.")));
  }
  function has(type, id) { return entries.some(function (e) { return e.type === type && e.id === id; }); }
  function add(e) { if (!has(e.type, e.id)) entries.push(Object.assign({ level: 1 }, e)); sug.innerHTML = ""; q.value = ""; paint(); }
  var timer = null;
  q.addEventListener("input", function () {
    clearTimeout(timer);
    timer = setTimeout(function () {
      call("principals?q=" + encodeURIComponent(q.value)).then(function (r) {
        sug.innerHTML = "";
        var rows = [{ type: "everyone", id: 0, name: t("Alle gebruikers") }, { type: "public", id: 0, name: t("Iedereen, ook bezoekers") }].filter(function (x) { return !q.value || x.name.toLowerCase().indexOf(q.value.toLowerCase()) >= 0; })
          .concat(r.groups.map(function (g) { return { type: "group", id: g.id, name: g.name }; })).concat(r.users.map(function (u) { return { type: "user", id: u.id, name: u.name || u.email, email: u.email }; }));
        if (rows.length) sug.appendChild(h("div", { class: "suggest" }, rows.map(function (e) { return h("button", { onclick: function () { add(e); } }, (e.type === "group" ? "👥 " : e.type === "everyone" ? "🌐 " : e.type === "public" ? "🌍 " : "👤 ") + e.name, h("small", { class: "muted" }, e.email || (e.type === "group" ? t("groep") : ""))); })));
      }).catch(function () {});
    }, 200);
  });
  var close = modal([h("h2", {}, t("Delen: {0}", name)), h("p", { class: "muted", style: "margin:0" }, kind === "folder" ? t("Wat je hier instelt, geldt ook voor alles in de map.") : t("Kies wie dit document mag bekijken, bewerken of beheren.")),
    list, h("label", {}, t("Toevoegen"), q), sug, err,
    h("div", { class: "row", style: "justify-content:flex-end" }, h("button", { onclick: function () { close(); } }, t("Annuleren")),
      h("button", { class: "primary", onclick: function () {
        call((kind === "folder" ? "folders/" : "documents/") + obj.id + "/access", "PUT", { entries: entries.map(function (e) { return { type: e.type, id: e.id, level: e.level }; }) })
          .then(function () { close(); load(); }).catch(function (e) { err.textContent = e.message; err.style.display = ""; });
      } }, t("Opslaan")))], true);
  call((kind === "folder" ? "folders/" : "documents/") + obj.id + "/access").then(function (r) { entries = r.entries; inherited = r.inherited || []; owner = r.owner; paint(); }).catch(function (e) { err.textContent = e.message; err.style.display = ""; });
  paint();
}

// uploading: one or more files, with tags
function pickFiles(files) {
  files = Array.prototype.slice.call(files);
  if (!files.length) return;
  var chosen = [], tf = tagField(chosen), rows = files.map(function (f) { return { f: f, el: h("div", {}, h("span", {}, f.name), h("span", { class: "muted" }, size(f.size))) }; });
  var go = h("button", { class: "primary" }, t("Uploaden")), cancel = h("button", {}, t("Annuleren"));
  var close = modal([h("h2", {}, t("Documenten uploaden")), h("div", { class: "files" }, rows.map(function (r) { return r.el; })), h("label", {}, t("Tags voor deze documenten"), tf.el),
    h("div", { class: "row", style: "justify-content:flex-end" }, cancel, go)]);
  cancel.addEventListener("click", function () { close(); });
  go.addEventListener("click", function () {
    tf.flush(); go.disabled = true; cancel.disabled = true;
    var i = 0, bad = 0;
    (function next() {
      if (i >= rows.length) { if (!bad) close(); else { cancel.disabled = false; cancel.textContent = t("Sluiten"); } load(); return; }
      var r = rows[i++];
      r.el.lastChild.textContent = "…";
      system.upload(ROUTE + "upload", r.f, { folder: S.folder || "", tags: chosen.join(",") }).then(function (res) { r.el.lastChild.textContent = res && res.new_version ? "✓ " + t("versie {0}", res.version) : "✓"; r.el.className = "ok"; next(); })
        .catch(function (e) { bad++; r.el.lastChild.textContent = e.message; r.el.className = "no"; next(); });
    })();
  });
}

// ── drawing ──
function icon(f) { return h("div", { class: "badge" }, ext(f.filename)); }
function drawFolders(list) {
  if (!list.length) return null;
  return h("div", { class: "folders" }, list.map(function (f) {
    var acts = h("div", { class: "acts", onclick: function (e) { e.stopPropagation(); } });
    if (f.level >= 3) acts.append(h("button", { class: "sm ghost", title: t("Delen"), onclick: function () { share("folder", f, f.name); } }, "👥"), h("button", { class: "sm ghost", title: t("Hernoemen"), onclick: function () { renameFolder(f); } }, "✎"),
      h("button", { class: "sm ghost danger", title: t("Verwijderen"), onclick: function () { deleteFolder(f); } }, "🗑"));
    return h("div", { class: "folder", tabindex: "0", onclick: function () { S.folder = f.id; load(); }, onkeydown: function (e) { if (e.key === "Enter") { S.folder = f.id; load(); } } }, h("span", { class: "ico" }, f.shared ? "📂" : "📁"),
      h("div", { class: "grow" }, h("div", { class: "name" }, f.name), h("small", { class: "muted" }, f.documents + " " + t("documenten") + (f.folders ? " · " + f.folders + " " + t("mappen") : ""))), acts);
  }));
}
function drawDocs(list) {
  if (!list.length) return h("div", { class: "empty card" }, S.data.searching ? t("Niets gevonden.") : t("Hier staan nog geen documenten."), S.cfg.me.can_upload && !S.data.searching ? h("div", { style: "margin-top:.6rem" }, t("Sleep bestanden hierheen of kies Uploaden.")) : null);
  return h("div", { class: "card", style: "padding:.2rem .4rem" }, h("table", { class: "docs" },
    h("thead", {}, h("tr", {}, h("th", {}, t("Document")), h("th", {}, t("Tags")), h("th", {}, t("Grootte")), h("th", {}, t("Bijgewerkt")), h("th", {}))),
    h("tbody", {}, list.map(function (d) {
      return h("tr", {},
        h("td", {}, h("div", { class: "file" }, icon(d), h("div", { style: "min-width:0" }, h("div", { class: "t", title: d.title }, d.title, " ", h("span", { class: "pill", title: t("Versie") }, "v" + d.version)), h("div", { class: "fn", title: d.filename }, d.filename)))),
        h("td", {}, h("div", { class: "tags" }, d.tags.map(function (x) { return tagChip(x); }), d.encrypted ? h("span", { class: "pill", title: t("Versleuteld") }, "🔒") : null, d.shared ? h("span", { class: "pill", title: t("Gedeeld") }, "👥") : null, d.storage === "s3" ? h("span", { class: "pill" }, "S3") : null)),
        h("td", { class: "muted" }, size(d.size)), h("td", { class: "muted" }, when(d.updated_at), h("small", { style: "display:block" }, d.owner)),
        h("td", {}, h("div", { class: "acts" }, h("button", { class: "sm", onclick: function () { download(d); } }, "⬇ " + t("Downloaden")),
          d.level >= 2 || d.versions ? h("button", { class: "sm", title: t("Versies"), onclick: function () { versions(d); } }, "🕘" + (d.versions ? " " + d.versions : "")) : null,
          d.level >= 2 ? h("button", { class: "sm", title: t("Bewerken"), onclick: function () { editDoc(d); } }, "✎") : null,
          d.level >= 3 ? h("button", { class: "sm", title: t("Delen"), onclick: function () { share("document", d, d.title); } }, "👥") : null,
          d.level >= 3 ? h("button", { class: "sm danger", title: t("Verwijderen"), onclick: function () { deleteDoc(d); } }, "🗑") : null)));
    }))));
}
function draw() {
  var d = S.data, c = S.cfg;
  if (!d || !c) { app.innerHTML = ""; app.appendChild(S.msg ? h("div", { class: "alert" }, S.msg.text) : h("p", { class: "muted" }, t("Laden…"))); return; }
  var focus = document.activeElement && document.activeElement.id === "q" ? document.activeElement.selectionStart : null;
  var search = h("input", { id: "q", type: "search", placeholder: t("Zoek op naam, omschrijving of tag…"), value: S.q });
  var timer = null;
  search.addEventListener("input", function () { clearTimeout(timer); timer = setTimeout(function () { S.q = search.value.trim(); load(); }, 250); });
  var sort = h("select", { onchange: function () { S.sort = sort.value; load(); }, style: "width:auto" }, [["name", "Naam"], ["new", "Nieuwste eerst"], ["size", "Grootte"]].map(function (o) { return h("option", { value: o[0], selected: S.sort === o[0] }, t(o[1])); }));
  var file = h("input", { type: "file", multiple: true, style: "display:none", onchange: function () { pickFiles(file.files); file.value = ""; } });
  var top = h("div", { class: "hero" }, h("h1", {}, S.mode === "admin" ? t("Documentbeheer") : t("Documenten")), h("div", { class: "row" },
    S.cfg.me.can_upload ? h("button", { onclick: newFolder }, "📁 " + t("Nieuwe map")) : null, S.cfg.me.can_upload ? h("button", { class: "primary", onclick: function () { file.click(); } }, "⬆ " + t("Uploaden")) : null, file));
  var crumbs = h("div", { class: "crumbs" }, h("button", { onclick: function () { S.folder = null; S.q = ""; S.tag = null; load(); } }, "🏠 " + t("Documenten")),
    d.crumbs.map(function (x) { return [h("span", { class: "sep" }, "/"), h("button", { onclick: function () { S.folder = x.id; load(); } }, x.name)]; }));
  var tagbar = (c.tags || []).length ? h("div", { class: "tags", style: "margin-bottom:.8rem" }, c.tags.map(function (x) { return tagChip(x, function () { S.tag = S.tag === x.id ? null : x.id; load(); }, S.tag === x.id); })) : null;
  var drop = c.me.can_upload ? h("div", { class: "drop" }, "⬆ " + t("Sleep bestanden hierheen om te uploaden")) : null;
  if (drop) {
    ["dragenter", "dragover"].forEach(function (ev) { drop.addEventListener(ev, function (e) { e.preventDefault(); drop.classList.add("over"); }); });
    ["dragleave", "drop"].forEach(function (ev) { drop.addEventListener(ev, function (e) { e.preventDefault(); drop.classList.remove("over"); }); });
    drop.addEventListener("drop", function (e) { if (e.dataTransfer && e.dataTransfer.files.length) pickFiles(e.dataTransfer.files); });
  }
  app.innerHTML = "";
  app.append(top, S.mode === "admin" ? adminBox() : null, S.msg ? h("div", { class: S.msg.ok ? "alert ok" : "alert", style: "margin-bottom:.6rem" }, S.msg.text) : null,
    h("div", { class: "bar" }, search, sort, h("span", { class: "muted" }, d.documents.length + " " + t("documenten"))), tagbar, d.searching ? null : crumbs, drop, drawFolders(d.folders), drawDocs(d.documents));
  if (focus !== null) { search.focus(); try { search.setSelectionRange(focus, focus); } catch (e) {} }
}

// ── admin: overview, apply settings, tags ──
var OV = null;
function adminBox() {
  if (!OV) { call("admin/overview").then(function (r) { OV = r; draw(); }).catch(fail); return null; }
  var stat = function (n, l) { return h("div", { class: "stat" }, h("strong", {}, n), h("span", {}, l)); };
  var tags = h("div", { class: "tags" }, (S.cfg.tags || []).map(function (x) {
    return h("span", { class: "tag c-" + x.color }, x.name + " (" + x.count + ")", h("span", { style: "cursor:pointer;margin-left:.3rem", title: t("Bewerken"), onclick: function () { editTag(x); } }, "✎"));
  }));
  var apply = h("button", { onclick: function () {
    system.confirm(t("Alle bestaande documenten verplaatsen en (de)crypteren volgens de instellingen?"), { okLabel: t("Toepassen") }).then(function (ok) {
      if (!ok) return;
      call("admin/apply", "POST").then(function (r) { S.msg = { ok: !r.failed.length, text: t("{0} documenten aangepast.", r.changed) + (r.failed.length ? " " + t("{0} mislukt: {1}", r.failed.length, r.failed[0].title) : "") }; OV = null; load(); }).catch(fail);
    });
  } }, t("Instellingen toepassen op bestaande documenten"));
  return h("div", { class: "stack", style: "margin-bottom:1rem" }, h("div", { class: "stats" }, stat(OV.documents, t("documenten")), stat(size(OV.size), t("opslag")), stat(OV.folders, t("mappen")), stat(OV.tags, t("tags")),
    stat(OV.s3 + " / " + OV.local, t("S3 / server")), stat(OV.encrypted, t("versleuteld"))),
    h("div", { class: "card stack", style: "gap:.5rem" }, h("h3", { style: "margin:0" }, t("Opslag en versleuteling")),
      h("p", { class: "muted", style: "margin:0" }, (OV.target === "s3" ? t("Nieuwe documenten gaan naar S3, in dezelfde mappen.") : OV.s3_available ? t("S3 is gekoppeld, maar de opslag staat op de server.") : t("S3 is niet gekoppeld: de documenten staan op de server.")) + " " + (OV.encrypt ? t("Nieuwe documenten worden versleuteld.") : t("Nieuwe documenten worden niet versleuteld."))),
      h("div", { class: "row" }, apply)),
    h("div", { class: "card stack", style: "gap:.5rem" }, h("h3", { style: "margin:0" }, t("Tags")), tags.childNodes.length ? tags : h("p", { class: "muted", style: "margin:0" }, t("Er zijn nog geen tags. Ze ontstaan bij het uploaden.")), h("p", { class: "muted", style: "margin:0" }, t("Rechten stel je per map of document in met de knop Delen."))));
}
function editTag(x) {
  var name = h("input", { value: x.name, maxlength: "40" }), colors = ["blue", "orange", "green", "pink", "purple", "teal", "red", "gray"], color = x.color;
  var box = h("div", { class: "tags" });
  function paint() { box.innerHTML = ""; colors.forEach(function (cc) { box.appendChild(h("span", { class: "tag pick c-" + cc + (cc === color ? " on" : ""), onclick: function () { color = cc; paint(); } }, cc)); }); }
  paint();
  var err = h("div", { class: "alert", style: "display:none" });
  var close = modal([h("h2", {}, t("Tag bewerken")), h("label", {}, t("Naam"), name), h("label", {}, t("Kleur"), box), err, h("div", { class: "row between" },
    h("button", { class: "danger", onclick: function () { system.confirm(t("De tag “{0}” verwijderen? De documenten blijven staan.", x.name), { danger: true, okLabel: t("Verwijderen") }).then(function (ok) { if (ok) call("tags/" + x.id, "DELETE").then(function () { close(); OV = null; load(); }).catch(fail); }); } }, t("Verwijderen")),
    h("div", { class: "row" }, h("button", { onclick: function () { close(); } }, t("Annuleren")), h("button", { class: "primary", onclick: function () {
      call("tags/" + x.id, "PATCH", { name: name.value, color: color }).then(function () { close(); load(); }).catch(function (e) { err.textContent = e.message; err.style.display = ""; });
    } }, t("Opslaan"))))]);
}

// the versions of a document: upload a new one, download or restore an old one
function versions(d) {
  var list = h("div", { class: "stack", style: "gap:.4rem" }), err = h("div", { class: "alert", style: "display:none" }), lv = d.level;
  var num = h("input", { placeholder: t("automatisch"), maxlength: "20", style: "width:9rem" }), note = h("input", { placeholder: t("Opmerking (optioneel)"), maxlength: "200" });
  var file = h("input", { type: "file", style: "display:none" });
  function show(e) { err.textContent = e.message || String(e); err.style.display = ""; }
  function paint(rows) {
    list.innerHTML = "";
    rows.forEach(function (v) {
      list.appendChild(h("div", { class: "entry" }, h("span", { class: "pill" }, "v" + v.number), h("span", { class: "grow" }, v.filename, h("small", { class: "muted", style: "display:block" }, when(v.created_at) + (v.by ? " · " + v.by : "") + " · " + size(v.size) + (v.note ? " · " + v.note : ""))),
        v.current ? h("span", { class: "tag c-green" }, t("Huidig")) : null,
        h("button", { class: "sm", onclick: function () {
          call("documents/" + d.id + (v.current ? "" : "/versions/" + v.id) + "/link").then(function (r) { var a = h("a", { href: S.apiBase + r.path, download: v.filename, target: "_blank", rel: "noopener" }); document.body.appendChild(a); a.click(); a.remove(); }).catch(show);
        } }, "⬇"),
        !v.current && lv >= 2 ? h("button", { class: "sm", title: t("Terugzetten"), onclick: function () { system.confirm(t("Versie {0} terugzetten? De huidige versie blijft bewaard.", v.number), { okLabel: t("Terugzetten") }).then(function (ok) { if (ok) call("documents/" + d.id + "/versions/" + v.id + "/restore", "POST").then(function () { close(); load(); }).catch(show); }); } }, "↩") : null,
        !v.current && lv >= 3 ? h("button", { class: "sm danger", title: t("Verwijderen"), onclick: function () { system.confirm(t("Versie {0} verwijderen?", v.number), { danger: true, okLabel: t("Verwijderen") }).then(function (ok) { if (ok) call("documents/" + d.id + "/versions/" + v.id, "DELETE").then(function () { refresh(); load(); }).catch(show); }); } }, "🗑") : null));
    });
  }
  function refresh() { call("documents/" + d.id + "/versions").then(function (r) { paint(r.versions); }).catch(show); }
  file.addEventListener("change", function () {
    if (!file.files.length) return;
    system.upload(ROUTE + "upload", file.files[0], { replace: d.id, version: num.value, note: note.value }).then(function () { num.value = ""; note.value = ""; refresh(); load(); }).catch(show);
    file.value = "";
  });
  var close = modal([h("h2", {}, t("Versies: {0}", d.title)), list,
    lv >= 2 ? h("div", { class: "stack", style: "gap:.5rem" }, h("h3", { style: "margin:0" }, t("Nieuwe versie uploaden")), h("p", { class: "muted", style: "margin:0" }, t("Het nummer gaat vanzelf een omhoog. Je kunt zelf een nummer kiezen, bijvoorbeeld 2.0.")),
      h("div", { class: "row" }, num, note, h("button", { class: "primary", onclick: function () { file.click(); } }, "⬆ " + t("Bestand kiezen")), file)) : null,
    err, h("div", { class: "row", style: "justify-content:flex-end" }, h("button", { onclick: function () { close(); } }, t("Sluiten")))], true);
  refresh();
}

// ── blocks for pages (system objects) ──
function partView(route) {
  var q = (route && route.query) || {}, view = q.view || "list", limit = q.limit || "";
  var P = { q: "", tag: null, folder: null, trail: [] };
  function fetchList() {
    return call("blocks/list?view=" + view + (limit ? "&limit=" + limit : "") + (P.q ? "&q=" + encodeURIComponent(P.q) : "") + (P.tag ? "&tag=" + P.tag : "") + (P.folder ? "&folder=" + P.folder : ""));
  }
  function open(d) { call("blocks/link/" + d.id).then(function (r) { var a = h("a", { href: S.apiBase + r.path, download: d.filename, target: "_blank", rel: "noopener" }); document.body.appendChild(a); a.click(); a.remove(); }).catch(function (e) { alert(e.message); }); }
  function meta(d) { return size(d.size) + " · " + when(d.updated_at) + (d.version && d.version !== "1" ? " · v" + d.version : ""); }
  function chips(d) { return d.tags.length ? h("div", { class: "tags" }, d.tags.map(function (x) { return tagChip(x); })) : null; }
  function empty(d) { return h("div", { class: "empty card" }, d.user && d.user.in ? t("Hier staan nog geen documenten.") : t("Er zijn nog geen documenten voor bezoekers. Log in om meer te zien.")); }
  function listView(docs) {
    return h("div", { class: "card", style: "padding:.2rem .4rem" }, h("table", { class: "docs" }, h("thead", {}, h("tr", {}, h("th", {}, t("Document")), h("th", {}, t("Tags")), h("th", {}, t("Grootte")), h("th", {}))),
      h("tbody", {}, docs.map(function (d) { return h("tr", {}, h("td", {}, h("div", { class: "file" }, icon(d), h("div", { style: "min-width:0" }, h("div", { class: "t" }, d.title), h("div", { class: "fn" }, d.filename)))), h("td", {}, chips(d)),
        h("td", { class: "muted" }, meta(d)), h("td", {}, h("div", { class: "acts" }, h("button", { class: "sm primary", onclick: function () { open(d); } }, "⬇ " + t("Downloaden"))))); }))));
  }
  function cardsView(docs) {
    return h("div", { class: "dcards" }, docs.map(function (d) {
      return h("div", { class: "dcard" }, h("div", { class: "dthumb" }, h("span", {}, ext(d.filename))), h("div", { class: "dbody" }, h("strong", { title: d.title }, d.title), h("small", { class: "muted" }, meta(d)), chips(d),
        d.description ? h("small", { class: "muted dsub" }, d.description) : null, h("button", { class: "sm primary", onclick: function () { open(d); } }, "⬇ " + t("Downloaden"))));
    }));
  }
  function compact(docs) {
    return h("div", { class: "blk" }, docs.map(function (d) { return h("div", { class: "blk-row", onclick: function () { open(d); } }, icon(d), h("div", { class: "grow", style: "min-width:0" }, h("div", { class: "t" }, d.title), h("small", { class: "muted" }, meta(d))), h("span", { class: "dl" }, "⬇")); }));
  }
  function searchBox(d) {
    var inp = h("input", { type: "search", placeholder: t("Zoek documenten…"), value: P.q, id: "bq" }), timer = null;
    inp.addEventListener("input", function () { clearTimeout(timer); timer = setTimeout(function () { P.q = inp.value.trim(); draw(true); }, 250); });
    return inp;
  }
  function draw(keepFocus) {
    fetchList().then(function (d) {
      if (d.theme) document.documentElement.setAttribute("data-ptheme", d.theme);
      var docs = d.documents, out = [];
      if (view === "upload") { uploadBlock(d); return; }
      if (view === "search") out.push(searchBox(d));
      if (view === "tags") out.push(h("div", { class: "tags", style: "margin-bottom:.4rem" }, h("span", { class: "tag pick c-gray" + (!P.tag ? " on" : ""), onclick: function () { P.tag = null; draw(); } }, t("Alles")), d.tags.map(function (x) { return tagChip(x, function () { P.tag = P.tag === x.id ? null : x.id; draw(); }, P.tag === x.id); })));
      if (view === "folders") {
        out.push(h("div", { class: "crumbs" }, h("button", { onclick: function () { P.folder = null; P.trail = []; draw(); } }, "🏠 " + (d.scope || t("Documenten"))), P.trail.map(function (f, i) { return [h("span", { class: "sep" }, "/"), h("button", { onclick: function () { P.trail = P.trail.slice(0, i + 1); P.folder = f.id; draw(); } }, f.name)]; })));
        if (d.folders.length) out.push(h("div", { class: "folders" }, d.folders.map(function (f) { return h("div", { class: "folder", onclick: function () { P.trail.push(f); P.folder = f.id; draw(); } }, h("span", { class: "ico" }, "📁"), h("div", { class: "grow" }, h("div", { class: "name" }, f.name))); })));
      }
      if (!docs.length) out.push(empty(d));
      else out.push(view === "cards" ? cardsView(docs) : view === "latest" || view === "search" ? compact(docs) : listView(docs));
      app.innerHTML = ""; app.append.apply(app, out);
      if (keepFocus) { var i = document.getElementById("bq"); if (i) { i.focus(); i.setSelectionRange(i.value.length, i.value.length); } }
    }).catch(function (e) { app.innerHTML = ""; app.appendChild(h("div", { class: "empty card" }, e.message || t("Laden…"))); });
  }
  function uploadBlock(d) {
    app.innerHTML = "";
    if (!d.user.in) { app.appendChild(h("div", { class: "card empty" }, t("Log in om documenten te uploaden."))); return; }
    if (!d.user.can_upload) { app.appendChild(h("div", { class: "card empty" }, t("Je mag geen documenten uploaden."))); return; }
    var chosen = [], tf = null, status = h("div", {}), where = h("select", {}, h("option", { value: "" }, t("(hoofdmap)")));
    S.cfg = { tags: [] };
    call("config").then(function (c) { S.cfg = c; tf = tagField(chosen); tagsBox.appendChild(tf.el); });
    call("folders").then(function (r) { r.folders.forEach(function (f) { where.appendChild(h("option", { value: f.id }, f.path)); }); });
    var tagsBox = h("div", {}), file = h("input", { type: "file", multiple: true, style: "display:none" });
    var drop = h("div", { class: "drop", onclick: function () { file.click(); }, style: "cursor:pointer" }, "⬆ " + t("Sleep bestanden hierheen of klik om te kiezen"));
    ["dragenter", "dragover"].forEach(function (ev) { drop.addEventListener(ev, function (e) { e.preventDefault(); drop.classList.add("over"); }); });
    ["dragleave", "drop"].forEach(function (ev) { drop.addEventListener(ev, function (e) { e.preventDefault(); drop.classList.remove("over"); }); });
    function send(files) {
      files = Array.prototype.slice.call(files); if (!files.length) return;
      if (tf) tf.flush();
      status.innerHTML = "";
      files.reduce(function (p, f) {
        var row = h("div", { class: "row" }, h("span", { class: "grow" }, f.name), h("span", { class: "muted" }, "…")); status.appendChild(row);
        return p.then(function () { return system.upload(ROUTE + "upload", f, { folder: where.value, tags: chosen.join(",") }).then(function (r) { row.lastChild.textContent = r && r.new_version ? "✓ " + t("versie {0}", r.version) : "✓"; row.className = "row ok"; }).catch(function (e) { row.lastChild.textContent = e.message; row.className = "row no"; }); });
      }, Promise.resolve());
    }
    drop.addEventListener("drop", function (e) { if (e.dataTransfer) send(e.dataTransfer.files); });
    file.addEventListener("change", function () { send(file.files); file.value = ""; });
    app.append(h("div", { class: "card stack" }, h("h3", { style: "margin:0" }, t("Documenten uploaden")), drop, file, h("div", { class: "grid2" }, h("label", {}, t("Map"), where), h("label", {}, t("Tags"), tagsBox)), status,
      h("small", { class: "muted" }, t("Staat een bestand met dezelfde naam al in de map, dan wordt het een nieuwe versie."))));
  }
  draw();
}

function start(mode) {
  S.mode = mode;
  system.ready.then(function (r) { S.apiBase = r.apiBase || ""; if (mode === "part") { partView(r.route || {}); return; } load(); });
}
