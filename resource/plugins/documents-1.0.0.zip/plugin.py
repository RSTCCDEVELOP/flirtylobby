# Copyright & Ownership Notice
# easy2Edit is the exclusive legal property of RST Coaching & Consultancy B.V. (RSTCC),
# owned by Ronald Stolk. All rights reserved. Any unauthorized use, copying, modification,
# reproduction, distribution, or commercial exploitation of Easy2Edit, including its source code,
# is strictly prohibited without prior written permission from Ronald Stolk or RSTCC.
# website https://rstcc.net

"""Documentbeheer (plugin). Documenten in een mappenstructuur, met tags, opslag lokaal of op S3 (in dezelfde mappen), versleuteling en rechten per gebruiker of groep.
De gegevens staan in de database van het systeem (tabellen plg_documents_*). De bestanden staan op de server (plugin-datamap) of op S3, onder de hoofdmap uit de instellingen.
Teksten staan in T("…") zodat het systeem ze in alle talen kan leveren.

Rechten: 1 = bekijken en downloaden · 2 = bewerken (gegevens, tags, nieuwe documenten in de map) · 3 = beheren (verwijderen en delen).
Een recht op een map geldt ook voor alles wat erin zit. Superadmins en beheerders van plugins mogen alles; de eigenaar beheert zijn eigen documenten.

Routes: /api/plugins/run/documents/<pad>  (zie onderaan `register`); de pagina's staan in web/."""
import io
import logging
import mimetypes
import os
import re
from pathlib import Path

from django.core import signing
from django.db import models
from django.db.models import Q
from django.http import HttpResponse
from rest_framework.response import Response

logger = logging.getLogger(__name__)
SCOPE = "documents"  # one data key for all documents (wrapped with the master key of Beveiliging → Bestanden)
LEVELS = {1: "bekijken", 2: "bewerken", 3: "beheren"}
BLOCKED = {".exe", ".bat", ".cmd", ".com", ".msi", ".scr", ".sh", ".js", ".mjs", ".vbs", ".ps1", ".jar", ".html", ".htm", ".svg", ".php"}  # no programs or pages: a document is data
TAG_COLORS = ("blue", "orange", "green", "pink", "purple", "teal", "red", "gray")


def register(system):
    from apps.accounts.access import level as module_level
    from apps.accounts.models import UserGroup
    from apps.plugins.facade import community as social  # (the plugin Community; without it: no profiles, nobody hidden)

    T = system.t
    U, label = system.User, system.app_label
    cfg = system.config
    bad = lambda msg, code=400: Response({"detail": msg}, status=code)  # noqa: E731

    def table(name):
        return type("Meta", (), {"app_label": label, "db_table": system.db_prefix + name})

    class Folder(models.Model):
        name = models.CharField(max_length=120)
        parent = models.ForeignKey("self", null=True, blank=True, on_delete=models.CASCADE, related_name="children")
        owner = models.ForeignKey(U, null=True, blank=True, on_delete=models.SET_NULL, related_name="+", db_constraint=False)
        demo = models.BooleanField(default=False)
        created_at = models.DateTimeField(auto_now_add=True)
        Meta = table("folder")

    class Tag(models.Model):
        name = models.CharField(max_length=40, unique=True)
        color = models.CharField(max_length=12, default="blue")
        demo = models.BooleanField(default=False)
        Meta = table("tag")

    class Document(models.Model):
        title = models.CharField(max_length=200)
        description = models.TextField(blank=True)
        folder = models.ForeignKey(Folder, null=True, blank=True, on_delete=models.SET_NULL, related_name="documents")
        filename = models.CharField(max_length=255)
        mime = models.CharField(max_length=120, blank=True)
        size = models.BigIntegerField(default=0)
        storage = models.CharField(max_length=8, default="local")  # local | s3
        key = models.CharField(max_length=600)  # the path in the storage: <hoofdmap>/<mappen>/<bestand>
        encrypted = models.BooleanField(default=False)
        version = models.CharField(max_length=20, default="1")  # shown next to the document; goes up by itself when the same file is uploaded again, and can be set by hand
        owner = models.ForeignKey(U, null=True, blank=True, on_delete=models.SET_NULL, related_name="+", db_constraint=False)
        demo = models.BooleanField(default=False)
        created_at = models.DateTimeField(auto_now_add=True)
        updated_at = models.DateTimeField(auto_now=True)
        Meta = table("document")

    class DocTag(models.Model):
        document = models.ForeignKey(Document, on_delete=models.CASCADE, related_name="doctags")
        tag = models.ForeignKey(Tag, on_delete=models.CASCADE, related_name="doctags")
        Meta = type("Meta", (), {"app_label": label, "db_table": system.db_prefix + "doctag", "unique_together": (("document", "tag"),)})

    class Access(models.Model):
        """Who may do what with a document or a folder: a user, a group of users, or every logged-in user."""
        document = models.ForeignKey(Document, null=True, blank=True, on_delete=models.CASCADE, related_name="access")
        folder = models.ForeignKey(Folder, null=True, blank=True, on_delete=models.CASCADE, related_name="access")
        user = models.ForeignKey(U, null=True, blank=True, on_delete=models.CASCADE, related_name="+", db_constraint=False)  # a removed user leaves a row that no longer matches anybody
        group_id = models.PositiveIntegerField(null=True, blank=True)
        everyone = models.BooleanField(default=False)  # every logged-in user
        public = models.BooleanField(default=False)  # everybody, also visitors who are not logged in (for download lists on the website)
        level = models.PositiveSmallIntegerField(default=1)
        Meta = table("access")

    class DocVersion(models.Model):
        """An earlier version of a document: the file as it was before a new version was uploaded."""
        document = models.ForeignKey(Document, on_delete=models.CASCADE, related_name="versions")
        number = models.CharField(max_length=20)
        filename = models.CharField(max_length=255)
        mime = models.CharField(max_length=120, blank=True)
        size = models.BigIntegerField(default=0)
        storage = models.CharField(max_length=8, default="local")
        key = models.CharField(max_length=600)
        encrypted = models.BooleanField(default=False)
        owner = models.ForeignKey(U, null=True, blank=True, on_delete=models.SET_NULL, related_name="+", db_constraint=False)
        note = models.CharField(max_length=200, blank=True)
        created_at = models.DateTimeField()  # when this version was made (uploaded)
        Meta = table("version")

    system.sync_models(Folder, Tag, Document, DocTag, Access, DocVersion)

    def ensure_columns(*pairs):
        """Tables of an older version of the plugin get the columns that came later."""
        from django.db import connection

        for model, names in pairs:
            have = {c.name for c in connection.introspection.get_table_description(connection.cursor(), model._meta.db_table)}
            for n in names:
                if n not in have:
                    with connection.schema_editor() as se:
                        se.add_field(model, model._meta.get_field(n))

    ensure_columns((Document, ("version",)), (Access, ("public",)))

    # ── storage: server or S3, in the same folders; optionally encrypted ──
    def s3():
        """The S3 helpers when S3 is linked and on, else None."""
        try:
            from apps.medialib import s3 as mod

            return mod if mod.available() else None
        except Exception:  # noqa: BLE001
            return None

    def root():
        return re.sub(r"[^a-z0-9_-]+", "-", str(cfg.get("s3_folder") or "documenten").lower()).strip("-") or "documenten"

    def target():
        return "s3" if (cfg.get("storage") or "automatisch") != "lokaal" and s3() else "local"

    def safe(name):
        name = re.sub(r"[\\/:*?\"<>|\x00-\x1f]+", "_", str(name or "").strip()).strip(". ")[:120]
        return name or "naam"

    def folder_path(folder):
        parts = []
        while folder is not None and len(parts) < 30:
            parts.append(safe(folder.name))
            folder = folder.parent
        return list(reversed(parts))

    def local_path(key):
        return Path(system.data_dir) / "files" / key

    def exists_key(key, storage, skip=None):
        if Document.objects.filter(key=key).exclude(pk=skip or 0).exists():
            return True
        if storage == "local":
            return local_path(key).exists()
        return False

    def unique_key(base, storage, skip=None):
        stem, ext = os.path.splitext(base)
        key, n = base, 1
        while exists_key(key, storage, skip) or DocVersion.objects.filter(key=key).exists():
            n += 1
            key = f"{stem} ({n}){ext}"
        return key

    def make_key(folder, filename, storage, skip=None):
        return unique_key("/".join([root(), *folder_path(folder), safe(filename)]), storage, skip)

    def move_raw(storage, old, new):
        """Move a stored file to another key (same storage)."""
        if storage == "s3":
            mod = s3()
            c = mod.config()
            cl = mod.client(c)
            cl.copy_object(Bucket=c["bucket"], CopySource={"Bucket": c["bucket"], "Key": mod.object_key(c, old)}, Key=mod.object_key(c, new))
            cl.delete_object(Bucket=c["bucket"], Key=mod.object_key(c, old))
        else:
            dst = local_path(new)
            dst.parent.mkdir(parents=True, exist_ok=True)
            local_path(old).replace(dst)

    def write(key, data, storage):
        if storage == "s3":
            mod = s3()
            c = mod.config()
            mod.client(c).put_object(Bucket=c["bucket"], Key=mod.object_key(c, key), Body=data, ContentType="application/octet-stream")
        else:
            p = local_path(key)
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_bytes(data)

    def read_raw(doc):
        if doc.storage == "s3":
            mod = s3()
            if not mod:
                raise OSError("S3 is niet beschikbaar.")
            c = mod.config()
            return mod.client(c).get_object(Bucket=c["bucket"], Key=mod.object_key(c, doc.key))["Body"].read()
        return local_path(doc.key).read_bytes()

    def delete_raw(storage, key):
        try:
            if storage == "s3":
                mod = s3()
                if mod:
                    c = mod.config()
                    mod.client(c).delete_object(Bucket=c["bucket"], Key=mod.object_key(c, key))
            else:
                local_path(key).unlink(missing_ok=True)
        except Exception:  # noqa: BLE001 - an orphan file is better than an error
            logger.warning("Documents: file %s could not be removed", key, exc_info=True)

    def seal(data):
        """Encrypt bytes (AES-256-GCM, the key of the system: Beveiliging → Bestanden)."""
        from apps.medialib import filecrypt

        tmp = Path(system.data_dir) / "tmp"
        tmp.mkdir(parents=True, exist_ok=True)
        f = tmp / f"enc-{os.urandom(6).hex()}"
        try:
            f.write_bytes(data)
            filecrypt.encrypt_file(str(f), SCOPE)
            return f.read_bytes()
        finally:
            f.unlink(missing_ok=True)

    def unseal(data):
        from apps.medialib import filecrypt

        return filecrypt.decrypt_bytes(io.BytesIO(data), SCOPE)

    def content(doc):
        raw = read_raw(doc)
        return unseal(raw) if doc.encrypted else raw

    def store(doc, data):
        """Put the (plain) bytes of a document in the place the settings choose; sets storage, key, encrypted and size on `doc` (not saved)."""
        storage, enc = target(), bool(cfg.get("encrypt"))
        key = make_key(doc.folder, doc.filename, storage, doc.pk)
        write(key, seal(data) if enc else data, storage)
        doc.storage, doc.key, doc.encrypted, doc.size = storage, key, enc, len(data)

    def relocate(doc):
        """After a move or a rename: the file follows its folder (same storage), so the structure on S3 stays the same as here."""
        new = make_key(doc.folder, doc.filename, doc.storage, doc.pk)
        if new == doc.key:
            return
        try:
            move_raw(doc.storage, doc.key, new)
            doc.key = new
            doc.save(update_fields=["key", "updated_at"])
        except Exception:  # noqa: BLE001 - the document stays where it was
            logger.warning("Documents: %s could not be moved", doc.key, exc_info=True)

    VERSION_RE = re.compile(r"^[0-9A-Za-z][0-9A-Za-z._-]{0,19}$")

    def next_version(cur):
        """1 → 2, 1.4 → 1.5, v2 → v3: the last number goes up."""
        m = re.search(r"(\d+)(?!.*\d)", str(cur or ""))
        if not m:
            return "2"
        return str(cur)[:m.start()] + str(int(m.group(1)) + 1) + str(cur)[m.end():]

    def new_version(doc, data, user, number=None, note=""):
        """A new file for an existing document: the file that is there goes to the versions (in the folder _versies, next to the document), the new one takes its place."""
        stem, ext = os.path.splitext(doc.filename)
        base = "/".join([root(), *folder_path(doc.folder), "_versies", safe(f"{stem}-v{doc.version}{ext}")])
        old_key = doc.key
        key = unique_key(base, doc.storage)
        move_raw(doc.storage, old_key, key)
        DocVersion.objects.create(document=doc, number=doc.version, filename=doc.filename, mime=doc.mime, size=doc.size, storage=doc.storage, key=key, encrypted=doc.encrypted, owner=doc.owner, note=note[:200], created_at=doc.updated_at)
        doc.version = number if number and VERSION_RE.match(str(number)) else next_version(doc.version)
        doc.owner = user
        store(doc, data)
        doc.save()
        return doc

    # ── rights ──
    def is_admin(u):
        return bool(u.is_staff or module_level(u, "plugins") >= 2)

    def my_groups(u):
        return set(u.user_groups.values_list("id", flat=True))

    def entry_q(u):
        return Q(user=u) | Q(everyone=True) | Q(public=True) | Q(group_id__in=my_groups(u))

    def ancestors(folder):
        out, n = [], 0
        while folder is not None and n < 40:
            out.append(folder)
            folder, n = folder.parent, n + 1
        return out

    def folder_level(u, folder):
        """The best level this user has on a folder (own, or from a folder above it)."""
        if is_admin(u):
            return 3
        best = 0
        chain = ancestors(folder)
        if any(f.owner_id == u.id for f in chain):
            return 3
        for a in Access.objects.filter(entry_q(u), folder__in=chain):
            best = max(best, a.level)
        return best

    def doc_level(u, doc):
        if is_admin(u) or doc.owner_id == u.id:
            return 3
        best = folder_level(u, doc.folder) if doc.folder_id else 0
        for a in Access.objects.filter(entry_q(u), document=doc):
            best = max(best, a.level)
        return best

    def open_folder_ids(u):
        """Ids of the folders this user may open: the ones with a right of their own and everything below them."""
        if is_admin(u):
            return set(Folder.objects.values_list("id", flat=True))
        start = set(Folder.objects.filter(owner=u).values_list("id", flat=True)) | set(Access.objects.filter(entry_q(u), folder__isnull=False).values_list("folder_id", flat=True))
        kids = {}
        for fid, pid in Folder.objects.values_list("id", "parent_id"):
            kids.setdefault(pid, []).append(fid)
        out, todo = set(), list(start)
        while todo:
            f = todo.pop()
            if f not in out:
                out.add(f)
                todo += kids.get(f, [])
        return out

    def visible_docs(u):
        if is_admin(u):
            return Document.objects.all()
        return Document.objects.filter(Q(owner=u) | Q(folder_id__in=open_folder_ids(u)) | Q(id__in=Access.objects.filter(entry_q(u), document__isnull=False).values("document_id")))

    def public_doc_ids():
        """Documents everybody may see, also visitors: shared with "iedereen" on the document or on a folder above it."""
        kids = {}
        for fid, pid in Folder.objects.values_list("id", "parent_id"):
            kids.setdefault(pid, []).append(fid)
        out, todo = set(), list(Access.objects.filter(public=True, folder__isnull=False).values_list("folder_id", flat=True))
        while todo:
            f = todo.pop()
            if f not in out:
                out.add(f)
                todo += kids.get(f, [])
        return set(Document.objects.filter(Q(id__in=Access.objects.filter(public=True, document__isnull=False).values("document_id")) | Q(folder_id__in=out)).values_list("id", flat=True))

    def is_public(doc):
        return doc.id in public_doc_ids()

    def can_upload(u):
        return bool(is_admin(u) or cfg.get("members_upload", True) is not False)

    # ── output ──
    def person(u):
        try:
            return social.display_name(u) if u else ""
        except Exception:  # noqa: BLE001 - a user that was removed
            return ""

    def tags_of(doc):
        return [{"id": dt.tag_id, "name": dt.tag.name, "color": dt.tag.color} for dt in doc.doctags.all()]

    def out_doc(doc, u):
        lv = doc_level(u, doc)
        return {"id": doc.id, "title": doc.title, "description": doc.description, "filename": doc.filename, "mime": doc.mime, "size": doc.size, "folder": doc.folder_id, "storage": doc.storage, "encrypted": doc.encrypted,
                "owner": person(doc.owner) if doc.owner_id else "", "owner_id": doc.owner_id, "created_at": doc.created_at.isoformat(), "updated_at": doc.updated_at.isoformat(), "tags": tags_of(doc), "level": lv,
                "shared": doc.access.exists() or (doc.folder_id is not None and Access.objects.filter(folder__in=ancestors(doc.folder)).exists()), "demo": doc.demo,
                "version": doc.version, "versions": doc.versions.count()}

    def out_folder(f, u):
        return {"id": f.id, "name": f.name, "parent": f.parent_id, "level": folder_level(u, f), "documents": f.documents.count(), "folders": f.children.count(), "demo": f.demo,
                "shared": Access.objects.filter(folder__in=ancestors(f)).exists()}

    def crumbs(f, u):
        chain = list(reversed(ancestors(f))) if f else []
        ids = open_folder_ids(u)
        return [{"id": x.id, "name": x.name} for x in chain if x.id in ids]

    def by_id(model, pk):
        return model.objects.filter(pk=pk).first() if str(pk).isdigit() else None

    def get_doc(id, u, need=1):
        d = by_id(Document, id)
        return d if d and doc_level(u, d) >= need else None

    def get_folder(id, u, need=1):
        f = by_id(Folder, id)
        return f if f and folder_level(u, f) >= need else None

    def set_tags(doc, names):
        keep = []
        for n in [str(x).strip()[:40] for x in (names or []) if str(x).strip()][:20]:
            t = Tag.objects.filter(name__iexact=n).first() or Tag.objects.create(name=n)
            keep.append(t.id)
        DocTag.objects.filter(document=doc).exclude(tag_id__in=keep).delete()
        for tid in keep:
            DocTag.objects.get_or_create(document=doc, tag_id=tid)

    # the models of a plugin are not in the registry of the system, so Django does not cascade: the rows that belong to a document or a folder are removed here
    def purge_docs(qs):
        ids = list(qs.values_list("id", flat=True))
        for d in Document.objects.filter(id__in=ids):
            delete_raw(d.storage, d.key)
        for v in DocVersion.objects.filter(document_id__in=ids):
            delete_raw(v.storage, v.key)
        DocVersion.objects.filter(document_id__in=ids).delete()
        DocTag.objects.filter(document_id__in=ids).delete()
        Access.objects.filter(document_id__in=ids).delete()
        Document.objects.filter(id__in=ids).delete()

    def purge_folders(ids):
        """Delete these folders and everything below them (documents too)."""
        todo, every = list(ids), []
        while todo:
            every += todo
            todo = list(Folder.objects.filter(parent_id__in=todo).values_list("id", flat=True))
        purge_docs(Document.objects.filter(folder_id__in=every))
        Access.objects.filter(folder_id__in=every).delete()
        for fid in reversed(every):
            Folder.objects.filter(pk=fid).delete()

    # ── routes ──
    @system.route("GET", "config")
    def config_(request):
        me = request.user
        return {"me": {"id": me.id, "admin": is_admin(me), "can_upload": can_upload(me)}, "max_mb": float(cfg.get("max_mb") or 50), "encrypt": bool(cfg.get("encrypt")), "storage": target(), "s3": bool(s3()), "colors": TAG_COLORS,
                "tags": [{"id": t.id, "name": t.name, "color": t.color, "count": t.doctags.count()} for t in Tag.objects.order_by("name")]}

    @system.route("GET", "browse")
    def browse(request):
        me, q = request.user, request.query_params
        text, tag = str(q.get("q") or "").strip(), q.get("tag")
        fid = q.get("folder")
        cur = get_folder(fid, me) if fid else None
        if fid and not cur:
            return bad(T("Deze map bestaat niet of is niet zichtbaar."), 404)
        docs = visible_docs(me).select_related("folder", "owner").prefetch_related("doctags__tag")
        searching = bool(text or tag)
        if text:
            docs = docs.filter(Q(title__icontains=text) | Q(filename__icontains=text) | Q(description__icontains=text) | Q(id__in=DocTag.objects.filter(tag__name__icontains=text).values("document_id")))
        if tag and str(tag).isdigit():
            docs = docs.filter(id__in=DocTag.objects.filter(tag_id=int(tag)).values("document_id"))
        opened = open_folder_ids(me)
        if not searching:
            if cur:
                docs = docs.filter(folder=cur)
            elif is_admin(me):
                docs = docs.filter(folder__isnull=True)
            else:  # at the top: loose documents, and shared documents whose folder this user cannot open
                docs = docs.filter(Q(folder__isnull=True) | ~Q(folder_id__in=opened))
        folders = []
        if not searching:
            sub = Folder.objects.filter(parent=cur) if cur else (Folder.objects.filter(parent__isnull=True) if is_admin(me) else Folder.objects.filter(id__in=opened).exclude(parent_id__in=opened))
            folders = [out_folder(f, me) for f in sub.order_by("name") if f.id in opened]
        sort = {"name": "title", "size": "-size", "new": "-created_at"}.get(q.get("sort"), "title")
        return {"folder": out_folder(cur, me) if cur else None, "crumbs": crumbs(cur, me), "folders": folders, "documents": [out_doc(d, me) for d in docs.order_by(sort)[:500]], "searching": searching}

    @system.route("GET", "folders")
    def folder_list(request):
        """All folders the user may put something in, with their path (for "move to")."""
        me = request.user
        every = {f.id: f for f in Folder.objects.all()}
        out = []
        for f in every.values():
            if folder_level(me, f) >= 2:
                out.append({"id": f.id, "path": " / ".join(x.name for x in reversed(ancestors(f)))})
        return {"folders": sorted(out, key=lambda x: x["path"].lower())}

    @system.route("POST", "folders")
    def folder_create(request):
        me, d = request.user, request.data
        name = str(d.get("name") or "").strip()[:120]
        if not name:
            return bad(T("Geef de map een naam."))
        parent = None
        if d.get("parent"):
            parent = get_folder(d["parent"], me, 2)
            if not parent:
                return bad(T("Je mag in deze map geen mappen maken."), 403)
        elif not (is_admin(me) or can_upload(me)):
            return bad(T("Je mag hier geen mappen maken."), 403)
        if Folder.objects.filter(parent=parent, name__iexact=name).exists():
            return bad(T("Er is hier al een map met deze naam."))
        f = Folder.objects.create(name=name, parent=parent, owner=me)
        return out_folder(f, me)

    @system.route("PATCH", "folders/<id>")
    def folder_update(request, id):
        me, d = request.user, request.data
        f = get_folder(id, me, 3)
        if not f:
            return bad(T("Je mag deze map niet wijzigen."), 403)
        if "name" in d:
            name = str(d["name"] or "").strip()[:120]
            if not name:
                return bad(T("Geef de map een naam."))
            f.name = name
        if "parent" in d:
            parent = get_folder(d["parent"], me, 2) if d["parent"] else None
            if d["parent"] and not parent:
                return bad(T("Je mag niet naar deze map verplaatsen."), 403)
            if parent and (parent.id == f.id or f.id in [a.id for a in ancestors(parent)]):
                return bad(T("Een map kan niet in zichzelf."))
            f.parent = parent
        if Folder.objects.filter(parent=f.parent, name__iexact=f.name).exclude(pk=f.pk).exists():
            return bad(T("Er is hier al een map met deze naam."))
        f.save()
        ids, todo = [f.id], [f.id]  # the files below follow the folder
        while todo:
            kids = list(Folder.objects.filter(parent_id__in=todo).values_list("id", flat=True))
            ids += kids
            todo = kids
        for doc in Document.objects.filter(folder_id__in=ids).select_related("folder__parent"):
            relocate(doc)
        return out_folder(f, me)

    @system.route("DELETE", "folders/<id>")
    def folder_delete(request, id):
        me = request.user
        f = get_folder(id, me, 3)
        if not f:
            return bad(T("Je mag deze map niet verwijderen."), 403)
        if f.children.exists() or f.documents.exists():
            if str(request.query_params.get("all") or "") != "1":
                return bad(T("De map is niet leeg. Verwijder eerst de inhoud, of verwijder alles."), 409)
        purge_folders([f.id])
        return {"ok": True}

    @system.route("POST", "upload")
    def upload(request):
        me = request.user
        if not can_upload(me):
            return bad(T("Je mag geen documenten uploaden."), 403)
        file = request.FILES.get("file")
        if not file:
            return bad(T("Kies een bestand."))
        folder = None
        if request.data.get("folder"):
            folder = get_folder(request.data["folder"], me, 2)
            if not folder:
                return bad(T("Je mag in deze map niets zetten."), 403)
        max_mb = float(cfg.get("max_mb") or 50)
        if file.size > max_mb * 1024 * 1024:
            return bad(T("Het bestand is groter dan {0} MB.", f"{max_mb:g}"), 413)
        name = safe(os.path.basename(file.name))
        if os.path.splitext(name)[1].lower() in BLOCKED:
            return bad(T("Dit soort bestand is niet toegestaan."), 415)
        data = file.read()
        tags = [x for x in str(request.data.get("tags") or "").split(",") if x.strip()]
        if str(request.data.get("replace") or "").isdigit():  # a new version of this document, whatever the file is called
            target_doc = get_doc(request.data["replace"], me, 2)
            if not target_doc:
                return bad(T("Je mag dit document niet vervangen."), 403)
            try:
                new_version(target_doc, data, me, number=str(request.data.get("version") or "").strip(), note=str(request.data.get("note") or ""))
            except Exception as e:  # noqa: BLE001
                logger.warning("Documents: new version failed", exc_info=True)
                return bad(T("Het bestand kon niet worden opgeslagen: {0}", str(e)[:150]), 502)
            return dict(out_doc(Document.objects.prefetch_related("doctags__tag").get(pk=target_doc.pk), me), new_version=True)
        same = Document.objects.filter(folder=folder, filename__iexact=name).first()
        if same and str(request.data.get("copy") or "") != "1":  # the same file again: a new version of that document
            if doc_level(me, same) < 2:
                return bad(T("Dit bestand bestaat al in deze map en je mag het niet vervangen."), 403)
            try:
                new_version(same, data, me, number=str(request.data.get("version") or "").strip(), note=str(request.data.get("note") or ""))
            except Exception as e:  # noqa: BLE001
                logger.warning("Documents: new version failed", exc_info=True)
                return bad(T("Het bestand kon niet worden opgeslagen: {0}", str(e)[:150]), 502)
            if tags:
                set_tags(same, sorted({*(t["name"] for t in tags_of(same)), *[x.strip() for x in tags]}))
            system.stats.record("new_version", "bestand")
            return dict(out_doc(Document.objects.prefetch_related("doctags__tag").get(pk=same.pk), me), new_version=True)
        doc = Document(title=str(request.data.get("title") or os.path.splitext(name)[0])[:200], description=str(request.data.get("description") or "")[:4000], folder=folder, filename=name,
                       mime=(mimetypes.guess_type(name)[0] or file.content_type or "application/octet-stream")[:120], owner=me)
        v = str(request.data.get("version") or "").strip()
        if v and VERSION_RE.match(v):
            doc.version = v
        try:
            store(doc, data)
        except Exception as e:  # noqa: BLE001 - S3 down, key missing …
            logger.warning("Documents: upload failed", exc_info=True)
            return bad(T("Het bestand kon niet worden opgeslagen: {0}", str(e)[:150]), 502)
        doc.save()
        set_tags(doc, tags)
        system.stats.record("upload", os.path.splitext(name)[1].lower().lstrip(".") or "bestand")
        return out_doc(Document.objects.prefetch_related("doctags__tag").get(pk=doc.pk), me)

    @system.route("GET", "documents/<id>")
    def doc_one(request, id):
        d = get_doc(id, request.user)
        return out_doc(d, request.user) if d else bad(T("Dit document bestaat niet of is niet zichtbaar."), 404)

    @system.route("PATCH", "documents/<id>")
    def doc_update(request, id):
        me, b = request.user, request.data
        d = get_doc(id, me, 2)
        if not d:
            return bad(T("Je mag dit document niet wijzigen."), 403)
        if "title" in b:
            d.title = str(b["title"] or "").strip()[:200] or d.title
        if "description" in b:
            d.description = str(b["description"] or "")[:4000]
        if "version" in b:
            v = str(b["version"] or "").strip()
            if not VERSION_RE.match(v):
                return bad(T("Het versienummer mag letters, cijfers, punten en streepjes bevatten (maximaal 20 tekens)."))
            d.version = v
        if "filename" in b and str(b["filename"] or "").strip():
            new = safe(b["filename"])
            if os.path.splitext(new)[1].lower() in BLOCKED:
                return bad(T("Dit soort bestand is niet toegestaan."), 415)
            d.filename = new
        if "folder" in b:
            folder = get_folder(b["folder"], me, 2) if b["folder"] else None
            if b["folder"] and not folder:
                return bad(T("Je mag niet naar deze map verplaatsen."), 403)
            d.folder = folder
        d.save()
        relocate(d)
        if "tags" in b:
            set_tags(d, b["tags"] if isinstance(b["tags"], list) else str(b["tags"]).split(","))
        return out_doc(Document.objects.prefetch_related("doctags__tag").get(pk=d.pk), me)

    @system.route("DELETE", "documents/<id>")
    def doc_delete(request, id):
        d = get_doc(id, request.user, 3)
        if not d:
            return bad(T("Je mag dit document niet verwijderen."), 403)
        purge_docs(Document.objects.filter(pk=d.pk))
        return {"ok": True}

    @system.route("GET", "documents/<id>/link")
    def doc_link(request, id):
        d = get_doc(id, request.user)
        if not d:
            return bad(T("Dit document bestaat niet of is niet zichtbaar."), 404)
        return {"path": "/api/plugins/run/documents/get/" + signing.dumps({"d": d.id, "u": request.user.id}, salt="documents-download")}  # short-lived: the link is the permission

    @system.route("GET", "documents/<id>/versions")
    def doc_versions(request, id):
        me = request.user
        d = get_doc(id, me)
        if not d:
            return bad(T("Dit document bestaat niet of is niet zichtbaar."), 404)
        rows = [{"id": 0, "number": d.version, "filename": d.filename, "size": d.size, "created_at": d.updated_at.isoformat(), "by": person(d.owner) if d.owner_id else "", "current": True, "encrypted": d.encrypted, "note": ""}]
        for v in d.versions.order_by("-id"):
            rows.append({"id": v.id, "number": v.number, "filename": v.filename, "size": v.size, "created_at": v.created_at.isoformat(), "by": person(v.owner) if v.owner_id else "", "current": False, "encrypted": v.encrypted, "note": v.note})
        return {"versions": rows, "level": doc_level(me, d)}

    @system.route("GET", "documents/<id>/versions/<vid>/link")
    def version_link(request, id, vid):
        d = get_doc(id, request.user)
        v = DocVersion.objects.filter(pk=vid, document=d).first() if d and str(vid).isdigit() else None
        if not v:
            return bad(T("Deze versie bestaat niet."), 404)
        return {"path": "/api/plugins/run/documents/get/" + signing.dumps({"d": d.id, "u": request.user.id, "v": v.id}, salt="documents-download")}

    @system.route("POST", "documents/<id>/versions/<vid>/restore")
    def version_restore(request, id, vid):
        me = request.user
        d = get_doc(id, me, 2)
        v = DocVersion.objects.filter(pk=vid, document=d).first() if d and str(vid).isdigit() else None
        if not v:
            return bad(T("Deze versie bestaat niet."), 404)
        try:
            raw = read_raw(v)
            data = unseal(raw) if v.encrypted else raw
            new_version(d, data, me, note=T("Teruggezet vanaf versie {0}", v.number))
        except Exception as e:  # noqa: BLE001
            logger.warning("Documents: restore failed", exc_info=True)
            return bad(T("Het bestand kon niet worden teruggezet: {0}", str(e)[:150]), 502)
        return out_doc(Document.objects.prefetch_related("doctags__tag").get(pk=d.pk), me)

    @system.route("DELETE", "documents/<id>/versions/<vid>")
    def version_delete(request, id, vid):
        d = get_doc(id, request.user, 3)
        v = DocVersion.objects.filter(pk=vid, document=d).first() if d and str(vid).isdigit() else None
        if v:
            delete_raw(v.storage, v.key)
            v.delete()
        return {"ok": True}

    @system.route("GET", "get/<token>", public=True)
    def doc_get(request, token):
        try:
            p = signing.loads(token, salt="documents-download", max_age=300)
        except signing.BadSignature:
            return HttpResponse(status=404)
        d = by_id(Document, p.get("d"))
        if not d:
            return HttpResponse(status=404)
        if p.get("v"):  # an earlier version
            d = DocVersion.objects.filter(pk=p["v"], document_id=d.id).first()
            if not d:
                return HttpResponse(status=404)
        try:
            data = content(d)
        except Exception:  # noqa: BLE001 - file lost, key changed, S3 down
            logger.warning("Documents: %s could not be read", d.key, exc_info=True)
            return HttpResponse(T("Het bestand kon niet worden gelezen."), status=502)
        system.stats.record("download", os.path.splitext(d.filename)[1].lower().lstrip(".") or "bestand")
        r = HttpResponse(data, content_type="application/octet-stream")
        r["Content-Disposition"] = 'attachment; filename="%s"' % re.sub(r'[^A-Za-z0-9._ -]+', "_", d.filename)
        r["X-Content-Type-Options"] = "nosniff"
        r["Cache-Control"] = "private, no-store"
        return r

    # ── tags ──
    @system.route("GET", "tags")
    def tags_list(request):
        return {"tags": [{"id": t.id, "name": t.name, "color": t.color, "count": t.doctags.count()} for t in Tag.objects.order_by("name")]}

    @system.route("POST", "tags")
    def tag_create(request):
        name, color = str(request.data.get("name") or "").strip()[:40], request.data.get("color")
        if not name:
            return bad(T("Geef de tag een naam."))
        if Tag.objects.filter(name__iexact=name).exists():
            return bad(T("Deze tag bestaat al."))
        t = Tag.objects.create(name=name, color=color if color in TAG_COLORS else "blue")
        return {"id": t.id, "name": t.name, "color": t.color, "count": 0}

    @system.route("PATCH", "tags/<id>")
    def tag_update(request, id):
        if not is_admin(request.user):
            return bad(T("Alleen beheerders wijzigen tags."), 403)
        t = by_id(Tag, id)
        if not t:
            return bad(T("Deze tag bestaat niet."), 404)
        name = str(request.data.get("name") or t.name).strip()[:40]
        if Tag.objects.filter(name__iexact=name).exclude(pk=t.pk).exists():
            return bad(T("Deze tag bestaat al."))
        t.name, t.color = name, request.data.get("color") if request.data.get("color") in TAG_COLORS else t.color
        t.save()
        return {"id": t.id, "name": t.name, "color": t.color, "count": t.doctags.count()}

    @system.route("DELETE", "tags/<id>")
    def tag_delete(request, id):
        if not is_admin(request.user):
            return bad(T("Alleen beheerders verwijderen tags."), 403)
        t = by_id(Tag, id)
        if t:
            DocTag.objects.filter(tag=t).delete()
            t.delete()
        return {"ok": True}

    # ── rights per user or group ──
    def entry_out(a):
        if a.public:
            return {"type": "public", "id": 0, "name": T("Iedereen, ook bezoekers"), "level": 1}
        if a.everyone:
            return {"type": "everyone", "id": 0, "name": T("Alle gebruikers"), "level": a.level}
        if a.group_id:
            g = UserGroup.objects.filter(pk=a.group_id).first()
            return {"type": "group", "id": a.group_id, "name": g.name if g else "?", "level": a.level}
        return {"type": "user", "id": a.user_id, "name": person(a.user), "email": a.user.email if a.user else "", "level": a.level}

    def access_target(kind, id, me):
        return get_doc(id, me, 3) if kind == "document" else get_folder(id, me, 3)

    def access_get(kind):
        def run(request, id):
            obj = access_target(kind, id, request.user)
            if not obj:
                return bad(T("Je mag de rechten hiervan niet zien of wijzigen."), 403)
            rows = Access.objects.filter(**{kind: obj}).select_related("user")
            inherited = []
            if kind == "document" and obj.folder_id:
                inherited = [dict(entry_out(a), from_folder=a.folder.name) for a in Access.objects.filter(folder__in=ancestors(obj.folder)).select_related("user", "folder")]
            elif kind == "folder" and obj.parent_id:
                inherited = [dict(entry_out(a), from_folder=a.folder.name) for a in Access.objects.filter(folder__in=ancestors(obj.parent)).select_related("user", "folder")]
            return {"entries": [entry_out(a) for a in rows], "inherited": inherited, "owner": person(obj.owner), "levels": LEVELS}
        return run

    def access_put(kind):
        def run(request, id):
            obj = access_target(kind, id, request.user)
            if not obj:
                return bad(T("Je mag de rechten hiervan niet wijzigen."), 403)
            entries = request.data.get("entries")
            if not isinstance(entries, list):
                return bad(T("Ongeldige gegevens."))
            seen, rows = set(), []
            for e in entries[:200]:
                lv, typ, ident = int(e.get("level") or 1), e.get("type"), e.get("id")
                lv = lv if lv in LEVELS else 1
                if typ == "public":
                    k, row, lv = ("p", 0), {"public": True}, 1
                elif typ == "everyone":
                    k, row = ("e", 0), {"everyone": True}
                elif typ == "group" and by_id(UserGroup, ident):
                    k, row = ("g", int(ident)), {"group_id": int(ident)}
                elif typ == "user" and by_id(U, ident):
                    k, row = ("u", int(ident)), {"user_id": int(ident)}
                else:
                    continue
                if k not in seen:
                    seen.add(k)
                    rows.append({**row, "level": lv})
            Access.objects.filter(**{kind: obj}).delete()
            for r in rows:
                Access.objects.create(**{kind: obj}, **r)
            return {"entries": [entry_out(a) for a in Access.objects.filter(**{kind: obj}).select_related("user")]}
        return run

    system.route("GET", "documents/<id>/access", access_get("document"))
    system.route("PUT", "documents/<id>/access", access_put("document"))
    system.route("GET", "folders/<id>/access", access_get("folder"))
    system.route("PUT", "folders/<id>/access", access_put("folder"))

    @system.route("GET", "principals")
    def principals(request):
        """People and groups to give rights to (as many as the user may see: everybody for admins, else the people of the own groups and the groups he is in)."""
        me, text = request.user, str(request.query_params.get("q") or "").strip()
        if len(text) < 2 and not is_admin(me):
            return {"users": [], "groups": []}
        users = U.objects.filter(is_active=True).exclude(pk=me.pk)
        if text:
            users = users.filter(Q(email__icontains=text) | Q(first_name__icontains=text) | Q(last_name__icontains=text) | Q(username__icontains=text))
        if not is_admin(me):
            users = users.filter(user_groups__in=my_groups(me)).distinct()
        groups = UserGroup.objects.all() if is_admin(me) else UserGroup.objects.filter(id__in=my_groups(me))
        if text:
            groups = groups.filter(name__icontains=text)
        return {"users": [{"id": u.id, "name": person(u), "email": u.email} for u in users.order_by("email")[:15]], "groups": [{"id": g.id, "name": g.name} for g in groups.order_by("name")[:15]]}

    # ── blocks for pages (system objects): lists of documents for visitors and members, in the style of the chosen theme ──
    def theme():
        try:
            return social.get()["profiles"]["theme"]
        except Exception:  # noqa: BLE001 - the community module is off
            return "normal"

    def folder_by_path(path):
        cur = None
        for part in [x.strip() for x in str(path or "").split("/") if x.strip()]:
            cur = Folder.objects.filter(parent=cur, name__iexact=part).first()
            if not cur:
                return None
        return cur

    def folder_tree_ids(fid):
        every, todo = [], [fid]
        while todo:
            every += todo
            todo = list(Folder.objects.filter(parent_id__in=todo).values_list("id", flat=True))
        return every

    @system.route("GET", "blocks/list", public=True)
    def blocks_list(request):
        """What a block on a page shows: the documents this visitor may see (visitors: only the public ones), optionally in one folder (the setting of the plugin, or ?folder=)."""
        me, q = request.user, request.query_params
        authed = bool(me and me.is_authenticated)
        docs = visible_docs(me) if authed else Document.objects.filter(id__in=public_doc_ids())
        scope = None
        if q.get("folder") and str(q["folder"]).isdigit():
            scope = Folder.objects.filter(pk=q["folder"]).first()
        elif cfg.get("block_folder"):
            scope = folder_by_path(cfg.get("block_folder"))
        if scope:
            docs = docs.filter(folder_id__in=folder_tree_ids(scope.id))
        elif cfg.get("block_folder") and folder_by_path(cfg.get("block_folder")) is None:
            docs = docs.none()
        text, tag = str(q.get("q") or "").strip(), q.get("tag")
        if text:
            docs = docs.filter(Q(title__icontains=text) | Q(filename__icontains=text) | Q(description__icontains=text) | Q(id__in=DocTag.objects.filter(tag__name__icontains=text).values("document_id")))
        if tag and str(tag).isdigit():
            docs = docs.filter(id__in=DocTag.objects.filter(tag_id=int(tag)).values("document_id"))
        try:
            limit = max(1, min(100, int(q.get("limit") or 50)))
        except ValueError:
            limit = 50
        docs = docs.select_related("folder").prefetch_related("doctags__tag").order_by("-updated_at" if q.get("view") in ("latest",) else "title")
        rows = [{"id": d.id, "title": d.title, "description": d.description[:200], "filename": d.filename, "mime": d.mime, "size": d.size, "version": d.version, "updated_at": d.updated_at.isoformat(), "tags": tags_of(d),
                 "folder": d.folder.name if d.folder_id else ""} for d in docs[:limit]]
        used = {t["id"]: t for r in rows for t in r["tags"]}
        folders = []
        if scope or not cfg.get("block_folder"):
            sub = Folder.objects.filter(parent=scope) if scope else Folder.objects.filter(parent__isnull=True)
            ids_docs = set(docs.values_list("folder_id", flat=True))
            folders = [{"id": f.id, "name": f.name} for f in sub.order_by("name") if set(folder_tree_ids(f.id)) & ids_docs]
        return {"documents": rows, "tags": sorted(used.values(), key=lambda t: t["name"].lower()), "folders": folders, "scope": scope.name if scope else "", "theme": theme(),
                "user": {"in": authed, "can_upload": bool(authed and can_upload(me))}}

    @system.route("GET", "blocks/link/<id>", public=True)
    def blocks_link(request, id):
        me = request.user
        d = by_id(Document, id)
        ok = bool(d and ((me and me.is_authenticated and doc_level(me, d) >= 1) or is_public(d)))
        if not ok:
            return bad(T("Dit document is niet beschikbaar."), 404)
        return {"path": "/api/plugins/run/documents/get/" + signing.dumps({"d": d.id, "u": me.id if me and me.is_authenticated else 0}, salt="documents-download")}

    def parts():
        return [
            {"key": "list", "title": "Documenten: bestandslijst", "file": "web/block.html", "query": {"view": "list"}},
            {"key": "cards", "title": "Documenten: tegels", "file": "web/block.html", "query": {"view": "cards"}},
            {"key": "latest", "title": "Documenten: laatste uploads", "file": "web/block.html", "query": {"view": "latest", "limit": "6"}},
            {"key": "tags", "title": "Documenten: per tag", "file": "web/block.html", "query": {"view": "tags"}},
            {"key": "folders", "title": "Documenten: mappen", "file": "web/block.html", "query": {"view": "folders"}},
            {"key": "search", "title": "Documenten: zoeken", "file": "web/block.html", "query": {"view": "search"}},
            {"key": "upload", "title": "Documenten: uploadformulier", "file": "web/block.html", "query": {"view": "upload"}},
        ]

    system.provide("parts", parts)

    # ── admin ──
    @system.route("GET", "admin/overview")
    def overview(request):
        if not is_admin(request.user):
            return bad(T("Je hebt hier geen rechten voor."), 403)
        qs = Document.objects.all()
        return {"documents": qs.count(), "size": sum(qs.values_list("size", flat=True)), "folders": Folder.objects.count(), "tags": Tag.objects.count(), "local": qs.filter(storage="local").count(), "s3": qs.filter(storage="s3").count(),
                "encrypted": qs.filter(encrypted=True).count(), "shared": Access.objects.count(), "target": target(), "encrypt": bool(cfg.get("encrypt")), "s3_available": bool(s3())}

    @system.route("POST", "admin/apply")
    def apply_settings(request):
        """Bring the existing documents in line with the settings: to S3 (or back) and encrypted (or not)."""
        if not is_admin(request.user):
            return bad(T("Je hebt hier geen rechten voor."), 403)
        done, failed = 0, []
        want_enc, want_store = bool(cfg.get("encrypt")), target()
        for d in Document.objects.select_related("folder__parent"):
            if d.encrypted == want_enc and d.storage == want_store:
                continue
            try:
                data = content(d)
                old_storage, old_key = d.storage, d.key
                store(d, data)
                d.save()
                delete_raw(old_storage, old_key)
                done += 1
            except Exception as e:  # noqa: BLE001 - one broken document must not stop the rest
                failed.append({"id": d.id, "title": d.title, "error": str(e)[:120]})
        return {"changed": done, "failed": failed[:20]}

    # ── demo data (Super admin → Demo-gegevens, and the standard installations) ──
    from datetime import timedelta

    from django.utils import timezone

    DEMO_TAGS = [("Contract", "blue"), ("Factuur", "orange"), ("Beleid", "purple"), ("Notulen", "teal"), ("Vertrouwelijk", "red"), ("Concept", "gray"), ("Definitief", "green"), ("Klant", "pink")]
    DEMO_TREE = {"Contracten": ["2025", "2026"], "Financieel": ["Facturen", "Begrotingen"], "Marketing": ["Campagnes"], "Personeel": [], "Vergaderingen": []}
    DEMO_DOCS = [  # (map, titel, bestandsnaam, tags, tekst)
        ("Contracten/2026", "Raamovereenkomst Hebbes", "raamovereenkomst-hebbes.pdf", ["Contract", "Klant", "Definitief"], "Raamovereenkomst voor het leveren van webdiensten, looptijd 12 maanden."),
        ("Contracten/2026", "Onderhoudscontract website", "onderhoudscontract.pdf", ["Contract", "Concept"], "Onderhoud, back-ups en updates van de website, per maand opzegbaar."),
        ("Contracten/2025", "Verwerkersovereenkomst", "verwerkersovereenkomst.pdf", ["Contract", "Beleid", "Vertrouwelijk"], "Afspraken over het verwerken van persoonsgegevens (AVG)."),
        ("Financieel/Facturen", "Factuur 2026-001", "factuur-2026-001.pdf", ["Factuur", "Klant"], "Factuur voor ontwerp en inrichting, betaalbaar binnen 14 dagen."),
        ("Financieel/Facturen", "Factuur 2026-002", "factuur-2026-002.pdf", ["Factuur", "Klant"], "Factuur voor hosting en onderhoud, eerste kwartaal."),
        ("Financieel/Begrotingen", "Begroting 2026", "begroting-2026.csv", ["Vertrouwelijk", "Concept"], "Post;Bedrag\nHosting;1200\nLicenties;2400\nMarketing;3000\nOverig;800\n"),
        ("Financieel", "Uitgavenoverzicht", "uitgaven.csv", ["Vertrouwelijk"], "Maand;Uitgaven\njanuari;4120\nfebruari;3980\nmaart;4310\n"),
        ("Marketing/Campagnes", "Campagneplan voorjaar", "campagneplan-voorjaar.txt", ["Concept"], "Doel: meer bezoekers en aanmeldingen. Kanalen: e-mail, social en zoekmachine."),
        ("Marketing", "Huisstijlgids", "huisstijlgids.pdf", ["Beleid", "Definitief"], "Kleuren, lettertypen en het gebruik van het logo."),
        ("Personeel", "Verlofregeling", "verlofregeling.pdf", ["Beleid", "Definitief"], "Afspraken over vakantie, verlof en ziekmelden."),
        ("Vergaderingen", "Notulen kwartaaloverleg", "notulen-kwartaaloverleg.txt", ["Notulen"], "Aanwezig: team en directie. Besluit: nieuwe website live voor 1 juni."),
        ("", "Welkom bij het documentbeheer", "welkom.txt", ["Definitief"], "Hier staan de documenten van het team. Upload, geef tags en deel ze met mensen of groepen."),
    ]

    def demo_pdf(title, text):
        try:
            from reportlab.lib.pagesizes import A4
            from reportlab.pdfgen import canvas

            buf = io.BytesIO()
            c = canvas.Canvas(buf, pagesize=A4)
            c.setFont("Helvetica-Bold", 18)
            c.drawString(60, 780, title)
            c.setFont("Helvetica", 11)
            y = 745
            for line in re.findall(r".{1,90}(?:\s|$)", text + " Dit is een voorbeelddocument (demo).") or [text]:
                c.drawString(60, y, line.strip())
                y -= 16
            c.save()
            return buf.getvalue()
        except Exception:  # noqa: BLE001 - without reportlab it becomes a text file with the same name
            return (title + "\n\n" + text + "\n").encode()

    class DocumentsDemo:
        def counts(self):
            return {"documents": Document.objects.filter(demo=True).count(), "folders": Folder.objects.filter(demo=True).count(), "tags": Tag.objects.filter(demo=True).count()}

        def create(self, objects=True, orders=True, use_media=False, sets=None):
            if Document.objects.filter(demo=True).exists():
                return {}
            owner = U.objects.filter(is_staff=True).order_by("id").first()
            tags = {n: Tag.objects.get_or_create(name=n, defaults={"color": c, "demo": True})[0] for n, c in DEMO_TAGS}
            folders = {}
            for top, subs in DEMO_TREE.items():
                folders[top] = Folder.objects.create(name=top, owner=owner, demo=True)
                for s in subs:
                    folders[f"{top}/{s}"] = Folder.objects.create(name=s, parent=folders[top], owner=owner, demo=True)
            demo_users = list(U.objects.filter(email__startswith="demo-", email__endswith="@example.com").order_by("id")[:8])
            team, _ = UserGroup.objects.get_or_create(slug="demo-team", defaults={"name": "Demo: Team", "description": "Voorbeeldgroep voor het documentbeheer"})
            board, _ = UserGroup.objects.get_or_create(slug="demo-directie", defaults={"name": "Demo: Directie", "description": "Voorbeeldgroep voor het documentbeheer"})
            for u in demo_users[:5]:
                u.user_groups.add(team)
            for u in demo_users[:2]:
                u.user_groups.add(board)
            made = 0
            for i, (path, title, fname, tg, text) in enumerate(DEMO_DOCS):
                doc = Document(title=title, description=text[:200] if not fname.endswith(".csv") else "Voorbeeldgegevens", folder=folders.get(path), filename=fname, owner=owner, demo=True,
                               mime=mimetypes.guess_type(fname)[0] or "application/octet-stream")
                data = demo_pdf(title, text) if fname.endswith(".pdf") else text.encode()
                if fname.endswith(".pdf") and not data.startswith(b"%PDF"):
                    doc.filename = fname[:-4] + ".txt"
                    doc.mime = "text/plain"
                store(doc, data)
                doc.save()
                Document.objects.filter(pk=doc.pk).update(created_at=timezone.now() - timedelta(days=3 * (len(DEMO_DOCS) - i)))
                for n in tg:
                    DocTag.objects.get_or_create(document=doc, tag=tags[n])
                made += 1
            # rights: the team may read and edit marketing and meetings, the board manages finance and contracts; one document is shared with a person; the welcome note is for everybody
            for top, grp, lv in (("Marketing", team, 2), ("Vergaderingen", team, 1), ("Financieel", board, 3), ("Contracten", board, 3), ("Personeel", team, 1)):
                Access.objects.create(folder=folders[top], group_id=grp.id, level=lv)
            Access.objects.create(folder=folders["Contracten/2026"], group_id=team.id, level=1)
            Access.objects.create(document=Document.objects.get(filename__startswith="welkom"), everyone=True, level=1)
            for pub in ("huisstijlgids", "welkom"):  # for everybody on the website, also visitors
                Access.objects.create(document=Document.objects.get(filename__startswith=pub), public=True, level=1)
            for fname, rounds in (("begroting-2026.csv", ("Post;Bedrag\nHosting;1250\nLicenties;2400\nMarketing;3200\nOverig;800\n", "Post;Bedrag\nHosting;1250\nLicenties;2600\nMarketing;3200\nOverig;900\nReserve;500\n")),
                                  ("campagneplan-voorjaar.txt", ("Doel: meer bezoekers en aanmeldingen. Kanalen: e-mail, social, zoekmachine en advertenties.",))):
                doc = Document.objects.get(filename=fname)
                for n, text in enumerate(rounds, 1):
                    new_version(doc, text.encode(), owner, note=T("Bijgewerkt na overleg") if n == 1 else T("Definitieve cijfers"))
            if demo_users:
                Access.objects.create(document=Document.objects.get(filename__startswith="begroting"), user=demo_users[-1], level=1)
            return {"documents": made, "folders": len(folders), "tags": len(tags)}

        def remove(self):
            n = Document.objects.filter(demo=True).count()
            purge_docs(Document.objects.filter(demo=True))
            purge_folders(list(Folder.objects.filter(demo=True, parent__isnull=True).values_list("id", flat=True)))
            DocTag.objects.filter(tag__demo=True).delete()
            Tag.objects.filter(demo=True).delete()
            UserGroup.objects.filter(slug__in=["demo-team", "demo-directie"]).delete()
            return {"documents": n}

    system.provide("demo", DocumentsDemo())

    class DocumentsStats:
        """Statistieken → tab Documentbeheer."""
        def widgets(self, days=30):
            from django.db.models import Count, Sum
            from django.utils import timezone

            docs = Document.objects.all()
            mb = round((docs.aggregate(n=Sum("size"))["n"] or 0) / 1048576, 1)
            top_tags = [(Tag.objects.filter(pk=r["tag_id"]).values_list("name", flat=True).first() or "?", r["n"]) for r in DocTag.objects.values("tag_id").annotate(n=Count("id")).order_by("-n")[:10]]
            by_type = {}
            for fn in docs.values_list("filename", flat=True):
                e = os.path.splitext(fn)[1].lower().lstrip(".") or "—"
                by_type[e] = by_type.get(e, 0) + 1
            owners = [(person(U.objects.filter(pk=r["owner_id"]).first()) or "?", r["n"]) for r in docs.exclude(owner=None).values("owner_id").annotate(n=Count("id")).order_by("-n")[:8]]
            from datetime import timedelta
            ds = [timezone.localdate() - timedelta(days=i) for i in range(days - 1, -1, -1)]
            made = {}
            for d in docs.filter(created_at__date__gte=ds[0]).values_list("created_at", flat=True):
                made[d.date()] = made.get(d.date(), 0) + 1
            return [
                {"type": "number", "title": "Documenten", "value": docs.count(), "sub": f"{Folder.objects.count()} mappen"}, {"type": "number", "title": "Opslag", "value": f"{mb} MB", "sub": f"{docs.filter(storage='s3').count()} op S3"},
                {"type": "number", "title": "Versleuteld", "value": docs.filter(encrypted=True).count()}, {"type": "number", "title": "Versies bewaard", "value": DocVersion.objects.count()},
                {"type": "number", "title": "Gedeeld (regels)", "value": Access.objects.count(), "sub": f"{Access.objects.filter(public=True).count()} voor iedereen"}, {"type": "number", "title": "Tags", "value": Tag.objects.count()},
                {"type": "series", "title": "Nieuwe documenten per dag", "points": [{"x": d.isoformat(), "y": made.get(d, 0)} for d in ds]},
                {"type": "bars", "title": "Meest gebruikte tags", "rows": [{"label": a, "value": b} for a, b in top_tags]}, {"type": "bars", "title": "Soort bestand", "rows": [{"label": a, "value": b} for a, b in sorted(by_type.items(), key=lambda kv: -kv[1])[:10]]},
                {"type": "bars", "title": "Meeste documenten per eigenaar", "rows": [{"label": a, "value": b} for a, b in owners]},
            ]

    system.provide("stats", DocumentsStats())
