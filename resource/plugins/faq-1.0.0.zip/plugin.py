# Copyright & Ownership Notice
# easy2Edit is the exclusive legal property of RST Coaching & Consultancy B.V. (RSTCC),
# owned by Ronald Stolk. All rights reserved. Any unauthorized use, copying, modification,
# reproduction, distribution, or commercial exploitation of Easy2Edit, including its source code,
# is strictly prohibited without prior written permission from Ronald Stolk or RSTCC.
# website https://rstcc.net


"""FAQ van je website (plugin). Je eigen veelgestelde vragen, zelf te maken en te vertalen, op de pagina /faq.

Dit was een vast onderdeel van het systeem (apps/faq: FaqEntry en user_views); nu een plugin. De code staat in faq_lib/, de routes zijn nog steeds /api/faq/... (System.mount) en de tabel
van het systeem uit de tijd dat dit nog het systeem was (faq_faqentry) wordt bij het starten hernoemd naar plg_faq_faqentry; er gaat geen gegeven verloren.
De uitleg van Easy2edit zelf (de helpmodule, de helpteksten) en de instellingen van de FAQ-pagina (menu, icoon, openbaar of privé) blijven in het systeem."""
import importlib
import inspect
import sys

PKG = "faq_lib"


def register(system):
    from django.db import connection, models

    for k in [k for k in sys.modules if k == PKG or k.startswith(PKG + ".")]:  # what an earlier load left behind (the models are made again)
        del sys.modules[k]

    models_mod = importlib.import_module(f"{PKG}.models")
    classes = [c for _n, c in inspect.getmembers(models_mod, inspect.isclass) if issubclass(c, models.Model) and c.__module__ == models_mod.__name__]

    # the table of the system from before (faq_faqentry) is renamed once: the data goes with it
    existing = set(connection.introspection.table_names())
    with connection.cursor() as cur:
        for m in classes:
            old, new = "faq_" + m.__name__.lower(), m._meta.db_table
            if old in existing and new not in existing:
                cur.execute(f'ALTER TABLE "{old}" RENAME TO "{new}"')
                existing.discard(old)
                existing.add(new)
    system.sync_models(*classes)

    importlib.import_module(f"{PKG}.views")
    urls = importlib.import_module(f"{PKG}.urls")
    system.mount(urls.urlpatterns)

    class Faq:
        models = models_mod

    system.provide("faq", Faq)
