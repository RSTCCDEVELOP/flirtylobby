# Copyright & Ownership Notice
# easy2Edit is the exclusive legal property of RST Coaching & Consultancy B.V. (RSTCC),
# owned by Ronald Stolk. All rights reserved. Any unauthorized use, copying, modification,
# reproduction, distribution, or commercial exploitation of Easy2Edit, including its source code,
# is strictly prohibited without prior written permission from Ronald Stolk or RSTCC.
# website https://rstcc.net


"""The model of the plugin FAQ: the table is the one of the system from before (faq_faqentry), now plg_faq_faqentry (renamed when the plugin starts)."""
from django.db import models

LABEL, PREFIX = "plugin_faq", "plg_faq_"


class FaqEntry(models.Model):
    """A question of the website owner's own FAQ (the page /faq): question and answer per language."""

    question = models.JSONField(default=dict)  # {"nl": "...", "en": "..."}
    answer = models.JSONField(default=dict)
    category = models.JSONField(default=dict, blank=True)  # optional heading per language
    order = models.PositiveIntegerField(default=0)
    active = models.BooleanField(default=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        app_label = LABEL
        db_table = PREFIX + "faqentry"
        ordering = ["order", "id"]
