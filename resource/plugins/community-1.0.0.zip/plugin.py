"""Community (plugin). Profielen, zoeken en matchen, berichten, chat en de directe verbinding.

Dit was een vast onderdeel van het systeem (apps/social); nu een plugin. De code staat in community_lib/ (dezelfde modules als eerst: models, service, views, discover, direct, availability,
themes, geocode), de routes zijn nog steeds /api/profile/..., /api/discover/..., /api/messages/..., /api/chat/... en /api/direct/... (System.mount), en de tabellen van het systeem uit de tijd
dat dit nog het systeem was (social_*) worden bij het starten hernoemd naar plg_community_*; er gaat geen gegeven verloren.
Het systeem en andere plugins vragen om hulp via `system.provide("community", ...)`: zie de klasse Community onderaan."""
import importlib
import inspect
import logging
import sys

logger = logging.getLogger(__name__)
PKG = "community_lib"


def register(system):
    from django.contrib.auth import get_user_model
    from django.db import connection, models
    from django.db.models.signals import pre_delete

    for k in [k for k in sys.modules if k == PKG or k.startswith(PKG + ".")]:  # what an earlier load left behind (the models are made again)
        del sys.modules[k]

    models_mod = importlib.import_module(f"{PKG}.models")
    classes = [c for _n, c in inspect.getmembers(models_mod, inspect.isclass) if issubclass(c, models.Model) and c.__module__ == models_mod.__name__]

    # the tables of the system from before (social_<model>) are renamed once: the data goes with them
    existing = set(connection.introspection.table_names())
    with connection.cursor() as cur:
        for m in classes:
            old, new = "social_" + m.__name__.lower(), m._meta.db_table
            if old in existing and new not in existing:
                cur.execute(f'ALTER TABLE "{old}" RENAME TO "{new}"')
                existing.discard(old)
                existing.add(new)
    system.sync_models(*classes)

    parts = {name: importlib.import_module(f"{PKG}.{name}") for name in ("service", "themes", "availability", "geocode", "discover", "direct", "views")}
    importlib.import_module(f"{PKG}.backup")  # (registers the settings of the community in the settings backup)
    urls = importlib.import_module(f"{PKG}.urls")
    system.mount(urls.urlpatterns)

    User = get_user_model()

    class Community:
        models = models_mod
        service, themes, availability, geocode, discover, direct, views = (parts[n] for n in ("service", "themes", "availability", "geocode", "discover", "direct", "views"))

        @staticmethod
        def purge_user(user_id):
            """Everything of this member goes (the database does not do that for the tables of a plugin): the profile with its photos, messages, likes, blocks, requests, rooms."""
            M = models_mod
            profiles = list(M.Profile.objects.filter(user_id=user_id).values_list("id", flat=True))
            rooms = list(M.DirectRoom.objects.filter(owner_id=user_id).values_list("id", flat=True))
            M.ProfilePhoto.objects.filter(profile_id__in=profiles).delete()
            M.ProfileAllow.objects.filter(profile_id__in=profiles).delete()
            M.ProfileVisit.objects.filter(profile_id__in=profiles).delete()
            M.DirectSignal.objects.filter(room_id__in=rooms).delete()
            for model in classes:
                if model in (M.ProfilePhoto, M.ProfileAllow, M.ProfileVisit, M.DirectSignal):
                    continue
                for f in model._meta.fields:
                    if isinstance(f, models.ForeignKey) and f.related_model is User:
                        model.objects.filter(**{f.attname: user_id}).delete()

    def purge(sender, instance, **kwargs):
        Community.purge_user(instance.pk)

    pre_delete.connect(purge, sender=User, dispatch_uid="community_purge_user", weak=False)
    system.provide("community", Community)
