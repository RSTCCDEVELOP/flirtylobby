# Copyright & Ownership Notice
# easy2Edit is the exclusive legal property of RST Coaching & Consultancy B.V. (RSTCC),
# owned by Ronald Stolk. All rights reserved. Any unauthorized use, copying, modification,
# reproduction, distribution, or commercial exploitation of Easy2Edit, including its source code,
# is strictly prohibited without prior written permission from Ronald Stolk or RSTCC.
# website https://rstcc.net

"""Community themes: ready-made sets of profile fields (and which built-in fields are shown).
Everything here is only a starting point: admins edit fields, options and visibility on Admin -> Community (no code needed).

Field spec: key, label, type (text | textarea | number | select | multiselect | checkbox | date | url), options (select/multiselect),
unit (number), required, visibility (public | members | friends | hidden), card (show on member cards), filter (search filter), group.
"""

BUILTIN_KEYS = ["headline", "bio", "gender", "birth_date", "city", "interests", "aim"]
BUILTIN_LABELS = {
    "headline": "Kopregel", "bio": "Over mij", "gender": "Geslacht", "birth_date": "Leeftijd / geboortedatum", "city": "Plaats en land",
    "interests": "Interesses (tags)", "aim": "Wat zoek ik",
}
TYPES = ["text", "textarea", "number", "select", "multiselect", "checkbox", "date", "url"]
VISIBILITY = ["public", "members", "friends", "hidden"]


def f(key, label, type="text", options=None, **kw):
    return {"key": key, "label": label, "type": type, "options": options or [], "unit": kw.get("unit", ""), "required": kw.get("required", False),
            "visibility": kw.get("visibility", "members"), "card": kw.get("card", False), "filter": kw.get("filter", False), "group": kw.get("group", "")}


ORIENTATION_OPTIONS = ["Heteroseksueel", "Homoseksueel", "Biseksueel", "Panseksueel", "Anders", "Liever niet zeggen"]

_BASIC_THEME = {
    "normal": {
        "label": "Normaal", "desc": "Een eenvoudig ledenprofiel: kopregel, over mij, plaats en interesses.",
        "builtin": {"headline": True, "bio": True, "gender": True, "birth_date": True, "city": True, "interests": True, "aim": False},
        "fields": [
            f("occupation", "Beroep of bezigheid", "text", visibility="public", card=True, filter=True, group="Over mij"),
            f("languages", "Talen", "multiselect", ["Nederlands", "Engels", "Duits", "Frans", "Spaans", "Anders"], visibility="members", filter=True, group="Over mij"),
            f("education", "Opleiding", "select", ["MBO", "HBO", "WO", "Anders"], visibility="members", group="Over mij"),
            f("hobbies", "Hobby's", "text", visibility="members", group="Over mij"),
            f("website", "Website", "url", visibility="public", group="Links"),
            f("instagram", "Instagram", "url", visibility="members", group="Links"),
        ],
    },
}


from collections.abc import Mapping  # noqa: E402


def _pack_provider():
    from apps.plugins import facade

    return facade.provider("profilethemes")


class _Themes(Mapping):
    """The themes: "normal" is here, the others come from the plugin Profielthema's (when it is on); without it only the basic theme exists."""

    def _all(self):
        out = dict(_BASIC_THEME)
        p = _pack_provider()
        if p is not None:
            try:
                for k, v in p.packages().items():
                    out[k] = v  # (also "normal": the basic theme can be changed in the plugin)
            except Exception:  # noqa: BLE001 - never block the profiles on a broken theme store
                pass
        return out

    def __getitem__(self, k):
        return self._all()[k]

    def __iter__(self):
        return iter(self._all())

    def __len__(self):
        return len(self._all())


THEMES = _Themes()


# Colour themes a member can give his profile page (Wijzig profiel -> Design). The colours live in the frontend (lib/profile-designs.js).
PROFILE_DESIGNS = ["ocean", "forest", "sunset", "midnight", "lavender", "mono", "rose", "rainbow", "trans", "bi", "lesbian", "nonbinary"]


# What members can look for ("Ik zoek"). The admin switches them on and off (Community -> Algemeen). Switching one on adds its profile fields
# (also as search filters); switching it off removes those fields again. "default" is the state of a new site.
AIM_OPTIONS = [
    {"key": "dating", "label": "Daten", "desc": "Kennismaken met het oog op een date.", "default": True, "fields": []},
    {"key": "relationship", "label": "Een relatie", "desc": "Op zoek naar een vaste partner.", "default": True, "fields": []},
    {"key": "friends", "label": "Vriendschap", "desc": "Nieuwe vrienden maken.", "default": True, "fields": []},
    {"key": "chat", "label": "Gewoon chatten", "desc": "Alleen een praatje, zonder verplichtingen.", "default": True, "fields": []},
    {"key": "appointments", "label": "Afspraakjes", "desc": "Vrijblijvend afspreken, zonder vaste relatie.", "default": False, "fields": [
        f("availability", "Wanneer kan ik afspreken", "multiselect", ["Overdag", "Avond", "Weekend", "Flexibel"], visibility="members", filter=True, group="Afspraken"),
        f("meet_place", "Waar spreek ik af", "multiselect", ["Bij mij thuis", "Bij jou thuis", "Neutrale plek", "Hotel"], visibility="members", group="Afspraken")]},
    {"key": "erotic", "label": "Erotiek", "desc": "Erotische contacten voor volwassenen (alleen 18+). Gevoelige gegevens: vermeld dit in je privacybeleid.", "default": False, "fields": [
        f("erotic_wish", "Wat zoek ik", "multiselect", ["Vrijblijvend", "Vaste afspraak", "Open relatie", "Swingen", "Fetisj / BDSM", "Anders"], visibility="members", filter=True, group="Erotiek"),
        f("erotic_limits", "Grenzen", "textarea", visibility="friends", group="Erotiek")]},
    {"key": "activities", "label": "Samen op pad", "desc": "Samen iets ondernemen: uit eten, wandelen, concerten.", "default": False, "fields": [
        f("activities", "Activiteiten", "multiselect", ["Uit eten", "Wandelen", "Concert", "Theater", "Sporten", "Uitgaan", "Cultuur"], visibility="members", filter=True, group="Samen op pad")]},
    {"key": "travel", "label": "Reisgenoot", "desc": "Samen op reis.", "default": False, "fields": [
        f("travel_style", "Reisstijl", "select", ["Stedentrip", "Strand", "Actief", "Rondreis", "Camping"], visibility="members", filter=True, group="Reizen"),
        f("travel_when", "Wanneer", "text", visibility="members", group="Reizen")]},
]
AIM_KEYS = [o["key"] for o in AIM_OPTIONS]


# How the search page looks per theme: which built-in filters show, and whether the swipe deck (like Tinder) is on by default.
SEARCH = {
    "normal": {"title": "Leden zoeken", "filters": ["q", "gender", "age", "city", "country", "interest", "distance", "sort", "online", "photo"], "swipe": False},
}


def layout_of(key):
    """How the profile page of this theme looks (the plugin Profielthema's lets the superadmin choose): "default" = the own design of the theme."""
    p = _pack_provider()
    return (p.layout(key) if p is not None else None) or "default"


def search_config(key):
    p = _pack_provider()
    return (p.search(key) if p is not None else None) or SEARCH.get(key) or SEARCH["normal"]


def theme_payload(key):
    t = THEMES[key]
    return {"theme": key, "builtin": dict(t["builtin"]), "fields": [dict(x, options=list(x["options"])) for x in t["fields"]]}


BASIC = "normal"  # the basic theme: always on


def enabled():
    """The profile themes that may be used (a superadmin switches them on): only the basic one by default. The theme in use always stays available."""
    from apps.core.models import SystemSettings

    from . import service

    stored = SystemSettings.objects.filter(pk=1).values_list("data", flat=True).first() or {}
    on = {k for k in (stored.get("community_themes") or []) if k in THEMES}
    try:
        on.add(service.get()["profiles"]["theme"])
    except Exception:  # noqa: BLE001
        pass
    return on | {BASIC}


def set_enabled(keys):
    from apps.core.models import SystemSettings

    row, _ = SystemSettings.objects.get_or_create(pk=1)
    data = dict(row.data or {})
    data["community_themes"] = [k for k in THEMES if k in set(keys) and k != BASIC]
    row.data = data
    row.save()


def public_list(everything=False):
    on = enabled()
    return [{"key": k, "label": t["label"], "desc": t["desc"], "fields": len(t["fields"]), "enabled": k in on} for k, t in THEMES.items() if everything or k in on]
