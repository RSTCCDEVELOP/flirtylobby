# Copyright & Ownership Notice
# easy2Edit is the exclusive legal property of RST Coaching & Consultancy B.V. (RSTCC),
# owned by Ronald Stolk. All rights reserved. Any unauthorized use, copying, modification,
# reproduction, distribution, or commercial exploitation of Easy2Edit, including its source code,
# is strictly prohibited without prior written permission from Ronald Stolk or RSTCC.
# website https://rstcc.net

"""Community settings (profiles, search, messages, chat)."""
from apps.core.settings_backup import register

from .models import SocialSettings


def _export(opts):
    return SocialSettings.objects.filter(pk=1).values_list("data", flat=True).first() or {}


def _apply(data, ctx):
    if not isinstance(data, dict):
        raise ValueError("Ongeldige community-instellingen.")
    obj, _ = SocialSettings.objects.get_or_create(pk=1)
    obj.data = data  # the community code merges stored values with its defaults and ignores unknown keys
    obj.save()
    return "Community-instellingen geladen (thema, profielvelden, zoeken, berichten, chat)."


register("community", "Community", _export, _apply, description="Profielthema en -velden, zoeken en swipen, berichten en chat.", order=35)
