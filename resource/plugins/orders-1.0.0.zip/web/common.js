/* Hulpfuncties voor de pagina's van deze plugin (zonder framework). Gebruikt window.system uit het systeem. */
var t = function () { return system.t.apply(system, arguments); };
var $ = function (s, r) { return (r || document).querySelector(s); };
function esc(s) { return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); }
var RUN = "/plugins/run/orders/";
function api(path, opts) { return system.api(RUN + path, opts); }
function money(v, cur) { try { return new Intl.NumberFormat(document.documentElement.lang || "nl", { style: "currency", currency: cur || "EUR" }).format(Number(v)); } catch (e) { return "€ " + Number(v).toFixed(2); } }
function height() {  /* a popup lies over the page: the frame must be as high as the popup, else it is cut off */
  var o = document.querySelector(".overlay"), m = o && o.firstElementChild, want = m ? Math.ceil(m.getBoundingClientRect().bottom + 24) + "px" : "";
  if (document.body.style.minHeight !== want) document.body.style.minHeight = want;
  system.resize(Math.ceil(Math.max(document.documentElement.scrollHeight, document.body.scrollHeight)));
}
new MutationObserver(function () { height(); }).observe(document.documentElement, { childList: true, subtree: true, attributes: true });
window.addEventListener("load", height);
document.addEventListener("click", function (e) {  /* a link with data-go opens an address of the website */
  var a = e.target.closest && e.target.closest("[data-go]");
  if (a) { e.preventDefault(); system.go(a.getAttribute("data-go")); }
});
function boot(fn) { system.ready.then(function (ctx) { return fn(ctx); }).catch(function (e) { document.body.innerHTML = '<div class="alert">' + esc(e.message || e) + "</div>"; }); }
