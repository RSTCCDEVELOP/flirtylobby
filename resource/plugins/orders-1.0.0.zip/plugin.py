# Copyright & Ownership Notice
# easy2Edit is the exclusive legal property of RST Coaching & Consultancy B.V. (RSTCC),
# owned by Ronald Stolk. All rights reserved. Any unauthorized use, copying, modification,
# reproduction, distribution, or commercial exploitation of Easy2Edit, including its source code,
# is strictly prohibited without prior written permission from Ronald Stolk or RSTCC.
# website https://rstcc.net

"""Orders (plugin). De bestellingen van de hele site: webshop, abonnementen en donaties, met de bestelstatus, btw-instellingen en de bevestigingsmail.

De gegevens staan in de database van het systeem (tabellen plg_orders_*). De plugin werkt ook alleen (betalen per factuur); Betalen en Webshop hebben hem nodig.
Het systeem (abonnementen, donaties, dashboard, account wissen) en de plugins vragen de plugin om hulp via `system.provide("orders", ...)`: zie de klasse Orders onderaan.

Routes: /api/plugins/run/orders/<pad>. Openbaar: order/<nummer>?t=<token>. Ingelogd: mine. Beheer: admin/orders, admin/orders/<id>, admin/settings."""
import logging
import secrets
from datetime import date, timedelta
from decimal import ROUND_HALF_UP, Decimal

from django.db import models
from django.db.models import Q
from rest_framework import status
from rest_framework.response import Response

logger = logging.getLogger(__name__)
TWO = Decimal("0.01")
TARIFFS = [{"key": "hoog", "name": "Hoog tarief", "rate": "21"}, {"key": "laag", "name": "Laag tarief", "rate": "9"}]  # the VAT rates of the shop: products and shipping point at one of them
DEFAULTS = {"pay_online": True, "currency": "EUR"}  # (what the shop pays with and the VAT tariffs come from the plugin Financieel and the system table Btw)
STATUSES = [("new", "Nieuw"), ("pending_payment", "Wacht op betaling"), ("paid", "Betaald"), ("processing", "In behandeling"), ("shipped", "Verzonden"),
            ("completed", "Afgerond"), ("returned", "Retour"), ("canceled", "Geannuleerd"), ("refunded", "Terugbetaald")]
KINDS = [("shop", "Webshop"), ("subscription", "Abonnement"), ("donation", "Donatie")]
money = lambda v: Decimal(str(v or 0)).quantize(TWO, rounding=ROUND_HALF_UP)  # noqa: E731


def register(system):
    from apps.accounts.access import level

    label = system.app_label

    def table(name, **extra):
        return type("Meta", (), {"app_label": label, "db_table": system.db_prefix + name, **extra})

    class OrderSettings(models.Model):
        data = models.JSONField(default=dict, blank=True)
        Meta = table("settings")

    class Order(models.Model):
        number = models.CharField(max_length=20, unique=True, blank=True)
        token = models.CharField(max_length=40)
        status = models.CharField(max_length=20, choices=STATUSES, default="new")
        name = models.CharField(max_length=150)
        email = models.EmailField()
        phone = models.CharField(max_length=30, blank=True)
        street = models.CharField(max_length=200)
        postal_code = models.CharField(max_length=20)
        city = models.CharField(max_length=100)
        country = models.CharField(max_length=2, default="NL")
        note = models.TextField(blank=True)
        internal_note = models.TextField(blank=True)
        subtotal = models.DecimalField(max_digits=10, decimal_places=2, default=0)
        shipping = models.DecimalField(max_digits=10, decimal_places=2, default=0)
        shipping_method = models.CharField(max_length=100, blank=True)
        discount = models.DecimalField(max_digits=10, decimal_places=2, default=0)
        discount_code = models.CharField(max_length=40, blank=True)
        vat_total = models.DecimalField(max_digits=10, decimal_places=2, default=0)
        total = models.DecimalField(max_digits=10, decimal_places=2, default=0)
        currency = models.CharField(max_length=3, default="EUR")
        payment_ref = models.CharField(max_length=30, blank=True)
        user = models.ForeignKey(system.User, null=True, blank=True, on_delete=models.SET_NULL, related_name="+")
        kind = models.CharField(max_length=12, choices=KINDS, default="shop", db_index=True)
        ref_id = models.PositiveIntegerField(null=True, blank=True)  # subscription / donation this order belongs to
        period_no = models.PositiveIntegerField(default=1)  # 1 = first order of a subscription, 2+ = repeats
        demo = models.BooleanField(default=False)  # an example order made by the demo content of the webshop
        created_at = models.DateTimeField(auto_now_add=True)
        updated_at = models.DateTimeField(auto_now=True)
        Meta = table("order", ordering=["-created_at", "-id"])

        def get_status_display(self):
            return dict(STATUSES).get(self.status, self.status)

    class OrderItem(models.Model):
        order = models.ForeignKey(Order, on_delete=models.CASCADE, related_name="items")
        product = models.PositiveIntegerField(null=True, blank=True)  # id of the product in the webshop plugin (None for subscriptions and donations)
        name = models.CharField(max_length=200)
        sku = models.CharField(max_length=60, blank=True)
        unit_price = models.DecimalField(max_digits=10, decimal_places=2)
        quantity = models.PositiveIntegerField()
        line_total = models.DecimalField(max_digits=10, decimal_places=2)  # incl. VAT, after discount
        vat_rate = models.DecimalField(max_digits=4, decimal_places=1, default=0)
        vat_amount = models.DecimalField(max_digits=10, decimal_places=2, default=0)
        option = models.CharField(max_length=80, blank=True)  # the chosen variant and size ("rood|m"): the webshop puts the right stock back when the order is cancelled
        Meta = table("item")

    class OrderDoc(models.Model):
        """A document of an order: packing slip, invoice, return form or credit invoice. `data` is the snapshot it is drawn from (an invoice never changes afterwards)."""
        order = models.ForeignKey(Order, on_delete=models.CASCADE, related_name="docs")
        kind = models.CharField(max_length=10, db_index=True)  # packing | invoice | return | credit
        number = models.CharField(max_length=30, unique=True)
        data = models.JSONField(default=dict, blank=True)
        total = models.DecimalField(max_digits=10, decimal_places=2, default=0)
        created_by = models.ForeignKey(system.User, null=True, blank=True, on_delete=models.SET_NULL, related_name="+", db_constraint=False)
        created_at = models.DateTimeField(auto_now_add=True)
        Meta = table("doc", ordering=["created_at", "id"])

    system.sync_models(OrderSettings, Order, OrderItem, OrderDoc)

    from django.db.models.signals import pre_delete

    def detach_deleted_user(sender, instance, **kwargs):  # (a table of a plugin is not known to the database cascade of the system: the orders stay, without the person)
        Order.objects.filter(user_id=instance.pk).update(user=None)

    pre_delete.connect(detach_deleted_user, sender=system.User, dispatch_uid="orders_detach_user", weak=False)
    from django.db import connection

    have = {c.name for c in connection.introspection.get_table_description(connection.cursor(), Order._meta.db_table)}
    ihave = {c.name for c in connection.introspection.get_table_description(connection.cursor(), OrderItem._meta.db_table)}
    if "option" not in ihave:
        with connection.schema_editor() as se:
            fo_ = OrderItem._meta.get_field("option")
            sql_, params_ = se.column_sql(OrderItem, fo_, include_default=True)
            se.execute("ALTER TABLE %s ADD COLUMN %s %s" % (se.quote_name(OrderItem._meta.db_table), se.quote_name(fo_.column), sql_), params_)
    if "demo" not in have:  # a table of an older version of the plugin gets the new column
        with connection.schema_editor() as se:
            f_ = Order._meta.get_field("demo")
            sql_, params_ = se.column_sql(Order, f_, include_default=True)
            se.execute("ALTER TABLE %s ADD COLUMN %s %s" % (se.quote_name(Order._meta.db_table), se.quote_name(f_.column), sql_), params_)

    # ── settings ──────────────────────────────────────────────────────────────
    def settings():
        d = dict(DEFAULTS)
        d.update(OrderSettings.objects.filter(pk=1).values_list("data", flat=True).first() or {})
        d.update({"vat_tariffs": TARIFFS, "default_tariff": "hoog", "shipping_tariff": "hoog", "default_vat": "21", "shipping_vat": "21", "vat_rates": ["21", "9"], "prices_include_vat": True})  # (until the plugin Financieel says otherwise)
        from apps import commerce

        fin = commerce.finance()  # payment options and terms: the plugin Financieel
        if fin:
            d.update(fin.vat())  # the VAT tariffs live in the plugin Financieel (tab Btw)
            fs = fin.settings()
            d.update({k: fs[k] for k in ("pay_online", "pay_invoice", "payment_days", "quote_days", "payment_terms", "currency") if k in fs})
        return d

    def rate(v):
        r = Decimal(str(v).replace(",", "."))
        if not 0 <= r <= 50:
            raise ValueError(system.t("Btw-percentage tussen 0 en 50."))
        return r

    def clean_tariffs(raw):
        from django.utils.text import slugify

        out, seen = [], set()
        for x in (raw if isinstance(raw, list) else [])[:12]:
            if not isinstance(x, dict):
                continue
            name = str(x.get("name") or "").strip()[:30]
            if not name:
                raise ValueError(system.t("Elk btw-tarief heeft een naam."))
            try:
                r = rate(x.get("rate"))
            except ArithmeticError:
                raise ValueError(system.t("Btw-percentage tussen 0 en 50."))
            key = str(x.get("key") or "") or slugify(name) or "tarief"
            n = 2
            while key in seen:
                key, n = f"{slugify(name) or 'tarief'}-{n}", n + 1
            seen.add(key)
            out.append({"key": key, "name": name, "rate": format(r.normalize(), "f")})
        if not out:
            raise ValueError(system.t("Minimaal één btw-tarief."))
        return out

    # ── the work on an order ──────────────────────────────────────────────────
    def confirmation_mail(order):
        """Order confirmation to the customer (captured by the sandbox when it is on)."""
        from apps.communication import sending

        lines = [f"- {i.quantity} × {i.name}: € {i.line_total}" for i in order.items.all()]
        extra = (f"Korting ({order.discount_code}): -€ {order.discount}\n" if order.discount else "") + f"Verzending ({order.shipping_method}): € {order.shipping}\n"
        body = (f"Bedankt voor je bestelling, {order.name}.\n\nBestelnummer: {order.number}\n\n" + "\n".join(lines) + "\n\n" + extra +
                f"Totaal: € {order.total} (waarvan € {order.vat_total} btw)\n\nBezorgadres:\n{order.street}\n{order.postal_code} {order.city}\n")
        try:
            sending.send_email(order.email, f"Bevestiging van je bestelling {order.number}", body, purpose="notifications")
        except Exception as e:  # an e-mail problem must never fail the order
            logger.warning("Order mail failed for %s: %s", order.number, e)

    def restock(order):
        """A cancelled webshop order: the webshop plugin puts the stock (and the discount code) back."""
        from apps.commerce import catalog

        catalog.restock(order)

    def after_status(order, before):
        """The status changed (by an admin or a payment): stock, subscriptions, notification."""
        if order.status == before:
            return
        from apps.plugins.facade import subs

        subs.on_order_status(order, before)
        try:
            from apps.notifications.service import notify

            if order.user_id:
                notify(order.user, "order", f"Bestelling {order.number}: {order.status}", url="/dashboard/plugins/orders")
        except Exception:  # noqa: BLE001
            pass

    def on_payment(payment):
        """Called by the payment engine after each status change of a payment."""
        order = Order.objects.filter(payment_ref=payment.ref).first()
        if not order:
            return
        before = order.status
        if payment.status == "paid" and before in ("new", "pending_payment"):
            order.status = "paid"
            order.save(update_fields=["status"])
            if order.kind == "shop":
                confirmation_mail(order)
        elif payment.status in ("failed", "canceled", "expired") and before == "pending_payment":
            order.status = "canceled"
            order.save(update_fields=["status"])
            if order.kind == "shop":
                restock(order)
        elif payment.status == "refunded":
            order.status = "refunded"
            order.save(update_fields=["status"])
        logger.info("Order %s: %s -> %s (payment %s)", order.number, before, order.status, payment.status)
        after_status(order, before)

    def create_simple(user, kind, ref_id, title, amount, vat_rate, period_no=1, contact=None):
        """One order with one line: a subscription period or a donation."""
        c = contact or {}
        amount = money(amount)
        vat = money(amount - amount / (1 + Decimal(str(vat_rate)) / 100)) if vat_rate else Decimal("0.00")
        name = c.get("name") or (user.get_full_name() or user.email or user.username if user else "") or "Onbekend"
        order = Order.objects.create(
            token=secrets.token_urlsafe(18), kind=kind, ref_id=ref_id, period_no=period_no, status="new", name=name[:150],
            email=(c.get("email") or (user.email if user else "") or "")[:254], phone=(getattr(user, "phone", "") or "")[:30],
            street=(c.get("street") or getattr(user, "address", "") or "-")[:200], postal_code=(getattr(user, "postal_code", "") or "-")[:20],
            city=(getattr(user, "city", "") or "-")[:100], country=(getattr(user, "country", "") or "NL")[:2], subtotal=amount, vat_total=vat, total=amount,
            currency=settings()["currency"], user=user, shipping_method="-")
        order.number = f"{order.created_at.year}-{order.id:05d}"
        order.save(update_fields=["number"])
        OrderItem.objects.create(order=order, product=None, name=title[:200], sku=kind, unit_price=amount, quantity=1, line_total=amount, vat_rate=vat_rate or 0, vat_amount=vat)
        return order

    # ── what the system and the other plugins may ask ─────────────────────────
    order_model, item_model = Order, OrderItem

    class Orders:
        Order, OrderItem = order_model, item_model
        STATUSES = STATUSES

        @staticmethod
        def number(order):
            order.number = f"{order.created_at.year}-{order.id:05d}"
            order.save(update_fields=["number"])
            return order

        @staticmethod
        def open_orders(kind, ref_id):
            return Order.objects.filter(kind=kind, ref_id=ref_id, status__in=("new", "pending_payment"))

        @staticmethod
        def recent(n=6):
            return [{"number": o.number, "name": o.name, "total": str(o.total), "status": o.status, "at": o.created_at} for o in Order.objects.all()[:n]]

        @staticmethod
        def revenue_rows(since):
            """[{d: date, n: orders, t: total}] of the orders since a date, without cancelled and refunded ones."""
            from django.db.models import Count, Sum
            from django.db.models.functions import TruncDate

            return list(Order.objects.filter(created_at__gte=since).exclude(status__in=["canceled", "refunded"]).annotate(d=TruncDate("created_at")).values("d").annotate(n=Count("id"), t=Sum("total")))

        @staticmethod
        def anonymize(user, blank):
            """Account removal: the orders stay (accounting) but lose the person."""
            Order.objects.filter(user=user).update(user=None, **blank)

        @staticmethod
        def mark_demo(order, status=None, days_ago=0):
            """An example order (demo content): flagged so it can be removed again, given a status and (optionally) an order date in the past.
            An order that is paid gets its documents like a real one: an invoice (and a packing slip when it is a shop order that is on its way)."""
            order.demo = True
            if status:
                order.status = status
            order.save()
            if days_ago:
                from datetime import timedelta

                from django.utils import timezone

                Order.objects.filter(pk=order.pk).update(created_at=timezone.now() - timedelta(days=days_ago, hours=order.pk % 7))
            if order.status in PAID_ON:
                o = Order.objects.filter(pk=order.pk).prefetch_related("items", "docs").first()
                kinds = ["invoice"] + (["packing"] if o.kind == "shop" and o.status in ("processing", "shipped", "completed") else [])
                for kind in kinds:
                    if not o.docs.filter(kind=kind).exists():
                        snap = snapshot(o, kind, None)
                        OrderDoc.objects.create(order=o, kind=kind, number=snap["number"], data=snap, total=Decimal(snap["total"]))
            return order

        @staticmethod
        def demo_count(kinds=("shop",)):
            """The example orders of the webshop (the example orders of gifts and subscriptions belong to those demo parts)."""
            return Order.objects.filter(demo=True, kind__in=list(kinds)).count()

        @staticmethod
        def remove_demo(kinds=None):
            """Remove the example orders (of these kinds: "shop", "subscription", "donation"; all when none are named)."""
            qs = Order.objects.filter(demo=True, **({"kind__in": list(kinds)} if kinds else {}))
            n = qs.count()
            OrderDoc.objects.filter(order__in=qs).delete()
            OrderItem.objects.filter(order__in=qs).delete()  # (the cascade of the system does not know the models of a plugin: the lines first)
            qs.delete()
            return n

        @staticmethod
        def detach_users(user_ids):
            """Before users are deleted: their orders stay, without the person."""
            return Order.objects.filter(user_id__in=list(user_ids)).update(user=None)

        @staticmethod
        def open_count():
            return Order.objects.filter(status__in=("new", "paid", "processing")).count()

    def save_settings(incoming):
        """The settings that are not VAT live in the plugin Financieel (payment options, terms, company data, layouts)."""
        fin = commerce_finance()
        return fin.save_settings(incoming) if fin else settings()

    def commerce_finance():
        from apps import commerce

        return commerce.finance()

    for fn in (settings, save_settings, create_simple, confirmation_mail, restock, on_payment, after_status):  # (a name assigned in a class body cannot be read from the function around it)
        setattr(Orders, fn.__name__, staticmethod(fn))
    system.provide("orders", Orders())

    # ── routes ────────────────────────────────────────────────────────────────
    def finance():
        from apps import commerce

        return commerce.finance()

    def body(request):
        return request.data if isinstance(request.data, dict) else {}

    # ── documents: pakbon, factuur, retourformulier, creditfactuur ────────────
    DOC_KINDS = {"quote": "Offerte", "packing": "Pakbon", "invoice": "Factuur", "return": "Retourformulier", "credit": "Creditfactuur"}
    PAID_ON = ("paid", "processing", "shipped", "completed", "returned", "refunded")

    def doc_options(o):
        """What can be made now, with the reason when it cannot: the documents follow the status of the order."""
        have = {x.kind for x in o.docs.all()}
        st, out = o.status, []
        rules = {
            "quote": (st not in ("canceled",) and "invoice" not in have, "Een offerte maak je vóór de factuur."),
            "packing": (st in ("paid", "processing", "shipped", "completed"), "Een pakbon maak je als de bestelling betaald is."),
            "invoice": (st not in ("canceled",), "Voor een geannuleerde bestelling maak je geen factuur."),
            "return": (st in ("shipped", "completed", "returned"), "Een retourformulier maak je vanaf Verzonden."),
            "credit": ("invoice" in have and st in ("paid", "processing", "shipped", "completed", "returned", "refunded") and "credit" not in have, "Een creditfactuur kan pas als er een factuur is, en maar één keer."),
        }
        for k, (ok, why) in rules.items():
            if k == "packing" and o.kind != "shop":
                ok, why = False, "Een pakbon is er alleen voor webshopbestellingen."
            if k == "return" and o.kind != "shop":
                ok, why = False, "Een retourformulier is er alleen voor webshopbestellingen."
            if k in ("invoice", "credit") and k in have and k != "credit":
                ok, why = False, "Er is al een factuur."
            out.append({"kind": k, "label": DOC_KINDS[k], "ok": bool(ok), "why": "" if ok else why, "done": k in have})
        return out

    def next_number(kind, o):
        prefix = {"quote": "O", "invoice": "F", "credit": "C"}.get(kind)
        if not prefix:
            return ("PB-" if kind == "packing" else "RT-") + o.number
        year = date.today().year
        mark = f"{prefix}{year}-"
        top = max([int(x.number.rsplit("-", 1)[1]) for x in OrderDoc.objects.filter(kind=kind, number__startswith=mark) if x.number.rsplit("-", 1)[1].isdigit()] or [0])
        return f"{mark}{top + 1:05d}"

    def carrier_name(o):
        """The transporter of the order (from its shipping method), for the barcode of the return form."""
        try:
            from apps.commerce import catalog

            c = catalog.carrier_of(o.shipping_method)
            return (c or {}).get("slug", "")
        except Exception:  # noqa: BLE001
            return ""

    def snapshot(o, kind, ref=None):
        sign = Decimal("-1") if kind == "credit" else Decimal("1")
        nr = lambda v: format(Decimal(str(v)).normalize(), "f")  # noqa: E731 - "21.0" -> "21"
        by_rate, base_by = {}, {}
        lines = list(o.items.all())
        for i in lines:
            r = nr(i.vat_rate)
            by_rate[r] = by_rate.get(r, Decimal("0")) + i.vat_amount * sign
            base_by[r] = base_by.get(r, Decimal("0")) + (i.line_total - i.vat_amount) * sign
        ship_vat = max(Decimal("0"), o.vat_total - sum((i.vat_amount for i in lines), Decimal("0"))) if o.shipping else Decimal("0")  # the VAT of the shipping costs is in the total of the order, not in a line
        if o.shipping:
            r = nr(settings()["shipping_vat"])
            by_rate[r] = by_rate.get(r, Decimal("0")) + ship_vat * sign
            base_by[r] = base_by.get(r, Decimal("0")) + (o.shipping - ship_vat) * sign
        return {
            "kind": kind, "number": next_number(kind, o), "date": date.today().strftime("%d-%m-%Y"), "currency": o.currency, "ref": ref, "paid": o.status in PAID_ON,
            "seller": (finance().company() if finance() else {}), "payment_days": settings().get("payment_days", 14), "payment_terms": settings().get("payment_terms", ""), "valid_until": (date.today() + timedelta(days=settings().get("quote_days", 30))).strftime("%d-%m-%Y"), "carrier": carrier_name(o),
            "customer": {"name": o.name, "email": o.email, "phone": o.phone, "street": o.street, "postal_code": o.postal_code, "city": o.city, "country": o.country},
            "order": {"number": o.number, "created": o.created_at.strftime("%d-%m-%Y"), "note": o.note},
            "items": [{"name": i.name, "sku": i.sku, "quantity": i.quantity, "unit_price": str(i.unit_price * sign), "vat_rate": nr(i.vat_rate), "line_total": str(i.line_total * sign), "vat_amount": str(i.vat_amount * sign)} for i in lines],
            "shipping": str(o.shipping * sign), "shipping_vat": str(ship_vat * sign), "shipping_method": o.shipping_method, "discount": str(o.discount * sign), "discount_code": o.discount_code,
            "vat_total": str(o.vat_total * sign), "vat_by_rate": {k: str(v) for k, v in by_rate.items()}, "base_by_rate": {k: str(v) for k, v in base_by.items()}, "total": str(o.total * sign),
        }

    def bad(text, code=400):
        return Response({"detail": text}, status=code)

    def lv(request):
        return level(request.user, "orders")

    def row(o, full=True):
        d = {"id": o.id, "number": o.number, "status": o.status, "status_label": o.get_status_display(), "name": o.name, "email": o.email, "phone": o.phone, "street": o.street,
             "postal_code": o.postal_code, "city": o.city, "country": o.country, "note": o.note, "internal_note": o.internal_note, "subtotal": str(o.subtotal), "shipping": str(o.shipping),
             "shipping_method": o.shipping_method, "discount": str(o.discount), "discount_code": o.discount_code, "vat_total": str(o.vat_total), "total": str(o.total), "currency": o.currency,
             "payment_ref": o.payment_ref, "created_at": o.created_at, "demo": o.demo, "kind": o.kind, "ref_id": o.ref_id, "period_no": o.period_no}
        if full:
            d["docs"] = [{"id": x.id, "kind": x.kind, "number": x.number, "created_at": x.created_at, "total": str(x.total)} for x in o.docs.all()]
            d["can_make"] = doc_options(o)
            d["items"] = [{"id": i.id, "product": i.product, "name": i.name, "sku": i.sku, "unit_price": str(i.unit_price), "quantity": i.quantity, "line_total": str(i.line_total),
                           "vat_rate": str(i.vat_rate), "vat_amount": str(i.vat_amount)} for i in o.items.all()]
        return d

    @system.route("GET", "admin/orders")
    def admin_list(request):
        if lv(request) < 1:
            return bad(system.t("Geen toegang."), 403)
        qs, p = Order.objects.prefetch_related("items", "docs"), request.query_params
        if p.get("status"):
            qs = qs.filter(status=p["status"])
        if p.get("kind"):
            qs = qs.filter(kind=p["kind"])
        if q := p.get("q"):
            qs = qs.filter(Q(number__icontains=q) | Q(name__icontains=q) | Q(email__icontains=q))
        return [row(o) for o in qs[:500]]

    @system.route("PATCH", "admin/orders/<id>")
    def admin_update(request, id):  # noqa: A002
        if lv(request) < 2:
            return bad(system.t("Geen toegang."), 403)
        o = Order.objects.filter(pk=id).first() if str(id).isdigit() else None
        if not o:
            return bad(system.t("Niet gevonden."), 404)
        b, old = body(request), o.status
        if "status" in b:
            if b["status"] not in dict(STATUSES):
                return bad(system.t("Onbekende status."))
            o.status = b["status"]
        if "internal_note" in b:
            o.internal_note = str(b["internal_note"])[:2000]
        o.save()
        if o.status == "canceled" and old not in ("canceled", "refunded") and o.kind == "shop":
            restock(o)  # the reserved stock goes back
        after_status(o, old)
        logger.info("Order %s: %s -> %s by %s", o.number, old, o.status, request.user.email)
        return row(o)

    @system.route("POST", "admin/orders/<id>/docs")
    def doc_make(request, id):  # noqa: A002
        """Make a document of the order. The document follows the status: a packing slip puts a paid order In behandeling, a return form makes it Retour, a credit invoice makes it Terugbetaald."""
        if lv(request) < 2:
            return bad(system.t("Geen toegang."), 403)
        o = Order.objects.filter(pk=id).prefetch_related("items", "docs").first() if str(id).isdigit() else None
        if not o:
            return bad(system.t("Niet gevonden."), 404)
        kind = body(request).get("kind")
        opt = next((x for x in doc_options(o) if x["kind"] == kind), None)
        if not opt:
            return bad(system.t("Onbekend document."))
        if not opt["ok"]:
            return bad(system.t(opt["why"]))
        ref = None
        if kind == "credit":
            ref = OrderDoc.objects.filter(order=o, kind="invoice").first().number
        snap = snapshot(o, kind, ref)
        old = o.status
        d = OrderDoc.objects.create(order=o, kind=kind, number=snap["number"], data=snap, total=Decimal(snap["total"]), created_by=request.user)
        new = {"packing": "processing" if old == "paid" else old, "return": "returned", "credit": "refunded"}.get(kind, old)
        if new != old:
            o.status = new
            o.save()
            after_status(o, old)
        logger.info("Order %s: %s %s made by %s (status %s -> %s)", o.number, kind, d.number, request.user.email, old, o.status)
        o = Order.objects.filter(pk=o.pk).prefetch_related("items", "docs").first()
        return Response({"doc": {"id": d.id, "kind": d.kind, "number": d.number}, "order": row(o)}, status=201)

    @system.route("GET", "admin/docs/<id>/link")
    def doc_link(request, id):  # noqa: A002
        if lv(request) < 1:
            return bad(system.t("Geen toegang."), 403)
        d = OrderDoc.objects.filter(pk=id).first() if str(id).isdigit() else None
        if not d:
            return bad(system.t("Niet gevonden."), 404)
        from django.core import signing

        return {"path": "/api/plugins/run/orders/doc/" + signing.dumps({"d": d.id}, salt="orders-doc"), "filename": f"{d.number}.pdf"}  # short-lived: the link is the permission

    @system.route("DELETE", "admin/docs/<id>")
    def doc_delete(request, id):  # noqa: A002
        """Remove a document: only superadmins and roles with the permission orders.documents (an invoice number that is gone leaves a gap in the numbering). The status of the order stays as it is."""
        if not may_delete_docs(request.user):
            return bad(system.t("Je mag documenten van orders niet verwijderen."), 403)
        d = OrderDoc.objects.filter(pk=id).select_related("order").first() if str(id).isdigit() else None
        if not d:
            return bad(system.t("Niet gevonden."), 404)
        oid, number = d.order_id, d.number
        d.delete()
        logger.info("Order document %s removed by %s", number, request.user.email)
        return row(Order.objects.filter(pk=oid).prefetch_related("items", "docs").first())

    @system.route("GET", "doc/<token>", public=True)
    def doc_pdf(request, token):
        from django.core import signing
        from django.http import HttpResponse

        try:
            p = signing.loads(token, salt="orders-doc", max_age=300)
        except signing.BadSignature:
            return HttpResponse(status=404)
        d = OrderDoc.objects.filter(pk=p.get("d")).first()
        if not d:
            return HttpResponse(status=404)
        try:
            fin = finance()
            if not fin:
                return HttpResponse(system.t("De plugin Financieel staat uit: zet hem aan bij Admin → Plugins."), status=503)
            pdf = fin.render(d.data, system.t)
        except Exception:  # noqa: BLE001
            logger.exception("Order document %s could not be made", d.number)
            return HttpResponse(system.t("Het document kon niet worden gemaakt."), status=500)
        r = HttpResponse(pdf, content_type="application/pdf")
        r["Content-Disposition"] = 'inline; filename="%s.pdf"' % d.number
        r["Cache-Control"] = "private, no-store"
        return r

    @system.route("DELETE", "admin/orders/<id>")
    def admin_delete(request, id):  # noqa: A002
        if lv(request) < 3:
            return bad(system.t("Geen toegang."), 403)
        if str(id).isdigit():
            OrderDoc.objects.filter(order_id=id).delete()
            OrderItem.objects.filter(order_id=id).delete()  # (the lines first: see Orders.remove_demo)
            Order.objects.filter(pk=id).delete()
        return Response(status=status.HTTP_204_NO_CONTENT)

    def catalog():
        from apps.plugins import runtime

        return runtime.provider("catalog")

    @system.route("GET", "admin/catalog")
    def admin_catalog(request):
        """The products and shipping methods that can be put on an order made by hand (empty without the webshop)."""
        if lv(request) < 2:
            return bad(system.t("Geen toegang."), 403)
        c = catalog()
        return {"products": c.products_detail() if c else [], "methods": c.methods() if c else []}

    @system.route("POST", "admin/orders")
    def admin_create(request):
        """An order made by hand: customer details and products from the shop."""
        if lv(request) < 2:
            return bad(system.t("Geen toegang."), 403)
        c = catalog()
        if not c:
            return bad(system.t("Hiervoor is de plugin Webshop nodig."))
        b = body(request)
        data = {k: str(b.get(k) or "").strip()[:n] for k, n in {"name": 150, "email": 254, "phone": 30, "street": 200, "postal_code": 20, "city": 100, "country": 2, "note": 1000}.items()}
        data["country"] = (data["country"] or "NL").upper()
        if not data["name"] or "@" not in data["email"]:
            return bad(system.t("Vul minstens een naam en een geldig e-mailadres in."))
        for k in ("street", "postal_code", "city"):
            data[k] = data[k] or "-"
        m = b.get("method")
        try:
            o = c.create_order(data, b.get("items") or [], m if isinstance(m, int) else None, str(b.get("code") or ""), None)
        except ValueError as e:
            return bad(str(e))
        confirmation_mail(o)
        logger.info("Order %s made by hand by %s", o.number, request.user.email)
        return Response(row(o), status=201)

    def may_delete_docs(user):
        """Superadmins, and everybody whose role has the permission "orders.documents" (the Admin role has every permission) and who may edit orders."""
        if not (user and user.is_authenticated):
            return False
        return bool(user.is_staff or (level(user, "orders") >= 2 and "orders.documents" in user.permission_keys()))

    @system.route("GET", "admin/settings")
    def settings_get(request):
        if lv(request) < 1:
            return bad(system.t("Geen toegang."), 403)
        return {**settings(), "level": min(3, max(0, lv(request))), "statuses": [[k, v] for k, v in STATUSES], "may_delete_docs": may_delete_docs(request.user)}

    @system.route("GET", "mine")
    def mine(request):
        """The member's own orders (webshop, subscriptions and donations that made an order), newest first."""
        return [{"number": o.number, "token": o.token, "status": o.status, "status_label": o.get_status_display(), "kind": o.kind, "total": str(o.total), "currency": o.currency,
                 "created_at": o.created_at} for o in Order.objects.filter(user=request.user).order_by("-id")[:100]]

    @system.route("GET", "order/<number>", public=True)
    def public_order(request, number):
        o = Order.objects.filter(number=number, token=request.query_params.get("t", "-")).prefetch_related("items").first()
        if not o:
            return bad(system.t("Niet gevonden."), 404)
        d = row(o)
        for k in ("internal_note", "id", "payment_ref", "docs", "can_make"):
            d.pop(k, None)
        return d
