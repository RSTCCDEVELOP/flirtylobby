// Copyright & Ownership Notice
// easy2Edit is the exclusive legal property of RST Coaching & Consultancy B.V. (RSTCC),
// owned by Ronald Stolk. All rights reserved. Any unauthorized use, copying, modification,
// reproduction, distribution, or commercial exploitation of Easy2Edit, including its source code,
// is strictly prohibited without prior written permission from Ronald Stolk or RSTCC.
// website https://rstcc.net

/* Helpers for the pages of Mailform (no framework). Uses window.system. */
var t = function () { return system.t.apply(system, arguments); };
var $ = function (s, r) { return (r || document).querySelector(s); };
function esc(s) { return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); }
var RUN = "/plugins/run/mailform/";
function api(path, opts) { return system.api(RUN + path, opts); }
/* one-colour icons (currentColor) */
var ICON = {
  plus: '<path d="M12 5v14M5 12h14"/>', trash: '<path d="M4 7h16M10 11v6M14 11v6M6 7l1 12h10l1-12M9 7V4h6v3"/>', copy: '<rect x="9" y="9" width="11" height="11" rx="2"/><path d="M5 15V6a2 2 0 0 1 2-2h9"/>',
  grip: '<path d="M9 6h.01M9 12h.01M9 18h.01M15 6h.01M15 12h.01M15 18h.01"/>', mail: '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3 7l9 6 9-6"/>',
  send: '<path d="M21 3L10 14M21 3l-7 18-4-7-7-4z"/>', eye: '<path d="M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',
  refresh: '<path d="M20 11a8 8 0 0 0-14-4L4 9M4 4v5h5M4 13a8 8 0 0 0 14 4l2-2M20 20v-5h-5"/>',
  flask: '<path d="M9 3h6M10 3v6l-5 9a2 2 0 0 0 2 3h10a2 2 0 0 0 2-3l-5-9V3"/>', back: '<path d="M15 5l-7 7 7 7"/>',
  text: '<path d="M5 7V5h14v2M12 5v14M9 19h6"/>', at: '<circle cx="12" cy="12" r="4"/><path d="M16 12v1.500a2.500 2.500 0 0 0 5 0V12a9 9 0 1 0-3.500 7"/>', phone: '<path d="M6 3h4l2 5-2.500 1.500a11 11 0 0 0 5 5L16 12l5 2v4a2 2 0 0 1-2 2A16 16 0 0 1 4 6a2 2 0 0 1 2-3z"/>',
  hash: '<path d="M5 9h14M5 15h14M10 4L8 20M16 4l-2 16"/>', calendar: '<rect x="4" y="5" width="16" height="15" rx="2"/><path d="M4 10h16M8 3v4M16 3v4"/>', para: '<path d="M4 6h16M4 11h16M4 16h10"/>',
  select: '<rect x="3" y="6" width="18" height="12" rx="2"/><path d="M9 11l3 3 3-3"/>', radio: '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="3"/>', check: '<rect x="4" y="4" width="16" height="16" rx="3"/><path d="M8 12l3 3 5-6"/>',
  heading: '<path d="M6 5v14M18 5v14M6 12h12"/>', hidden: '<path d="M3 3l18 18M10.600 6.100A9 9 0 0 1 12 6c6 0 10 6 10 6a17 17 0 0 1-3 3.500M6.500 6.500A17 17 0 0 0 2 12s4 7 10 7a9 9 0 0 0 4-1"/>'
};
function icon(n, size) { return '<svg class="ic" width="' + (size || 16) + '" height="' + (size || 16) + '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + (ICON[n] || "") + "</svg>"; }
function typeLabel(x) { return { text: t("Tekst"), email: t("E-mail"), tel: t("Telefoon"), number: t("Getal"), date: t("Datum"), textarea: t("Lange tekst"), select: t("Keuzelijst"), radio: t("Keuzerondjes"), checkbox: t("Vinkvakje"), heading: t("Kopje"), hidden: t("Verborgen veld") }[x] || x; }
var TYPE_ICON = { text: "text", email: "at", tel: "phone", number: "hash", date: "calendar", textarea: "para", select: "select", radio: "radio", checkbox: "check", heading: "heading", hidden: "hidden" };
function height() { system.resize(Math.ceil(Math.max(document.documentElement.scrollHeight, document.body.scrollHeight))); }
new MutationObserver(height).observe(document.documentElement, { childList: true, subtree: true, attributes: true });
window.addEventListener("load", height); window.addEventListener("resize", height);
function pageDone() { try { system.loaded(); } catch (e) { /* an older system */ } }
function boot(fn) { system.ready.then(function (ctx) { return fn(ctx); }).then(function () { setTimeout(pageDone, 60); }).catch(function (e) { document.body.innerHTML = '<p class="alert">' + esc(e && e.message || e) + "</p>"; pageDone(); }); }

/* the form as the visitor sees it (also used for the live preview in the designer) */
var uid = 0;
function fieldHtml(x) {
  var id = "mf" + (++uid), req = x.required ? " required" : "", ph = x.placeholder ? ' placeholder="' + esc(x.placeholder) + '"' : "", nm = ' name="' + esc(x.name) + '"';
  var lab = x.label ? "<label" + (x.type === "radio" ? "" : ' for="' + id + '"') + ">" + esc(x.label) + (x.required ? ' <span class="req" aria-hidden="true">*</span>' : "") + "</label>" : "";
  if (x.type === "heading") return '<h3 class="fh">' + esc(x.label) + "</h3>";
  if (x.type === "hidden") return "";
  if (x.type === "textarea") return '<div class="fld">' + lab + '<textarea id="' + id + '"' + nm + req + ph + ' rows="5"></textarea></div>';
  if (x.type === "select") return '<div class="fld">' + lab + '<select id="' + id + '"' + nm + req + '><option value="">' + esc(t("Kies…")) + "</option>" + (x.options || []).map(function (o) { return "<option>" + esc(o) + "</option>"; }).join("") + "</select></div>";
  if (x.type === "radio") return '<div class="fld" role="radiogroup">' + lab + (x.options || []).map(function (o) { return '<label class="opt"><input type="radio"' + nm + ' value="' + esc(o) + '"' + req + "> " + esc(o) + "</label>"; }).join("") + "</div>";
  if (x.type === "checkbox") return '<div class="fld"><label class="opt"><input id="' + id + '" type="checkbox"' + nm + req + "> " + esc(x.label) + (x.required ? ' <span class="req" aria-hidden="true">*</span>' : "") + "</label></div>";
  return '<div class="fld">' + lab + '<input id="' + id + '" type="' + (["email", "tel", "number", "date"].indexOf(x.type) >= 0 ? x.type : "text") + '"' + nm + req + ph + (x.type === "email" ? ' autocomplete="email"' : "") + "></div>";
}
function formHtml(D) {
  return '<form class="mf e2e-card" data-easy2edit-tag="ui-form" novalidate>' + (D.title ? "<h2>" + esc(D.title) + "</h2>" : "") + (D.intro ? '<p class="muted">' + esc(D.intro) + "</p>" : "") +
    (D.fields || []).map(fieldHtml).join("") + '<div class="hp" aria-hidden="true"><input type="text" name="website" tabindex="-1" autocomplete="off"></div>' +
    (D.captcha ? '<div class="fld cap"><label>' + esc(t("Typ de tekens uit het plaatje")) + ' <span class="req" aria-hidden="true">*</span></label><div class="row"><span class="cimg" aria-live="polite"></span><button type="button" class="sm" data-newcap title="' + esc(t("Nieuw plaatje")) + '">' + icon("refresh") + '</button></div><input type="text" name="_captcha" autocomplete="off" autocapitalize="characters" maxlength="8" style="margin-top:.4rem;max-width:12rem"></div>' : "") +
    (D.verify_email ? '<div class="fld vc"><label>' + esc(t("Verificatiecode uit je e-mail")) + ' <span class="req" aria-hidden="true">*</span></label><div class="row"><button type="button" class="sm" data-sendcode>' + icon("mail") + " " + esc(t("Stuur mij een code")) + '</button><input type="text" name="_code" inputmode="numeric" autocomplete="one-time-code" maxlength="6" placeholder="000000" style="max-width:9rem"></div><small class="vcmsg muted" role="status"></small></div>' : "") +
    '<div class="row"><button class="primary" type="submit" data-easy2edit-tag="ui-button">' + icon("send") + " " + esc(D.button || t("Verstuur")) + '</button><span class="msg" role="status"></span></div></form>';
}
function formValues(form, D) {
  var v = {};
  (D.fields || []).forEach(function (x) {
    if (x.type === "heading" || x.type === "hidden") return;
    var els = form.querySelectorAll('[name="' + x.name + '"]');
    if (x.type === "checkbox") v[x.name] = !!(els[0] && els[0].checked);
    else if (x.type === "radio") { var c = form.querySelector('[name="' + x.name + '"]:checked'); v[x.name] = c ? c.value : ""; }
    else v[x.name] = els[0] ? els[0].value : "";
  });
  return v;
}

/* captcha (characters of a picture) and e-mail code of a public form: wiring; returns {extra(): fields for the submit, reset()} */
function wireChecks(form, D, slug) {
  var st = { ctoken: "", vtoken: "" }, base = "forms/" + encodeURIComponent(slug);
  function newCap() {
    var box = form.querySelector(".cimg"); if (!box) return Promise.resolve();
    return api(base + "/captcha").then(function (r) { st.ctoken = r.token; box.innerHTML = r.svg; var i = form.elements._captcha; if (i) i.value = ""; });
  }
  var nb = form.querySelector("[data-newcap]"); if (nb) nb.onclick = function () { newCap(); };
  var sb = form.querySelector("[data-sendcode]"), vm = form.querySelector(".vcmsg");
  if (sb) sb.onclick = function () {
    var em = (D.fields || []).filter(function (x) { return x.type === "email"; }), el = null;
    em.forEach(function (x) { var e = form.querySelector('[name="' + x.name + '"]'); if (!el && e && e.value) el = e; });
    if (!el) { vm.textContent = t("Vul eerst je e-mailadres in."); return; }
    sb.disabled = true; vm.textContent = "";
    api(base + "/code", { method: "POST", body: { email: el.value, website: form.elements.website.value, captcha_token: st.ctoken, captcha: form.elements._captcha ? form.elements._captcha.value : "" } }).then(function (r) {
      st.vtoken = r.token || ""; vm.textContent = t("De code is verstuurd naar {0}.", el.value) + (r.test_code ? " " + t("(Testmodus: de code is {0})", r.test_code) : "");
    }).catch(function (e) { vm.textContent = e && e.message || String(e); newCap(); }).then(function () { sb.disabled = false; });
  };
  newCap();
  return {
    extra: function () { return { captcha_token: st.ctoken, captcha: form.elements._captcha ? form.elements._captcha.value : "", code_token: st.vtoken, code: form.elements._code ? form.elements._code.value : "" }; },
    reset: function () { st.vtoken = ""; if (vm) vm.textContent = ""; return newCap(); }
  };
}
