# Copyright & Ownership Notice
# easy2Edit is the exclusive legal property of RST Coaching & Consultancy B.V. (RSTCC),
# owned by Ronald Stolk. All rights reserved. Any unauthorized use, copying, modification,
# reproduction, distribution, or commercial exploitation of Easy2Edit, including its source code,
# is strictly prohibited without prior written permission from Ronald Stolk or RSTCC.
# website https://rstcc.net

"""Mailform (plugin). Mail forms that are designed with drag and drop (fields, order, and per field: sent or not sent), mailed through the easy2edit Postmark link
(default) or another mail link, with a test mode that shows how the mail arrives. Every form is a system object for pages (parts). Tables: plg_mailform_*.
Routes: /api/plugins/run/mailform/<path>; the pages are in web/."""
import hashlib
import hmac
import random
import re
import time

from django.core import signing
from django.core.cache import cache
from django.db import models
from django.utils import timezone
from django.utils.text import slugify
from rest_framework.response import Response

TYPES = ("text", "email", "tel", "number", "date", "textarea", "select", "radio", "checkbox", "heading", "hidden")
MAX_FIELDS = 40
MAX_LEN = 5000
PER_HOUR = 60  # submissions per form per hour (a simple brake against spam)
MIN_SECONDS = 2  # a human needs more than this to fill a form
DEFAULT_FIELDS = [
    {"id": "f1", "type": "text", "name": "name", "label": "Naam", "required": True, "send": True, "placeholder": "", "options": []},
    {"id": "f2", "type": "email", "name": "email", "label": "E-mailadres", "required": True, "send": True, "placeholder": "", "options": []},
    {"id": "f3", "type": "textarea", "name": "message", "label": "Bericht", "required": True, "send": True, "placeholder": "", "options": []},
]


def register(system):
    from apps.accounts.access import level

    T = system.t
    label = system.app_label
    cfg = system.config
    bad = lambda msg, code=400: Response({"detail": msg}, status=code)  # noqa: E731

    def table(name):
        return type("Meta", (), {"app_label": label, "db_table": system.db_prefix + name})

    class Form(models.Model):
        name = models.CharField(max_length=120)
        slug = models.SlugField(max_length=80, unique=True)
        title = models.CharField(max_length=200, blank=True)  # heading above the form (empty: none)
        intro = models.TextField(blank=True)
        fields = models.JSONField(default=list, blank=True)
        recipients = models.CharField(max_length=400, blank=True)  # comma separated
        subject = models.CharField(max_length=200, default="Nieuw bericht via {form}")
        integration = models.CharField(max_length=50, blank=True)  # slug of the mail link; empty = the easy2edit Postmark link (or the first mail link)
        reply_field = models.CharField(max_length=60, blank=True)  # field name whose value becomes the reply-to
        button = models.CharField(max_length=60, default="Verstuur")
        success = models.CharField(max_length=300, default="Bedankt! Je bericht is verstuurd.")
        captcha = models.BooleanField(default=False)  # the visitor types the characters of a picture before sending
        verify_email = models.BooleanField(default=False)  # the visitor gets a code by e-mail and types it before sending
        verify_field = models.CharField(max_length=60, blank=True)  # the e-mail field that gets the code (empty: the reply field, else the first e-mail field)
        test_mode = models.BooleanField(default=True)  # test mode: nothing goes to the recipients; the mail is shown on screen
        active = models.BooleanField(default=True)
        order = models.PositiveIntegerField(default=0)
        Meta = table("form")

    class Message(models.Model):
        form = models.ForeignKey(Form, on_delete=models.CASCADE, related_name="+")
        data = models.JSONField(default=dict, blank=True)
        subject = models.CharField(max_length=300, blank=True)
        body = models.TextField(blank=True)
        test = models.BooleanField(default=False)
        ok = models.BooleanField(default=True)
        error = models.CharField(max_length=300, blank=True)
        created = models.DateTimeField(auto_now_add=True)
        Meta = table("message")

    system.sync_models(Form, Message)

    # ── helpers ──
    def is_admin(u):
        return bool(u.is_authenticated and (u.is_staff or level(u, "plugins") >= 2))

    def need_admin(request):
        return None if is_admin(request.user) else bad(T("Je hebt hier geen rechten voor."), 403)

    def body(request):
        return request.data if isinstance(request.data, dict) else {}

    def sync_objects():
        try:
            from apps.sysobjects import service as so

            so.sync()
        except Exception:  # noqa: BLE001
            pass

    def clean_fields(raw):
        out, names = [], set()
        for n, f in enumerate((raw if isinstance(raw, list) else [])[:MAX_FIELDS]):
            if not isinstance(f, dict):
                continue
            typ = f.get("type") if f.get("type") in TYPES else "text"
            lab = str(f.get("label") or "").strip()[:120]
            name = slugify(str(f.get("name") or lab or f"veld-{n + 1}")).replace("-", "_")[:40] or f"veld_{n + 1}"
            base, k = name, 2
            while name in names:
                name, k = f"{base}_{k}", k + 1
            names.add(name)
            opts = [str(o).strip()[:120] for o in (f.get("options") or []) if str(o).strip()][:50] if typ in ("select", "radio") else []
            out.append({"id": str(f.get("id") or f"f{n + 1}")[:20], "type": typ, "name": name, "label": lab, "required": bool(f.get("required")) and typ not in ("heading", "hidden"),
                        "send": bool(f.get("send", True)) and typ != "heading", "placeholder": str(f.get("placeholder") or "")[:120], "options": opts,
                        "value": str(f.get("value") or "")[:200] if typ == "hidden" else ""})
        return out

    def mail_links():
        """The mail links that can send: [{slug, name, provider}] (the easy2edit Postmark link first)."""
        try:
            from apps.core import modules
            from apps.integrations.models import Integration
        except Exception:  # noqa: BLE001
            return []
        if not modules.enabled("integrations"):
            return []
        rows = Integration.objects.filter(enabled=True, provider__in=("postmark", "smtp")).order_by("name")
        out = [{"slug": i.slug, "name": i.name, "provider": i.provider} for i in rows]
        out.sort(key=lambda r: (r["slug"] != "postmark-easy2edit", r["name"]))
        return out

    def form_admin(f):
        return {"id": f.id, "name": f.name, "slug": f.slug, "title": f.title, "intro": f.intro, "fields": f.fields, "recipients": f.recipients, "subject": f.subject,
                "integration": f.integration, "reply_field": f.reply_field, "captcha": f.captcha, "verify_email": f.verify_email, "verify_field": f.verify_field, "button": f.button, "success": f.success, "test_mode": f.test_mode, "active": f.active,
                "order": f.order, "messages": Message.objects.filter(form=f).count()}

    def form_public(f):  # no recipients, no mail link
        return {"slug": f.slug, "title": f.title, "intro": f.intro, "button": f.button, "test_mode": f.test_mode, "captcha": f.captcha, "verify_email": f.verify_email,
                "fields": [{k: v for k, v in x.items() if k not in ("send",)} for x in f.fields]}

    def unique_slug(name, skip=None):
        base = slugify(name)[:70] or "formulier"
        slug, k = base, 2
        while Form.objects.filter(slug=slug).exclude(pk=skip).exists():
            slug, k = f"{base}-{k}", k + 1
        return slug

    def apply(f, d):
        if "name" in d:
            f.name = str(d["name"]).strip()[:120] or f.name or "Formulier"
        for k, n in (("title", 200), ("intro", 2000), ("recipients", 400), ("subject", 200), ("integration", 50), ("reply_field", 60), ("verify_field", 60), ("button", 60), ("success", 300)):
            if k in d:
                setattr(f, k, str(d[k] or "").strip()[:n])
        for k in ("test_mode", "active", "captcha", "verify_email"):
            if k in d:
                setattr(f, k, bool(d[k]))
        if "fields" in d:
            f.fields = clean_fields(d["fields"])
        if "slug" in d and str(d["slug"]).strip():
            f.slug = unique_slug(str(d["slug"]), f.pk)
        elif not f.slug:
            f.slug = unique_slug(f.name)
        f.save()
        sync_objects()

    def emails(text):
        return [x for x in re.split(r"[,\s;]+", text or "") if re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", x)]

    def build_mail(f, values):
        """(subject, text body) of the mail: only the fields that are marked as sent."""
        lines = []
        for x in f.fields:
            if x["type"] == "heading":
                lines += ["", f"== {x['label']} =="] if x["label"] else []
            elif x["send"]:
                v = values.get(x["name"])
                v = (T("Ja") if v else T("Nee")) if x["type"] == "checkbox" else ("" if v is None else str(v))
                lines.append(f"{x['label'] or x['name']}: {v}")
        subject = (f.subject or "{form}").replace("{form}", f.name)
        for x in f.fields:  # {field_name} in the subject
            subject = subject.replace("{" + x["name"] + "}", str(values.get(x["name"]) or ""))
        return subject[:200], "\n".join(lines).strip()

    def link_name(slug):
        return next((l["name"] for l in mail_links() if l["slug"] == slug), "")

    def deliver(f, to, subject, text, reply=None):
        from apps.communication import sending

        return sending.send_email(to, subject, text, purpose="plugin", integration=f.integration or "postmark-easy2edit", reply_to=reply)

    def preview(f, values, to=None):
        subject, text = build_mail(f, values)
        used = link_name(f.integration) or link_name("postmark-easy2edit") or (mail_links() or [{"name": ""}])[0]["name"]
        return {"to": to or emails(f.recipients), "subject": subject, "text": text, "via": used, "reply_to": reply_of(f, values)}

    def reply_of(f, values):
        v = str(values.get(f.reply_field) or "").strip()
        return v if v and emails(v) else None

    def check(f, raw):
        """Validated values of a submission, or ValueError with the message for the visitor."""
        raw = raw if isinstance(raw, dict) else {}
        values = {}
        for x in f.fields:
            if x["type"] == "heading":
                continue
            v = x.get("value", "") if x["type"] == "hidden" else raw.get(x["name"])
            if x["type"] == "checkbox":
                v = bool(v)
                if x["required"] and not v:
                    raise ValueError(T("Vul dit veld in: {0}", x["label"] or x["name"]))
            else:
                v = ("" if v is None else str(v)).strip()[:MAX_LEN]
                if x["required"] and not v:
                    raise ValueError(T("Vul dit veld in: {0}", x["label"] or x["name"]))
                if v and x["type"] == "email" and not emails(v):
                    raise ValueError(T("Dit is geen geldig e-mailadres: {0}", x["label"] or x["name"]))
                if v and x["type"] in ("select", "radio") and v not in x["options"]:
                    raise ValueError(T("Kies een geldige optie: {0}", x["label"] or x["name"]))
                v = re.sub(r"[\x00-\x08\x0b\x0c\x0e-\x1f]", "", v)
            values[x["name"]] = v
        return values

    # ── captcha and e-mail code ──
    def digest(*parts):
        from django.conf import settings as dj

        return hashlib.sha256(("|".join(str(p) for p in parts) + "|mailform|" + dj.SECRET_KEY).encode()).hexdigest()

    def captcha_make():
        chars = "".join(random.SystemRandom().choice("ACDEFGHJKLMNPRTUVWXY34679") for _ in range(5))
        rnd = random.SystemRandom()
        parts = [f'<rect width="170" height="56" fill="#f1f5f9"/>']
        for _ in range(5):
            parts.append(f'<path d="M{rnd.randint(0, 170)} {rnd.randint(0, 56)} Q{rnd.randint(0, 170)} {rnd.randint(0, 56)} {rnd.randint(0, 170)} {rnd.randint(0, 56)}" stroke="#94a3b8" stroke-width="1.5" fill="none"/>')
        for n, c in enumerate(chars):
            parts.append(f'<text x="{14 + n * 29}" y="{rnd.randint(34, 42)}" font-size="{rnd.randint(26, 32)}" font-family="monospace" font-weight="700" fill="#1e293b" transform="rotate({rnd.randint(-18, 18)} {20 + n * 29} 30)">{c}</text>')
        svg = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 170 56" width="170" height="56" role="img" aria-label="captcha">' + "".join(parts) + "</svg>"
        return svg, signing.dumps({"h": digest("captcha", chars), "n": random.SystemRandom().getrandbits(48)}, salt="mailform-captcha")

    def captcha_ok(token, answer):
        try:
            d = signing.loads(str(token or ""), salt="mailform-captcha", max_age=900)
        except signing.BadSignature:
            return False
        if cache.get(f"mf-used-{d['n']}"):
            return False
        cache.set(f"mf-used-{d['n']}", 1, 1000)  # a picture can be answered once
        return hmac.compare_digest(d["h"], digest("captcha", re.sub(r"\s", "", str(answer or "")).upper()))

    def verify_name(f):
        names = [x["name"] for x in f.fields if x["type"] == "email"]
        return f.verify_field if f.verify_field in names else (f.reply_field if f.reply_field in names else (names[0] if names else ""))

    def code_ok(token, email, code):
        try:
            d = signing.loads(str(token or ""), salt="mailform-code", max_age=900)
        except signing.BadSignature:
            return False
        if cache.get(f"mf-tries-{d['n']}", 0) >= 5:
            return False
        cache.set(f"mf-tries-{d['n']}", cache.get(f"mf-tries-{d['n']}", 0) + 1, 1000)
        return hmac.compare_digest(d["h"], digest("code", email.lower(), re.sub(r"\s", "", str(code or ""))))

    def parts():
        return [{"key": f"mailform-{f.slug}"[:60], "title": T("Mailform: {0}", f.name), "file": "web/form.html", "query": {"form": f.slug}} for f in Form.objects.filter(active=True).order_by("order", "id")]

    system.provide("parts", parts)

    # ── public ──
    @system.route("GET", "forms/<slug>", public=True)
    def form_get(request, slug):
        f = Form.objects.filter(slug=slug, active=True).first()
        return form_public(f) if f else bad(T("Niet gevonden."), 404)

    @system.route("GET", "forms/<slug>/captcha", public=True)
    def form_captcha(request, slug):
        f = Form.objects.filter(slug=slug, active=True, captcha=True).first()
        if not f:
            return bad(T("Niet gevonden."), 404)
        svg, token = captcha_make()
        return {"svg": svg, "token": token}

    @system.route("POST", "forms/<slug>/code", public=True)
    def form_code(request, slug):
        """Send a 6-digit code to the e-mail address of the visitor (test mode: the code is shown on screen instead of mailed)."""
        f = Form.objects.filter(slug=slug, active=True, verify_email=True).first()
        if not f:
            return bad(T("Niet gevonden."), 404)
        d = body(request)
        email = str(d.get("email") or "").strip()
        if not emails(email) or len(emails(email)) != 1:
            return bad(T("Vul eerst een geldig e-mailadres in."))
        if d.get("website"):
            return {"ok": True}
        if f.captcha and not captcha_ok(d.get("captcha_token"), d.get("captcha")):
            return bad(T("De tekens kloppen niet. Probeer het opnieuw."), 422)
        key = f"mf-codes-{f.pk}-{email.lower()}"
        if cache.get(key, 0) >= 5 or cache.get(f"mf-codes-{f.pk}", 0) >= 200:
            return bad(T("Er zijn te veel codes aangevraagd. Probeer het later nog eens."), 429)
        cache.set(key, cache.get(key, 0) + 1, 3600)
        cache.set(f"mf-codes-{f.pk}", cache.get(f"mf-codes-{f.pk}", 0) + 1, 3600)
        code = f"{random.SystemRandom().randint(0, 999999):06d}"
        token = signing.dumps({"h": digest("code", email.lower(), code), "n": random.SystemRandom().getrandbits(48)}, salt="mailform-code")
        if f.test_mode:
            return {"ok": True, "token": token, "test_code": code}
        try:
            deliver(f, email, T("Je code voor {0}", f.name), T("Je verificatiecode is: {0}\n\nDeze code is 15 minuten geldig.", code))
        except Exception:  # noqa: BLE001
            return bad(T("De code kon niet worden verstuurd. Probeer het later nog eens."), 502)
        return {"ok": True, "token": token}

    @system.route("POST", "forms/<slug>/submit", public=True)
    def form_submit(request, slug):
        f = Form.objects.filter(slug=slug, active=True).first()
        if not f:
            return bad(T("Niet gevonden."), 404)
        d = body(request)
        if d.get("website"):  # honeypot: a human never fills this hidden field
            return {"ok": True, "message": f.success}
        try:
            took = time.time() - float(d.get("t") or 0) / 1000
        except (TypeError, ValueError):
            took = 99
        if took < MIN_SECONDS:
            return bad(T("Even geduld, probeer het zo nog eens."), 429)
        if Message.objects.filter(form=f, created__gte=timezone.now() - __import__("datetime").timedelta(hours=1)).count() >= PER_HOUR:
            return bad(T("Er zijn te veel berichten verstuurd. Probeer het later nog eens."), 429)
        try:
            values = check(f, d.get("values"))
        except ValueError as e:
            return bad(str(e))
        if f.captcha and not f.verify_email and not captcha_ok(d.get("captcha_token"), d.get("captcha")):  # (with a code, the characters were already typed when the code was asked)
            return bad(T("De tekens kloppen niet. Probeer het opnieuw."), 422)
        if f.verify_email:
            vn = verify_name(f)
            if not vn or not code_ok(d.get("code_token"), str(values.get(vn) or ""), d.get("code")):
                return bad(T("De code klopt niet of is verlopen."), 422)
        pv = preview(f, values)
        if f.test_mode:  # test mode: nothing leaves the building, the visitor sees how the mail would arrive
            Message.objects.create(form=f, data=values, subject=pv["subject"], body=pv["text"], test=True)
            return {"ok": True, "test": True, "message": f.success, "mail": pv}
        to = emails(f.recipients)
        if not to:
            return bad(T("Dit formulier heeft nog geen ontvanger."), 503)
        m = Message.objects.create(form=f, data=values, subject=pv["subject"], body=pv["text"])
        try:
            deliver(f, ", ".join(to), pv["subject"], pv["text"], pv["reply_to"])
        except Exception as e:  # noqa: BLE001
            m.ok, m.error = False, str(e)[:300]
            m.save(update_fields=["ok", "error"])
            return bad(T("Het bericht kon niet worden verstuurd. Probeer het later nog eens."), 502)
        return {"ok": True, "message": f.success}

    # ── admin ──
    @system.route("GET", "admin/forms")
    def admin_forms(request):
        if (r := need_admin(request)):
            return r
        return {"forms": [form_admin(f) for f in Form.objects.all().order_by("order", "id")], "links": mail_links(), "default_link": "postmark-easy2edit",
                "types": list(TYPES)}

    @system.route("POST", "admin/forms")
    def admin_form_add(request):
        if (r := need_admin(request)):
            return r
        d = body(request)
        f = Form(name=str(d.get("name") or T("Nieuw formulier"))[:120], fields=[dict(x, label=T(x["label"])) for x in DEFAULT_FIELDS], recipients=str(cfg.get("default_to") or ""),
                 order=Form.objects.count() + 1, subject=T("Nieuw bericht via {form}"), button=T("Verstuur"), success=T("Bedankt! Je bericht is verstuurd."))
        f.slug = unique_slug(f.name)
        f.save()
        sync_objects()
        return Response(form_admin(f), status=201)

    def pick(id):  # noqa: A002
        return Form.objects.filter(pk=id).first() if str(id).isdigit() else None

    @system.route("PATCH", "admin/forms/<id>")
    def admin_form_change(request, id):  # noqa: A002
        if (r := need_admin(request)):
            return r
        f = pick(id)
        if not f:
            return bad(T("Niet gevonden."), 404)
        apply(f, body(request))
        return form_admin(f)

    @system.route("DELETE", "admin/forms/<id>")
    def admin_form_delete(request, id):  # noqa: A002
        if (r := need_admin(request)):
            return r
        f = pick(id)
        if not f:
            return bad(T("Niet gevonden."), 404)
        f.delete()
        sync_objects()
        return {"ok": True}

    @system.route("POST", "admin/forms/<id>/duplicate")
    def admin_form_copy(request, id):  # noqa: A002
        if (r := need_admin(request)):
            return r
        f = pick(id)
        if not f:
            return bad(T("Niet gevonden."), 404)
        g = Form(name=f"{f.name} ({T('kopie')})"[:120], title=f.title, intro=f.intro, fields=f.fields, recipients=f.recipients, subject=f.subject, integration=f.integration,
                 reply_field=f.reply_field, captcha=f.captcha, verify_email=f.verify_email, verify_field=f.verify_field, button=f.button, success=f.success, test_mode=True, order=Form.objects.count() + 1)
        g.slug = unique_slug(g.name)
        g.save()
        sync_objects()
        return Response(form_admin(g), status=201)

    @system.route("POST", "admin/forms/<id>/test")
    def admin_form_test(request, id):  # noqa: A002
        """Test mode of the designer: show the mail (with sample values) and, when asked, really send it to one address through the chosen link."""
        if (r := need_admin(request)):
            return r
        f = pick(id)
        if not f:
            return bad(T("Niet gevonden."), 404)
        d = body(request)
        if isinstance(d.get("form"), dict):  # test the unsaved design
            f = Form(name=f.name, slug=f.slug, fields=clean_fields(d["form"].get("fields", f.fields)), subject=str(d["form"].get("subject") or f.subject), integration=str(d["form"].get("integration") or ""),
                     reply_field=str(d["form"].get("reply_field") or ""), recipients=f.recipients)
        sample = {}
        for x in f.fields:
            if x["type"] in ("heading",):
                continue
            sample[x["name"]] = (True if x["type"] == "checkbox" else {"email": "voorbeeld@example.com", "tel": "+31 6 12345678", "number": "42", "date": "2026-01-31", "select": (x["options"] or [""])[0], "radio": (x["options"] or [""])[0], "hidden": x.get("value", "")}.get(x["type"], T("Voorbeeld van {0}", x["label"] or x["name"])))
        values = d.get("values") if isinstance(d.get("values"), dict) else sample
        pv = preview(f, values, to=[])
        to = str(d.get("to") or "").strip()
        if d.get("send"):
            if not emails(to):
                return bad(T("Vul een geldig e-mailadres in om naartoe te sturen."))
            try:
                deliver(f, to, "[TEST] " + pv["subject"], pv["text"], pv["reply_to"])
            except Exception as e:  # noqa: BLE001
                return bad(T("Verzenden mislukt: {0}", str(e)[:200]), 502)
            pv["sent_to"] = to
        return pv

    @system.route("GET", "admin/messages")
    def admin_messages(request):
        if (r := need_admin(request)):
            return r
        rows = Message.objects.select_related("form").order_by("-id")[:200]
        return {"messages": [{"id": m.id, "form": m.form.name, "subject": m.subject, "body": m.body, "test": m.test, "ok": m.ok, "error": m.error, "created": m.created.isoformat(timespec="seconds")} for m in rows]}

    @system.route("DELETE", "admin/messages/<id>")
    def admin_message_delete(request, id):  # noqa: A002
        if (r := need_admin(request)):
            return r
        Message.objects.filter(pk=id).delete() if str(id).isdigit() else None
        return {"ok": True}

    sync_objects()


def migrate(system, old, new):
    """Version 2: captcha and e-mail verification are new columns of the table of the forms."""
    from django.db import connection, models as m

    table = system.db_prefix + "form"
    cols = {c.name for c in connection.introspection.get_table_description(connection.cursor(), table)}
    with connection.schema_editor() as se:
        model = type("FormOld", (m.Model,), {"__module__": __name__, "Meta": type("Meta", (), {"app_label": system.app_label, "db_table": table}), "id": m.AutoField(primary_key=True)})
        for name_, field in (("captcha", m.BooleanField(default=False)), ("verify_email", m.BooleanField(default=False)), ("verify_field", m.CharField(max_length=60, blank=True, default=""))):
            if name_ not in cols:
                field.set_attributes_from_name(name_)
                se.add_field(model, field)
