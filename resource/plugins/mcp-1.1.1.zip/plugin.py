# Copyright & Ownership Notice
# easy2Edit is the exclusive legal property of RST Coaching & Consultancy B.V. (RSTCC),
# owned by Ronald Stolk. All rights reserved. Any unauthorized use, copying, modification,
# reproduction, distribution, or commercial exploitation of Easy2Edit, including its source code,
# is strictly prohibited without prior written permission from Ronald Stolk or RSTCC.
# website https://rstcc.net

"""MCP connection (plugin). Other MCP servers/clients connect to this website over the Model Context Protocol (JSON-RPC 2.0 over HTTP):
POST /api/plugins/run/mcp/rpc. The plugin is off by default; when it is on, its tile is in Admin -> System. Table: plg_mcp_client.

Keys and tokens:
- a connection has a client id (mcp_<16 hex>) and a secret (<client id>.<random>), made here and shown once; only the sha256 of the secret is kept;
- the secret is a bearer token, or it is exchanged (client credentials, POST /api/plugins/run/mcp/token) for a signed access token that is valid for an hour;
- verification: the client must exist, not be revoked or expired, come from an allowed address and have the scope the tool needs; failed tries are limited per address."""
import hashlib
import hmac
import ipaddress
import json
import re
import socket
import secrets

from django.core import signing
from django.core.cache import cache
from django.db import models
from django.utils import timezone
from django.utils.dateparse import parse_datetime
from rest_framework.response import Response

PROTOCOL = "2025-03-26"
SALT = "easy2edit.mcp.access"
TTL = 3600
MAX_FAILS = 20  # failed tries per address per minute
# What a connection may do, per part of the website: read and write rights, each with the tools it opens. The screen shows the texts (tabs per section).
SECTIONS = ["website", "people", "system"]
RESOURCES = {
    "site": {"section": "website", "read": ["site_info"], "write": []},
    "pages": {"section": "website", "read": ["list_pages", "get_page"], "write": ["update_page"]},
    "media": {"section": "website", "read": ["list_media"], "write": []},
    "users": {"section": "people", "read": ["list_users"], "write": []},
    "entity": {"section": "people", "read": ["get_company"], "write": []},
    "tags": {"section": "people", "read": ["list_tags"], "write": ["create_tag"]},
    "modules": {"section": "system", "read": ["list_modules"], "write": ["set_module"]},
    "plugins": {"section": "system", "read": ["list_plugins"], "write": ["set_plugin"]},
}
ALL = [f"{k}:{a}" for k, r in RESOURCES.items() for a in ("read", "write") if r[a]]
TOOL_SCOPE = {tool: f"{k}:{a}" for k, r in RESOURCES.items() for a in ("read", "write") for tool in r[a]}
DEFAULT_SCOPES = ["site:read", "pages:read"]
PLUGIN_SCOPE = re.compile(r"^plugin:[a-z0-9-]{3,40}$")  # "plugin:<name>": this connection may use that plugin (only a plugin that is on); the tool get_plugin works for those


def scopes_of(v):
    """The rights that are valid: "<part>:read" or "<part>:write" (write brings read with it). The old right "read" means every read right."""
    v = list(v or [])
    if "read" in v:
        v += [x for x in ALL if x.endswith(":read")]
    out = {x for x in v if isinstance(x, str) and (x in ALL or PLUGIN_SCOPE.match(x))}
    out |= {x[:-6] + ":read" for x in out if x.endswith(":write") and x[:-6] + ":read" in ALL}
    return sorted(out)


def register(system):
    from apps.accounts.access import level
    from apps.accounts.views import client_ip

    T = system.t
    bad = lambda msg, code=400: Response({"detail": msg}, status=code)  # noqa: E731

    class Client(models.Model):
        name = models.CharField(max_length=80)
        client_id = models.CharField(max_length=40, unique=True)
        secret_hash = models.CharField(max_length=64)
        secret_tail = models.CharField(max_length=4, blank=True)
        scopes = models.JSONField(default=list, blank=True)
        allowed_ips = models.JSONField(default=list, blank=True)  # empty = from anywhere
        expires = models.DateTimeField(null=True, blank=True)
        revoked = models.BooleanField(default=False)
        created = models.DateTimeField(auto_now_add=True)
        last_used = models.DateTimeField(null=True, blank=True)
        last_ip = models.CharField(max_length=45, blank=True)
        uses = models.PositiveIntegerField(default=0)

        class Meta:
            app_label = system.app_label
            db_table = system.db_prefix + "client"
            ordering = ["-created"]

    system.sync_models(Client)

    def is_admin(u):
        return bool(u.is_authenticated and (u.is_staff or level(u, "plugins") >= 3))

    def need_admin(request):
        return None if is_admin(request.user) else bad(T("Je hebt hier geen rechten voor."), 403)

    def body(request):
        return request.data if isinstance(request.data, dict) else {}

    def h(secret):
        return hashlib.sha256(secret.encode()).hexdigest()

    def state(c):
        if c.revoked:
            return "revoked"
        return "expired" if c.expires and c.expires <= timezone.now() else "ok"

    def row(c):
        return {"id": c.id, "name": c.name, "client_id": c.client_id, "secret_tail": c.secret_tail, "scopes": scopes_of(c.scopes), "allowed_ips": c.allowed_ips, "expires": c.expires, "state": state(c),
                "created": c.created, "last_used": c.last_used, "last_ip": c.last_ip, "uses": c.uses}

    def log(event, request, c):
        try:
            from apps.auditlog import service

            service.log(event, request.user, target=c.client_id, detail=c.name, request=request)
        except Exception:  # noqa: BLE001
            pass

    def parse_expires(v):
        if not v:
            return None
        d = parse_datetime(str(v)) or parse_datetime(str(v) + "T23:59:59")
        if not d:
            raise ValueError(T("Geen geldige vervaldatum."))
        return timezone.make_aware(d) if timezone.is_naive(d) else d

    def ips(v):
        out = []
        for i in (v or []):
            i = str(i).strip()
            if not i:
                continue
            try:
                out.append(str(ipaddress.ip_address(i)))
            except ValueError:
                raise ValueError(T("Geen geldig IP-adres: {0}. Gebruik de knop om een hostnaam om te zetten.", i[:60])) from None
        return out[:20]

    def check_secret(secret):
        """The client that this secret belongs to (any state), or None. Constant-time compare."""
        secret = (secret or "").strip()
        if not secret.startswith("mcp_"):
            return None
        c = Client.objects.filter(client_id=secret.split(".", 1)[0]).first()
        return c if c and hmac.compare_digest(c.secret_hash, h(secret)) else None

    def client_of_token(token):
        try:
            d = signing.loads(token, salt=SALT, max_age=TTL)
        except signing.BadSignature:
            return None
        c = Client.objects.filter(client_id=d.get("c")).first()
        return c if c and c.secret_hash[:12] == d.get("h") else None  # a renewed secret kills its tokens

    class Denied(Exception):
        def __init__(self, text, status):
            super().__init__(text)
            self.status = status

    def seen_ip(request):
        """The address of the caller as this server sees it. Behind a proxy that is not always the client: the plugin setting "ip_source" says which header to trust (the default is what the rest of the system uses)."""
        m = request.META
        xff = [x.strip() for x in str(m.get("HTTP_X_FORWARDED_FOR") or "").split(",") if x.strip()]
        pick = {"x-real-ip": m.get("HTTP_X_REAL_IP"), "x-forwarded-for-laatste": xff[-1] if xff else "", "x-forwarded-for-eerste": xff[0] if xff else "",
                "cf-connecting-ip": m.get("HTTP_CF_CONNECTING_IP"), "directe-verbinding": m.get("REMOTE_ADDR")}.get(str(system.config.get("ip_source") or "auto"))
        return str(pick or client_ip(request) or "").strip()[:45]

    def authenticate(request, secret=""):
        """The client behind Authorization: Bearer <secret or access token> (or a secret that was handed over in the body). Raises Denied."""
        ip = seen_ip(request)
        key = f"mcp:fail:{ip}"
        n = cache.get(key, 0)
        if n >= MAX_FAILS:
            raise Denied("Too many failed tries. Try again in a minute.", 429)
        head = request.headers.get("Authorization", "")
        token = secret or (head.split(" ", 1)[1].strip() if head[:7].lower() == "bearer " else "")
        c = check_secret(token) if token.startswith("mcp_") else client_of_token(token) if token else None
        if not c or state(c) != "ok":
            cache.set(key, n + 1, 60)
            raise Denied("Invalid, revoked or expired key.", 401)
        if c.allowed_ips and ip not in c.allowed_ips:
            cache.set(key, n + 1, 60)
            raise Denied(f"This address may not connect: {ip}. Add it to the IP list of this connection, or check the setting for the source of the IP address of the MCP plugin.", 403)
        c.last_used, c.last_ip, c.uses = timezone.now(), ip[:45], c.uses + 1
        c.save(update_fields=["last_used", "last_ip", "uses"])
        return c

    # ── tools an MCP client can call (each belongs to one right of RESOURCES) ──
    def site_info(args):
        from apps.core import system as core_system

        return {"name": core_system.site_name()}

    def list_modules(args):
        from apps.core import modules

        return [{"key": m["key"], "label": m["label"], "enabled": modules.enabled(m["key"])} for m in modules.MODULES]

    def page_url(p):
        return p.url or f"/p/{p.key}"

    def list_pages(args):
        from apps.pages.models import Page

        return [{"key": p.key, "title": p.title, "url": page_url(p), "in_menu": p.in_menu} for p in Page.objects.filter(enabled=True, scope="public").order_by("order")[:200]]

    def get_page(args):
        from apps.pages.models import Page

        p = Page.objects.filter(key=str(args.get("key") or ""), enabled=True, scope="public").first()
        if not p:
            raise ValueError("This page does not exist.")
        return {"key": p.key, "title": p.title, "url": page_url(p), "updated_at": p.updated_at.isoformat()}

    def update_page(args):
        from apps.pages.models import Page

        p = Page.objects.filter(key=str(args.get("key") or ""), scope="public").first()
        if not p:
            raise ValueError("This page does not exist.")
        fields = []
        if "title" in args:
            tt = args["title"]
            if not isinstance(tt, dict) or not tt or not all(isinstance(k, str) and isinstance(v, str) and v.strip() for k, v in tt.items()):
                raise ValueError('title must be an object like {"nl": "Tekst", "en": "Text"}.')
            p.title = {**(p.title or {}), **{k[:8]: v.strip()[:200] for k, v in tt.items()}}
            fields.append("title")
        for f in ("enabled", "in_menu"):
            if f in args:
                if not isinstance(args[f], bool):
                    raise ValueError(f"{f} must be true or false.")
                setattr(p, f, args[f])
                fields.append(f)
        if not fields:
            raise ValueError("Nothing to change: give title, enabled or in_menu.")
        p.save(update_fields=fields + ["updated_at"])
        return {"key": p.key, "title": p.title, "enabled": p.enabled, "in_menu": p.in_menu}

    def list_media(args):
        from apps.medialib.models import MediaItem

        return [{"id": m.id, "name": m.name, "kind": m.kind, "mime": m.mime, "size": m.size, "created": m.created_at.isoformat()} for m in MediaItem.objects.filter(owner_id__isnull=True)[:200]]  # (the files of the site, not the private files of members)

    def list_users(args):
        return [{"id": u.id, "name": getattr(u, "display_name", "") or u.first_name or u.username, "active": u.is_active} for u in system.User.objects.order_by("id")[:200]]  # (no e-mail addresses)

    def get_company(args):
        from apps.core.models import Entity

        e = Entity.objects.filter(is_own=True).first()
        if not e:
            return {}
        keys = ("name", "legal_name", "email", "phone", "website", "street", "house_number", "postal_code", "city", "country", "registration_no", "vat_no")
        return {k: getattr(e, k) for k in keys}

    def list_tags(args):
        from apps.core.models import Tag

        return [{"id": t.id, "name": t.name, "color": t.color, "description": t.description} for t in Tag.objects.all()]

    def create_tag(args):
        from apps.core import tags

        t = tags.save(None, {"name": args.get("name"), "color": args.get("color") or "#2563eb", "description": args.get("description") or "", "scope": "global"})
        return {"id": t.id, "name": t.name, "color": t.color}

    def set_module(args):
        from apps.core import modules
        from apps.core.models import ModuleState

        key = str(args.get("key") or "")
        m = modules.BY_KEY.get(key)
        if not m:
            raise ValueError("This module does not exist.")
        if not isinstance(args.get("enabled"), bool):
            raise ValueError("enabled must be true or false.")
        if m.get("core") or m.get("plugin") or key in modules.ALWAYS_ON:
            raise ValueError("This module is part of the base of the system (or belongs to a plugin) and cannot be switched here.")
        if key in modules.owner_only_keys():
            raise ValueError("This module is only for a superadmin+.")
        ModuleState.objects.update_or_create(key=key, defaults={"enabled": args["enabled"]})
        modules.invalidate()
        try:
            from apps.security import service as security_service

            security_service.invalidate()
        except Exception:  # noqa: BLE001
            pass
        return {"key": key, "enabled": args["enabled"]}

    def list_plugins(args):
        from apps.plugins.models import Plugin

        return [{"name": p.name, "title": p.title, "version": p.version, "enabled": p.enabled, "section": p.manifest.get("section", "system"), "error": p.error} for p in Plugin.objects.order_by("name")]

    def set_plugin(args):
        from apps.plugins import switch
        from apps.plugins.models import Plugin

        p = Plugin.objects.filter(name=str(args.get("name") or "")).first()
        if not p:
            raise ValueError("This plugin is not installed.")
        if not isinstance(args.get("enabled"), bool):
            raise ValueError("enabled must be true or false.")
        if p.name == system.name:
            raise ValueError("The MCP connection cannot switch itself off.")
        try:
            p = switch.set_enabled(p, args["enabled"], bool(args.get("with_requires")))
        except switch.SwitchError as e:
            raise ValueError(str(e)) from None
        return {"name": p.name, "enabled": p.enabled, "error": p.error}

    def get_plugin(args):
        """Details of one plugin that is on and that this connection may use (the access was checked before this runs)."""
        from apps.plugins import installer
        from apps.plugins.models import Plugin

        p = Plugin.objects.filter(name=str(args.get("name") or ""), enabled=True).first()
        if not p:
            raise ValueError("This plugin is not on.")
        m = p.manifest or {}
        return {"name": p.name, "title": p.title, "version": p.version, "description": p.description, "section": m.get("section", "system"), "provides": m.get("provides", []), "settings": installer.public_config(p)}

    empty = {"type": "object", "properties": {}}
    flag = {"type": "boolean"}
    TOOLS = {
        "site_info": (site_info, "The name of this website.", empty),
        "list_pages": (list_pages, "The public pages of this website (key, title per language, url).", empty),
        "get_page": (get_page, "One public page by its key.", {"type": "object", "properties": {"key": {"type": "string"}}, "required": ["key"]}),
        "update_page": (update_page, "Change a page: its title per language, whether it is on, whether it is in the menu.",
                        {"type": "object", "properties": {"key": {"type": "string"}, "title": {"type": "object", "additionalProperties": {"type": "string"}}, "enabled": {"type": "boolean"}, "in_menu": {"type": "boolean"}}, "required": ["key"]}),
        "list_media": (list_media, "The files of the media library of the site (name, kind, size).", empty),
        "list_users": (list_users, "The accounts (id, name, active); no e-mail addresses.", empty),
        "get_company": (get_company, "The company or organisation behind the website: name, address, contact, registration.", empty),
        "list_modules": (list_modules, "The modules of this website and whether they are on.", empty),
        "set_module": (set_module, "Switch a module on or off (not the base modules).", {"type": "object", "properties": {"key": {"type": "string"}, "enabled": flag}, "required": ["key", "enabled"]}),
        "list_plugins": (list_plugins, "The installed plugins and whether they are on.", empty),
        "set_plugin": (set_plugin, "Switch a plugin on or off (not this plugin itself). with_requires also switches on the plugins it needs.",
                       {"type": "object", "properties": {"name": {"type": "string"}, "enabled": flag, "with_requires": flag}, "required": ["name", "enabled"]}),
        "get_plugin": (get_plugin, "Details of one active plugin (title, version, description, settings without secrets). Only for the plugins this key may use.", {"type": "object", "properties": {"name": {"type": "string"}}, "required": ["name"]}),
        "list_tags": (list_tags, "The tags (name, colour).", empty),
        "create_tag": (create_tag, "Make a tag that applies everywhere.", {"type": "object", "properties": {"name": {"type": "string"}, "color": {"type": "string", "description": "#rrggbb"}, "description": {"type": "string"}}, "required": ["name"]}),
    }

    def ok(i, r):
        return {"jsonrpc": "2.0", "id": i, "result": r}

    def err(i, code, text):
        return {"jsonrpc": "2.0", "id": i, "error": {"code": code, "message": text}}

    def handle(c, msg):
        """One JSON-RPC message -> the answer, or None for a notification."""
        if not isinstance(msg, dict) or msg.get("jsonrpc") != "2.0":
            return err(None, -32600, "Invalid request")
        if "id" not in msg:
            return None
        i, method, params = msg["id"], msg.get("method"), msg.get("params") or {}
        if method == "initialize":
            from apps.core import system as core_system

            return ok(i, {"protocolVersion": PROTOCOL, "capabilities": {"tools": {"listChanged": False}}, "serverInfo": {"name": f"easy2edit ({core_system.site_name()})", "version": system.version}})
        if method == "ping":
            return ok(i, {})
        if method == "tools/list":
            have = set(scopes_of(c.scopes))
            return ok(i, {"tools": [{"name": k, "description": d, "inputSchema": sc} for k, (fn, d, sc) in TOOLS.items() if (TOOL_SCOPE[k] in have if k in TOOL_SCOPE else any(x.startswith("plugin:") for x in have))]})
        if method == "tools/call":
            t = TOOLS.get(params.get("name"))
            if not t:
                return err(i, -32602, "Unknown tool")
            need = TOOL_SCOPE.get(params["name"]) or "plugin:" + str((params.get("arguments") or {}).get("name") or "")  # (the tools of a plugin need the right on that plugin)
            if need not in scopes_of(c.scopes):
                return err(i, -32001, "This key has no right for this tool")
            try:
                out = t[0](params.get("arguments") or {})
                if need.endswith(":write"):  # a change by a connection is written in the log
                    try:
                        from apps.auditlog import service

                        service.log("mcp.write", None, target=c.client_id, detail=f"{c.name}: {params['name']} {json.dumps(params.get('arguments') or {}, ensure_ascii=False)}"[:480])
                    except Exception:  # noqa: BLE001
                        pass
                return ok(i, {"content": [{"type": "text", "text": json.dumps(out, ensure_ascii=False)}], "isError": False})
            except ValueError as e:
                return ok(i, {"content": [{"type": "text", "text": str(e)}], "isError": True})
        return err(i, -32601, "Method not found")

    # ── public: for MCP clients ──
    @system.route("POST", "rpc", public=True)
    @system.route("GET", "rpc", public=True)
    def rpc(request):
        try:
            c = authenticate(request)
        except Denied as e:
            r = Response({"jsonrpc": "2.0", "id": None, "error": {"code": -32000, "message": str(e)}}, status=e.status)
            if e.status == 401:
                r["WWW-Authenticate"] = 'Bearer realm="easy2edit-mcp"'
            return r
        if request.method == "GET":
            return Response(status=405)
        data = request.data
        if isinstance(data, list):
            out = [a for a in (handle(c, m) for m in data) if a is not None]
            return Response(out) if out else Response(status=202)
        a = handle(c, data)
        return Response(a) if a is not None else Response(status=202)

    @system.route("POST", "token", public=True)
    def token(request):
        """Client credentials: Authorization: Bearer <secret> (or {client_secret}) -> a short-lived access token."""
        d = body(request)
        try:
            c = authenticate(request, str(d.get("client_secret") or ""))
        except Denied as e:
            return Response({"error": "invalid_client", "error_description": str(e)}, status=e.status)
        if d.get("client_id") and d["client_id"] != c.client_id:
            return Response({"error": "invalid_client"}, status=401)
        return {"access_token": signing.dumps({"c": c.client_id, "h": c.secret_hash[:12]}, salt=SALT), "token_type": "Bearer", "expires_in": TTL, "scope": " ".join(scopes_of(c.scopes))}

    # ── admin ──
    def plugin_list():
        """The plugins that are on (a connection can only be given access to those; not this plugin itself)."""
        from apps.plugins.models import Plugin

        return [{"name": p.name, "title": p.title, "section": (p.manifest or {}).get("section", "system"), "description": (p.description or "")[:160]} for p in Plugin.objects.filter(enabled=True).exclude(name=system.name).order_by("title")]

    @system.route("GET", "admin/clients")
    def admin_clients(request):
        if (r := need_admin(request)):
            return r
        base = f"{request.scheme}://{request.get_host()}/api/plugins/run/mcp/"
        return {"clients": [row(c) for c in Client.objects.all()], "resources": RESOURCES, "sections": SECTIONS, "plugins": plugin_list(), "endpoint": base + "rpc", "token_endpoint": base + "token"}

    @system.route("POST", "admin/clients")
    def admin_client_add(request):
        if (r := need_admin(request)):
            return r
        d = body(request)
        if not str(d.get("name") or "").strip():
            return bad(T("Geef de koppeling een naam."))
        try:
            exp, allowed = parse_expires(d.get("expires")), ips(d.get("allowed_ips"))
        except ValueError as e:
            return bad(str(e))
        cid = "mcp_" + secrets.token_hex(8)
        secret = f"{cid}.{secrets.token_urlsafe(32)}"
        c = Client.objects.create(name=str(d["name"]).strip()[:80], client_id=cid, secret_hash=h(secret), secret_tail=secret[-4:], scopes=scopes_of(d["scopes"]) if "scopes" in d else list(DEFAULT_SCOPES), allowed_ips=allowed, expires=exp)
        log("mcp.created", request, c)
        return Response({**row(c), "secret": secret}, status=201)  # the only time the secret is known

    def pick(id):  # noqa: A002
        return Client.objects.filter(pk=id).first() if str(id).isdigit() else None

    @system.route("PATCH", "admin/clients/<id>")
    def admin_client_change(request, id):  # noqa: A002
        if (r := need_admin(request)):
            return r
        c = pick(id)
        if not c:
            return bad(T("Deze koppeling bestaat niet."), 404)
        d = body(request)
        try:
            if str(d.get("name") or "").strip():
                c.name = str(d["name"]).strip()[:80]
            if "scopes" in d:
                c.scopes = scopes_of(d["scopes"])
            if "expires" in d:
                c.expires = parse_expires(d["expires"])
            if "allowed_ips" in d:
                c.allowed_ips = ips(d["allowed_ips"])
            if "revoked" in d:
                c.revoked = bool(d["revoked"])
        except ValueError as e:
            return bad(str(e))
        c.save()
        log("mcp.changed", request, c)
        return row(c)

    @system.route("POST", "admin/clients/<id>/renew")
    def admin_client_renew(request, id):  # noqa: A002
        if (r := need_admin(request)):
            return r
        c = pick(id)
        if not c:
            return bad(T("Deze koppeling bestaat niet."), 404)
        secret = f"{c.client_id}.{secrets.token_urlsafe(32)}"
        c.secret_hash, c.secret_tail = h(secret), secret[-4:]
        c.save(update_fields=["secret_hash", "secret_tail"])
        log("mcp.renewed", request, c)
        return {**row(c), "secret": secret}

    @system.route("DELETE", "admin/clients/<id>")
    def admin_client_delete(request, id):  # noqa: A002
        if (r := need_admin(request)):
            return r
        c = pick(id)
        if not c:
            return bad(T("Deze koppeling bestaat niet."), 404)
        log("mcp.deleted", request, c)
        c.delete()
        return None

    @system.route("POST", "admin/resolve")
    def admin_resolve(request):
        """{hosts: [name or ip]} = the IP addresses of these names (an address stays as it is). An empty list gives the address this request comes from."""
        if (r := need_admin(request)):
            return r
        hosts = [str(x).strip() for x in (body(request).get("hosts") or []) if str(x).strip()][:10]
        if not hosts:
            return {"ips": [seen_ip(request)], "failed": []}
        found, failed = [], []
        for host in hosts:
            try:
                found.append(str(ipaddress.ip_address(host)))
                continue
            except ValueError:
                pass
            try:
                found += sorted({a[4][0] for a in socket.getaddrinfo(host.replace("https://", "").replace("http://", "").split("/")[0], None, proto=socket.IPPROTO_TCP)})
            except (socket.gaierror, UnicodeError):
                failed.append(host)
        return {"ips": list(dict.fromkeys(found))[:20], "failed": failed}

    @system.route("POST", "admin/clients/import")
    def admin_client_import(request):
        """{client_id, secret, name, scopes} from a saved connection file: make the connection here when it does not exist yet (only the hash of the secret is stored)."""
        if (r := need_admin(request)):
            return r
        d = body(request)
        cid, secret = str(d.get("client_id") or ""), str(d.get("secret") or "")
        if not re.fullmatch(r"mcp_[0-9a-f]{16}", cid) or not secret.startswith(cid + ".") or not 40 <= len(secret) <= 200:
            return bad(T("Dit bestand heeft geen geldig client-id en geldige sleutel."))
        if Client.objects.filter(client_id=cid).exists():
            return bad(T("Deze koppeling bestaat al."), 409)
        c = Client.objects.create(name=str(d.get("name") or "").strip()[:80] or "MCP", client_id=cid, secret_hash=h(secret), secret_tail=secret[-4:], scopes=scopes_of(d["scopes"]) if "scopes" in d else list(DEFAULT_SCOPES))
        log("mcp.created", request, c)
        return Response(row(c), status=201)

    @system.route("POST", "admin/verify")
    def admin_verify(request):
        """{secret} = is this key valid (exists, not revoked, not expired) and what may it do."""
        if (r := need_admin(request)):
            return r
        c = check_secret(str(body(request).get("secret") or ""))
        if not c:
            return {"valid": False, "state": "unknown"}
        return {"valid": state(c) == "ok", "state": state(c), "name": c.name, "scopes": scopes_of(c.scopes), "client_id": c.client_id}
