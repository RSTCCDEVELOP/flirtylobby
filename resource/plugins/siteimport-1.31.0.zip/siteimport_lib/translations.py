# Copyright & Ownership Notice
# easy2Edit is the exclusive legal property of RST Coaching & Consultancy B.V. (RSTCC),
# owned by Ronald Stolk. All rights reserved. Any unauthorized use, copying, modification,
# reproduction, distribution, or commercial exploitation of Easy2Edit, including its source code,
# is strictly prohibited without prior written permission from Ronald Stolk or RSTCC.
# website https://rstcc.net

"""Supplied translations (vertalingen-<taal>.json, format easy2edit-vertalingen/1): an exact lookup on the normalized source text (whitespace and html entities),
so only the texts that are NOT in the file go to Claude."""
import html as htmllib
import re

SEG = re.compile(r"(<(p|h[1-6]|li|blockquote)\b[^>]*>)(.*?)(</\2>)", re.S | re.I)


def norm(text):
    """The text without tags, with entities resolved and whitespace collapsed: the key of the lookup."""
    t = re.sub(r"<[^>]+>", " ", str(text or ""))
    return " ".join(htmllib.unescape(t).replace("\xa0", " ").split())


class Lookup:
    """{language code: {normalized source text: translated text}} from the translation files {code: parsed json}."""

    def __init__(self, files):
        self.by_lang = {}
        for code, d in (files or {}).items():
            src_lang = str((d or {}).get("bron") or "")
            idx = self.by_lang.setdefault(code, {})
            for items in ((d or {}).get("paginas") or {}).values():
                for it in items if isinstance(items, list) else []:
                    if not isinstance(it, dict):
                        continue
                    s, t = it.get(src_lang) if src_lang else None, it.get(code)
                    if s is None:  # no "bron" given: the first key that is not element/doel is the source
                        s = next((v for k, v in it.items() if k not in ("element", code) and isinstance(v, str)), None)
                    if isinstance(s, str) and isinstance(t, str) and norm(s) and t.strip():
                        idx.setdefault(norm(s), t.strip())

    def get(self, code, source):
        return (self.by_lang.get(code) or {}).get(norm(source))

    def count(self, code):
        return len(self.by_lang.get(code) or {})


def split_segments(text):
    """[(open, inner, close)] for the elements that can be translated one by one (p, h1-h6, li, blockquote); literal parts between them have open=close=None.
    A text without such elements (a button label, a title) is one segment."""
    parts, pos = [], 0
    for m in SEG.finditer(text):
        if m.start() > pos:
            parts.append((None, text[pos:m.start()], None))
        parts.append((m.group(1), m.group(3), m.group(4)))
        pos = m.end()
    if not parts:
        return [("", text, "")]
    if pos < len(text):
        parts.append((None, text[pos:], None))
    return parts


def join_segments(parts):
    return "".join(o + i + c if o is not None else i for o, i, c in parts)


def translate_known(lookup, code, text):
    """(new_text or None, missing) where missing = list of (index, inner) of segments that the file does not have. new_text is the text with the known segments translated
    (the unknown ones still in the source language: fill them from `missing` then join)."""
    parts = split_segments(text)
    out, missing = [], []
    for n, (o, inner, c) in enumerate(parts):
        if o is None or not norm(inner):  # literal markup between the elements
            out.append((o, inner, c))
            continue
        got = lookup.get(code, inner) if lookup else None
        if got is None:
            missing.append((n, inner))
            out.append((o, inner, c))
        else:
            out.append((o, got, c))
    return out, missing
