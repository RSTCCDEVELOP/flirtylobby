# Copyright & Ownership Notice
# easy2Edit is the exclusive legal property of RST Coaching & Consultancy B.V. (RSTCC),
# owned by Ronald Stolk. All rights reserved. Any unauthorized use, copying, modification,
# reproduction, distribution, or commercial exploitation of Easy2Edit, including its source code,
# is strictly prohibited without prior written permission from Ronald Stolk or RSTCC.
# website https://rstcc.net

"""Site import API (module "siteimport": superadmins, or users who were given the module)."""
import logging

from django.core.files.storage import default_storage
from rest_framework import status
from rest_framework.decorators import api_view, parser_classes, permission_classes
from rest_framework.parsers import FormParser, JSONParser, MultiPartParser
from rest_framework.response import Response

from apps.accounts.permissions import has_level_for
from apps.core.modules import module_required
from apps.medialib.models import MediaItem
from apps.pages.models import Page

from . import importer
from .models import SiteImport

logger = logging.getLogger(__name__)
PERM = [has_level_for("siteimport", {"GET": "use"}, default="manage"), module_required("siteimport")]
ROLES = {"logo", "logo_dark", "favicon", "icon", "og_image"}  # brand slots (Logo's & beeld)
bad = lambda msg, code=status.HTTP_400_BAD_REQUEST: Response({"detail": msg}, status=code)  # noqa: E731


def _summary(imp):
    th = imp.theme or {}
    return {"id": imp.id, "name": imp.name, "slug": imp.slug, "status": "analysing" if imp.status == "proposal" and not imp.proposal else imp.status, "source": imp.source, "kind": imp.kind, "created_at": imp.created_at,
            "folder": f"themes/{imp.slug}" if imp.slug else "",
            "paths": [{"title": t["title"], "path": t["path"]} for t in th.get("targets", [])] + [{"title": next(iter(p.title.values()), p.key) if isinstance(p.title, dict) else p.key, "path": p.path} for p in Page.objects.filter(source=imp.tag)[:12]],
            "apply": {"state": (th.get("apply") or {}).get("state", ""), "step": (th.get("apply") or {}).get("step", ""), "percent": (th.get("apply") or {}).get("percent", 0), "pending": imp.status == "imported" and bool(th.get("sources")), "built": [{"title": b["title"], "path": b["path"]} for b in (th.get("apply") or {}).get("built", [])]},
            "theme": {"has_values": bool(th.get("values")), "pack": th.get("pack", ""), "modules": th.get("modules", []), "palette": th.get("palette", [])[:6], "primary": th.get("values", {}).get("primary"), "secondary": th.get("values", {}).get("secondary"),
                      "fonts": th.get("fonts", []), "dark": th.get("dark", False), "applied": imp.theme_applied,
                      "popup": th.get("popup"), "profile": th.get("profile")},
            "home": {"title": (imp.home or {}).get("title", ""), "exists": bool(imp.home), "applied": imp.home_applied},
            "analyse": (imp.theme or {}).get("analyse"), "pages": Page.objects.filter(source=imp.tag).count(), "images": MediaItem.objects.filter(source=imp.tag).count(), "notes": imp.notes}


def _detail(imp):
    out = {**_summary(imp)}
    if imp.status == "proposal":
        pr = imp.proposal or {}
        out["proposal"] = {**pr, "pages": [{**p, "i": n} for n, p in enumerate(pr.get("pages", []))],
                           "assets": [{**a, "url": default_storage.url(a["file"])} for a in pr.get("assets", [])],
                           "profile_options": PROFILE_OPTIONS, "popup_options": ["clean", "header", "glass", "minimal", "bold"]}
        # the pages' html stays on the server: the screen only needs a preview
        for p in out["proposal"]["pages"]:
            p.pop("html", None)
            p.pop("design", None)
        out["proposal"]["targets"] = importer.apply_targets(imp)
        out["proposal"]["languages"] = importer.active_languages()
        out["proposal"]["home"] = {k: v for k, v in pr.get("home", {}).items() if k != "html"}
        return out
    items = {m.id: m for m in MediaItem.objects.filter(source=imp.tag)}
    out["targets"] = [{"key": t["key"], "title": t["title"], "path": t["path"]} for t in (imp.theme or {}).get("targets", [])]
    out.update({"page_list": [{"id": p.id, "key": p.key, "design": bool(p.design), "kind": p.kind, "title": next(iter(p.title.values()), p.key), "path": p.path, "in_menu": p.in_menu, "enabled": p.enabled} for p in Page.objects.filter(source=imp.tag)],
                "assets": [{"media": a["media"], "role": a["role"], "name": a["name"], "url": default_storage.url(items[a["media"]].key)} for a in imp.assets if a["media"] in items],
                "choices": {"popup": (imp.theme or {}).get("popup"), "popup_reason": (imp.theme or {}).get("popup_reason"), "profile": (imp.theme or {}).get("profile"), "profile_reason": (imp.theme or {}).get("profile_reason")}})
    return out


PROFILE_OPTIONS = ["normal", "dating", "sporters", "business", "webshop"]


@api_view(["GET", "POST"])
@permission_classes(PERM)
@parser_classes([JSONParser, MultiPartParser, FormParser])
def imports(request):
    if request.method == "GET":
        return Response({"imports": [_summary(i) for i in SiteImport.objects.all()], "folders": importer.list_folders()})
    d = request.data
    kind = d.get("kind")
    try:
        if kind == "url":
            imp = importer.import_url(d.get("url"), d.get("name"), request.user)
        elif kind == "folder":
            imp = importer.import_folder(str(d.get("folder") or ""), d.get("name"), request.user)
        elif kind == "html" and request.FILES.getlist("file"):
            imp = importer.import_html(request.FILES.getlist("file"), d.get("name"), request.user, background=True)  # the analysis (Claude) takes a while: it runs in the background and reports its progress
        elif kind == "zip" and request.FILES.get("file"):
            imp = importer.import_zip(request.FILES["file"], d.get("name"), request.user)
        else:
            return bad("Kies een website-adres, een map, een ZIP-bestand of een html-bestand.")
    except importer.ImportError_ as e:
        return bad(str(e))
    except Exception as e:  # noqa: BLE001
        logger.exception("site import failed")
        return bad(f"Inlezen mislukt: {e}")
    logger.info("Site imported by %s: %s (%s)", request.user.email, imp.name, imp.source)
    return Response(_detail(imp), status=status.HTTP_201_CREATED)


@api_view(["GET", "POST"])
@permission_classes(PERM)
def apply_(request, pk):
    """POST: build the pages of this import with the blocks of the page builder (editable), in the background. GET: how far it is."""
    imp = SiteImport.objects.filter(pk=pk).first()
    if not imp or imp.status != "imported":
        return bad("Niet gevonden.", status.HTTP_404_NOT_FOUND)
    if request.method == "GET" and request.query_params.get("info"):  # what the screen asks before it applies
        return Response(importer.apply_info(imp))
    if request.method == "POST" and (request.data or {}).get("cancel"):  # Annuleren
        importer.apply_cancel(imp)
        imp.refresh_from_db()
    elif request.method == "POST":
        try:
            importer.apply_start(imp, (request.data or {}).get("map") if isinstance((request.data or {}).get("map"), dict) else {}, (request.data or {}).get("mode") or "clear", (request.data or {}).get("prompt") or "", bool((request.data or {}).get("translate")), (request.data or {}).get("render") or "design", (request.data or {}).get("options") if isinstance((request.data or {}).get("options"), dict) else {})
        except importer.ImportError_ as e:
            return bad(str(e))
        imp.refresh_from_db()
        logger.info("Site import %s applied by %s", pk, request.user.email)
    st = importer.apply_state(imp)
    return Response({"state": st.get("state", ""), "percent": st.get("percent", 0), "step": st.get("step", ""), "error": st.get("error", ""),
                     "built": [{"title": b["title"], "path": b["path"]} for b in st.get("built", [])], "warning": st.get("warning", ""), "stale": st.get("state") == "running" and __import__("time").time() - float(st.get("updated") or 0) > 150})


@api_view(["GET"])
@permission_classes(PERM)
def preview(request, pk, i):
    """The design of one page of a proposal, to look at before the approval (the links between the pages do not lead anywhere yet)."""
    import re as _re

    imp = SiteImport.objects.filter(pk=pk).first()
    try:
        page = ((imp.proposal or {}).get("pages") or [])[int(i)] if imp else None
    except (IndexError, ValueError):
        page = None
    if not page or not page.get("design"):
        return bad("Niet gevonden.", status.HTTP_404_NOT_FOUND)
    return Response({"title": page["title"], "design": _re.sub(r"__PAGE__/[a-z0-9._-]+", "#", page["design"])})


@api_view(["GET", "DELETE"])
@permission_classes(PERM)
def one(request, pk):
    imp = SiteImport.objects.filter(pk=pk).first()
    if not imp:
        return bad("Niet gevonden.", status.HTTP_404_NOT_FOUND)
    if request.method == "DELETE":
        summary = importer.remove_import(imp)
        logger.info("Site import %s removed by %s", pk, request.user.email)
        return Response({"removed": True, **summary})
    return Response(_detail(imp))


@api_view(["POST"])
@permission_classes(PERM)
@parser_classes([JSONParser])
def approve(request, pk):
    """The user checked the proposal: create the theme package, the pages and register the pictures."""
    imp = SiteImport.objects.filter(pk=pk).first()
    if not imp:
        return bad("Niet gevonden.", status.HTTP_404_NOT_FOUND)
    try:
        importer.approve(imp, request.data or {})
    except importer.ImportError_ as e:
        return bad(str(e))
    logger.info("Site import %s approved by %s", pk, request.user.email)
    return Response(_detail(imp))


def _setting(key):
    p = Page.objects.filter(key=key).first()
    return {"in_menu": p.in_menu, "enabled": p.enabled, "page_title": next(iter(p.title.values()), key) if isinstance(p.title, dict) and p.title else key, "page_kind": p.kind} if p else {}


@api_view(["POST"])
@permission_classes(PERM)
def page_setting(request, pk):
    """The settings of one page of an import (name, in the menu, visible); only pages that this import made or that it put its design on."""
    imp = SiteImport.objects.filter(pk=pk).first()
    if not imp:
        return bad("Niet gevonden.", status.HTTP_404_NOT_FOUND)
    key = str(request.data.get("key") or "")
    own = Page.objects.filter(source=imp.tag, key=key).exists() or key in {t.get("key") for t in (imp.theme or {}).get("targets", [])}
    page = Page.objects.filter(key=key).first() if own else None
    if not page:
        return bad("Pagina niet gevonden.", status.HTTP_404_NOT_FOUND)
    if isinstance(request.data.get("title"), str) and request.data["title"].strip():
        t = dict(page.title) if isinstance(page.title, dict) else {}
        t[next(iter(t), "nl")] = request.data["title"].strip()[:120]
        page.title = t
    for f in ("in_menu", "enabled"):
        if isinstance(request.data.get(f), bool):
            setattr(page, f, request.data[f])
    page.save()
    return Response(_detail(imp))


def _import_of_page(key):
    """The import that made this page or that put its design on it: (import, source of the file), or (None, None)."""
    for imp in SiteImport.objects.filter(status="imported").order_by("-id"):
        src = next((s for s in (imp.theme or {}).get("sources") or [] if s.get("dest") == key), None)
        if src:
            return imp, src
    return None, None


@api_view(["GET", "POST"])
@permission_classes(PERM)
def page_import(request, key):
    """Pagina-instellingen → Import: GET = was this page imported (and from which file); POST = build this one page again from the original, with an instruction for Claude."""
    imp, src = _import_of_page(key)
    if not imp:
        return Response({"imported": False})
    st = importer.apply_state(imp)
    if request.method == "POST":
        d = request.data or {}
        render = d.get("render") if d.get("render") in ("blocks", "design") else (st.get("render") if st.get("render") in ("blocks", "design") else "blocks")
        try:
            importer.apply_start(imp, {src["stem"]: key}, "clear", str(d.get("prompt") or ""), False, render, {"header": False, "site_footer": st.get("site_footer", True), "links": st.get("link_map") or {}}, only=[src["stem"]])
        except importer.ImportError_ as e:
            return bad(str(e))
        imp.refresh_from_db()
        st = importer.apply_state(imp)
    return Response({"imported": True, "id": imp.id, "name": imp.name, "file": src.get("title") or src["stem"], "render": st.get("render") or st.get("last_mode") or "blocks", "prompt": st.get("last_prompt") or st.get("prompt") or "",
                     "state": st.get("state", ""), "percent": st.get("percent", 0), "step": st.get("step", ""), "error": st.get("error", ""), "stale": st.get("state") == "running" and __import__("time").time() - float(st.get("updated") or 0) > 150})


@api_view(["POST"])
@permission_classes(PERM)
def theme(request, pk):
    imp = SiteImport.objects.filter(pk=pk).first()
    if not imp:
        return bad("Niet gevonden.", status.HTTP_404_NOT_FOUND)
    (importer.apply_theme if request.data.get("apply") else importer.revert_theme)(imp)
    return Response(_detail(imp))


@api_view(["POST"])
@permission_classes(PERM)
def home(request, pk):
    imp = SiteImport.objects.filter(pk=pk).first()
    if not imp:
        return bad("Niet gevonden.", status.HTTP_404_NOT_FOUND)
    try:
        (importer.apply_home if request.data.get("apply") else importer.revert_home)(imp)
    except importer.ImportError_ as e:
        return bad(str(e))
    return Response(_detail(imp))


@api_view(["POST"])
@permission_classes(PERM)
def asset(request, pk):
    """Use a picture of the import as logo / favicon / app icon / share image (Logo's & beeld)."""
    from apps.branding.models import SiteAsset

    imp = SiteImport.objects.filter(pk=pk).first()
    item = MediaItem.objects.filter(pk=request.data.get("media"), source=imp.tag).first() if imp else None
    role = request.data.get("role")
    if not item or role not in ROLES:
        return bad("Kies een afbeelding van deze import en een bestemming.")
    SiteAsset.objects.update_or_create(slot=role, defaults={"image": item.key})
    return Response({"ok": True})
