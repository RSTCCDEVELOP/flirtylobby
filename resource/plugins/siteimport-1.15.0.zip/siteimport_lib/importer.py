# Copyright & Ownership Notice
# easy2Edit is the exclusive legal property of RST Coaching & Consultancy B.V. (RSTCC),
# owned by Ronald Stolk. All rights reserved. Any unauthorized use, copying, modification,
# reproduction, distribution, or commercial exploitation of Easy2Edit, including its source code,
# is strictly prohibited without prior written permission from Ronald Stolk or RSTCC.
# website https://rstcc.net

"""
Read in another website and turn it into: a theme (colours + fonts), a basic home page, pages, icons and pictures.

Safe by design: addresses may only be public http(s) hosts (no internal network), redirects are re-checked, sizes and counts are
limited, a folder import is limited to the imports folder, ZIP files are unpacked without leaving their folder, and all text goes
through the same HTML sanitizer as the rich text editor. Nothing is applied to the live site by the import itself: the theme and the
home page are options that the user switches on (and off) afterwards.
"""
import html as htmllib
import json
import logging
import threading
import secrets
import time
import mimetypes
import os
import re
import uuid
import zipfile
from urllib.parse import urljoin, urldefrag, urlparse

from django.conf import settings
from django.core.files.storage import default_storage
from django.utils.text import get_valid_filename, slugify

from apps.core import richtext
from apps.core.models import ContentBlock, Language
from apps.core.webtoolkit import (MAX_CSS, MAX_HTML, MAX_IMAGES, MAX_IMG, MAX_STYLESHEETS, VIRTUAL, FolderFetcher, ImportError_, WebFetcher, _clamp, _links, analyse_css, check_public, css_radius, find,
                                  main_node, parse_html, pick_theme, suggest_popup)
from apps.medialib.models import IMAGE_EXT, MediaItem, kind_of
from apps.pages.models import Page

from .models import SiteImport

logger = logging.getLogger(__name__)

# ── content -> clean rich text ───────────────────────────────────────────────
SKIP = {"script", "style", "nav", "header", "footer", "form", "noscript", "svg", "iframe", "button", "aside", "select", "input", "textarea", "template", "head", "video", "audio", "canvas", "object"}
BLOCKS = {"h1": "h2", "h2": "h2", "h3": "h3", "h4": "h4", "h5": "h4", "h6": "h4", "p": "p", "ul": "ul", "ol": "ol", "li": "li", "blockquote": "blockquote"}
INLINE = {"strong": "strong", "b": "strong", "em": "em", "i": "em"}


class Ctx:
    def __init__(self, imp, fetcher, page_url, images):
        self.imp, self.fetcher, self.page_url, self.images = imp, fetcher, page_url, images

    def link(self, href):
        href = (href or "").strip()
        if not href or href.startswith(("#", "javascript:")):
            return ""
        absu = urljoin(self.page_url, href)
        if absu.startswith(("mailto:", "tel:")):
            return absu
        if self.fetcher.virtual and absu.startswith(VIRTUAL):
            return ""  # a link to a file of the imported folder: has no address of its own on this site
        return absu if absu.startswith(("http://", "https://")) else ""

    def image(self, src, alt):
        key = self.images.fetch(urljoin(self.page_url, src or ""), role="image", alt=alt)
        return f'<img data-file="{htmllib.escape(key, quote=True)}" alt="{htmllib.escape(alt or "", quote=True)}">' if key else ""


def to_html(node, ctx, depth=0):
    out = []
    for k in node.kids:
        if isinstance(k, str):
            t = " ".join(k.split())
            if t:
                out.append(htmllib.escape(t) + " ")
            continue
        tag = k.tag
        if tag in SKIP or depth > 40:
            continue
        inner = to_html(k, ctx, depth + 1)
        if tag in BLOCKS:
            if inner.strip():
                out.append(f"<{BLOCKS[tag]}>{inner.strip()}</{BLOCKS[tag]}>")
        elif tag in INLINE:
            if inner.strip():
                out.append(f"<{INLINE[tag]}>{inner.strip()}</{INLINE[tag]}> ")
        elif tag == "a":
            href = ctx.link(k.attrs.get("href"))
            out.append(f'<a href="{htmllib.escape(href, quote=True)}">{inner.strip()}</a> ' if href and inner.strip() else inner)
        elif tag == "br":
            out.append("<br>")
        elif tag == "hr":
            out.append("<hr>")
        elif tag == "img":
            out.append(ctx.image(k.attrs.get("src") or k.attrs.get("data-src"), k.attrs.get("alt", "")))
        else:  # div, section, span, table cells, …: keep what is inside
            out.append(inner)
    return "".join(out)


def tidy(html_text):
    h = re.sub(r"(<br>\s*){3,}", "<br><br>", html_text)
    h = re.sub(r"<p>\s*</p>", "", h)
    return h[: richtext.MAX * 2]  # sanitized later, when the proposal is approved


def text_preview(html_text, n=240):
    return " ".join(re.sub(r"<[^>]+>", " ", html_text).split())[:n]


# ── pictures: written into the theme folder, registered in the library only after approval ──
def theme_dir(slug):
    return os.path.join(str(settings.MEDIA_ROOT), "themes", slug)


class Images:
    def __init__(self, slug, fetcher):
        self.slug, self.f, self.cache, self.items = slug, fetcher, {}, []

    def fetch(self, url, role="image", alt="", name=""):
        """Download one picture into themes/<slug>/img/. Returns its key (path below the media folder) or None."""
        url = urldefrag(url)[0]
        if not url.startswith(("http://", "https://")) or not self.f.same_site(url):
            return None
        if url in self.cache:
            return self.cache[url]
        self.cache[url] = None
        if len(self.items) >= MAX_IMAGES:
            return None
        ext = os.path.splitext(urlparse(url).path)[1].lower().lstrip(".")
        if ext not in IMAGE_EXT:
            return None
        try:
            _, data, _ct = self.f.get(url, MAX_IMG)
        except ImportError_:
            return None
        if ext != "ico":
            try:
                from io import BytesIO

                from PIL import Image

                Image.open(BytesIO(data)).verify()
            except Exception:  # noqa: BLE001
                return None
        base = get_valid_filename(os.path.basename(urlparse(url).path)) or f"image.{ext}"
        rel = f"themes/{self.slug}/img/{uuid.uuid4().hex[:6]}-{base}"
        full = os.path.join(str(settings.MEDIA_ROOT), rel)
        os.makedirs(os.path.dirname(full), exist_ok=True)
        with open(full, "wb") as fh:
            fh.write(data)
        self.cache[url] = rel
        self.items.append({"file": rel, "role": role, "name": (name or alt or base)[:120], "src": url, "include": True, "size": len(data)})
        return rel


    def add_data(self, uri, role="image", alt="", name=""):
        """A picture that sits inside the html file itself (data:image/...;base64,...): written into themes/<slug>/img/."""
        import base64

        m = re.match(r"^data:image/([a-z0-9.+-]+);base64,(.+)$", (uri or "").strip(), re.I | re.S)
        if not m or len(self.items) >= MAX_IMAGES:
            return None
        ext = {"jpeg": "jpg", "svg+xml": "svg", "x-icon": "ico", "vnd.microsoft.icon": "ico"}.get(m.group(1).lower(), m.group(1).lower())
        if ext not in IMAGE_EXT:
            return None
        key = uri[:80] + str(len(uri))
        if key in self.cache:
            return self.cache[key]
        try:
            data = base64.b64decode(re.sub(r"\s", "", m.group(2)), validate=False)
        except Exception:  # noqa: BLE001
            return None
        if not data or len(data) > MAX_IMG:
            return None
        if ext not in ("ico", "svg"):
            try:
                from io import BytesIO

                from PIL import Image

                Image.open(BytesIO(data)).verify()
            except Exception:  # noqa: BLE001
                return None
        rel = f"themes/{self.slug}/img/{uuid.uuid4().hex[:6]}-{get_valid_filename((name or alt or 'afbeelding')[:30]) or 'afbeelding'}.{ext}"
        full = os.path.join(str(settings.MEDIA_ROOT), rel)
        os.makedirs(os.path.dirname(full), exist_ok=True)
        with open(full, "wb") as fh:
            fh.write(data)
        self.cache[key] = rel
        self.items.append({"file": rel, "role": role, "name": (name or alt or "Afbeelding")[:120], "src": "(in het bestand)", "include": True, "size": len(data)})
        return rel


def _lang():
    return Language.objects.filter(is_default=True).values_list("code", flat=True).first() or "nl"


# ── suggestions ──────────────────────────────────────────────────────────────
PROFILE_WORDS = {
    "dating": ["dating", "relatie", "match", "single", "ontmoet", "liefde", "love", "partner zoeken", "flirt"],
    "sporters": ["sport", "training", "fitness", "hardlop", "club", "wedstrijd", "yoga", "coach", "marathon", "zwem"],
    "business": ["bedrijf", "zakelijk", "netwerk", "consult", "advies", "diensten", "b2b", "vacature", "oplossingen", "klanten", "expertise"],
    "webshop": ["winkel", "webshop", "bestel", "producten", "verzending", "korting", "winkelwagen", "shop", "bezorg", "assortiment"],
}


def suggest_profile(text):
    t = text.lower()
    score = {k: sum(t.count(w) for w in ws) for k, ws in PROFILE_WORDS.items()}
    best = max(score, key=score.get)
    if score[best] < 2:
        return {"key": "normal", "reason": "Geen duidelijk type gevonden: een gewoon ledenprofiel past het best.", "scores": score}
    found = [w for w in PROFILE_WORDS[best] if w in t][:4]
    return {"key": best, "reason": "Gevonden woorden: " + ", ".join(found) + ".", "scores": score}


# ── step 1: analyse (nothing is added to the site yet) ───────────────────────
def unique_slug(name):
    base = slugify(name)[:40] or "thema"
    slug, n = base, 2
    while SiteImport.objects.filter(slug=slug).exists() or os.path.exists(theme_dir(slug)):
        slug, n = f"{base}-{n}", n + 1
    return slug


def analyze(fetcher, start_url, theme_name, kind, source, user):
    """Read the site and make a proposal (theme, profiles, popups, pages, pictures). Files go into themes/<name>/;
    the library, pages and settings are only touched after the user approves the proposal."""
    name = (theme_name or "").strip()[:120] or "Geïmporteerde site"
    slug = unique_slug(name)
    imp = SiteImport.objects.create(name=name, slug=slug, status="proposal", source=source[:500], kind=kind, created_by=user)
    try:
        base, data, _ = fetcher.get(start_url, MAX_HTML)
        root = parse_html(data.decode("utf-8", "replace"))
        title_el = find(root, "title")
        site_name = (next((m.attrs.get("content", "") for m in find(root, "meta") if m.attrs.get("property") == "og:site_name"), "") or (title_el[0].text() if title_el else "")).strip()
        site_name = re.split(r"\s[|–—-]\s", site_name)[0][:120]
        if not theme_name and site_name:
            imp.name = site_name
        notes = []

        css = "\n".join(" ".join(k for k in s.kids if isinstance(k, str)) for s in find(root, "style"))
        sheets = [urljoin(base, l.attrs.get("href", "")) for l in find(root, "link", lambda n: "stylesheet" in n.attrs.get("rel", "").lower())][:MAX_STYLESHEETS]
        for s in sheets:
            try:
                if s.startswith("https://fonts.googleapis.com") and not fetcher.virtual:
                    css += f"\n/* {s} */"
                elif fetcher.same_site(s):
                    css += "\n" + fetcher.get(s, MAX_CSS)[1].decode("utf-8", "replace")
            except ImportError_ as e:
                notes.append(f"Stijlblad overgeslagen: {e}")
        weight, bg, fg, fonts = analyse_css(css)
        tc = next((m.attrs.get("content") for m in find(root, "meta") if m.attrs.get("name") == "theme-color"), None)
        th = pick_theme(weight, bg, fg, fonts, tc)
        radius = css_radius(css)
        popup = suggest_popup(css, radius)
        btn = css_radius("".join(re.findall(r"(?:button|\.btn[\w-]*|input)[^{]*\{[^}]*\}", css, re.I)))
        for key, val in (("radius", _clamp("radius", radius)), ("popup_radius", _clamp("popup_radius", popup["radius"])),
                         ("btn_radius", _clamp("btn_radius", btn)), ("popup_btn_radius", _clamp("popup_btn_radius", btn))):
            if val is not None:
                th["values"][key] = val

        images = Images(slug, fetcher)
        for l in find(root, "link", lambda n: "icon" in n.attrs.get("rel", "").lower()):
            images.fetch(urljoin(base, l.attrs.get("href", "")), role="icon" if "apple" in l.attrs.get("rel", "").lower() else "favicon", name="Icoon van de site")
        og = next((m.attrs.get("content") for m in find(root, "meta") if m.attrs.get("property") == "og:image"), None)
        if og:
            images.fetch(urljoin(base, og), role="og_image", name="Deelafbeelding")
        header_imgs = [i for h in (find(root, "header") + find(root, "nav")) for i in find(h, "img")]
        logo = next((i for i in header_imgs + find(root, "img", lambda n: "logo" in (n.attrs.get("src", "") + n.attrs.get("alt", "") + n.attrs.get("class", "")).lower())), None)
        if logo:
            images.fetch(urljoin(base, logo.attrs.get("src", "")), role="logo", name="Logo van de site")

        ctx = Ctx(imp, fetcher, base, images)
        main = main_node(root)
        h1 = find(main, "h1")
        home_html = tidy(to_html(main, ctx))
        home = {"title": (h1[0].text() if h1 else imp.name)[:200], "html": home_html, "preview": text_preview(home_html), "include": True}
        pages, all_text = [], home["title"] + " " + home["preview"]
        for href, label in _links(root, base, fetcher):
            try:
                url2, d2, _ = fetcher.get(href, MAX_HTML)
            except ImportError_ as e:
                notes.append(f"Pagina overgeslagen ({label}): {e}")
                continue
            m2 = main_node(parse_html(d2.decode("utf-8", "replace")))
            h = find(m2, "h1")
            body = tidy(to_html(m2, Ctx(imp, fetcher, url2, images)))
            title = (h[0].text() if h else label or "Pagina")[:80]
            pages.append({"title": title, "path": urlparse(url2).path or "/", "in_menu": True, "include": True, "html": body, "preview": text_preview(body)})
            all_text += " " + title + " " + text_preview(body, 600)
        if len(images.items) >= MAX_IMAGES:
            notes.append(f"{MAX_IMAGES} afbeeldingen is het maximum; de rest is overgeslagen.")

        profile = suggest_profile(all_text)
        imp.proposal = {
            "theme": {"name": imp.name, "values": th["values"], "palette": th["palette"], "fonts": th["fonts"], "dark": th["dark"], "include": True},
            "profile": {"key": profile["key"], "reason": profile["reason"], "apply": True},
            "popup": {"key": popup["key"], "reason": popup["reason"], "apply": True},
            "home": home, "pages": pages, "assets": images.items,
        }
        imp.notes = notes
        imp.save()
        return imp
    except Exception:
        remove_import(imp)  # a failed analysis leaves nothing behind
        raise


# ── step 2: approval → create everything ─────────────────────────────────────
def _register_file(rel, name, imp):
    full = os.path.join(str(settings.MEDIA_ROOT), rel)
    item, _ = MediaItem.objects.get_or_create(key=rel, defaults={"name": name[:255], "kind": kind_of(rel), "mime": mimetypes.guess_type(rel)[0] or "", "size": os.path.getsize(full), "storage": "local"})
    item.name, item.source, item.tags = name[:255], imp.tag, ["import", imp.slug[:28]]
    item.save(update_fields=["name", "source", "tags"])
    return item


def approve(imp, choice):
    """`choice` = what the user left on after checking the proposal (names, colours, ticks). Creates the theme package, the pages and
    registers the pictures. The theme itself is switched on separately ("Thema gebruiken")."""
    if imp.status != "proposal":
        raise ImportError_("Deze import is al verwerkt.")
    pr = imp.proposal
    th = pr["theme"]
    name = str(choice.get("name") or th["name"]).strip()[:120] or imp.name
    pack_key = ""
    values = {}  # the look (colours, fonts, popups …) is made in Thema -> Nieuw themapakket -> Importeren van een website; this import brings the pages, pictures and profile type
    if th.get("ai") and (choice.get("theme") or {}).get("include", True):  # an html file: the AI made a complete theme, it goes into the library and can be switched on
        values = th["values"]
        try:
            from apps.core import resources

            pack_key = resources.save_theme(name, th.get("description"), None, values, install=True)["key"]
        except Exception as e:  # noqa: BLE001
            imp.notes = [*(imp.notes or []), f"Het thema kon niet in de bibliotheek worden gezet ({e}); je kunt het wel gebruiken met de knop Thema gebruiken."]
    prof_key = choice.get("profile") if choice.get("profile") in PROFILE_WORDS or choice.get("profile") == "normal" else None
    popup_key = None

    # pictures: keep the ticked ones, remove the other files from the theme folder
    keep = {a["file"]: a for a in (choice.get("assets") or []) if a.get("include")}
    used_by_designs = set(re.findall(r"__MEDIA__/([^\"'()\s<>]+)", " ".join(p.get("design", "") for p in pr.get("pages", []))))
    for a in pr["assets"]:  # a picture that a page points to stays, whatever was ticked
        if a["file"] in used_by_designs:
            keep[a["file"]] = keep.get(a["file"]) or {"file": a["file"], "include": True, "role": a["role"]}
    idmap, assets = {}, []
    for a in pr["assets"]:
        c = keep.get(a["file"])
        if c:
            item = _register_file(a["file"], a["name"], imp)
            idmap[a["file"]] = item.id
            role = c.get("role") if c.get("role") in ("logo", "logo_dark", "favicon", "icon", "og_image", "image") else a["role"]
            assets.append({"media": item.id, "role": role, "name": a["name"], "src": a["src"]})
        else:
            try:
                os.remove(os.path.join(str(settings.MEDIA_ROOT), a["file"]))
            except OSError:
                pass

    def final(html_text):
        def fix(m):
            mid = idmap.get(htmllib.unescape(m.group(1)))
            return f'<img data-media="{mid}" alt="{m.group(2)}">' if mid else ""
        return richtext.clean(re.sub(r'<img data-file="([^"]*)" alt="([^"]*)">', fix, html_text))[: richtext.MAX]

    lang = _lang()
    n_order = (Page.objects.order_by("-order").values_list("order", flat=True).first() or 0) + 1
    made = 0
    sources_done = []
    design_keys = {}  # file stem -> the address of the page that was made from it (the links between the pages use it)
    place = {}  # file stem -> an existing page that gets the design instead of a new page
    targets_done = []
    for sel in choice.get("pages") or []:
        try:
            src = pr["pages"][int(sel["i"])]
        except (KeyError, ValueError, IndexError, TypeError):
            continue
        tkey = str(sel.get("target") or "")
        tpage = Page.objects.filter(key=tkey, scope="public").first() if tkey else None
        if tpage and not (tpage.kind == "content" or tpage.key == "home"):
            tpage = None  # only the start page and own pages can take over a design
        if src.get("design") and sel.get("include") and tpage:
            place[src["stem"]] = tpage
            design_keys[src["stem"]] = "" if tpage.key == "home" else tpage.key
        elif src.get("design") and sel.get("include"):
            k = f"{imp.slug[:22]}-{slugify(src.get('stem') or src['title'])[:28] or 'pagina'}".strip("-")[:58]
            while Page.objects.filter(key=k).exists() or k in design_keys.values():
                k = f"{k[:54]}-{uuid.uuid4().hex[:3]}"
            design_keys[src["stem"]] = k
    relink = lambda h: re.sub(r"__PAGE__/([a-z0-9._-]+)", lambda m: ("/" + ("p/" + design_keys[m.group(1)] if design_keys[m.group(1)] else "")) if m.group(1) in design_keys else "#", h)  # noqa: E731
    for sel in choice.get("pages") or []:
        try:
            src = pr["pages"][int(sel["i"])]
        except (KeyError, ValueError, IndexError, TypeError):
            continue
        if not sel.get("include"):
            continue
        title = str(sel.get("title") or src["title"]).strip()[:80] or "Pagina"
        if src.get("design") and src["stem"] in place:  # the design goes on a page that exists: the start page or an own page (what it had is kept, to put back when the import is removed)
            pg = place[src["stem"]]
            targets_done.append({"key": pg.key, "title": next(iter(pg.title.values()), pg.key) if isinstance(pg.title, dict) else pg.key, "path": "/" if pg.key == "home" else f"/p/{pg.key}", "design": pg.design, "setup": pg.setup or {}})
            pg.design = relink(src["design"])
            sources_done.append(_save_source(imp, src, pg.design, title, "", pg.key))
            pg.setup = {**(pg.setup or {}), "header": "hide", "footer": "hide"}
            pg.save(update_fields=["design", "setup", "updated_at"])
            continue
        if src.get("design"):  # taken over 1 to 1: the page is its own html; the header and footer of the site are off until the user wants them
            Page.objects.create(key=design_keys[src["stem"]], kind="content", title={lang: title}, in_menu=bool(sel.get("in_menu")), enabled=True, order=n_order + made, source=imp.tag,
                                design=relink(src["design"]), setup={"header": "hide", "footer": "hide"})
            sources_done.append(_save_source(imp, src, relink(src["design"]), title, design_keys[src["stem"]], design_keys[src["stem"]]))
            made += 1
            continue
        key = f"{imp.slug[:22]}-{slugify(title)[:26] or 'pagina'}".strip("-")[:58]
        while Page.objects.filter(key=key).exists():
            key = f"{key[:54]}-{uuid.uuid4().hex[:3]}"
        Page.objects.create(key=key, kind="content", title={lang: title}, in_menu=bool(sel.get("in_menu")), enabled=True, order=n_order + made, source=imp.tag)
        ContentBlock.objects.update_or_create(key=f"page.{key}.body", lang=lang, defaults={"text": richtext.PREFIX + final(src["html"])})
        made += 1
    home = pr["home"]
    imp.home = {"title": home["title"], "html": final(home["html"])} if home.get("title") and (choice.get("home") or {}).get("include", True) else {}
    imp.theme = {"values": values, "palette": [], "fonts": [], "dark": False,
                 "popup": popup_key, "profile": prof_key, "profile_reason": pr["profile"]["reason"], "popup_reason": pr["popup"]["reason"]}
    if pack_key:
        imp.theme["pack"] = pack_key
    if targets_done:
        imp.theme["targets"] = targets_done
    if sources_done:
        imp.theme["sources"] = sources_done
    wanted = {m["key"] for m in (choice.get("modules") or []) if m.get("include")}
    allowed = [m["key"] for m in pr.get("modules", []) if m["key"] in wanted]
    if allowed:
        on, problems = enable_modules(allowed)
        imp.theme["modules"] = on
        if on:
            imp.notes = [*(imp.notes or []), "Aangezet: " + ", ".join(on) + "."]
        imp.notes = [*(imp.notes or []), *problems]
    imp.name, imp.assets, imp.proposal, imp.status = name, assets, {}, "imported"
    imp.save()
    if th.get("ai") and imp.theme.get("values"):  # the theme that was made is switched on and used at once (Thema terugzetten puts the old look back)
        try:
            apply_theme(imp)
        except Exception as e:  # noqa: BLE001
            imp.notes = [*(imp.notes or []), f"Het thema kon niet worden aangezet ({e}); gebruik de knop Thema gebruiken."]
            imp.save(update_fields=["notes"])
    try:  # the package as a plain file next to its pictures: easy to find, copy and back up
        import json

        with open(os.path.join(theme_dir(imp.slug), "theme.json"), "w", encoding="utf-8") as fh:
            json.dump({"name": name, "source": imp.source, "theme": imp.theme, "home": imp.home, "assets": assets}, fh, ensure_ascii=False, indent=2)
    except OSError:
        pass
    return imp


# ── apply / revert / remove ──────────────────────────────────────────────────
def apply_theme(imp):
    """Switch the package on: colours/fonts/popup look (Vormgeving) and, when chosen, the community profile theme."""
    from apps.core.models import SiteSettings

    obj = SiteSettings.load()
    cur = dict(obj.theme or {})
    if not imp.theme_applied:
        imp.theme_backup = {"values": {k: cur.get(k) for k in imp.theme["values"]}}
    cur.update(imp.theme["values"])
    obj.theme = cur
    obj.save()
    prof = imp.theme.get("profile")
    from apps.plugins import facade

    social, ST, SocialSettings = facade.mod("community", "service"), facade.mod("community", "themes"), facade.model("community", "SocialSettings")  # (the plugin Community)
    if prof and "profile" not in imp.theme_backup and social and SocialSettings:
        so, _ = SocialSettings.objects.get_or_create(pk=1)
        imp.theme_backup["profile"] = {"had": "profiles" in (so.data or {}), "data": (so.data or {}).get("profiles")}
        social.save({"profiles": ST.theme_payload(prof)}, ["profiles"])
    imp.theme_applied = True
    imp.save(update_fields=["theme_applied", "theme_backup"])


def revert_theme(imp):
    from apps.core.models import SiteSettings

    if not imp.theme_applied:
        return
    obj = SiteSettings.load()
    cur = dict(obj.theme or {})
    for k, v in ((imp.theme_backup or {}).get("values") or {}).items():
        if v is None:
            cur.pop(k, None)
        else:
            cur[k] = v
    obj.theme = cur
    obj.save()
    prev = (imp.theme_backup or {}).get("profile")
    from apps.plugins import facade

    SocialSettings = facade.model("community", "SocialSettings")
    if prev and SocialSettings:
        so, _ = SocialSettings.objects.get_or_create(pk=1)
        data = dict(so.data or {})
        if prev["had"]:
            data["profiles"] = prev["data"]
        else:
            data.pop("profiles", None)
        so.data = data
        so.save()
    imp.theme_applied, imp.theme_backup = False, {}
    imp.save(update_fields=["theme_applied", "theme_backup"])


HOME_KEYS = ("home.title", "home.text")


def apply_home(imp):
    if not imp.home:
        raise ImportError_("Er is geen startpagina ingelezen.")
    if not imp.home_applied:
        imp.home_backup = {k: list(ContentBlock.objects.filter(key=k).values("lang", "text")) for k in HOME_KEYS}
    lang = _lang()
    for k in HOME_KEYS:
        ContentBlock.objects.filter(key=k).delete()
    ContentBlock.objects.create(key="home.title", lang=lang, text=imp.home.get("title", ""))
    ContentBlock.objects.create(key="home.text", lang=lang, text=richtext.PREFIX + imp.home.get("html", ""))
    imp.home_applied = True
    imp.save(update_fields=["home_applied", "home_backup"])


def revert_home(imp):
    if not imp.home_applied:
        return
    for k in HOME_KEYS:
        ContentBlock.objects.filter(key=k).delete()
        for row in (imp.home_backup or {}).get(k, []):
            ContentBlock.objects.create(key=k, lang=row["lang"], text=row["text"])
    imp.home_applied = False
    imp.save(update_fields=["home_applied"])


def remove_import(imp):
    """Everything of this import goes and what it replaced comes back. Returns what happened, for the screen: {"done": [...], "problems": [...], "leftovers": [...]}."""
    th, ap = dict(imp.theme or {}), dict((imp.theme or {}).get("apply") or {})
    summary = {"done": [], "problems": [], "leftovers": []}
    if imp.theme_applied:
        summary["done"].append("Het thema is teruggezet naar de vorige vormgeving.")
    if th.get("menu_backup"):
        summary["done"].append("De header en het menu zijn teruggezet.")
    if th.get("pack"):
        summary["done"].append("Het thema van deze import is uit de thema's en de bibliotheek gehaald.")
    back = [b["key"] for b in ap.get("backups", [])] + [b["key"] for b in ap.get("design_backups", [])] + [t["key"] for t in th.get("targets", [])]
    if back:
        summary["done"].append("De inhoud van deze pagina's is teruggezet: " + ", ".join(dict.fromkeys(back)) + ".")
    if Page.objects.filter(source=imp.tag).exists():
        summary["done"].append(f"{Page.objects.filter(source=imp.tag).count()} pagina('s) van de import zijn verwijderd.")
    if ap.get("faq_ids"):
        summary["done"].append("De veelgestelde vragen van de import zijn uit de FAQ-module gehaald.")
    if ap.get("built") and not back:
        summary["problems"].append("Pagina's die met blokken zijn opgebouwd en geen eerdere inhoud hadden, zijn leeg teruggezet.")
    on = th.get("modules") or []
    if on:
        summary["leftovers"].append("De modules die de import aanzette blijven aan (" + ", ".join(on) + "). Zet ze uit bij Modules of Plugins als je ze niet nodig hebt.")
    try:
        _remove_import(imp)
    except Exception as e:  # noqa: BLE001
        logger.exception("remove_import %s", imp.id)
        summary["problems"].append(f"Opruimen is niet helemaal gelukt ({e}).")
    if summary["problems"]:
        summary["advice"] = "Klopt er na het verwijderen iets niet op je pagina's? Doe dan een herinstallatie van de standaard installatie via Superadmin → Standaard installaties."
    return summary


def _remove_import(imp):
    """Everything that came from this import goes: pages and their texts, library pictures (and brand pictures that use them), the
    theme folder, and the theme / home page are put back when they were switched on."""
    import shutil

    from apps.branding.models import SiteAsset

    try:
        revert_theme(imp)
        revert_home(imp)
    except Exception:  # noqa: BLE001
        logger.exception("revert failed for import %s", imp.id)
    try:
        restore_header(imp)
        if "content_w_before" in (imp.theme or {}):
            from apps.core.models import SiteSettings

            so = SiteSettings.load()
            t = dict(so.theme or {})
            if imp.theme["content_w_before"] is None:
                t.pop("content_w", None)
            else:
                t["content_w"] = imp.theme["content_w_before"]
            so.theme = t
            so.save()
    except Exception:  # noqa: BLE001
        logger.exception("header / content width of import %s could not be restored", imp.id)
    for b in ((imp.theme or {}).get("apply") or {}).get("design_backups", []):  # pages of the website that got a design: what they had comes back
        Page.objects.filter(key=b["key"]).update(design=b.get("design", ""), setup=b.get("setup") or {})
    pack = (imp.theme or {}).get("pack")
    if pack:  # the theme package made by this import goes from the themes and from the library
        try:
            from apps.core import resources, themepacks

            themepacks.remove(pack)
            resources.delete_theme(pack)
        except Exception:  # noqa: BLE001
            logger.exception("theme %s of import %s could not be removed", pack, imp.id)
    for b in ((imp.theme or {}).get("apply") or {}).get("backups", []):  # pages that were rebuilt: the blocks they had come back
        from apps.pages.models import PageLayout

        PageLayout.objects.filter(key=b["key"]).delete()
        if b.get("layout"):
            PageLayout.objects.create(key=b["key"], data=b["layout"])
        for row in b.get("texts") or []:
            ContentBlock.objects.update_or_create(key=row["key"], lang=row["lang"], defaults={"text": row["text"]})
    for t in (imp.theme or {}).get("targets", []):  # pages that got a design: what they had comes back
        Page.objects.filter(key=t["key"]).update(design=t.get("design", ""), setup=t.get("setup") or {})
    ContentBlock.objects.filter(key__startswith=f"imp{imp.id}.").delete()
    faq_ids = ((imp.theme or {}).get("apply") or {}).get("faq_ids") or []
    if faq_ids:
        try:
            from apps.plugins import facade

            Entry = facade.model("faq", "FaqEntry")
            if Entry:
                Entry.objects.filter(pk__in=faq_ids).delete()
        except Exception:  # noqa: BLE001
            logger.exception("faq entries of import %s could not be removed", imp.id)
    for p in Page.objects.filter(source=imp.tag):
        from apps.pages.models import PageLayout as _PL

        _PL.objects.filter(key=p.key).delete()
        ContentBlock.objects.filter(key__startswith=f"page.{p.key}.").delete()
        p.delete()
    for item in MediaItem.objects.filter(source=imp.tag):
        SiteAsset.objects.filter(image=item.key).delete()
        default_storage.delete(item.key)
    MediaItem.objects.filter(source=imp.tag).delete()
    if imp.slug:
        shutil.rmtree(theme_dir(imp.slug), ignore_errors=True)
    imp.delete()


# ── entry points ─────────────────────────────────────────────────────────────
def imports_dir():
    d = getattr(settings, "SITE_IMPORT_DIR", None) or os.path.join(settings.BASE_DIR, "imports")
    os.makedirs(d, exist_ok=True)
    return d


def list_folders():
    d = imports_dir()
    return sorted(n for n in os.listdir(d) if os.path.isdir(os.path.join(d, n)) and not n.startswith("."))


def import_url(url, name, user):
    url = (url or "").strip()
    if not re.match(r"^https?://", url):
        url = "https://" + url
    check_public(url)
    return analyze(WebFetcher(url), url, name, "url", url, user)


def import_folder(folder, name, user):
    if folder not in list_folders():
        raise ImportError_("Deze map staat niet in de importmap.")
    return analyze(FolderFetcher(os.path.join(imports_dir(), folder)), VIRTUAL, name or folder, "folder", folder, user)


def import_zip(upload, name, user):
    import shutil
    import tempfile

    tmp = tempfile.mkdtemp(prefix="siteimport-")
    try:
        with zipfile.ZipFile(upload) as z:
            infos = [i for i in z.infolist() if not i.is_dir()]
            if len(infos) > 800 or sum(i.file_size for i in infos) > 120 * 2**20:
                raise ImportError_("Het ZIP-bestand is te groot.")
            for i in infos:
                dest = os.path.realpath(os.path.join(tmp, i.filename))
                if not dest.startswith(os.path.realpath(tmp) + os.sep):
                    continue  # never write outside the folder
                if os.path.splitext(i.filename)[1].lower().lstrip(".") not in {"html", "htm", "css", *IMAGE_EXT, "svg"}:
                    continue
                os.makedirs(os.path.dirname(dest), exist_ok=True)
                with z.open(i) as src, open(dest, "wb") as out:
                    out.write(src.read())
        root = tmp
        entries = os.listdir(tmp)
        if not os.path.exists(os.path.join(tmp, "index.html")) and len(entries) == 1 and os.path.isdir(os.path.join(tmp, entries[0])):
            root = os.path.join(tmp, entries[0])
        if not os.path.exists(os.path.join(root, "index.html")):
            raise ImportError_("Er staat geen index.html in het ZIP-bestand.")
        return analyze(FolderFetcher(root), VIRTUAL, name or os.path.splitext(upload.name)[0], "zip", upload.name, user)
    except zipfile.BadZipFile:
        raise ImportError_("Dit is geen geldig ZIP-bestand.")
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


# ── one html file: the AI makes the theme, the pages, the content and says which modules are needed ──
MODULE_CHOICES = [  # (key, kind, label, what it is for)
    ("webshop", "plugin", "Webshop", "producten met prijzen, winkelwagen en afrekenen"),
    ("faq", "plugin", "FAQ", "veelgestelde vragen met antwoorden"),
    ("community", "plugin", "Community", "ledenprofielen, zoeken, berichten en chat"),
    ("agenda", "plugin", "Agenda", "evenementen, activiteiten en afspraken"),
    ("documents", "plugin", "Documenten", "downloads en documenten"),
    ("marketplace", "plugin", "Marktplaats", "advertenties van gebruikers"),
    ("subscriptions", "plugin", "Abonnementen en donaties", "betaalde toegang of giften"),
    ("seo", "plugin", "SEO", "vindbaarheid in zoekmachines"),
    ("languages", "module", "Talen", "een site in meer dan één taal"),
    ("privacy_pages", "module", "Privacy- en cookiepagina", "privacyverklaring en cookies"),
]
HTML_MAX = 6 * 2**20
DESIGN_EXT = {"html", "htm"}


class AnyFetcher:
    """Stylesheets that a dropped html file points to with a full address: any public address (checked for every one of them)."""
    virtual = False

    def same_site(self, url):
        return url.startswith(("http://", "https://"))

    def get(self, url, limit):
        check_public(url)
        return WebFetcher(url).get(url, limit)


def _ai_plan(pages, lang):
    from apps.core import themeimport as TI

    cand = [{"key": k, "label": lab, "for": use} for k, _kind, lab, use in MODULE_CHOICES]
    system = ("You analyse the html files of a website that is taken over into a content management system (every file becomes a page, its design is kept exactly as it is). "
              'Answer with ONE JSON object only: {"site_name": string, "profile": "normal"|"dating"|"sporters"|"business"|"webshop", "profile_reason": one short Dutch sentence, '
              '"pages": [{"file": file name exactly as given, "title": short page title in the language of the content (like in a menu), "in_menu": boolean}], '
              '"modules": [{"key": one of the module keys, "reason": one short Dutch sentence}]}. '
              "List every file once, in the order of a sensible menu (home first). Use in_menu false for pages that only make sense behind a link (thank-you page, terms). "
              "Choose a module only when the content needs it (prices and products -> webshop, questions and answers -> faq, members or dating -> community, events -> agenda, downloads -> documents, adverts -> marketplace, paid access or gifts -> subscriptions); at most 5, none when nothing is needed.")
    prompt = json.dumps({"files": pages, "language_hint": lang, "modules": cand}, ensure_ascii=False)
    return TI._ai_json(system, prompt, 3000, 120, need=("pages", "site_name"))


def _prog(imp_id, percent, step, error=""):
    """The progress of the analysis of an import that runs in the background."""
    row = SiteImport.objects.filter(pk=imp_id).first()
    if not row:  # the import was thrown away (Annuleren): the analysis stops here
        if error:
            return
        raise ImportError_("Geannuleerd")
    th = dict(row.theme or {})
    cur = th.get("analyse") or {}
    th["analyse"] = {"percent": cur.get("percent", 0) if percent is None else percent, "step": step or cur.get("step", ""), **({"error": error} if error else {})}
    SiteImport.objects.filter(pk=imp_id).update(theme=th)


def import_html(uploads, name, user, background=False):
    """One or more html files (with their css and pictures when they are dropped along): every html file becomes a page whose design is kept 1 to 1
    (its own html, css and scripts), the colours and shapes become a theme (made by the AI from the CSS), the pictures go into the media library and the modules
    that the content needs are proposed. Nothing is changed before approval.
    With background=True the (long) analysis runs in a thread and reports its progress (imp.theme["analyse"] = {percent, step, error}); the proposal appears when it is ready."""
    from apps.core import theme as T
    from apps.core import themeimport as TI
    from apps.integrations import ai

    if not ai.available():
        raise ImportError_("Koppel Claude eerst bij Admin → API keys (Anthropic) en zet de koppeling aan.")
    files, total = {}, 0
    for u in list(uploads)[:80]:
        data = u.read(HTML_MAX + 1)
        total += len(data)
        if len(data) > HTML_MAX or total > 40 * 2**20:
            raise ImportError_("De bestanden zijn te groot (een bestand maximaal 6 MB, samen maximaal 40 MB).")
        fname = os.path.basename(str(getattr(u, "name", "") or "bestand")).strip()
        files[fname.lower()] = (fname, data)
    ext = lambda n: os.path.splitext(n)[1].lower().lstrip(".")  # noqa: E731
    htmls = {n: v for n, v in files.items() if ext(n) in DESIGN_EXT}
    csss = {n: v[1].decode("utf-8", "replace") for n, v in files.items() if ext(n) == "css"}
    pics = {n: v for n, v in files.items() if ext(n) in IMAGE_EXT or ext(n) == "svg"}
    if not htmls:
        raise ImportError_("Er staat geen html-bestand tussen. Sleep één of meer .html-bestanden (met eventueel de css en de afbeeldingen).")
    first = sorted(htmls)[0]
    base_name = (name or "").strip()[:120] or os.path.splitext(htmls[first][0])[0][:60] or "Geïmporteerde site"
    imp = SiteImport.objects.create(name=base_name, slug=unique_slug(base_name), status="proposal", source=", ".join(v[0] for v in list(htmls.values())[:6])[:480], kind="html", created_by=user)
    run_bg = {"on": False}  # (not "bg": that name is used for the background colour in the analysis below)

    def work():
        try:
            notes = []
            _prog(imp.pk, 6, "De afbeeldingen opslaan")
            # pictures that were dropped along: into the theme folder (the designs point to them)
            picmap, items = {}, []
            for n, (orig, data) in pics.items():
                if len(items) >= MAX_IMAGES or len(data) > MAX_IMG:
                    notes.append(f"{orig} is overgeslagen (te veel of te groot).")
                    continue
                if ext(n) not in ("ico", "svg"):
                    try:
                        from io import BytesIO

                        from PIL import Image

                        Image.open(BytesIO(data)).verify()
                    except Exception:  # noqa: BLE001
                        notes.append(f"{orig} is geen geldige afbeelding.")
                        continue
                rel = f"themes/{imp.slug}/img/{uuid.uuid4().hex[:6]}-{get_valid_filename(orig) or 'afbeelding.' + ext(n)}"
                full = os.path.join(str(settings.MEDIA_ROOT), rel)
                os.makedirs(os.path.dirname(full), exist_ok=True)
                with open(full, "wb") as fh:
                    fh.write(data)
                picmap[n] = rel
                items.append({"file": rel, "role": "image", "name": orig[:120], "src": orig, "include": True, "size": len(data)})

            _prog(imp.pk, 14, "De pagina's inlezen")
            stems = {os.path.splitext(n)[0]: n for n in htmls}
            url_re = re.compile(r"url\(\s*([\"']?)([^)\"']+)\1\s*\)", re.I)

            def fix_url(m):
                raw = m.group(2).strip()
                if raw.startswith(("data:", "http", "//", "#")):
                    return m.group(0)
                b = os.path.basename(urlparse(raw).path).lower()
                return f"url({m.group(1)}__MEDIA__/{picmap[b]}{m.group(1)})" if b in picmap else m.group(0)

            def design_of(text):
                def link(m):
                    tag = m.group(0)
                    href = re.search(r"href\s*=\s*[\"']([^\"']+)[\"']", tag, re.I)
                    if href and "stylesheet" in tag.lower() and not href.group(1).startswith(("http://", "https://", "//")):
                        b = os.path.basename(urlparse(href.group(1)).path).lower()
                        if b in csss:
                            return f"<style>{csss[b]}</style>"
                    return tag

                text = re.sub(r"<link\b[^>]*>", link, text, flags=re.I)
                text = url_re.sub(fix_url, text)

                def attr(m):
                    raw = m.group(3).strip()
                    if raw.startswith(("data:", "http", "//", "#", "mailto:", "tel:", "javascript:")):
                        return m.group(0)
                    b = os.path.basename(urlparse(raw).path).lower()
                    if b in picmap:
                        return f"{m.group(1)}={m.group(2)}__MEDIA__/{picmap[b]}{m.group(2)}"
                    return m.group(0)

                text = re.sub(r"\b(src|poster|data-src|data-bg)\s*=\s*([\"'])([^\"']+)\2", attr, text, flags=re.I)

                def page_link(m):
                    path = m.group(2)
                    stem = os.path.splitext(os.path.basename(urlparse(path).path))[0].lower()
                    return f"href={m.group(1)}__PAGE__/{stem}{m.group(3) or ''}{m.group(1)}" if stem in stems else m.group(0)

                return re.sub(r"href\s*=\s*([\"'])((?![a-z]+:|//)[^\"'#?]*\.html?)([#?][^\"']*)?\1", page_link, text, flags=re.I)

            css_all = "\n".join(csss.values())
            pages, plain = [], {}
            fetcher = AnyFetcher()
            for n in sorted(htmls, key=lambda k: (not k.startswith(("index", "home")), k)):
                _prog(imp.pk, 14 + int(26 * len(pages) / max(1, len(htmls))), f"Pagina {len(pages) + 1} van {len(htmls)} inlezen")
                orig, data = htmls[n]
                text = data.decode("utf-8", "replace")
                if not re.search(r"<(html|body|div|p|h1)\b", text, re.I):
                    notes.append(f"{orig} lijkt geen html en is overgeslagen.")
                    continue
                root = parse_html(text)
                css_all += "\n" + "\n".join(" ".join(k for k in s.kids if isinstance(k, str)) for s in find(root, "style"))
                for l in [l.attrs.get("href", "") for l in find(root, "link", lambda x: "stylesheet" in x.attrs.get("rel", "").lower())][:MAX_STYLESHEETS]:
                    if l.startswith("https://fonts.googleapis.com"):
                        css_all += f"\n/* {l} */"
                    elif l.startswith(("http://", "https://")) and len(css_all) < 3 * MAX_CSS:
                        try:
                            css_all += "\n" + fetcher.get(l, MAX_CSS)[1].decode("utf-8", "replace")
                        except ImportError_ as e:
                            notes.append(f"Stijlblad overgeslagen: {e}")
                for l in find(root, "link", lambda x: "icon" in x.attrs.get("rel", "").lower()):
                    b = os.path.basename(urlparse(l.attrs.get("href", "")).path).lower()
                    for it in items:
                        if b in picmap and it["file"] == picmap[b] and it["role"] == "image":
                            it["role"] = "favicon"
                title_el = find(root, "title")
                h1 = find(root, "h1")
                title = ((title_el[0].text() if title_el else "") or (h1[0].text() if h1 else "") or os.path.splitext(orig)[0]).strip()
                title = re.split(r"\s[|–—-]\s", title)[0].strip()[:80] or os.path.splitext(orig)[0]
                body = main_node(root).text()
                plain[n] = " ".join(body.split())[:600]
                design = design_of(text)
                if len(design) > 3 * 2**20:
                    notes.append(f"{orig} is groot; het kan traag laden.")
                pages.append({"file": orig, "stem": os.path.splitext(n)[0], "title": title, "path": "/" + orig, "in_menu": True, "include": True, "html": "", "design": design, "preview": plain[n][:240], "suggest": "home" if os.path.splitext(n)[0] in ("index", "home", "start") else ""})
            if not pages:
                raise ImportError_("Er is geen bruikbaar html-bestand gevonden.")

            _prog(imp.pk, 42, "Kleuren, lettertypen en vormen bepalen")
            # the look: from the CSS of all files; Claude designs the whole theme from it
            weight, bg, fg, fonts = analyse_css(css_all)
            first_root = parse_html(htmls[first][1].decode("utf-8", "replace"))
            tc = next((m.attrs.get("content") for m in find(first_root, "meta") if m.attrs.get("name") == "theme-color"), None)
            th = pick_theme(weight, bg, fg, fonts, tc)
            radius = css_radius(css_all)
            popup = suggest_popup(css_all, radius)
            btn = css_radius("".join(re.findall(r"(?:button|\.btn[\w-]*|input)[^{]*\{[^}]*\}", css_all, re.I)))
            values = dict(th["values"])
            for key, val in (("radius", _clamp("radius", radius)), ("popup_radius", _clamp("popup_radius", popup["radius"])), ("btn_radius", _clamp("btn_radius", btn)), ("popup_btn_radius", _clamp("popup_btn_radius", btn))):
                if val is not None:
                    values[key] = val
            values["system_popup"] = popup["key"]
            values.update(TI.guess_layout(css_all, values.get("primary"), False))
            tokens = TI.site_tokens(css_all)
            values.update(TI.tokens_to_values(tokens))
            site_fonts = tokens["fonts"] or th["fonts"]
            if not site_fonts:
                values["font_body"] = values["font_heading"] = "System"
            meta_desc = next((m.attrs.get("content", "") for m in find(first_root, "meta") if m.attrs.get("name") == "description"), "")[:300]
            theme_name, theme_desc = base_name, meta_desc[:200] or f"Gemaakt uit {htmls[first][0]}"
            try:
                info = {"name": base_name, "description": meta_desc, "dark_site": th["dark"], "palette": th["palette"], "fonts": th["fonts"], "radius": radius, "button_radius": btn, "popup_suggestion": popup["key"],
                        "site_tokens": tokens, "fonts_found": site_fonts, "heuristic_values": values, "text": plain.get(first, "")[:700]}
                _prog(imp.pk, 50, "Easy2edit ontwerpt het thema uit de kleuren en vormen…")
                out = TI._ask_ai(info)
                clean, errors = T.validate({k: v for k, v in (out.get("values") or {}).items() if k in T.FIELDS})
                values.update({k: v for k, v in clean.items() if k not in errors})
                theme_name = str(out.get("name") or theme_name)[:60]
                theme_desc = str(out.get("description") or theme_desc)[:300]
            except (ValueError, KeyError, TypeError) as e:
                notes.append(f"Easy2edit kon het thema niet maken ({e}). Het thema is afgeleid uit de kleuren en lettertypen van de bestanden.")
            if not th["dark"] and "prefers-color-scheme" not in css_all.lower():
                values["default_mode"] = "light"  # the file has one (light) look: the site starts in it
            values["block_style"] = "flat"  # the design has its own blocks: no extra boxes around texts
            values, _err = T.validate(TI._complete(values))

            # the pages: names, menu and the modules, by Claude
            _prog(imp.pk, 78, "Easy2edit geeft de pagina's een naam en kiest de modules…")
            lang_hint = _lang()
            try:
                plan = _ai_plan([{"file": p["file"], "title": p["title"], "text": plain.get(p["file"].lower(), "")[:400]} for p in pages], lang_hint)
            except (ValueError, KeyError, TypeError) as e:  # Claude gave no readable answer: the pages keep the titles of their files
                plan = {}
                notes.append(f"Easy2edit kon de pagina's niet benoemen ({e}); de titels komen uit de bestanden zelf. Je kunt ze hieronder aanpassen.")
            by_file = {p["file"].lower(): p for p in pages}
            ordered = []
            for r in plan.get("pages") or []:
                p = by_file.pop(str((r or {}).get("file") or "").lower(), None)
                if p:
                    p["title"] = str((r or {}).get("title") or p["title"]).strip()[:80] or p["title"]
                    p["in_menu"] = bool((r or {}).get("in_menu", True))
                    ordered.append(p)
            ordered += list(by_file.values())
            profile = plan.get("profile") if plan.get("profile") in PROFILE_WORDS or plan.get("profile") == "normal" else suggest_profile(" ".join(plain.values())[:1500])["key"]
            known = {k: (kind, lab) for k, kind, lab, _u in MODULE_CHOICES}
            modules = []
            for m in plan.get("modules") or []:
                k = (m or {}).get("key")
                if k in known and k not in {x["key"] for x in modules}:
                    modules.append({"key": k, "kind": known[k][0], "label": known[k][1], "reason": str((m or {}).get("reason") or "")[:200], "include": True})
            if not name and plan.get("site_name"):
                imp.name = str(plan["site_name"])[:120]
            missing = len([p for p in ordered for _ in re.finditer(r'(?:src|poster)=["\'](?!data:|https?:|//|__MEDIA__)[^"\']+\.(?:png|jpe?g|gif|webp|svg)', p["design"], re.I)])
            if missing:
                notes.append(f"{missing} afbeeldingen waar de pagina's naar verwijzen zijn niet meegestuurd. Sleep ze er de volgende keer bij, dan staan ze er precies zo op.")
            _prog(imp.pk, 95, "Het voorstel opmaken")
            imp.proposal = {
                "theme": {"name": theme_name, "description": theme_desc, "values": values, "palette": th["palette"], "fonts": site_fonts[:3] or th["fonts"], "dark": th["dark"], "include": True, "ai": True},
                "profile": {"key": profile, "reason": str(plan.get("profile_reason") or "Gekozen door Easy2edit uit de inhoud van de bestanden.")[:300], "apply": True},
                "popup": {"key": popup["key"], "reason": popup.get("reason", ""), "apply": False},
                "home": {"title": "", "html": "", "preview": "", "include": False}, "pages": ordered, "assets": items, "modules": modules, "design": True,
            }
            imp.notes = notes
            imp.save()
            return imp
        except Exception as e:  # noqa: BLE001
            if run_bg["on"] and str(e) == "Geannuleerd":  # thrown away by the user while it was analysing: nothing to report
                return None
            if run_bg["on"]:  # in the background: the import stays (with the reason), so the screen can show it and the user can throw it away
                logger.exception("site import analysis failed")
                _prog(imp.pk, None, "", error=str(e)[:300] if isinstance(e, ImportError_) else "Het analyseren is niet gelukt. Probeer het nog eens.")
                return None
            remove_import(imp)  # a failed analysis leaves nothing behind
            raise

    if not background:
        return work()
    run_bg["on"] = True
    _prog(imp.pk, 2, "Starten")

    def runner():
        from django import db

        try:
            work()
        finally:
            db.connections.close_all()

    threading.Thread(target=runner, daemon=True).start()
    return imp


def enable_modules(keys):
    """Switch on the modules the pages need (plugins with the plugins they need). Returns (labels, problems)."""
    from apps.core import modules as M
    from apps.core import presets
    from apps.core.models import ModuleState

    known = {k: (kind, lab) for k, kind, lab, _u in MODULE_CHOICES}
    on, problems = [], []
    for k in keys:
        if k not in known:
            continue
        kind, lab = known[k]
        if kind == "plugin":
            done = presets.ensure_plugin(k)
            if done.get("problem"):
                problems.append(done["problem"])
                continue
        else:
            ModuleState.objects.update_or_create(key=k, defaults={"enabled": True})
        on.append(lab)
    M.invalidate()
    return on, problems


# ── Toepassen: the design becomes blocks of the page builder (editable in edit mode) ─────────────────────────
HOME_FIXED = ["home.hero", "home.title", "home.text", "home.photos"]
HEX6 = re.compile(r"#[0-9a-fA-F]{6}")
APPLY_CSS_MAX = 22000
APPLY_TAGS = {"script", "style", "noscript", "template", "header", "nav", "footer"}


class ApplyCancelled(Exception):
    """The user pressed Annuleren during the application: the work ends at the next moment that its progress is kept."""


def _set_apply(imp_id, _force=False, **kw):
    """The progress of an application is kept with the import: the screen asks for it every moment."""
    imp = SiteImport.objects.filter(pk=imp_id).first()
    if not imp:
        return
    th = dict(imp.theme or {})
    st = dict(th.get("apply") or {})
    if st.get("cancel") and not _force and kw.get("state") not in ("done", "error", "cancelled"):
        raise ApplyCancelled()  # (the progress is kept all the time: this is where a cancel is noticed)
    st.update(kw)
    st["updated"] = time.time()
    th["apply"] = st
    SiteImport.objects.filter(pk=imp_id).update(theme=th)


def apply_cancel(imp):
    """Annuleren: the running application stops at its next step (state 'cancelled')."""
    imp = SiteImport.objects.get(pk=imp.pk)  # (the state is read from the database, not from this copy)
    if apply_state(imp).get("state") == "running":
        _set_apply(imp.id, _force=True, cancel=True, step="Bezig met annuleren…")
    return apply_state(SiteImport.objects.get(pk=imp.pk))


def apply_state(imp):
    return (imp.theme or {}).get("apply") or {}


def pending_pages(imp):
    """The pages of this import that still hold a design: its own new pages and the existing pages that got one."""
    pages = list(Page.objects.filter(source=imp.tag).exclude(design=""))
    for t in (imp.theme or {}).get("targets", []):
        p = Page.objects.filter(key=t["key"]).exclude(design="").first()
        if p and all(p.pk != x.pk for x in pages):
            pages.append(p)
    return pages


def _compact(node, imgs, depth=0):
    """The html of a section as short text for the AI: no icons, scripts or styles; pictures as IMG:n."""
    out = []
    for k in node.kids:
        if isinstance(k, str):
            t = " ".join(k.split())
            if t:
                out.append(htmllib.escape(t))
            continue
        tag = k.tag
        if tag in ("script", "style", "noscript", "template") or depth > 30:
            continue
        if tag == "svg":
            out.append("[icon]")
            continue
        attrs = "".join(f' {a}="{htmllib.escape(str(k.attrs.get(a))[:120], quote=True)}"' for a in ("class", "id", "href", "alt", "data-sysobject") if k.attrs.get(a))
        if tag == "img":
            src = str(k.attrs.get("src") or "").replace("__MEDIA__/", "")
            out.append(f'<img{attrs} src="IMG:{imgs[src]}">' if src in imgs else f"<img{attrs}>")
            continue
        if tag in ("br", "hr"):
            out.append(f"<{tag}>")
            continue
        out.append(f"<{tag}{attrs}>{_compact(k, imgs, depth + 1)}</{tag}>")
    return "".join(out)


def _sections(root):
    """The top-level sections of a page (without header, menu and footer: the site has its own)."""
    level = main_node(root)
    for _ in range(3):
        kids = [k for k in level.kids if not isinstance(k, str) and k.tag not in APPLY_TAGS]
        if len(kids) == 1 and kids[0].tag in ("div", "main", "article", "section") and len([x for x in kids[0].kids if not isinstance(x, str)]) > 1:
            level = kids[0]
        else:
            break
    out = []
    for k in level.kids:
        if isinstance(k, str) or k.tag in APPLY_TAGS:
            continue
        if k.text().strip() or find(k, "img"):
            out.append(k)
    return out[:40]


def _css_of(design, imgs):
    css = "\n".join(re.findall(r"<style[^>]*>(.*?)</style>", design, re.S | re.I))
    css = re.sub(r"/\*.*?\*/", "", css, flags=re.S)
    css = re.sub(r"\s+", " ", css)
    for rel, n in imgs.items():
        css = css.replace("__MEDIA__/" + rel, f"IMG:{n}")
    return css[:APPLY_CSS_MAX]


ROW_SYSTEM = (
    "You rebuild one section of a web page with the blocks of a page builder, so that it looks like the original and can still be edited. You get the section as html, the page's CSS and the numbered pictures. "
    'Answer with ONE JSON object only: {"rows": [row, ...]} (1 to 4 rows; use more than one row when the section has several distinct bands or a grid with more than 4 items). A row is: '
    '{"title": short name, "anchor": id of the section when links point to it (#id) else "", "full": true when the background runs edge to edge (a hero or a call-to-action banner), "bg": "#rrggbb" background colour or "", '
    '"bg_image": picture number or null, "overlay": 0-0.9, "color": "#rrggbb" text colour on this background or "" for the normal text colour, "radius": px, "pad_top": px, "pad_bottom": px, "min_height": share of the screen height 0-100 (a hero) or 0, '
    '"gap": "sm"|"md"|"lg", "cells": [cell, ...]} with 1 to 4 cells side by side; a cell is {"width": "auto" or a percentage 25|33|50|66|75, "halign": "left"|"center"|"right", "valign": "top"|"center"|"bottom", "card": {"bg": "#rrggbb", "radius": px, "pad": px, "border": "#rrggbb" or "", "shadow": true|false} or null, "items": [item, ...]}. A cell with "card" is a real card (a box with its own background, rounded corners, space inside, a line and/or a shadow): use it for every card, tile, plan, step box and preview box of the original (also a white box on a dark band) and give the exact colours, radius and padding of the CSS. '
    'Items: {"type": "heading", "html": text, "size": rem, "weight": "400"|"500"|"600"|"700"|"800", "color": "#rrggbb"|"", "align": "left"|"center"|"right", "mb": rem}; '
    '{"type": "text", "html": "<p>..</p>" (only p, ul, ol, li, strong, em, a with href, br), "size": rem, "color": "#rrggbb"|"", "align": ..., "bg": "#rrggbb" (a label/pill with its own background, then also "radius": px and "pad": {"t":px,"r":px,"b":px,"l":px})}; '
    '{"type": "image", "img": picture number, "align": ..., "radius": px, "w": "100%"|"50%"|"320px"}; '
    '{"type": "button", "label": text, "href": "#id" or "/path" or "https://...", "style": "primary"|"outline"|"ghost", "radius": px, "bg": "#rrggbb" or "transparent", "color": "#rrggbb", "border": "#rrggbb" (the colours of the button as in the CSS, also on a dark band)}; {"type": "spacer", "h": px}; {"type": "line"}; '
    '{"type": "code", "html": "<div>..</div>", "css": ".x{..}"} for a part that the blocks above cannot make look right: a progress bar, a list with check marks or icons, a mock-up/preview card, a gradient or decorative shape, an inline SVG, a table. Copy its html and the CSS rules it needs from the original (the real texts, colours, sizes, border radius and shadows), write the pictures as IMG:n, keep it self-contained (no script, no external css). Prefer normal blocks for headings, texts, buttons and pictures; use code only for what really cannot be made with them. '
    '{"type": "sysobject", "slug": value of the data-sysobject attribute} for every element <div data-sysobject="..."> (a live block of the system: keep it, in the same place and order as in the section, as its own item; it has no text and no styling). '
    '{"type": "faq", "heading": text, "items": [{"q": question, "a": "<p>answer</p>"}]} for a list of frequently asked questions (they are put into the FAQ module of the system, so use it for every question and answer list/accordion). '
    "Every section is one full-width BAND: put its background colour in bg (\"\" when it has the page colour) and its content in cells; the system centres the content in the width of the page and runs the band edge to edge, so never put a card or box around a whole section. design_notes tell you the exact colours, padding and layout of this section: follow them. "
    "A hero or intro with text on one side and a picture, preview card or other visual on the other: use TWO cells (50/50 or 55/45), both valign center, the text cell with heading, text and buttons in the order and sizes of the original, the visual cell with the card (card) or a code item. Take EVERY element of the hero: the small label above the heading (a text with bg), the heading, the paragraph, all buttons and the small notes/trust lines below them. Give min_height only when the CSS gives the section a height in vh/svh/dvh or 100%; otherwise use 0 and the padding of the CSS (pad_top/pad_bottom) so the band is as high as the original. "
    "Rules: make the result look like the original: same order, same colours, same alignment, same relative sizes. Keep every text exactly as it is in the section (do not rewrite, shorten or translate). Resolve CSS variables (var(--x)) to real #rrggbb colours using the CSS. Sizes in rem (16px = 1rem). "
    "A grid of cards becomes cells, each card a cell with its heading and text; cards cannot have their own box, so put them in cells without a background. A call to action with a button becomes heading + text + button items. "
    "The user may give extra_instructions: follow them, they win where they conflict with the rules above. Icons ([icon]) and decorative things are left out. A dark section gets bg and color (light text). Use halign center for centred text. Headings of a section come first in the first cell or a row of their own."
)


def _ask_section(node, imgs, css, colours, i, n, page_path, extra="", note=None):
    from apps.core import themeimport as TI

    prompt = json.dumps({"section": i + 1, "of": n, "section_html": _compact(node, imgs)[:14000], "css": css, "pictures": [{"n": v, "file": k.rsplit("/", 1)[-1]} for k, v in imgs.items()], "theme_colours": colours, "page_address": page_path, **({"design_notes": note} if note else {}), **({"extra_instructions": extra} if extra else {})}, ensure_ascii=False)
    return TI._ai_json(ROW_SYSTEM, prompt, 6000, 170, need=("rows", "row"))


def _plain(html_text):
    return " ".join(htmllib.unescape(re.sub(r"<[^>]+>", " ", str(html_text or ""))).split())


def _hexc(v):
    v = str(v or "").strip()
    return v if HEX6.fullmatch(v) else ""


def _num(v, lo, hi, default=None):
    try:
        return min(max(float(v), lo), hi)
    except (TypeError, ValueError):
        return default


def _rows_from_ai(ai_rows, ctx):
    """The rows of the AI answer as rows of the page builder; the texts and pictures they need are collected in ctx['texts'] / ctx['images']."""
    lang, imp, imgs, page_path = ctx["lang"], ctx["imp"], ctx["media"], ctx["path"]
    rows = []
    for r in (ai_rows or [])[:6]:
        if not isinstance(r, dict):
            continue
        cells = []
        for c in (r.get("cells") or [])[:4]:
            if not isinstance(c, dict):
                continue
            items = []
            for it in (c.get("items") or [])[:30]:
                if not isinstance(it, dict):
                    continue
                kind, iid = it.get("type"), secrets.token_hex(4)
                ref = f"imp{imp.id}.{iid}"
                style = {}
                if it.get("align") in ("left", "center", "right"):
                    style["align"] = it["align"]
                if _hexc(it.get("color")):
                    style["color"] = _hexc(it["color"])
                if kind == "heading":
                    text = _plain(it.get("html") or it.get("text"))[:300]
                    if not text:
                        continue
                    ctx["texts"][ref] = text
                    if _num(it.get("size"), 0.8, 6):
                        style["size"] = round(_num(it["size"], 0.8, 6), 2)
                    if str(it.get("weight") or "") in ("400", "500", "600", "700", "800"):
                        style["weight"] = str(it["weight"])
                    if _num(it.get("mb"), 0, 6) is not None:
                        style["mb"] = round(_num(it["mb"], 0, 6), 2)
                    items.append({"id": iid, "type": "heading", "ref": ref, "style": style})
                elif kind == "text":
                    html = richtext.clean(str(it.get("html") or ""))
                    if not _plain(html):
                        continue
                    if _hexc(it.get("bg")):
                        style["bg"] = _hexc(it["bg"])
                        if _num(it.get("radius"), 0, 999) is not None:
                            style["radius"] = int(_num(it["radius"], 0, 999))
                    if isinstance(it.get("pad"), dict):
                        style["pad"] = {k: int(_num(v, 0, 100, 0)) for k, v in it["pad"].items() if k in ("t", "r", "b", "l")}
                    ctx["texts"][ref] = richtext.PREFIX + html
                    if _num(it.get("size"), 0.7, 4):
                        style["size"] = round(_num(it["size"], 0.7, 4), 2)
                    items.append({"id": iid, "type": "text", "ref": ref, "style": style})
                elif kind == "image":
                    try:
                        mid = imgs.get(int(it.get("img")))
                    except (TypeError, ValueError):
                        mid = None
                    if not mid:
                        continue
                    ctx["images"][ref] = mid
                    if _num(it.get("radius"), 0, 999) is not None:
                        style["radius"] = int(_num(it["radius"], 0, 999))
                    if re.fullmatch(r"[1-9][0-9]{0,3}(px|%)", str(it.get("w") or "")):
                        style["w"] = it["w"]
                    items.append({"id": iid, "type": "image", "ref": ref, "style": style})
                elif kind == "button":
                    label = _plain(it.get("label"))[:80]
                    if not label:
                        continue
                    href = str(it.get("href") or "").strip()
                    if href.startswith("#"):
                        href = f"{page_path}{href}"
                    btn = {"labels": {lang: label}}
                    if re.fullmatch(r"(https?://|mailto:|tel:|/)[^\\s<>\"']{0,500}", href):
                        btn["url"] = href
                    if it.get("style") in ("outline", "ghost"):
                        btn["style"] = it["style"]
                    for k in ("bg", "color", "border"):
                        v = str(it.get(k) or "")
                        if HEX6.fullmatch(v) or (k == "bg" and v == "transparent"):
                            btn[k] = v
                    if _num(it.get("radius"), 0, 60) is not None:
                        btn["radius"] = int(_num(it["radius"], 0, 60))
                    items.append({"id": iid, "type": "button", "ref": "", "btn": btn})
                elif kind == "sysobject":  # a live block of the system (a product overview, a plan, a donation button...): the page stores it as <div data-sysobject="slug"> in a text block
                    from apps.sysobjects.models import SystemObject

                    slug = str(it.get("slug") or "").strip()
                    if not SystemObject.objects.filter(slug=slug).exists():
                        continue
                    ctx["texts"][ref] = richtext.PREFIX + f'<div data-sysobject="{slug}"></div><p><br></p>'
                    items.append({"id": iid, "type": "text", "ref": ref, "style": {}})
                elif kind == "faq":  # frequently asked questions: they go into the FAQ module (page /faq) and stay on this page as text
                    qa = []
                    for x in (it.get("items") or [])[:40]:
                        q, a = (_plain(x.get("q")), richtext.clean(str(x.get("a") or ""))) if isinstance(x, dict) else ("", "")
                        if q and _plain(a):
                            qa.append((q[:300], a))
                    if not qa:
                        continue
                    ctx["faq"].extend(qa)
                    if _plain(it.get("heading")):
                        hid = secrets.token_hex(4)
                        ctx["texts"][f"imp{imp.id}.{hid}"] = _plain(it["heading"])[:300]
                        items.append({"id": hid, "type": "heading", "ref": f"imp{imp.id}.{hid}", "style": {"size": 2.2, "weight": "800", **style}})
                    body = "".join(f"<p><strong>{htmllib.escape(q)}</strong><br>{_plain(a)}</p>" for q, a in qa)
                    ctx["texts"][ref] = richtext.PREFIX + richtext.clean(body)
                    items.append({"id": iid, "type": "text", "ref": ref, "style": {}})
                    bid = secrets.token_hex(4)
                    items.append({"id": bid, "type": "button", "ref": "", "btn": {"labels": {lang: "Alle veelgestelde vragen"}, "url": "/faq", "style": "outline"}})
                elif kind == "code":  # a part that the blocks cannot make: its own html and css, shown in a frame without rights
                    rels = ctx.get("rels") or {}
                    put = lambda t: re.sub(r"IMG:(\d+)", lambda m: "__MEDIA__/" + rels[int(m.group(1))] if int(m.group(1)) in rels else "", str(t or ""))  # noqa: E731
                    chtml, ccss = put(it.get("html")).strip()[:20000], put(it.get("css")).strip()[:10000]
                    if re.search(r"<\s*script", chtml, re.I) or not chtml:
                        chtml = re.sub(r"<\s*script.*?(</\s*script\s*>|$)", "", chtml, flags=re.S | re.I)
                    if chtml:
                        items.append({"id": iid, "type": "widget", "ref": "", "widget": "code", "data": {"html": chtml, "css": ccss}})
                elif kind == "spacer":
                    items.append({"id": iid, "type": "spacer", "ref": "", "style": {"h": int(_num(it.get("h"), 4, 400, 24))}})
                elif kind == "line":
                    items.append({"id": iid, "type": "line", "ref": "", "style": {}})
            if items:
                w = str(c.get("width") or "auto")
                card = c.get("card") if isinstance(c.get("card"), dict) else None
                cstyle = {k: v for k, v in {"bg": _hexc((card or {}).get("bg")), "border": _hexc((card or {}).get("border")), "radius": (card or {}).get("radius"), "pad": (card or {}).get("pad"), "shadow": bool((card or {}).get("shadow"))}.items() if v not in (None, "", False)} if card else {}
                cells.append({**({"style": cstyle} if cstyle else {}), "id": secrets.token_hex(4), "width": w if re.fullmatch(r"[0-9]{1,3}", w) else "auto", "halign": c.get("halign") if c.get("halign") in ("left", "center", "right") else "left",
                              "valign": c.get("valign") if c.get("valign") in ("top", "center", "bottom") else "top", "items": items})
        if not cells:
            continue
        row = {"id": secrets.token_hex(4), "cols": len(cells), "width": "default", "gap": r.get("gap") if r.get("gap") in ("sm", "md", "lg") else "md", "cells": cells, "bg": {}}
        if str(r.get("title") or "").strip():
            row["title"] = str(r["title"]).strip()[:80]
        if str(r.get("anchor") or "").strip():
            row["anchor"] = str(r["anchor"]).strip()[:40]
        style = {}
        style["bg"] = _hexc(r.get("bg")) or _hexc(ctx.get("page_bg")) or "#ffffff"  # every band has the colour of the original, also when the site is in the dark mode
        if _hexc(r.get("color")):
            style["color"] = _hexc(r["color"])
        if _num(r.get("radius"), 0, 60):
            style["radius"] = int(_num(r["radius"], 0, 60))
        if style:
            row["style"] = style
        pad = {}
        for k, key in (("pad_top", "t"), ("pad_bottom", "b")):
            if _num(r.get(k), 0, 300) is not None:
                pad[key] = int(_num(r[k], 0, 300))
        if pad:
            row["padding"] = pad
        try:
            bi = imgs.get(int(r.get("bg_image"))) if r.get("bg_image") not in (None, "") else None
        except (TypeError, ValueError):
            bi = None
        if bi:
            row["bg"] = {"type": "image", "media": bi, "overlay": round(_num(r.get("overlay"), 0, 0.9, 0.4), 2)}
        row.update({"screen": True, "width": "100", "inner": True, "top": "prev" if ctx.get("rows_done") else "touch"})  # a band: edge to edge, the content in the width of the page
        if _num(r.get("min_height"), 10, 100):  # only a section that really has a screen height of its own; the height of other bands follows from their padding
            row.update({"hero": "custom", "h_mode": "pct", "h": int(_num(r["min_height"], 10, 100))})
        ctx["rows_done"] = True
        rows.append(row)
    return rows


def _fallback_rows(node, ctx):
    """The AI gave nothing for a section: its text goes in as one editable block, so no content is lost."""
    cx = Ctx(ctx["imp"], AnyFetcher(), "", Images(ctx["imp"].slug, AnyFetcher()))
    cx.image = lambda src, alt: ""
    html = richtext.clean(tidy(to_html(node, cx)))
    return [{"title": "Tekst", "cells": [{"items": [{"type": "text", "html": html}]}]}] if _plain(html) else []


# ── looking at the page: a screenshot of the original (when a browser is available), an analysis of the design and of the header ───────────────
CHROME_PATHS = ("/Applications/Google Chrome.app/Contents/MacOS/Google Chrome", "/usr/bin/google-chrome", "/usr/bin/chromium", "/usr/bin/chromium-browser", "/snap/bin/chromium")


def page_shots(html_text, slices=4):
    """The original page as a few pictures (top to bottom), [(media_type, base64)]; [] when no browser is installed on this machine."""
    import base64
    import shutil
    import subprocess
    import tempfile
    from io import BytesIO

    from PIL import Image

    exe = next((p for p in CHROME_PATHS if os.path.exists(p)), None) or shutil.which("chromium") or shutil.which("google-chrome")
    if not exe:
        return []
    d = tempfile.mkdtemp(prefix="siteimport-shot-")
    try:
        src = os.path.join(d, "p.html")
        with open(src, "w", encoding="utf-8") as fh:
            fh.write(re.sub(r"__MEDIA__/", f"file://{settings.MEDIA_ROOT}/", html_text))
        out = os.path.join(d, "p.png")
        subprocess.run([exe, "--headless=new", "--disable-gpu", "--no-sandbox", "--hide-scrollbars", "--window-size=1440,5600", "--virtual-time-budget=6000", f"--screenshot={out}", f"file://{src}"],
                       capture_output=True, timeout=60)
        im = Image.open(out).convert("RGB")
        px = im.load()
        w, h = im.size
        bottom = px[w // 2, h - 1]
        y = h - 1
        while y > 400 and all(px[x, y] == bottom for x in range(0, w, 97)):  # the empty canvas below the page
            y -= 1
        im = im.crop((0, 0, w, min(h, y + 40)))
        step = max(900, -(-im.size[1] // slices))
        shots = []
        for top in range(0, im.size[1], step):
            part = im.crop((0, top, im.size[0], min(im.size[1], top + step)))
            part = part.resize((1000, max(1, int(part.size[1] * 1000 / part.size[0]))))
            buf = BytesIO()
            part.save(buf, "JPEG", quality=82)
            shots.append(("image/jpeg", base64.b64encode(buf.getvalue()).decode()))
        return shots[:5]
    except Exception:  # noqa: BLE001
        logger.exception("screenshot of the original failed")
        return []
    finally:
        import shutil as _sh

        _sh.rmtree(d, ignore_errors=True)


DESIGN_SYSTEM = (
    "You analyse the design of ONE web page (screenshots from top to bottom, the html outline and the CSS) so that it can be rebuilt with the blocks of a page builder and the header of that system. "
    'Answer with ONE JSON object only: {"container_px": the width of the content column in px (the max-width of the main container), "sections": [{"index": n (as numbered in the outline), "name": short name, "band_bg": "#rrggbb" colour of the band behind it ("" = same as the page), '
    '"text": "#rrggbb" main text colour on it, "pad_top": px, "pad_bottom": px, "note": how the content is laid out (columns, cards with a border/background/shadow, alignment, what sits next to what)}], '
    '"header": {"found": true|false, "height_px": number, "bg": "#rrggbb", "link_color": "#rrggbb", "brand_text": the logo text, "brand_tag": small text next to it or "", '
    '"links": [{"label": text, "href": "#anchor" or "/path"}], "buttons": [{"label": text, "href": "...", "style": "solid"|"outline", "bg": "#rrggbb"}]}}. '
    "Resolve CSS variables to real #rrggbb colours. Be exact about colours, widths and spacing: read them from the CSS and the pictures."
)


def analyse_design(html_text, secs, css, shots):
    from apps.core import themeimport as TI

    outline = [{"index": i, "tag": s.tag, "class": s.attrs.get("class", ""), "id": s.attrs.get("id", ""), "text": " ".join(s.text().split())[:140]} for i, s in enumerate(secs)]
    hdr = ""
    m = re.search(r"<header\b.*?</header>", html_text, re.S | re.I)
    if m:
        hdr = re.sub(r"<svg.*?</svg>", "[icon]", m.group(0), flags=re.S)[:5000]
    prompt = json.dumps({"outline": outline, "header_html": hdr, "css": css, "title": (re.search(r"<title>(.*?)</title>", html_text, re.S | re.I) or [None, ""])[1][:120]}, ensure_ascii=False)
    from apps.integrations import ai

    raw = ai.claude(DESIGN_SYSTEM, prompt, max_tokens=4500, timeout=170, images=shots or None)
    return TI._parse_json(raw, need=("sections", "header", "container_px"))


def header_menu(imp, plan, anchors, link_map=None, link_list=None):
    """The header of the original on the header of this system: the links and buttons as menu items, bigger buttons, the colours of the original. What was there is kept, to put back when the import is removed."""
    from apps.pages import service
    from apps.pages.models import MenuSettings

    h = (plan or {}).get("header") or {}
    links, buttons = [x for x in (h.get("links") or []) if isinstance(x, dict) and _plain(x.get("label")) and suggest_link(str(x.get("href") or "")) != "/login"][:8], [x for x in (h.get("buttons") or []) if isinstance(x, dict) and _plain(x.get("label")) and suggest_link(str(x.get("href") or "")) != "/login"][:3]  # (the login button of the system is already in the header)
    lmap = {l["label"].lower(): v for l, v in ((l, (link_map or {}).get(l["key"])) for l in (link_list or [])) if v}
    if not (h.get("found") and (links or buttons)):
        return None
    th = dict(imp.theme or {})
    if "menu_backup" not in th:
        row = MenuSettings.objects.filter(pk=1).first()
        th["menu_backup"] = {"settings": dict(row.data or {}) if row else None, "pages": {p.key: p.in_menu for p in Page.objects.filter(in_menu=True, scope="public").exclude(source=imp.tag)}}
    else:
        Page.objects.filter(source=imp.tag, kind="link").delete()  # an earlier run: the items are made again
    Page.objects.filter(key__in=list(th["menu_backup"]["pages"])).update(in_menu=False)
    order = (Page.objects.order_by("-order").values_list("order", flat=True).first() or 0) + 1
    lang = _lang()

    def url(href, label=""):
        href = (lmap.get(str(label).strip().lower()) or str(href or "")).strip()
        if href.startswith("#"):
            return "/" + href if href[1:] in anchors else "/"
        return href if re.fullmatch(r"(https?://|mailto:|tel:|/)[^\s<>\"']{0,300}", href) else "/"

    n = 0
    for kind, items in (("link", links), ("btn", buttons)):
        for it in items:
            label = _plain(it["label"])[:60]
            key = f"{imp.slug[:20]}-m{n}"
            Page.objects.update_or_create(key=key, defaults={"kind": "link", "title": {lang: label}, "url": url(it.get("href"), it.get("label")), "in_menu": True, "enabled": True, "order": order + n, "source": imp.tag, "cta": kind == "btn" and it.get("style") != "outline", "scope": "public"})
            n += 1
    cur = service.menu_settings()
    new = {**cur, "size": "lg" if len(links) + len(buttons) <= 5 else "md", "item_style": "button", "uppercase": False}
    hh = int(min(max(float(h.get("height_px") or 80), 56), 120))
    new["height"] = {**cur["height"], "desktop": hh, "tablet": hh}
    if re.fullmatch(r"#[0-9a-fA-F]{6}", str(h.get("bg") or "")):
        new["bg"], new["bg_opacity"], new["blur"] = h["bg"], 1, 0
        new["fg"] = h.get("link_color") if re.fullmatch(r"#[0-9a-fA-F]{6}", str(h.get("link_color") or "")) else "#ffffff"
    MenuSettings.objects.update_or_create(pk=1, defaults={"data": service.clean_menu_settings(new)})
    service.invalidate() if hasattr(service, "invalidate") else None
    SiteImport.objects.filter(pk=imp.pk).update(theme=th)
    return {"links": [_plain(x["label"]) for x in links], "buttons": [_plain(x["label"]) for x in buttons]}


def restore_header(imp):
    from apps.pages.models import MenuSettings

    mb = (imp.theme or {}).get("menu_backup")
    if not mb:
        return False
    Page.objects.filter(source=imp.tag, kind="link").delete()
    Page.objects.filter(key__in=list((mb.get("pages") or {}))).update(in_menu=True)
    if mb.get("settings") is None:
        MenuSettings.objects.filter(pk=1).delete()
    else:
        MenuSettings.objects.update_or_create(pk=1, defaults={"data": mb["settings"]})
    return True


def _write_faq(qa, lang):
    """The questions go into the module FAQ (the page /faq); returns the ids that were made (so removing the import removes them again)."""
    from apps.plugins import facade

    Entry = facade.model("faq", "FaqEntry")
    if not Entry:
        return []
    order = (Entry.objects.order_by("-order").values_list("order", flat=True).first() or 0) + 1
    out = []
    for n, (q, a) in enumerate(qa):
        e = Entry.objects.create(question={lang: q}, answer={lang: _plain(a)}, order=order + n, active=True)
        out.append(e.id)
    return out


def _lum(h):
    r, g, b = (int(h[i:i + 2], 16) / 255 for i in (1, 3, 5))
    f = lambda c: c / 12.92 if c <= 0.03928 else ((c + 0.055) / 1.055) ** 2.4  # noqa: E731
    return 0.2126 * f(r) + 0.7152 * f(g) + 0.0722 * f(b)


def _contrast(a, b):
    la, lb = _lum(a), _lum(b)
    return (max(la, lb) + 0.05) / (min(la, lb) + 0.05)


def fix_colors(layout, ink="#0e0638", dark_bg="#0f0b13"):
    """Every text can be read, on a light and on a dark site: a block with a background colour gets a text colour that contrasts with it, and a colour of a single text that
    would disappear (dark on dark, white on white) is taken away, so the text follows the theme again."""
    ink = ink if HEX6.fullmatch(str(ink or "")) else "#0e0638"
    dark_bg = dark_bg if HEX6.fullmatch(str(dark_bg or "")) else "#0f0b13"
    for r in layout.get("rows", []):
        st = r.get("style") or {}
        bg = st.get("bg") if HEX6.fullmatch(str(st.get("bg") or "")) else ""
        if bg:
            col = st.get("color")
            if not col or not HEX6.fullmatch(col) or _contrast(col, bg) < 3:
                st["color"] = ink if _lum(bg) > 0.4 else "#ffffff"
            r["style"] = st
        for c in r.get("cells", []):
            cbg = (c.get("style") or {}).get("bg")
            for it in c.get("items", []):  # the colour of a text reads on what is behind it: the text's own background, the card, or the band
                if it.get("type") not in ("text", "heading"):
                    continue
                ibg = (it.get("style") or {}).get("bg")
                eff = ibg if ibg and HEX6.fullmatch(ibg) else cbg if cbg and HEX6.fullmatch(cbg) else None
                if eff:
                    col = (it.get("style") or {}).get("color")
                    if not col or not HEX6.fullmatch(col) or _contrast(col, eff) < 3:
                        it["style"] = {**(it.get("style") or {}), "color": ink if _lum(eff) > 0.4 else "#ffffff"}
            for it in c.get("items", []):
                if it.get("type") == "button" and bg and _lum(bg) <= 0.4 and (it.get("btn") or {}).get("style") in ("outline", "ghost") and not (it["btn"].get("bg") or it["btn"].get("color")):
                    it["btn"].update({"bg": "transparent", "color": "#ffffff", "border": "#4b3f8a"})  # an outline button on a dark band: light text, no white box
                ist = it.get("style") or {}
                col = ist.get("color")
                if not col or not HEX6.fullmatch(col):
                    continue
                if (cbg and HEX6.fullmatch(cbg)) or (ist.get("bg") and HEX6.fullmatch(str(ist.get("bg")))):
                    continue  # on a card or a label: already checked against that
                ok = _contrast(col, bg) >= 3 if bg else (_contrast(col, "#ffffff") >= 3 and _contrast(col, dark_bg) >= 3)
                if not ok:
                    ist.pop("color", None)
    return layout


def _save_source(imp, src, html, title, own_key, dest):
    """The original html of a page stays with the import (themes/<slug>/source/): Toepassen can run again, also with an extra instruction for Claude."""
    rel = f"themes/{imp.slug}/source/{get_valid_filename(src['stem'])[:60] or 'pagina'}.html"
    full = os.path.join(str(settings.MEDIA_ROOT), rel)
    os.makedirs(os.path.dirname(full), exist_ok=True)
    with open(full, "w", encoding="utf-8") as fh:
        fh.write(html)
    return {"stem": src["stem"], "title": title, "file": rel, "own_key": own_key, "dest": dest}


def read_source(src):
    try:
        with open(os.path.join(str(settings.MEDIA_ROOT), src["file"]), encoding="utf-8") as fh:
            return fh.read()
    except (OSError, KeyError):
        return ""


def _is_imp_row(imp, r):
    return any(str(it.get("ref", "")).startswith(f"imp{imp.id}.") for c in r.get("cells", []) for it in c.get("items", []))


def _refs_of(rows):
    return {it.get("ref") for r in rows for c in r.get("cells", []) for it in c.get("items", []) if it.get("ref")}


def _resolve_dest(imp, src, dest_key):
    """The page that gets the blocks: the chosen page of the website, or the own page of this import for the file (made again when it was removed)."""
    if dest_key:
        pg = Page.objects.filter(key=dest_key, scope="public").first()
        if pg and (pg.kind == "content" or pg.key == "home"):
            return pg
    key = src.get("own_key") or f"{imp.slug[:22]}-{slugify(src['stem'])[:28] or 'pagina'}".strip("-")[:58]
    pg = Page.objects.filter(key=key).first()
    if pg:
        return pg
    order = (Page.objects.order_by("-order").values_list("order", flat=True).first() or 0) + 1
    src["own_key"] = key
    return Page.objects.create(key=key, kind="content", title={_lang(): src.get("title") or "Pagina"}, in_menu=True, enabled=True, order=order, source=imp.tag)


def _restore_backup(backups, key):
    from apps.pages.models import PageLayout

    b = next((x for x in backups if x["key"] == key), None)
    if not b:
        return
    PageLayout.objects.filter(key=key).delete()
    if b.get("layout"):
        PageLayout.objects.create(key=key, data=b["layout"])
    for row in b.get("texts") or []:
        ContentBlock.objects.update_or_create(key=row["key"], lang=row["lang"], defaults={"text": row["text"]})


def _apply_theme_over(imp, over):
    """Settings the user changed on the tab Thema: they go into the theme of this import (and into the site when the theme is in use)."""
    from apps.core import theme as T

    if not over:
        return
    clean, errors = T.validate({k: v for k, v in over.items() if k in ("primary", "secondary", "default_mode", "radius", "btn_radius", "content_w")})
    clean = {k: v for k, v in clean.items() if k not in errors}
    if not clean:
        return
    th = dict(imp.theme or {})
    th["values"] = {**(th.get("values") or {}), **clean}
    SiteImport.objects.filter(pk=imp.pk).update(theme=th)
    if imp.theme_applied:
        from apps.core.models import SiteSettings

        so = SiteSettings.load()
        cur = dict(so.theme or {})
        cur.update(clean)
        so.theme = cur
        so.save()


def _apply_design(imp_id, imp, st0, mapping):
    """Exact: every page is its own html design, 1 to 1 as in the file. What a page of the website held is kept and comes back when the import is removed."""
    from apps.pages.models import PageLayout

    sources = [dict(x) for x in ((imp.theme or {}).get("sources") or [])]
    backups = list(st0.get("design_backups") or [])
    built = []
    _set_apply(imp_id, state="running", percent=10, step="De pagina's klaarzetten")
    only = set(st0.get("only") or [])
    for n, src in enumerate(sources):
        if only and src["stem"] not in only:
            continue
        html = rewrite_links(read_source(src), st0.get("link_map"), collect_links(read_source(src) or ""))
        if not html:
            continue
        old_dest = src.get("dest") or ""
        dest = _resolve_dest(imp, src, mapping.get(src["stem"], src.get("dest") if src.get("dest") != src.get("own_key") else ""))
        if old_dest and old_dest != dest.key:
            old_pg = Page.objects.filter(key=old_dest).first()
            if old_pg is not None and old_pg.source == imp.tag:
                PageLayout.objects.filter(key=old_pg.key).delete()
                old_pg.delete()
            else:
                prev = next((b for b in backups if b["key"] == old_dest), None)
                if prev:
                    Page.objects.filter(key=old_dest).update(design=prev["design"], setup=prev["setup"])
                    backups = [b for b in backups if b["key"] != old_dest]
        if dest.source != imp.tag and not any(b["key"] == dest.key for b in backups):
            backups.append({"key": dest.key, "design": dest.design, "setup": dest.setup or {}})
        Page.objects.filter(pk=dest.pk).update(design=html, setup={**(dest.setup or {}), "header": "hide", "footer": "hide"})
        src["dest"] = dest.key
        built.append({"key": dest.key, "title": next(iter(dest.title.values()), dest.key) if isinstance(dest.title, dict) else dest.key, "path": "/" if dest.key == "home" else (dest.path or f"/p/{dest.key}"), "blocks": 0})
        _set_apply(imp_id, percent=10 + int(80 * (n + 1) / max(1, len(sources))), step=f"Pagina {n + 1} van {len(sources)} klaargezet")
    fresh = SiteImport.objects.get(pk=imp_id)
    th = dict(fresh.theme or {})
    th["sources"] = sources
    SiteImport.objects.filter(pk=imp_id).update(theme=th)
    _set_apply(imp_id, state="done", percent=100, step="Klaar", built=built, design_backups=backups, error="", warning="", last_mode="design")


def active_languages():
    """The other languages that are switched on: pages and content can be translated into them."""
    from apps.core.models import Language

    return [{"code": x.code, "name": x.name} for x in Language.objects.filter(enabled=True, is_default=False).order_by("order")]


def _translate_chunk(name, chunk):
    from apps.core import themeimport as TI

    system = (f"Translate the texts of a website into {name}. A text is plain or contains simple HTML (p, ul, ol, li, strong, em, a, br, h3, h4): keep the tags and their attributes exactly as they are and translate only the words. "
              "Keep numbers, prices, names of products and brands and placeholders like [PRIJS] as they are. Answer with ONE JSON object only with exactly the same keys and the translated texts as values.")
    out = TI._ai_json(system, json.dumps(chunk, ensure_ascii=False), 4500, 150, need=tuple(chunk))
    return {k: v for k, v in out.items() if k in chunk and isinstance(v, str) and v.strip()}


def _translate_all(imp_id, items, langs, base, span):
    """items {key: text} -> {code: {key: translated text}}; the progress runs from `base` to `base + span`."""
    from concurrent.futures import ThreadPoolExecutor

    keys = list(items)
    jobs = [(lg, {k: items[k] for k in keys[i:i + 25]}) for lg in langs for i in range(0, len(keys), 25)]
    out, n = {lg["code"]: {} for lg in langs}, {"done": 0}

    def work(job):
        lg, chunk = job
        for _ in range(2):
            try:
                return lg["code"], _translate_chunk(lg["name"], chunk)
            except Exception:  # noqa: BLE001
                continue
        return lg["code"], {}

    with ThreadPoolExecutor(3) as pool:
        for code, part in pool.map(work, jobs):
            out[code].update(part)
            n["done"] += 1
            _set_apply(imp_id, percent=base + int(span * n["done"] / max(1, len(jobs))), step=f"Vertalen: {n['done']} van {len(jobs)}")
    return out


def _apply_run(imp_id):
    from concurrent.futures import ThreadPoolExecutor

    from django.db import connections

    from apps.integrations import aiusage as _aiusage
    from apps.pages import layout as page_layout
    from apps.pages.models import PageLayout

    try:
        imp = SiteImport.objects.get(pk=imp_id)
        st0 = apply_state(imp)
        mapping, mode, extra, translate = st0.get("map") or {}, st0.get("mode") or "clear", st0.get("prompt") or "", bool(st0.get("translate"))
        lang = _lang()
        _apply_theme_over(imp, st0.get("theme_over") or {})
        imp = SiteImport.objects.get(pk=imp_id)
        if st0.get("render") == "design":
            return _apply_design(imp_id, imp, st0, mapping)
        values = (imp.theme or {}).get("values") or {}
        colours = {k: values.get(k) for k in ("primary", "secondary", "light_bg", "light_text", "dark_bg", "dark_text") if values.get(k)}
        sources = [dict(x) for x in ((imp.theme or {}).get("sources") or [])]
        backups, faq_ids = list(st0.get("backups") or []), list(st0.get("faq_ids") or [])
        only = set(st0.get("only") or [])  # one page of the import (Pagina-instellingen → Import): the other pages stay as they are
        if faq_ids and not only:  # the questions of an earlier run are replaced, not doubled
            try:
                from apps.plugins import facade

                Old = facade.model("faq", "FaqEntry")
                if Old:
                    Old.objects.filter(pk__in=faq_ids).delete()
            except Exception:  # noqa: BLE001
                logger.exception("old faq entries of import %s could not be removed", imp_id)
            faq_ids = []
        _set_apply(imp_id, state="running", percent=2, step="De pagina's lezen")
        plan, total = [], 0
        for src in sources:
            if only and src["stem"] not in only:
                continue
            raw_html = read_source(src)
            html = rewrite_links(raw_html, st0.get("link_map"), collect_links(raw_html or ""))
            if not html:
                continue
            old_dest = src.get("dest") or ""
            dest = _resolve_dest(imp, src, mapping.get(src["stem"], src.get("dest") if src.get("dest") != src.get("own_key") else ""))
            root = parse_html(html)
            rels = list(dict.fromkeys(re.findall(r"__MEDIA__/([^\"'()\s<>]+)", html)))
            imgs = {rel: n for n, rel in enumerate(rels)}
            media = {n: (MediaItem.objects.filter(key=rel).values_list("id", flat=True).first()) for rel, n in imgs.items()}
            path = "/" if dest.key == "home" else (dest.path or f"/p/{dest.key}")
            secs = _sections(root)
            plan.append({"src": src, "dest": dest, "old_dest": old_dest, "secs": secs, "imgs": imgs, "media": media, "css": _css_of(html, imgs), "path": path})
            total += len(secs)
        if not total:
            raise ImportError_("Er is geen inhoud gevonden om te bouwen.")
        results, done = {}, {"n": 0}
        _set_apply(imp_id, percent=4, step="De pagina bekijken en het ontwerp analyseren")
        for p in plan:  # Claude looks at the original (screenshots when a browser is installed) and measures the design
            try:
                p["ana"] = analyse_design(read_source(p["src"]), p["secs"], p["css"], page_shots(read_source(p["src"])))
            except Exception:  # noqa: BLE001
                logger.exception("design analysis failed")
                p["ana"] = {}

        def note_for(p, si):
            ana = p.get("ana") or {}
            sec = next((x for x in ana.get("sections", []) if isinstance(x, dict) and x.get("index") == si), None)
            return {"container_px": ana.get("container_px"), **(sec or {})} if (sec or ana.get("container_px")) else None

        def work(job):
            pi, si = job
            p = plan[pi]
            try:
                out = _aiusage.run_as(st0.get("actor"), _ask_section, p["secs"][si], p["imgs"], p["css"], colours, si, len(p["secs"]), p["path"], extra, note_for(p, si))
                rows = out.get("rows") if isinstance(out.get("rows"), list) else ([out["row"]] if isinstance(out.get("row"), dict) else [])
            except Exception:  # noqa: BLE001 - a section that cannot be read is kept as a text block
                logger.exception("apply: section %s of %s could not be read", si, p["dest"].key)
                rows = None
            return job, rows

        jobs = [(pi, si) for pi, p in enumerate(plan) for si in range(len(p["secs"]))]
        with ThreadPoolExecutor(3) as pool:
            for job, rows in pool.map(work, jobs):
                results[job] = rows
                done["n"] += 1
                _set_apply(imp_id, percent=5 + int(70 * done["n"] / total), step=f"Blok {done['n']} van {total} opgebouwd")

        cw = int(min(max(float((plan[0].get("ana") or {}).get("container_px") or 0), 0), 1600)) if plan else 0
        if cw >= 720:
            from apps.core.models import SiteSettings

            so = SiteSettings.load()
            t = dict(so.theme or {})
            if t.get("content_w") != cw:
                th0 = dict(imp.theme or {})
                th0.setdefault("content_w_before", t.get("content_w"))
                SiteImport.objects.filter(pk=imp_id).update(theme=th0)
                t["content_w"] = cw
                so.theme = t
                so.save()
        _set_apply(imp_id, percent=77, step="De pagina's leegmaken en vullen")
        built, layouts, all_texts, all_btn, own_titles = [], {}, {}, [], {}
        used_all = set()
        if only:  # the texts of the pages that were not built again are still needed
            for o in sources:
                if o["stem"] not in only and o.get("dest"):
                    ol = PageLayout.objects.filter(key=o["dest"]).first()
                    used_all |= _refs_of((ol.data or {}).get("rows") or []) if ol else set()
        for pi, p in enumerate(plan):
            pg, src = p["dest"], p["src"]
            ctx = {"imp": imp, "lang": lang, "media": p["media"], "rels": {n: rel for rel, n in p["imgs"].items()}, "path": p["path"], "texts": {}, "images": {}, "faq": [], "page_bg": values.get("light_bg")}
            rows = []
            for si in range(len(p["secs"])):
                ai_rows = results.get((pi, si))
                part = _rows_from_ai(ai_rows, ctx) if ai_rows else []
                part = part or _rows_from_ai(_fallback_rows(p["secs"][si], ctx), ctx)
                nid = p["secs"][si].attrs.get("id") or next((x.attrs.get("id") for x in find(p["secs"][si], None) if x.attrs.get("id")), "")  # the id the links of the header point to
                if part and nid and not part[0].get("anchor"):
                    part[0]["anchor"] = nid
                rows += part
            # where the page was before: when it moves, the page it leaves gets its own blocks back
            if p["old_dest"] and p["old_dest"] != pg.key:
                old_pg = Page.objects.filter(key=p["old_dest"]).first()
                if old_pg is not None and old_pg.source == imp.tag:
                    PageLayout.objects.filter(key=old_pg.key).delete()
                    old_pg.delete()
                else:
                    _restore_backup(backups, p["old_dest"])
            old = PageLayout.objects.filter(key=pg.key).first()
            old_data = dict(old.data or {}) if old else {}
            old_rows = old_data.get("rows") or []
            if pg.source != imp.tag and not any(b["key"] == pg.key for b in backups):  # what an existing page held is kept, to put back when the import is removed
                refs = _refs_of(old_rows)
                backups.append({"key": pg.key, "layout": old.data if old else None, "texts": list(ContentBlock.objects.filter(key__in=refs).values("key", "lang", "text"))})
            if mode == "append" and old_rows:
                data = {**old_data, "rows": old_rows + rows}
            elif mode == "replace" and old_rows:
                kept = [r for r in old_rows if not _is_imp_row(imp, r)]
                first = next((n for n, r in enumerate(old_rows) if _is_imp_row(imp, r)), len(old_rows))
                at = len([r for r in old_rows[:first] if not _is_imp_row(imp, r)])
                data = {**old_data, "rows": kept[:at] + rows + kept[at:]}
            else:  # clear: the page is emptied first, then built
                ContentBlock.objects.filter(key__in=_refs_of(old_rows)).delete()
                data = {"rows": rows, "bg": {}, **({"moved": HOME_FIXED} if pg.key == "home" else {})}
            if pg.key == "home":  # the standard start page (logo, title, text, photos) is always empty and overwritten by the import, in every mode
                data = {**data, "moved": sorted(set(data.get("moved") or []) | set(HOME_FIXED))}
            clean = fix_colors(page_layout.clean(data), values.get("light_text"), values.get("dark_bg"))
            used = _refs_of(clean["rows"])
            used_all |= used
            PageLayout.objects.filter(key=pg.key).delete()
            for ref, text in ctx["texts"].items():
                if ref in used:
                    ContentBlock.objects.update_or_create(key=ref, lang=lang, defaults={"text": text})
                    all_texts[ref] = text
            for ref, mid in ctx["images"].items():
                if ref in used:
                    ContentBlock.objects.update_or_create(key=ref, lang="*", defaults={"text": f"media:{mid}"})
            PageLayout.objects.create(key=pg.key, data=clean)
            layouts[pg.key] = clean
            setup = {k: v for k, v in (pg.setup or {}).items() if k not in ("header", "footer")}  # built with blocks: the header and footer of the site are back
            if not st0.get("site_footer", True):
                setup["footer"] = "hide"
            Page.objects.filter(pk=pg.pk).update(design="", setup=setup)
            if ctx["faq"]:
                faq_ids += _write_faq(ctx["faq"], lang)
            if pg.source == imp.tag:
                own_titles[pg.key] = src.get("title") or ""
            src["dest"] = pg.key
            built.append({"key": pg.key, "title": next(iter(pg.title.values()), pg.key) if isinstance(pg.title, dict) else pg.key, "path": p["path"], "blocks": len(clean["rows"])})
        ContentBlock.objects.filter(key__startswith=f"imp{imp.id}.").exclude(key__in=used_all).delete()
        header_info = None
        first_ana = (plan[0].get("ana") if plan else None) or {}
        if first_ana.get("header") and st0.get("header", True):  # (the tab Header: switch the header of the system to the one of the file)
            _set_apply(imp_id, percent=76, step="De header aanpassen")
            try:
                anchors = {r.get("anchor") for lay in layouts.values() for r in lay["rows"] if r.get("anchor")}
                header_info = header_menu(imp, first_ana, anchors, st0.get("link_map"), collect_links(read_source(plan[0]["src"]) or ""))
            except Exception:  # noqa: BLE001
                logger.exception("header of import %s could not be applied", imp_id)  # blocks of an earlier run that are not used any more

        # translation: the texts, the buttons, the questions and the names of the pages into the other languages of the site
        langs = active_languages() if translate else []
        warning = ""
        if langs:
            items = {}
            for ref, text in all_texts.items():
                items[ref] = text[len(richtext.PREFIX):] if text.startswith(richtext.PREFIX) else text
            for key, lay in layouts.items():
                for r in lay["rows"]:
                    for c in r["cells"]:
                        for it in c["items"]:
                            if it["type"] == "button" and (it.get("btn") or {}).get("labels", {}).get(lang):
                                items[f"btn|{key}|{it['id']}"] = it["btn"]["labels"][lang]
            Entry = None
            if faq_ids:
                from apps.plugins import facade

                Entry = facade.model("faq", "FaqEntry")
                for e in (Entry.objects.filter(pk__in=faq_ids) if Entry else []):
                    items[f"faqq|{e.id}"] = (e.question or {}).get(lang, "")
                    items[f"faqa|{e.id}"] = (e.answer or {}).get(lang, "")
            for key, title in own_titles.items():
                if title:
                    items[f"title|{key}"] = title
            items = {k: v for k, v in items.items() if v}
            tr = _translate_all(imp_id, items, langs, 80, 17)
            missing = 0
            for code, got in tr.items():
                missing += len(items) - len(got)
                for k, v in got.items():
                    kind, _, rest = k.partition("|")
                    if k in all_texts:
                        ContentBlock.objects.update_or_create(key=k, lang=code, defaults={"text": (richtext.PREFIX + richtext.clean(v)) if all_texts[k].startswith(richtext.PREFIX) else _plain(v)})
                    elif kind == "btn":
                        pk_, _, iid = rest.partition("|")
                        for r in layouts.get(pk_, {}).get("rows", []):
                            for c in r["cells"]:
                                for it in c["items"]:
                                    if it["id"] == iid:
                                        it["btn"]["labels"][code] = _plain(v)[:80]
                    elif kind in ("faqq", "faqa") and Entry:
                        e = Entry.objects.filter(pk=int(rest)).first()
                        if e:
                            field = "question" if kind == "faqq" else "answer"
                            setattr(e, field, {**(getattr(e, field) or {}), code: _plain(v)})
                            e.save()
                    elif kind == "title":
                        pg2 = Page.objects.filter(key=rest).first()
                        if pg2:
                            pg2.title = {**(pg2.title or {}), code: _plain(v)[:80]}
                            pg2.save(update_fields=["title", "updated_at"])
            for key, lay in layouts.items():
                PageLayout.objects.filter(key=key).update(data=lay)
            if missing:
                warning = f"{missing} teksten konden niet worden vertaald."
        if faq_ids:
            enable_modules(["faq"])
        fresh = SiteImport.objects.get(pk=imp_id)
        th = dict(fresh.theme or {})
        th["sources"] = sources
        SiteImport.objects.filter(pk=imp_id).update(theme=th)
        _set_apply(imp_id, state="done", percent=100, step="Klaar", built=built, backups=backups, faq_ids=faq_ids, error="", warning=warning, last_prompt=extra, last_mode=mode, header_result=header_info)
    except ApplyCancelled:
        _set_apply(imp_id, _force=True, state="cancelled", step="Geannuleerd", cancel=False)
    except Exception as e:  # noqa: BLE001
        logger.exception("apply of import %s failed", imp_id)
        _set_apply(imp_id, state="error", error=str(e)[:300] or "Het toepassen is mislukt.")
    finally:
        connections.close_all()


def collect_links(html_text):
    """The links and buttons of an html file: [{key, label, href, kind: "button"|"link", where: "header"|"footer"|"page"}] (an address once, a link inside the page itself is left out)."""
    import hashlib

    root = parse_html(html_text)
    out, seen = [], set()
    for a in find(root, "a"):
        href = str(a.attrs.get("href") or "").strip()
        label = " ".join(a.text().split()) or str(a.attrs.get("aria-label") or "").strip() or next((i.attrs.get("alt", "") for i in find(a, "img")), "")
        if not href or href.startswith(("javascript:", "mailto:", "tel:")) or not label:
            continue
        if href.startswith("#") and len(href) > 1:
            continue  # a link to a place on the page itself keeps working
        tags, n = set(), a
        while n is not None:
            tags.add(n.tag)
            n = getattr(n, "parent", None)
        where = "footer" if "footer" in tags else "header" if tags & {"header", "nav"} else "page"
        cls = str(a.attrs.get("class") or "").lower()
        key = hashlib.sha1(f"{href}|{label}".encode()).hexdigest()[:8]
        if key in seen:
            continue
        seen.add(key)
        out.append({"key": key, "label": label[:80], "href": href[:300], "kind": "button" if re.search(r"btn|button|cta", cls) else "link", "where": where})
    return out[:120]


SYSTEM_LINKS = [("/", "Startpagina"), ("/login", "Inloggen"), ("/registreren", "Registreren"), ("/dashboard", "Dashboard"), ("/faq", "FAQ"), ("/producten", "Producten (webshop)"), ("/winkelwagen", "Winkelwagen")]


def link_targets(imp):
    """What a link or a button can lead to: the pages of the system and of the website, by address."""
    out, seen = [], set()
    for path, title in SYSTEM_LINKS:
        out.append({"key": path, "title": title, "std": True})
        seen.add(path)
    for x in Page.objects.filter(scope="public", enabled=True).exclude(source=imp.tag).exclude(kind="menu").order_by("order")[:150]:
        path = x.path
        if path and "<" not in path and path not in seen:
            seen.add(path)
            out.append({"key": path, "title": next(iter(x.title.values()), x.key) if isinstance(x.title, dict) else x.key, "std": bool(x.url)})
    return out


def suggest_link(href):
    h = href.lower().split("?")[0].rstrip("/")
    if h in ("/login", "/inloggen", "/signin"):
        return "/login"
    if h in ("/register", "/registreren", "/signup", "/aanmelden"):
        return "/registreren"
    return ""


def rewrite_links(html_text, mapping, links):
    """Every mapped link of the original gets the address it was linked to."""
    by_key = {l["key"]: l for l in links}
    for key, target in (mapping or {}).items():
        l = by_key.get(key)
        if not l or not target or not re.fullmatch(r"/[^\s<>\"']{0,300}", str(target)):
            continue
        html_text = re.sub(r"(href\s*=\s*[\"'])" + re.escape(l["href"]) + r"([\"'])", lambda m: m.group(1) + target + m.group(2), html_text)
    return html_text


def apply_targets(imp):
    """The pages that can take the blocks: the start page and the pages of the website (own and standard pages), not the ones of this import; with how many blocks they hold."""
    from apps.pages.models import PageLayout

    pages = [("home", "Startpagina (Home)", True)] + [(x.key, next(iter(x.title.values()), x.key) if isinstance(x.title, dict) else x.key, bool(x.url))
                                                     for x in Page.objects.filter(kind="content", scope="public", enabled=True).exclude(source=imp.tag).order_by("order")[:100]]
    lay = {l.key: (l.data or {}).get("rows") or [] for l in PageLayout.objects.filter(key__in=[p[0] for p in pages])}
    return [{"key": k, "title": t, "std": std, "rows": len(lay.get(k, [])), "own_rows": len([r for r in lay.get(k, []) if _is_imp_row(imp, r)])} for k, t, std in pages]


def apply_info(imp):
    """What the screen needs before it applies: the files with where they are now, the pages they can go to, the languages and the last instruction."""
    st = apply_state(imp)
    out = []
    for s in (imp.theme or {}).get("sources") or []:
        pg = Page.objects.filter(key=s.get("dest")).first()
        out.append({"key": s["stem"], "title": s.get("title") or s["stem"], "dest": s.get("dest") or "", "own": bool(pg and pg.source == imp.tag) or not pg,
                    "path": "/" if s.get("dest") == "home" else (pg.path if pg else f"/p/{s.get('own_key') or s.get('dest')}")})
    links, seen = [], set()
    for sdef in (imp.theme or {}).get("sources") or []:
        for l in collect_links(read_source(sdef) or ""):
            if l["key"] not in seen:
                seen.add(l["key"])
                links.append({**l, "suggest": suggest_link(l["href"])})
    th = (imp.theme or {}).get("values") or {}
    return {"sources": out, "targets": apply_targets(imp), "languages": active_languages(), "prompt": st.get("last_prompt", ""), "done": st.get("state") == "done",
            "links": links, "link_targets": link_targets(imp), "link_map": st.get("link_map") or {}, "options": {"header": st.get("header", True), "site_footer": st.get("site_footer", True)},
            "theme": {k: th.get(k) for k in ("primary", "secondary", "default_mode", "radius", "btn_radius", "content_w") if th.get(k) is not None}}


def apply_start(imp, mapping=None, mode="clear", prompt="", translate=False, render="design", options=None, only=None):
    import threading

    st = apply_state(imp)
    if st.get("state") == "running" and time.time() - float(st.get("updated") or 0) < 150:
        raise ImportError_("Er loopt al een toepassing.")
    from apps.integrations import ai

    if not ai.available():
        raise ImportError_("Koppel Claude eerst bij Admin → API keys (Anthropic) en zet de koppeling aan.")
    sources = (imp.theme or {}).get("sources") or []
    if not sources:
        raise ImportError_("Er is niets om toe te passen.")
    allowed = {t["key"] for t in apply_targets(imp)}
    clean = {}
    for s in sources:  # per file: a page of the website, "" (= its own page), or not mentioned (= where it is now)
        if s["stem"] not in (mapping or {}):
            continue
        v = (mapping or {}).get(s["stem"]) or ""
        if v and v not in allowed:
            continue
        if v and v in clean.values():
            raise ImportError_("Twee pagina's kunnen niet op dezelfde pagina komen.")
        clean[s["stem"]] = v
    mode = mode if mode in ("clear", "replace", "append") else "clear"
    _set_apply(imp.id, _force=True, cancel=False, state="running", percent=1, step="Starten…", error="", warning="", map=clean, mode=mode, prompt=str(prompt or "")[:1500], translate=bool(translate), render="blocks" if render == "blocks" else "design",
             link_map={k: v for k, v in ((options or {}).get("links") or {}).items() if isinstance(k, str) and isinstance(v, str)}, header=bool((options or {}).get("header", True)),
             site_footer=bool((options or {}).get("site_footer", True)), only=[str(x) for x in (only or [])], theme_over=(options or {}).get("theme") if isinstance((options or {}).get("theme"), dict) else {})
    from apps.integrations import aiusage

    actor = aiusage.current_user_id()  # the AI calls of this work (in the background) are counted for the person who started it
    _set_apply(imp.id, actor=actor)
    threading.Thread(target=aiusage.run_as, args=(actor, _apply_run, imp.id), daemon=True).start()
