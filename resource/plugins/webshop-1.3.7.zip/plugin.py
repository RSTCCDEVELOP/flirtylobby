# Copyright & Ownership Notice
# easy2Edit is the exclusive legal property of RST Coaching & Consultancy B.V. (RSTCC),
# owned by Ronald Stolk. All rights reserved. Any unauthorized use, copying, modification,
# reproduction, distribution, or commercial exploitation of Easy2Edit, including its source code,
# is strictly prohibited without prior written permission from Ronald Stolk or RSTCC.
# website https://rstcc.net

"""Webshop (plugin). Producten en productgroepen, verzendmethoden en kortingscodes, en de winkelpagina's op de website.

De gegevens staan in de database van het systeem (tabellen plg_webshop_*). De bestellingen zelf staan in de plugin Orders (die deelt de webshop met abonnementen en donaties, met bevestigingsmail en btw-instellingen),
het betalen gaat via de plugin Betalen. De webshop heeft beide nodig (zie "requires" in plugin.json).
Het systeem vraagt de plugin om de producten (voor abonnementen, het dashboard, de sitemap): zie `system.provide("catalog", ...)` onderaan.

Routes: /api/plugins/run/webshop/<pad>. Openbaar: groups, products, products/<slug>, cart, config, methods, quote, order. Beheer: admin/…"""
import json
import re
import secrets
from decimal import ROUND_HALF_UP, Decimal, InvalidOperation

from django.db import connection, models, transaction
from django.db.models import Count, F, Q
from django.utils import timezone
from django.utils.text import slugify
from rest_framework.response import Response

TWO = Decimal("0.01")
q2 = lambda v: Decimal(v).quantize(TWO, rounding=ROUND_HALF_UP)  # noqa: E731
LEGACY = [("shop_productgroup", "group"), ("shop_product", "product"), ("shop_productimage", "image"), ("shop_shippingmethod", "method"), ("shop_discountcode", "discount")]


class OrderError(Exception):
    pass


def register(system):
    from apps.accounts.access import level
    from apps.core import richtext
    from apps.medialib.models import MediaItem
    from apps import commerce
    from apps.security.countries import COUNTRY_CODES
    from apps.security.words import find_forbidden

    class shop:  # the order settings and the mail live in the plugin Orders: asked at the moment of use (the plugin can be reloaded)
        settings = staticmethod(lambda: commerce.need_orders().settings())
        confirmation_mail = staticmethod(lambda order: commerce.need_orders().confirmation_mail(order))
    from django.core.files.storage import default_storage

    T = system.t
    label = system.app_label

    def table(name, **extra):
        return type("Meta", (), {"app_label": label, "db_table": system.db_prefix + name, **extra})

    class Carrier(models.Model):
        """A transporter (PostNL, DHL, FedEx ...): the label settings and the returns policy live here; shipping methods, products and groups point at it."""
        name = models.CharField(max_length=80)
        slug = models.SlugField(max_length=60, unique=True)
        tracking_url = models.CharField(max_length=300, blank=True)  # with {code}: where the customer follows the parcel
        active = models.BooleanField(default=True)
        order = models.PositiveIntegerField(default=0)
        label_format = models.CharField(max_length=10, default="a6")  # a4 | a6 | 10x15
        label_auto = models.BooleanField(default=False)  # make the label as soon as the order is paid
        label_packing_slip = models.BooleanField(default=True)  # print a packing slip with the label
        label_tracking = models.BooleanField(default=True)  # the label has a track & trace code
        label_sender = models.CharField(max_length=400, blank=True)  # the sender address on the label (empty = the address of the shop)
        label_note = models.CharField(max_length=200, blank=True)  # a line printed on the label
        return_allowed = models.BooleanField(default=True)
        return_days = models.PositiveIntegerField(default=14)
        return_free = models.BooleanField(default=False)  # free returns
        return_cost = models.DecimalField(max_digits=8, decimal_places=2, default=0)  # costs for the customer when returns are not free
        return_label = models.BooleanField(default=False)  # a return label is in the parcel or sent by mail
        return_address = models.CharField(max_length=400, blank=True)
        return_text = models.TextField(blank=True)  # the policy as the customer reads it
        Meta = table("carrier", ordering=["order", "name"])

    class ShipConfig(models.Model):
        """One row: may the customer choose the transporter, or is it fixed by the product, the group or the standard."""
        choice = models.CharField(max_length=10, default="customer")  # customer | fixed
        default_carrier = models.ForeignKey(Carrier, null=True, blank=True, on_delete=models.SET_NULL, related_name="+")
        Meta = table("shipconfig")

    class Group(models.Model):
        carrier = models.ForeignKey(Carrier, null=True, blank=True, on_delete=models.SET_NULL, related_name="+")  # the transporter of the products in this group (the product itself goes first)
        name = models.CharField(max_length=100)
        slug = models.SlugField(max_length=120, unique=True)
        description = models.CharField(max_length=500, blank=True)
        media = models.ForeignKey(MediaItem, null=True, blank=True, on_delete=models.SET_NULL, related_name="+")
        parent = models.ForeignKey("self", null=True, blank=True, on_delete=models.SET_NULL, related_name="children")
        order = models.PositiveIntegerField(default=0)
        active = models.BooleanField(default=True)
        demo = models.BooleanField(default=False)  # made by "Demo-inhoud": can be removed again in one go
        i18n = models.JSONField(default=dict, blank=True)  # {language: {name, description}}: the texts in the other languages
        Meta = table("group", ordering=["order", "name"])

    class Product(models.Model):
        carrier = models.ForeignKey(Carrier, null=True, blank=True, on_delete=models.SET_NULL, related_name="+")  # empty = the group, then the standard transporter
        name = models.CharField(max_length=200)
        slug = models.SlugField(max_length=220, unique=True)
        sku = models.CharField(max_length=60, blank=True)
        summary = models.CharField(max_length=300, blank=True)
        description = models.TextField(blank=True)  # cleaned html
        price = models.DecimalField(max_digits=10, decimal_places=2)
        stock = models.IntegerField(null=True, blank=True)  # None = unlimited (a product without variants and sizes, or with a stock that is shared)
        stock_per_option = models.BooleanField(default=False)  # the stock is kept per variant and size (stock_map) instead of one number
        stock_map = models.JSONField(default=dict, blank=True)  # {"rood|m": {"stock": 5, "ordered": 20}}: per choice; stock None/absent = 0
        backorder = models.BooleanField(default=False)  # may be sold while there is no stock (delivered when the supplier delivers)
        ordered = models.PositiveIntegerField(default=0)  # ordered at the supplier, not yet in (for a product without stock per option)
        ordered_eta = models.CharField(max_length=40, blank=True)  # when it is expected (free text or a date)
        vat_rate = models.DecimalField(max_digits=4, decimal_places=1, null=True, blank=True)  # an own percentage (older products); the tariff below is used first
        sale = models.BooleanField(default=False)  # on sale: sale_price is the price now (price is the old price)
        sale_price = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)
        is_new = models.BooleanField(default=False)  # shows the flag "Nieuw"
        flag = models.BooleanField(default=False)  # a flag of its own (text and colour below)
        flag_text = models.CharField(max_length=24, blank=True)
        flag_color = models.CharField(max_length=10, default="blue", blank=True)
        flag_shape = models.CharField(max_length=8, default="ribbon", blank=True)  # ribbon (hangs from the top) | flag (pennant) | star | pill
        flag_size = models.CharField(max_length=2, default="m", blank=True)  # s | m | l
        sale_color = models.CharField(max_length=10, default="red", blank=True)
        new_color = models.CharField(max_length=10, default="green", blank=True)
        vat_key = models.CharField(max_length=40, blank=True)  # the VAT tariff of the product (system table Admin → Btw): every product has one; a product without gets the standard tariff when it is saved
        group = models.ForeignKey(Group, null=True, blank=True, on_delete=models.SET_NULL, related_name="products")
        active = models.BooleanField(default=True)
        variants = models.JSONField(default=list, blank=True)  # [{key, label, color, price (None = the price of the product), sku}]: colours, sizes, materials
        variant_label = models.CharField(max_length=24, blank=True)  # what the variants are called for the customer: Kleur, Verpakking ...
        size_label = models.CharField(max_length=24, blank=True)  # what the second choice is called: Maat, Gewicht, Stof ...
        sizes = models.JSONField(default=list, blank=True)  # [{key, label, extra}]: sizes (XS-XL, 36-46 ...), combined with the variants (colours); extra = what this size costs more
        tiers = models.JSONField(default=list, blank=True)  # [{min, price}]: from `min` pieces this is the price of one (volume pricing)
        demo = models.BooleanField(default=False)
        i18n = models.JSONField(default=dict, blank=True)  # {language: {name, summary, description}}: the texts in the other languages
        img_cfg = models.JSONField(default=dict, blank=True)  # the photos of this product: {pad: px, pos: top|center|bottom}; absent = the standard of the webshop (Webshop → Overzicht → Productfoto's)
        created_at = models.DateTimeField(auto_now_add=True)
        def save(self, *a, **k):
            if not self.vat_key:
                from apps import commerce

                fin = commerce.finance()
                self.vat_key = fin.vat_default_key() if fin else ""
            super().save(*a, **k)

        Meta = table("product", ordering=["name"])

    class Image(models.Model):
        product = models.ForeignKey(Product, on_delete=models.CASCADE, related_name="images")
        media = models.ForeignKey(MediaItem, null=True, on_delete=models.SET_NULL, related_name="+")
        alt = models.CharField(max_length=200, blank=True)
        order = models.PositiveIntegerField(default=0)
        Meta = table("image", ordering=["order", "id"])

    class Method(models.Model):
        carrier = models.ForeignKey(Carrier, null=True, blank=True, on_delete=models.SET_NULL, related_name="+")  # who delivers with this method (empty = any)
        name = models.CharField(max_length=100)
        description = models.CharField(max_length=200, blank=True)
        delivery_time = models.CharField(max_length=60, blank=True)
        price = models.DecimalField(max_digits=8, decimal_places=2, default=0)  # incl. VAT
        free_from = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)
        countries = models.JSONField(default=list, blank=True)  # empty = all countries
        active = models.BooleanField(default=True)
        order = models.PositiveIntegerField(default=0)
        Meta = table("method", ordering=["order", "name"])

    class Discount(models.Model):
        code = models.CharField(max_length=40, unique=True)
        description = models.CharField(max_length=200, blank=True)
        kind = models.CharField(max_length=10, default="percent")  # percent | fixed
        value = models.DecimalField(max_digits=8, decimal_places=2)
        min_subtotal = models.DecimalField(max_digits=10, decimal_places=2, default=0)
        max_uses = models.PositiveIntegerField(null=True, blank=True)
        used_count = models.PositiveIntegerField(default=0)
        starts_at = models.DateTimeField(null=True, blank=True)
        ends_at = models.DateTimeField(null=True, blank=True)
        active = models.BooleanField(default=True)
        created_at = models.DateTimeField(auto_now_add=True)
        Meta = table("discount", ordering=["-created_at"])

    class Design(models.Model):
        """A design of the product overview: how it looks and what it shows. Every active design is a system object that can be put on a page."""
        name = models.CharField(max_length=60)
        slug = models.SlugField(max_length=48, unique=True)
        data = models.JSONField(default=dict, blank=True)  # see DESIGN_DEFAULT
        active = models.BooleanField(default=True)
        order = models.PositiveIntegerField(default=0)
        demo = models.BooleanField(default=False)
        Meta = table("design", ordering=["order", "name"])

    models_ = (Carrier, ShipConfig, Group, Product, Image, Method, Discount, Design)
    system.sync_models(*models_)
    try:  # every product has a VAT tariff: the ones without get the standard tariff of the system
        from apps import commerce as _commerce

        _fin = _commerce.finance()
        if _fin:
            Product.objects.filter(vat_key="").update(vat_key=_fin.vat_default_key())
    except Exception:  # noqa: BLE001 - the table may not exist yet (first start)
        pass
    ensure_columns(connection, ((Group, ("demo", "i18n", "carrier")), (Method, ("carrier",)), (Product, ("carrier", "variants", "tiers", "demo", "vat_key", "i18n", "sale", "sale_price", "stock_per_option", "stock_map", "backorder", "ordered", "ordered_eta", "sizes", "variant_label", "size_label", "is_new", "flag", "flag_text", "flag_color", "flag_shape", "flag_size", "sale_color", "new_color", "img_cfg")), (Design, ("demo",))))  # tables of an older version of the plugin get the new columns
    _import_legacy(connection, system, {"group": Group, "product": Product, "image": Image, "method": Method, "discount": Discount})

    bad = lambda msg, code=400: Response({"detail": msg}, status=code)  # noqa: E731

    def media_url(m):
        return default_storage.url(m.key) if m else None

    def unique_slug(model, text, exclude=None):
        base, n = slugify(text) or "item", 2
        slug = base
        while model.objects.filter(slug=slug).exclude(pk=exclude).exists():
            slug, n = f"{base}-{n}", n + 1
        return slug

    def shop_off():
        """Ordering needs the module Orders & betalen to be on."""
        from apps.core import modules

        return None if modules.enabled("orders") else bad(T("De webshop is niet beschikbaar."), 404)

    def lvl(request, need):  # 1 gebruik, 2 bewerken, 3 beheer: the levels of "Orders" in the roles
        return level(request.user, "orders") >= need

    def body(request):
        return request.data if isinstance(request.data, dict) else {}

    # ── catalog (what the website shows) ──────────────────────────────────────
    def locked():
        from apps.plugins.facade import subs

        return subs.locked_products()

    def eff(p):
        """The price of a product now: the sale price while it is on sale."""
        return p.sale_price if p.sale and p.sale_price is not None else p.price

    def combo_key(variant, size):
        return ((variant or {}).get("key") or "") + (("|" + size["key"]) if size else "")

    def per_option(p):
        return bool(p.stock_per_option and (p.variants or p.sizes))

    def option_stock(p, key):
        """The stock of one choice (variant + size): a number, or None = unlimited (a product with a stock per choice always has numbers)."""
        if per_option(p):
            return int((p.stock_map or {}).get(key, {}).get("stock") or 0)
        return p.stock

    def total_stock(p):
        """What is in stock in all: the sum of the choices, or the number of the product (None = unlimited)."""
        if per_option(p):
            return sum(int((v or {}).get("stock") or 0) for v in (p.stock_map or {}).values())
        return p.stock

    def total_ordered(p):
        if per_option(p):
            return sum(int((v or {}).get("ordered") or 0) for v in (p.stock_map or {}).values())
        return p.ordered or 0

    def status_of(stock, p):
        """in | low | out | backorder for a stock number."""
        if stock is None or stock > 5:
            return "in"
        if stock > 0:
            return "low"
        return "backorder" if p.backorder else "out"

    def rate_of(p, s):
        """The VAT percentage of a product: its tariff (it follows a change of the tariff), else an own percentage, else the standard tariff."""
        tar = next((x for x in s["vat_tariffs"] if x["key"] == p.vat_key), None) if p.vat_key else None
        if tar:
            return Decimal(tar["rate"])
        return Decimal(str(p.vat_rate)) if p.vat_rate is not None else Decimal(s["default_vat"])

    def variant_of(p, key):
        return next((v for v in (p.variants or []) if v.get("key") == str(key).partition("|")[0]), None)

    def size_of(p, key):
        sk = str(key).partition("|")[2]
        return next((x for x in (p.sizes or []) if x.get("key") == sk), None)

    def unit_price(p, variant, qty):
        """The price of one piece: the price of the variant (else of the product), and the volume price (staffel) that applies from `qty` pieces."""
        base = Decimal(str(variant["price"])) if variant and variant.get("price") not in (None, "") else eff(p)
        delta, price = base - p.price, base
        for tr in sorted(p.tiers or [], key=lambda x: x["min"]):
            if qty >= tr["min"]:
                price = Decimal(str(tr["price"])) + delta
        return max(price, Decimal("0.00"))

    def tr(obj, lang):
        """The texts of a product or group in the language of the visitor (empty = the base text)."""
        return (obj.i18n or {}).get(lang or "") or {}

    FLAG_COLORS = ("red", "green", "blue", "orange", "black", "purple", "pink", "yellow")
    FLAG_SHAPES, FLAG_SIZES = ("ribbon", "flag", "star", "pill"), ("s", "m", "l")

    def color_ok(v, default):
        v = str(v or "")
        return v if v in FLAG_COLORS or re.fullmatch(r"#[0-9a-fA-F]{6}", v) else default

    def flags_of(p):
        """The little flags on a product: sale, new and one of its own, with the shape, size and colours chosen for this product."""
        shape = p.flag_shape if p.flag_shape in FLAG_SHAPES else "ribbon"
        size = p.flag_size if p.flag_size in FLAG_SIZES else "m"
        out = []
        if p.sale and p.sale_price is not None:
            out.append({"kind": "sale", "text": "Sale", "color": color_ok(p.sale_color, "red")})
        if p.is_new:
            out.append({"kind": "new", "text": "Nieuw", "color": color_ok(p.new_color, "green")})
        if p.flag and p.flag_text:
            out.append({"kind": "flag", "text": p.flag_text, "color": color_ok(p.flag_color, "blue")})
        for f in out:
            f.update(shape=shape, size=size)
        return out

    IMG_POS = {"boven": "top", "midden": "center", "onder": "bottom"}
    IMG_Y = {"top": 0, "center": 50, "bottom": 100}
    IMG_RATIO = {"standaard": "", "liggend": "4/3", "staand": "3/4", "vierkant": "1/1"}  # the shape of the photo frame: landscape, portrait, square (empty = what the overview or the system object says)

    def _y_of(pos, y):
        """The vertical position of the photo in its frame (0 = top, 100 = bottom). An older setting only has top / centre / bottom."""
        try:
            if y not in (None, ""):
                y = int(min(max(float(y), 0), 100))
                if not (y == 50 and pos in ("top", "bottom")):
                    return y
        except (TypeError, ValueError):
            pass
        return IMG_Y.get(pos, 50)

    def _pos_of(y):
        return {0: "top", 50: "center", 100: "bottom"}.get(y, "center")

    def img_default():
        """The standard of the webshop for the photos of a product: space around the photo (px), where it is held (position 0-100, top to bottom) and the shape of the frame."""
        try:
            pad = int(min(max(float(system.config.get("img_pad", 0) or 0), 0), 80))
        except (TypeError, ValueError):
            pad = 0
        pos = IMG_POS.get(str(system.config.get("img_pos", "midden")), "center")
        y = _y_of(pos, system.config.get("img_y", 50))
        return {"pad": pad, "pos": _pos_of(y), "y": y, "ratio": IMG_RATIO.get(str(system.config.get("img_ratio", "standaard")), "")}

    PAGE_OPTS = {"pp_gallery": ("links", "rechts", "boven"), "pp_thumbs": ("ja", "nee"), "pp_summary": ("ja", "nee"), "pp_stock": ("ja", "nee"), "pp_tiers": ("ja", "nee"), "pp_sku": ("ja", "nee")}

    def page_cfg():
        """The settings of the product page for the whole webshop (where the photos are, and what is shown)."""
        out = {}
        for k, opts in PAGE_OPTS.items():
            v = str(system.config.get(k, opts[0]) or opts[0])
            out[k] = v if v in opts else opts[0]
        return out

    def img_of(p):
        d, own = img_default(), (p.img_cfg or {})
        y = _y_of(own.get("pos"), own["y"]) if "y" in own else (IMG_Y[own["pos"]] if own.get("pos") in IMG_Y else d["y"])
        return {"pad": own.get("pad", d["pad"]), "pos": _pos_of(y), "y": y, "ratio": own.get("ratio", d["ratio"])}

    def clean_img(raw):
        """What a product holds of its own: only the values that differ from the standard (a missing one follows the standard)."""
        out = {}
        if isinstance(raw, dict):
            try:
                if raw.get("pad") not in (None, ""):
                    out["pad"] = int(min(max(float(raw["pad"]), 0), 80))
            except (TypeError, ValueError):
                pass
            if raw.get("pos") in ("top", "center", "bottom"):
                out["pos"] = raw["pos"]
            try:
                if raw.get("y") not in (None, ""):
                    out["y"] = int(min(max(float(raw["y"]), 0), 100))
                    out["pos"] = _pos_of(out["y"])
            except (TypeError, ValueError):
                pass
            if raw.get("ratio") in ("", "4/3", "3/4", "1/1"):
                out["ratio"] = raw["ratio"]
        return out

    def pub(p, full=False, lock=None, lang=None):
        t_ = tr(p, lang)
        imgs = [{"url": media_url(i.media), "alt": i.alt or p.name} for i in p.images.all() if i.media_id]
        out = {"id": p.id, "name": t_.get("name") or p.name, "slug": p.slug, "price": str(eff(p)), "sale": bool(p.sale and p.sale_price is not None), "flags": flags_of(p), "old_price": str(p.price) if p.sale and p.sale_price is not None else None, "summary": t_.get("summary") or p.summary, "image": imgs[0] if imgs else None, "image2": imgs[1] if len(imgs) > 1 else None,
               "stock": status_of(total_stock(p), p), "backorder": p.backorder, "ordered": total_ordered(p), "ordered_eta": p.ordered_eta,
               "option_stock": ({k: {"status": status_of(int((v or {}).get("stock") or 0), p), "ordered": int((v or {}).get("ordered") or 0)} for k, v in (p.stock_map or {}).items()} if per_option(p) else None),
               "group": {"name": tr(p.group, lang).get("name") or p.group.name, "slug": p.group.slug} if p.group_id and p.group.active else None,
               "members_only": str(p.id) in (locked() if lock is None else lock),
               "variants": [{"key": v["key"], "label": v["label"], "color": v.get("color") or "", "price": str(v["price"]) if v.get("price") not in (None, "") else None, "sku": v.get("sku") or ""} for v in (p.variants or [])],
               "tiers": [{"min": x["min"], "price": str(x["price"])} for x in sorted(p.tiers or [], key=lambda x: x["min"])],
               "sizes": [{"key": x["key"], "label": x["label"], "extra": str(x.get("extra") or "0")} for x in (p.sizes or [])],
               "variant_label": p.variant_label, "size_label": p.size_label, "img": img_of(p)}
        prices = [Decimal(str(v["price"])) for v in (p.variants or []) if v.get("price") not in (None, "")] + ([eff(p)] if any(v.get("price") in (None, "") for v in (p.variants or [])) or not p.variants else [])
        out["price_from"] = str(min(prices)) if prices and min(prices) < max(prices) else None  # "vanaf": the variants have different prices
        if full:
            out.update(description=t_.get("description") or p.description, sku=p.sku, images=imgs, max_quantity=(None if (p.backorder or per_option(p)) else p.stock))
        return out

    @system.route("GET", "groups", public=True)
    def groups(request):
        counts = dict(Product.objects.filter(active=True, group__isnull=False).values_list("group").annotate(n=Count("id")))  # (reverse names are not usable in queries of a plugin's models)
        lang = request.query_params.get("lang")
        return [{"id": g.id, "name": tr(g, lang).get("name") or g.name, "slug": g.slug, "description": tr(g, lang).get("description") or g.description, "image": media_url(g.media), "parent": g.parent.slug if g.parent_id else None, "count": counts.get(g.id, 0)}
                for g in Group.objects.filter(active=True).select_related("parent", "media")]

    @system.route("GET", "products", public=True)
    def products(request):
        qs = Product.objects.filter(active=True).select_related("group").prefetch_related("images__media")
        if g := request.query_params.get("group"):
            grp = Group.objects.filter(slug=g, active=True).first()
            qs = qs.filter(group_id__in=[grp.id, *grp.children.values_list("id", flat=True)] if grp else [])
        if s := request.query_params.get("q"):
            qs = qs.filter(Q(name__icontains=s) | Q(summary__icontains=s))
        order = {"price_asc": ("price", "name"), "price_desc": ("-price", "name"), "new": ("-created_at",), "name": ("name",)}.get(request.query_params.get("sort"))
        if order:
            qs = qs.order_by(*order)
        try:
            limit = min(200, max(1, int(request.query_params.get("limit") or 200)))
        except ValueError:
            limit = 200
        lock, lang = locked(), request.query_params.get("lang")
        return [pub(p, lock=lock, lang=lang) for p in qs[:limit]]

    # ── designs of the product overview ───────────────────────────────────────
    @system.route("GET", "designs/<slug>", public=True)
    def design_public(request, slug):
        d = Design.objects.filter(slug=slug, active=True).first()
        return {"slug": d.slug, "name": d.name, **design_data(d.data)} if d else bad(T("Niet gevonden."), 404)

    @system.route("GET", "products/<slug>", public=True)
    def product(request, slug):
        p = Product.objects.filter(slug=slug, active=True).select_related("group").prefetch_related("images__media").first()
        return pub(p, full=True, lang=request.query_params.get("lang")) if p else bad(T("Dit product bestaat niet."), 404)

    @system.route("POST", "cart", public=True)
    def cart(request):
        """Current price and stock of the products in a cart (the browser only keeps numbers)."""
        if (off := shop_off()):
            return off
        ids = [i for i in body(request).get("ids", []) if isinstance(i, int)][:50]
        return [pub(p, full=True, lang=request.query_params.get("lang")) for p in Product.objects.filter(id__in=ids, active=True).prefetch_related("images__media")]

    # ── totals and orders ─────────────────────────────────────────────────────
    def ship_config():
        c = ShipConfig.objects.first()
        return c or ShipConfig.objects.create()

    def carrier_of(p):
        """The transporter of a product: its own, else that of its group (or the group above), else None."""
        if p.carrier_id:
            return p.carrier_id
        g = p.group
        for _ in range(3):
            if not g:
                break
            if g.carrier_id:
                return g.carrier_id
            g = g.parent
        return None

    def carrier_ids_for(products):
        """The transporter for these products when it is fixed: the one they share, else the standard one (None = no restriction)."""
        cfg = ship_config()
        if cfg.choice != "fixed":
            return None
        ids = {carrier_of(p) or cfg.default_carrier_id for p in products}
        ids.discard(None)
        if len(ids) == 1:
            return ids
        return {cfg.default_carrier_id} if cfg.default_carrier_id else (ids or None)

    def methods_for(country, products=None):
        ok = carrier_ids_for(products) if products else (None)
        out = [m for m in Method.objects.filter(active=True).select_related("carrier") if (not m.countries or (country or "").upper() in m.countries) and (m.carrier_id is None or m.carrier.active)]
        if ok:
            out = [m for m in out if m.carrier_id is None or m.carrier_id in ok]
        if products and ship_config().choice != "fixed":  # the customer may choose: the transporter of the products comes first
            pref = {carrier_of(p) for p in products}
            out.sort(key=lambda m: 0 if m.carrier_id in pref else 1)
        return out

    def check_discount(code, subtotal, lock=False):
        if not code:
            return None
        d = (Discount.objects.select_for_update() if lock else Discount.objects).filter(code=code.strip().upper(), active=True).first()
        now = timezone.now()
        if not d or (d.starts_at and d.starts_at > now) or (d.ends_at and d.ends_at < now):
            raise OrderError(T("Deze kortingscode is ongeldig of verlopen."))
        if d.max_uses is not None and d.used_count >= d.max_uses:
            raise OrderError(T("Deze kortingscode is niet meer beschikbaar."))
        if subtotal < d.min_subtotal:
            raise OrderError(T("Deze code geldt vanaf een bestelling van € {0}.", d.min_subtotal))
        return d

    def quote(items, code="", method_id=None, country="NL", lock=False, user=None, check=True):
        """The one place where prices are calculated (cart, checkout and order). Line totals are gross (incl. VAT)."""
        s = shop.settings()
        if not items or len(items) > 50 or not all(isinstance(i, dict) for i in items):
            raise OrderError(T("Je winkelwagen is leeg."))
        prods = {p.id: p for p in (Product.objects.select_for_update() if lock else Product.objects).filter(id__in=[i.get("product") for i in items if isinstance(i.get("product"), int)], active=True)}
        if check and (user is not None or lock):
            from apps.plugins.facade import subs

            try:
                subs.check_products(user, prods.values())
            except subs.SubError as e:
                raise OrderError(str(e))
        lines, gross_sum, pieces = [], Decimal("0.00"), {}
        for it in items:  # the volume price counts the pieces of all variants of a product together
            qty = it.get("quantity")
            if isinstance(qty, int) and not isinstance(qty, bool) and isinstance(it.get("product"), int):
                pieces[it["product"]] = pieces.get(it["product"], 0) + qty
        optpieces = {}
        for it in items:  # pieces per product and choice (a stock per choice is counted per choice)
            q_, pr_ = it.get("quantity"), prods.get(it.get("product")) if isinstance(it.get("product"), int) else None
            if pr_ and isinstance(q_, int) and not isinstance(q_, bool):
                kk = (pr_.id, combo_key(variant_of(pr_, it.get("variant") or ""), size_of(pr_, it.get("variant") or "")))
                optpieces[kk] = optpieces.get(kk, 0) + q_
        for it in items:
            p, qty = prods.get(it.get("product")), it.get("quantity")
            if not p or not isinstance(qty, int) or isinstance(qty, bool) or not 1 <= qty <= 99:
                raise OrderError(T("Een product in je winkelwagen bestaat niet meer."))
            key = str(it.get("variant") or "")
            variant, size = variant_of(p, key), size_of(p, key)
            if p.variants and not variant:
                raise OrderError(T("Kies een {0} van '{1}'.", (p.variant_label or T("variant")).lower(), p.name))
            if p.sizes and not size:
                raise OrderError(T("Kies een {0} van '{1}'.", (p.size_label or T("maat")).lower(), p.name))
            if key and not variant and not size:
                raise OrderError(T("Een product in je winkelwagen bestaat niet meer."))
            ck = combo_key(variant, size)
            have = option_stock(p, ck)
            want = optpieces.get((p.id, ck), 0) if per_option(p) else pieces[p.id]
            if have is not None and want > have and not p.backorder:
                label = " / ".join(x for x in ((variant or {}).get("label"), (size or {}).get("label")) if x)
                nm = f"{p.name} ({label})" if (label and per_option(p)) else p.name
                raise OrderError(T("Van '{0}' is nog maar {1} op voorraad.", nm, have) if have else T("'{0}' is uitverkocht.", nm))
            rate = rate_of(p, s)
            unit = unit_price(p, variant, pieces[p.id]) + (Decimal(str(size.get("extra") or 0)) if size else Decimal("0"))
            base = unit * qty
            gross = q2(base * (1 + rate / 100)) if not s["prices_include_vat"] else q2(base)
            lines.append({"product": p, "qty": qty, "rate": rate, "gross": gross, "unit": unit, "variant": variant, "size": size})
            gross_sum += gross
        disc = check_discount(code, gross_sum, lock)
        discount = Decimal("0.00")
        if disc:
            discount = q2(gross_sum * disc.value / 100) if disc.kind == "percent" else q2(min(disc.value, gross_sum))
            discount = min(discount, gross_sum)
        ratio = (gross_sum - discount) / gross_sum if gross_sum else Decimal(1)
        vat_total = Decimal("0.00")
        for ln in lines:
            ln["line_total"] = q2(ln["gross"] * ratio)
            ln["vat"] = q2(ln["line_total"] - ln["line_total"] / (1 + ln["rate"] / 100))
            vat_total += ln["vat"]
        method, shipping = None, Decimal("0.00")
        if method_id is not None:
            method = next((m for m in methods_for(country, [ln["product"] for ln in lines]) if m.id == method_id), None)
            if not method:
                raise OrderError(T("Kies een verzendmethode die beschikbaar is voor jouw land."))
            shipping = Decimal("0.00") if method.free_from is not None and gross_sum - discount >= method.free_from else q2(method.price)
            vat_total += q2(shipping - shipping / (1 + Decimal(s["shipping_vat"]) / 100))
        return {"lines": lines, "subtotal": gross_sum, "discount": discount, "discount_obj": disc, "shipping": shipping, "method": method, "vat_total": vat_total, "total": gross_sum - discount + shipping}

    @system.route("GET", "config", public=True)
    def config(request):
        if (off := shop_off()):
            return off
        s = shop.settings()
        return {"currency": s["currency"], "prices_include_vat": s["prices_include_vat"], "pay_online": commerce.pay_online_wanted(), "payment_available": commerce.can_pay_online(), "discounts": Discount.objects.filter(active=True).exists(), "page": page_cfg()}

    def return_line(c):
        if not c.return_allowed:
            return T("Geen retour mogelijk")
        txt = T("Retour binnen {0} dagen", c.return_days) + (", " + T("gratis") if c.return_free else (", " + T("retourkosten") + f" € {c.return_cost}" if c.return_cost else ""))
        return txt

    @system.route("GET", "methods", public=True)
    def methods(request):
        if (off := shop_off()):
            return off
        ids = [int(x) for x in str(request.query_params.get("ids", "")).split(",") if x.isdigit()][:50]
        prods = list(Product.objects.filter(id__in=ids).select_related("group__parent")) if ids else None
        fixed = ship_config().choice == "fixed"
        return [{"id": m.id, "name": m.name, "description": m.description, "delivery_time": m.delivery_time, "price": str(m.price), "free_from": str(m.free_from) if m.free_from is not None else None,
                 "carrier": m.carrier.name if m.carrier_id else "", "carrier_id": m.carrier_id, "returns": return_line(m.carrier) if m.carrier_id else "", "fixed": fixed}
                for m in methods_for(request.query_params.get("country", "NL"), prods)]

    @system.route("POST", "quote", public=True)
    def quote_route(request):
        if (off := shop_off()):
            return off
        b = body(request)
        try:
            m = b.get("method")
            qt = quote(b.get("items") or [], str(b.get("code") or ""), m if isinstance(m, int) else None, str(b.get("country") or "NL"))
        except OrderError as e:
            return bad(str(e))
        return {"subtotal": str(qt["subtotal"]), "discount": str(qt["discount"]), "shipping": str(qt["shipping"]), "vat_total": str(qt["vat_total"]), "total": str(qt["total"]),
                "code": qt["discount_obj"].code if qt["discount_obj"] else "", "method": qt["method"].name if qt["method"] else "",
                "lines": [{"product": ln["product"].id, "variant": ((ln["variant"] or {}).get("key") or "") + (("|" + ln["size"]["key"]) if ln.get("size") else ""), "name": tr(ln["product"], request.query_params.get("lang")).get("name") or ln["product"].name, "label": " / ".join(x for x in ((ln["variant"] or {}).get("label"), (ln.get("size") or {}).get("label")) if x),
                           "color": (ln["variant"] or {}).get("color") or "", "slug": ln["product"].slug, "qty": ln["qty"], "unit": str(ln["unit"]), "line": str(ln["gross"]),
                           "image": next((media_url(i.media) for i in ln["product"].images.all() if i.media_id), None), "max_quantity": (None if (ln["product"].backorder or per_option(ln["product"])) else ln["product"].stock)} for ln in qt["lines"]]}

    @transaction.atomic
    def make_order(data, items, method_id, code, user, check=True):
        qt = quote(items, code, method_id, data["country"], lock=True, user=user, check=check)
        if qt["method"] is None:
            raise OrderError(T("Kies een verzendmethode."))
        o = commerce.need_orders()
        Order, OrderItem = o.Order, o.OrderItem
        order = Order.objects.create(token=secrets.token_urlsafe(18), subtotal=qt["subtotal"], discount=qt["discount"], discount_code=qt["discount_obj"].code if qt["discount_obj"] else "",
                                     shipping=qt["shipping"], shipping_method=((qt["method"].carrier.name + " – ") if qt["method"].carrier_id else "") + qt["method"].name, vat_total=qt["vat_total"], total=qt["total"], currency=shop.settings()["currency"], user=user, **data)
        order.number = f"{order.created_at.year}-{order.id:05d}"
        order.save(update_fields=["number"])
        for ln in qt["lines"]:
            p = ln["product"]
            v = ln["variant"]
            OrderItem.objects.create(order=order, product=p.id, name=(f"{p.name} – {' / '.join(x for x in ((v or {}).get('label'), (ln.get('size') or {}).get('label')) if x)}" if (v or ln.get("size")) else p.name)[:200], sku=((v or {}).get("sku") or p.sku)[:60], unit_price=ln["unit"], quantity=ln["qty"], option=combo_key(v, ln.get("size")), line_total=ln["line_total"], vat_rate=ln["rate"], vat_amount=ln["vat"])
            ck = combo_key(v, ln.get("size"))
            if per_option(p):
                m = dict(p.stock_map or {})
                row = dict(m.get(ck) or {})
                row["stock"] = max(0, int(row.get("stock") or 0) - ln["qty"])
                m[ck] = row
                p.stock_map = m
                p.save(update_fields=["stock_map"])
            elif p.stock is not None:
                p.stock = max(0, p.stock - ln["qty"])
                p.save(update_fields=["stock"])
        if qt["discount_obj"]:
            Discount.objects.filter(pk=qt["discount_obj"].pk).update(used_count=F("used_count") + 1)
        return order

    FIELDS = {"name": 150, "email": 254, "phone": 30, "street": 200, "postal_code": 20, "city": 100, "country": 2, "note": 1000}
    REQUIRED = ["name", "email", "street", "postal_code", "city", "country"]

    @system.route("POST", "order", public=True)
    def create_order(request):
        if (off := shop_off()):
            return off
        b = body(request)
        data = {k: str(b.get(k, "")).strip()[:n] for k, n in FIELDS.items()}
        if any(not data[k] for k in REQUIRED) or not re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", data["email"]) or data["country"].upper() not in COUNTRY_CODES:
            return bad(T("Controleer je gegevens: naam, e-mail en het volledige adres zijn verplicht."))
        data["country"] = data["country"].upper()
        if find_forbidden(data["note"]):
            return bad(T("Je opmerking bevat niet toegestane woorden."))
        online = commerce.pay_online_wanted()
        if online and not commerce.can_pay_online():
            return bad(T("Online betalen is nog niet beschikbaar."), 503)
        try:
            m = b.get("method")
            order = make_order(data, b.get("items") or [], m if isinstance(m, int) else None, str(b.get("code") or ""), request.user if request.user.is_authenticated else None)
        except OrderError as e:
            return bad(str(e))
        if online:
            back = f"{str(b.get('return_base', '')).rstrip('/')}/bestelling/{order.number}?t={order.token}" if b.get("return_base") else ""
            go = commerce.payments().pay_order(order, back, f"/bestelling/{order.number}?t={order.token}")  # where the customer pays (or comes back when it is paid at once)
            order.refresh_from_db()
            return Response({"number": order.number, "token": order.token, "status": order.status, "checkout_path": go}, status=201)
        else:
            shop.confirmation_mail(order)  # pay by invoice: confirmed right away
        return Response({"number": order.number, "token": order.token, "status": order.status, "checkout_path": None}, status=201)

    # ── admin ─────────────────────────────────────────────────────────────────
    def f(v, default=None):
        return default if v in (None, "") else v

    def dec(v, what, lo=Decimal(0), hi=Decimal(100000), null=False):
        if v in (None, "") and null:
            return None
        try:
            d = Decimal(str(v).replace(",", ".")).quantize(TWO)
        except (InvalidOperation, ValueError):
            raise ValueError(T("{0}: ongeldig bedrag.", what))
        if not lo <= d <= hi:
            raise ValueError(T("{0}: ongeldig bedrag.", what))
        return d

    def clean_text(v, n, what, required=False):
        v = str(v or "").strip()[:n]
        if required and not v:
            raise ValueError(T("{0} is verplicht.", what))
        if find_forbidden(v):
            raise ValueError(T("{0} bevat niet toegestane woorden.", what))
        return v

    DESIGN_DEFAULT = {"layout": "grid", "size": "md", "ratio": "4/3", "style": "card", "align": "left", "show_title": True, "title": "", "search": True, "switch": True, "chips": True,
                      "pager": True, "page_size": "all", "show_summary": True, "show_price": True, "show_stock": True, "show_group": False, "button": "", "group": "", "sort": "", "limit": 0, "hover": "lift", "hover_button": False, "hover_opacity": 50, "autoplay": False, "only": "", "show_flag": True, "flag_scale": 100,
                      "f_search": True, "f_group": True, "f_price": True, "f_variant": True, "f_stock": True, "f_tier": True, "f_sort": True}
    DESIGN_CHOICES = {"layout": ("grid", "rows", "carousel", "finder"), "size": ("sm", "md", "lg"), "ratio": ("1/1", "4/3", "16/9", "3/4"), "style": ("card", "flat", "outline"), "align": ("left", "center", "right"),
                      "page_size": ("5", "10", "25", "100", "all"), "sort": ("", "name", "price_asc", "price_desc", "new"), "hover": ("none", "lift", "zoom", "second", "dim", "glow", "plane"), "only": ("", "new", "sale", "flag")}

    def design_data(raw):
        """The settings of a design, complete and safe (unknown or wrong values become the default)."""
        raw = raw if isinstance(raw, dict) else {}
        out = {}
        for k, dflt in DESIGN_DEFAULT.items():
            v = raw.get(k, dflt)
            if k in DESIGN_CHOICES:
                out[k] = v if v in DESIGN_CHOICES[k] else dflt
            elif isinstance(dflt, bool):
                out[k] = bool(v)
            elif k in ("limit", "hover_opacity", "flag_scale"):
                try:
                    out[k] = min(100 if k == "hover_opacity" else 200, max(50 if k == "flag_scale" else 0, int(v if v not in (None, "") else dflt)))
                except (TypeError, ValueError):
                    out[k] = dflt if k == "flag_scale" else 0
            else:
                out[k] = str(v or "").strip()[:80]
        if out["group"] and not Group.objects.filter(slug=out["group"]).exists():
            out["group"] = ""
        return out

    def design_out(d):
        return {"id": d.id, "name": d.name, "slug": d.slug, "active": d.active, "order": d.order, **design_data(d.data)}

    def sync_objects():
        try:
            from apps.sysobjects import service as so

            so.sync()
        except Exception:  # noqa: BLE001  (the system objects are optional)
            pass

    def apply_design(x, d):
        if "name" in d or not x.pk:
            x.name = clean_text(d.get("name"), 60, T("Naam"), True)
        if not x.slug:
            x.slug = unique_slug(Design, x.name)[:48]
        x.data = design_data({**(x.data or {}), **{k: v for k, v in d.items() if k in DESIGN_DEFAULT}})
        for k in ("title", "button"):
            if x.data[k] and find_forbidden(x.data[k]):
                raise ValueError(T("{0} bevat niet toegestane woorden.", k))
        if "active" in d:
            x.active = bool(d["active"])
        if "order" in d:
            x.order = max(0, int(f(d["order"], 0)))
        x.save()
        sync_objects()

    def g_out(g):
        return {"id": g.id, "name": g.name, "slug": g.slug, "description": g.description, "media": g.media_id, "image": media_url(g.media), "parent": g.parent_id, "carrier": g.carrier_id, "order": g.order, "active": g.active, "demo": g.demo, "languages": sorted(g.i18n or {}), "i18n": g.i18n or {}, "product_count": g.products.count()}

    def p_out(p):
        return {"id": p.id, "name": p.name, "slug": p.slug, "sku": p.sku, "summary": p.summary, "description": p.description, "price": str(p.price), "sale": p.sale, "sale_price": str(p.sale_price) if p.sale_price is not None else "", "is_new": p.is_new, "flag": p.flag, "flag_text": p.flag_text, "flag_color": p.flag_color or "blue", "flag_shape": p.flag_shape or "ribbon", "flag_size": p.flag_size or "m", "sale_color": p.sale_color or "red", "new_color": p.new_color or "green", "stock": p.stock,
                "carrier": p.carrier_id, "carrier_name": carrier_name(carrier_of(p)), "vat_rate": str(p.vat_rate) if p.vat_rate is not None else None, "vat_key": p.vat_key, "group": p.group_id, "group_name": p.group.name if p.group_id else "", "active": p.active, "demo": p.demo, "languages": sorted(p.i18n or {}), "i18n": p.i18n or {}, "img_cfg": p.img_cfg or {}, "img_default": img_default(),
                "stock_per_option": p.stock_per_option, "stock_map": p.stock_map or {}, "backorder": p.backorder, "ordered": p.ordered, "ordered_eta": p.ordered_eta, "stock_total": total_stock(p), "ordered_total": total_ordered(p),
                "variants": p.variants or [], "sizes": p.sizes or [], "variant_label": p.variant_label, "size_label": p.size_label, "tiers": p.tiers or [],
                "images": [{"media": i.media_id, "url": media_url(i.media), "alt": i.alt} for i in p.images.all()]}

    def m_out(m):
        return {"id": m.id, "name": m.name, "description": m.description, "delivery_time": m.delivery_time, "price": str(m.price), "free_from": str(m.free_from) if m.free_from is not None else None,
                "countries": m.countries, "carrier": m.carrier_id, "carrier_name": m.carrier.name if m.carrier_id else "", "active": m.active, "order": m.order}

    def carrier_name(cid):
        c = Carrier.objects.filter(pk=cid).first() if cid else None
        return c.name if c else ""

    CARRIER_TEXT = (("tracking_url", 300), ("label_sender", 400), ("label_note", 200), ("return_address", 400), ("return_text", 2000))
    CARRIER_BOOL = ("active", "label_auto", "label_packing_slip", "label_tracking", "return_allowed", "return_free", "return_label")

    def c_out(c):
        return {"id": c.id, "name": c.name, "slug": c.slug, "tracking_url": c.tracking_url, "active": c.active, "order": c.order, "label_format": c.label_format, "label_auto": c.label_auto,
                "label_packing_slip": c.label_packing_slip, "label_tracking": c.label_tracking, "label_sender": c.label_sender, "label_note": c.label_note, "return_allowed": c.return_allowed, "return_days": c.return_days,
                "return_free": c.return_free, "return_cost": str(c.return_cost), "return_label": c.return_label, "return_address": c.return_address, "return_text": c.return_text,
                "methods": Method.objects.filter(carrier=c).count()}

    def d_out(d):
        return {"id": d.id, "code": d.code, "description": d.description, "kind": d.kind, "value": str(d.value), "min_subtotal": str(d.min_subtotal), "max_uses": d.max_uses, "used_count": d.used_count,
                "starts_at": d.starts_at, "ends_at": d.ends_at, "active": d.active}

    def crud(name, model, out, apply, need_list=1, order=None, before_delete=None, after_delete=None):
        """GET/POST admin/<name>, PATCH/DELETE admin/<name>/<id>; apply(obj, data) fills and validates the object (raises ValueError)."""
        @system.route("GET", f"admin/{name}")
        def lst(request):
            return [out(o) for o in (order() if order else model.objects.all())] if lvl(request, need_list) else bad(T("Je hebt hier geen rechten voor."), 403)

        @system.route("POST", f"admin/{name}")
        def add(request):
            if not lvl(request, 3):
                return bad(T("Je hebt hier geen rechten voor."), 403)
            try:
                with transaction.atomic():
                    o = model()
                    apply(o, body(request))
            except ValueError as e:
                return bad(str(e))
            return Response(out(o), status=201)

        @system.route("PATCH", f"admin/{name}/<id>")
        def change(request, id):  # noqa: A002
            o = model.objects.filter(pk=id).first() if str(id).isdigit() else None
            if not o:
                return bad(T("Niet gevonden."), 404)
            if not lvl(request, 2):
                return bad(T("Je hebt hier geen rechten voor."), 403)
            try:
                with transaction.atomic():
                    apply(o, body(request))
            except ValueError as e:
                return bad(str(e))
            return out(o)

        @system.route("DELETE", f"admin/{name}/<id>")
        def delete(request, id):  # noqa: A002
            o = model.objects.filter(pk=id).first() if str(id).isdigit() else None
            if not o:
                return bad(T("Niet gevonden."), 404)
            if not lvl(request, 3):
                return bad(T("Je hebt hier geen rechten voor."), 403)
            if before_delete:
                before_delete(o)  # (the cascade of the system does not know the models of a plugin: handle what points at this object first)
            o.delete()
            if after_delete:
                after_delete()
            return Response(status=204)

    EXAMPLE_CARRIERS = (
        ("PostNL", "https://postnl.nl/tracktrace/?B={code}", dict(label_format="a6", label_auto=True, return_days=14, return_free=False, return_cost="3.95", return_label=True, return_text="Retourneren kan binnen 14 dagen via een PostNL-retourlabel. De retourkosten zijn voor de klant.")),
        ("DHL", "https://www.dhl.com/nl-nl/home/tracking.html?tracking-id={code}", dict(label_format="10x15", label_auto=False, return_days=30, return_free=True, return_label=True, return_text="Gratis retour binnen 30 dagen: print het retourlabel uit je e-mail en lever het pakket in bij een DHL ServicePoint.")),
        ("FedEx", "https://www.fedex.com/fedextrack/?trknbr={code}", dict(label_format="a4", label_auto=False, return_days=14, return_free=False, return_cost="9.50", return_label=False, return_text="Retour binnen 14 dagen na overleg met de klantenservice; FedEx haalt het pakket op tegen retourkosten.")),
    )

    def make_example_carriers():
        made = 0
        for n, (name, url, extra) in enumerate(EXAMPLE_CARRIERS):
            if not Carrier.objects.filter(name=name).exists():
                Carrier.objects.create(name=name, slug=unique_slug(Carrier, name), tracking_url=url, order=n, label_sender="", **{k: (Decimal(v) if k == "return_cost" else v) for k, v in extra.items()})
                made += 1
        cfg = ship_config()
        if not cfg.default_carrier_id and Carrier.objects.exists():
            cfg.default_carrier = Carrier.objects.order_by("order").first()
            cfg.save()
        return made

    def media_id(v):
        return v if v and MediaItem.objects.filter(pk=v, kind="image").exists() else None

    def apply_group(g, d):
        if "carrier" in d:
            g.carrier_id = carrier_pk(d["carrier"])
        before = (g.name, g.description) if g.pk else None
        if "name" in d or not g.pk:
            g.name = clean_text(d.get("name"), 100, T("Naam"), True)
        if not g.slug:
            g.slug = unique_slug(Group, g.name)
        if "description" in d:
            g.description = clean_text(d.get("description"), 500, T("Omschrijving"))
        if "parent" in d:
            par = Group.objects.filter(pk=d["parent"]).first() if d["parent"] else None
            if par and g.pk and (par.pk == g.pk or par.parent_id == g.pk):
                raise ValueError(T("Een groep kan niet onder zichzelf vallen."))
            g.parent = par
        if "media" in d:
            g.media_id = media_id(d["media"])
        if "order" in d:
            g.order = max(0, int(f(d["order"], 0)))
        if "active" in d:
            g.active = bool(d["active"])
        if before and before != (g.name, g.description):
            g.i18n = {}  # the base text changed: the translations are made again
        if "i18n" in d:
            g.i18n = clean_i18n(d["i18n"], GROUP_I18N)
        g.save()

    def clean_i18n(raw, fields):
        """The texts per language typed by hand: {code: {name, summary, description}} -> clean (empty texts are left out: the base text shows then)."""
        out = {}
        limits = {"name": 200, "summary": 300, "description": 20000}
        for code, row in (raw if isinstance(raw, dict) else {}).items():
            if not isinstance(row, dict) or not re.fullmatch(r"[a-z]{2,3}(-[A-Za-z0-9]{2,8})?", str(code)):
                continue
            clean = {}
            for k in fields:
                v = str(row.get(k) or "").strip()
                if not v:
                    continue
                if k == "description" and fields is PRODUCT_I18N:
                    v = richtext.clean(v)
                elif find_forbidden(v):
                    raise ValueError(T("{0} bevat niet toegestane woorden.", k))
                clean[k] = v[:limits[k] if fields is PRODUCT_I18N else (100 if k == "name" else 500)]
            if clean:
                out[code] = clean
        return out

    def clean_variants(raw):
        """[{label, color, price, sku}] -> clean list with a key per variant. price empty = the price of the product."""
        out, seen = [], set()
        for v in (raw if isinstance(raw, list) else [])[:40]:
            if not isinstance(v, dict):
                continue
            label = clean_text(v.get("label"), 60, T("Naam van de variant"), True)
            key = slugify(label) or "v"
            n = 2
            while key in seen:
                key, n = f"{slugify(label)}-{n}", n + 1
            seen.add(key)
            color = str(v.get("color") or "").strip()
            if color and not re.fullmatch(r"#[0-9a-fA-F]{6}", color):
                raise ValueError(T("Kleur: gebruik een kleurcode zoals #c0392b."))
            price = None if f(v.get("price")) is None else dec(v["price"], T("Prijs van de variant"))
            out.append({"key": key, "label": label, "color": color, "price": str(price) if price is not None else None, "sku": clean_text(v.get("sku"), 60, T("Artikelnummer"))})
        return out

    def clean_sizes(raw):
        """[{label, extra}] -> sizes with a key; extra (a price on top of the price of the product) is optional."""
        out, seen = [], set()
        for x in (raw if isinstance(raw, list) else [])[:40]:
            if not isinstance(x, dict):
                continue
            label = clean_text(x.get("label"), 12, T("Maat"), True)
            key = slugify(label) or "m"
            n = 2
            while key in seen:
                key, n = f"{slugify(label)}-{n}", n + 1
            seen.add(key)
            extra = dec(x.get("extra") if f(x.get("extra")) is not None else 0, T("Toeslag van de maat"), lo=Decimal("-1000"))
            out.append({"key": key, "label": label, "extra": str(extra)})
        return out

    def clean_tiers(raw):
        """[{min, price}] -> volume prices, sorted, one per quantity."""
        out = {}
        for x in (raw if isinstance(raw, list) else [])[:10]:
            if not isinstance(x, dict) or f(x.get("min")) is None:
                continue
            try:
                n = int(x["min"])
            except (TypeError, ValueError):
                raise ValueError(T("Staffel: het aantal moet een getal zijn."))
            if not 2 <= n <= 9999:
                raise ValueError(T("Staffel: het aantal is minimaal 2."))
            out[n] = {"min": n, "price": str(dec(x.get("price"), T("Staffelprijs")))}
        return [out[k] for k in sorted(out)]

    PRODUCT_I18N, GROUP_I18N = ("name", "summary", "description"), ("name", "description")

    def apply_product(p, d):
        if "carrier" in d:
            p.carrier_id = carrier_pk(d["carrier"])
        before = (p.name, p.summary, p.description) if p.pk else None
        if "name" in d or not p.pk:
            p.name = clean_text(d.get("name"), 200, T("Naam"), True)
        if not p.slug:
            p.slug = unique_slug(Product, p.name)
        for k, n, w in (("sku", 60, T("Artikelnummer")), ("summary", 300, T("Korte omschrijving"))):
            if k in d:
                setattr(p, k, clean_text(d[k], n, w))
        if "description" in d:
            p.description = richtext.clean(str(d["description"] or ""))
        if "price" in d or not p.pk:
            p.price = dec(d.get("price"), T("Prijs"))
        if "sale" in d or "sale_price" in d:
            p.sale = bool(d.get("sale", p.sale))
            if "sale_price" in d:
                p.sale_price = None if f(d["sale_price"]) is None else dec(d["sale_price"], T("Actieprijs"))
            if p.sale and (p.sale_price is None or p.sale_price >= p.price):
                raise ValueError(T("Vul een actieprijs in die lager is dan de prijs."))
        if "is_new" in d:
            p.is_new = bool(d["is_new"])
        if "flag" in d or "flag_text" in d or "flag_color" in d:
            p.flag = bool(d.get("flag", p.flag))
            if "flag_text" in d:
                p.flag_text = clean_text(d["flag_text"], 24, T("Tekst van het vlaggetje"))
            if "flag_color" in d:
                p.flag_color = color_ok(d["flag_color"], "blue")
            if p.flag and not p.flag_text:
                raise ValueError(T("Vul de tekst van het vlaggetje in."))
        if "flag_shape" in d:
            p.flag_shape = d["flag_shape"] if d["flag_shape"] in FLAG_SHAPES else "ribbon"
        if "flag_size" in d:
            p.flag_size = d["flag_size"] if d["flag_size"] in FLAG_SIZES else "m"
        if "sale_color" in d:
            p.sale_color = color_ok(d["sale_color"], "red")
        if "new_color" in d:
            p.new_color = color_ok(d["new_color"], "green")
        if "backorder" in d:
            p.backorder = bool(d["backorder"])
        if "stock_per_option" in d:
            p.stock_per_option = bool(d["stock_per_option"])
        if "ordered" in d:
            p.ordered = max(0, int(f(d["ordered"], 0) or 0))
        if "ordered_eta" in d:
            p.ordered_eta = clean_text(d["ordered_eta"], 40, T("Verwacht"))
        if "stock_map" in d and isinstance(d["stock_map"], dict):
            m = {}
            for k_, v_ in d["stock_map"].items():
                if not isinstance(v_, dict) or not re.fullmatch(r"[a-z0-9-]*(\|[a-z0-9-]+)?", str(k_)):
                    continue
                m[str(k_)] = {"stock": max(0, int(f(v_.get("stock"), 0) or 0)), "ordered": max(0, int(f(v_.get("ordered"), 0) or 0))}
            p.stock_map = m
        if "stock" in d:
            if f(d["stock"]) is None:
                p.stock = None
            else:
                p.stock = int(d["stock"])
                if p.stock < 0:
                    raise ValueError(T("Voorraad kan niet negatief zijn."))
        if "vat_key" in d:
            key = str(d["vat_key"] or "")
            if key and key not in {x["key"] for x in shop.settings()["vat_tariffs"]}:
                raise ValueError(T("Onbekend btw-tarief."))
            p.vat_key = key
            if key:
                p.vat_rate = None  # the tariff counts, not an own percentage
        elif "vat_rate" in d:
            p.vat_rate = None if f(d["vat_rate"]) is None else dec(d["vat_rate"], T("Btw-percentage"), hi=Decimal(50))
        if "group" in d:
            p.group = Group.objects.filter(pk=d["group"]).first() if d["group"] else None
        if "active" in d:
            p.active = bool(d["active"])
        if before and before != (p.name, p.summary, p.description):
            p.i18n = {}  # the base text changed: the translations are out of date and are made again
        if "i18n" in d:  # texts per language typed by hand (the screen sends them only when they were changed)
            p.i18n = clean_i18n(d["i18n"], PRODUCT_I18N)
        if "img_cfg" in d:
            p.img_cfg = clean_img(d["img_cfg"])
        if "variants" in d:
            p.variants = clean_variants(d["variants"])
        if "tiers" in d:
            p.tiers = clean_tiers(d["tiers"])
        if "sizes" in d:
            p.sizes = clean_sizes(d["sizes"])
        for k_ in ("variant_label", "size_label"):
            if k_ in d:
                setattr(p, k_, clean_text(d[k_], 24, T("Naam van de keuze")))
        p.save()
        if isinstance(d.get("images"), list):
            p.images.all().delete()
            for n, im in enumerate(d["images"][:12]):
                if isinstance(im, dict) and media_id(im.get("media")):
                    Image.objects.create(product=p, media_id=im["media"], alt=str(im.get("alt", ""))[:200], order=n)

    def carrier_pk(v):
        if v in (None, ""):
            return None
        if not Carrier.objects.filter(pk=v).exists():
            raise ValueError(T("Onbekende transporteur."))
        return int(v)

    def apply_carrier(c, d):
        if "name" in d or not c.pk:
            c.name = clean_text(d.get("name"), 80, T("Naam"), True)
        if not c.slug:
            c.slug = unique_slug(Carrier, c.name)
        for k, n in CARRIER_TEXT:
            if k in d:
                setattr(c, k, clean_text(d[k], n, k))
        if "label_format" in d:
            if d["label_format"] not in ("a4", "a6", "10x15"):
                raise ValueError(T("Kies een labelformaat."))
            c.label_format = d["label_format"]
        for k in CARRIER_BOOL:
            if k in d:
                setattr(c, k, bool(d[k]))
        if "return_days" in d:
            c.return_days = min(365, max(0, int(f(d["return_days"], 0))))
        if "return_cost" in d:
            c.return_cost = dec(d["return_cost"] or 0, T("Retourkosten"))
        if "order" in d:
            c.order = max(0, int(f(d["order"], 0)))
        c.save()

    def apply_method(m, d):
        if "carrier" in d:
            m.carrier_id = carrier_pk(d["carrier"])
        if "name" in d or not m.pk:
            m.name = clean_text(d.get("name"), 100, T("Naam"), True)
        for k, n, w in (("description", 200, T("Omschrijving")), ("delivery_time", 60, T("Levertijd"))):
            if k in d:
                setattr(m, k, clean_text(d[k], n, w))
        if "price" in d or not m.pk:
            m.price = dec(d.get("price", 0), T("Prijs"))
        if "free_from" in d:
            m.free_from = dec(d["free_from"], T("Gratis vanaf"), null=True)
        if "countries" in d:
            codes = [str(c).strip().upper() for c in (d["countries"] if isinstance(d["countries"], list) else str(d["countries"]).split(",")) if str(c).strip()]
            if any(c not in COUNTRY_CODES for c in codes):
                raise ValueError(T("Onbekende landcode."))
            m.countries = codes
        if "active" in d:
            m.active = bool(d["active"])
        if "order" in d:
            m.order = max(0, int(f(d["order"], 0)))
        m.save()

    def apply_discount(x, d):
        if "code" in d or not x.pk:
            code = str(d.get("code") or "").strip().upper().replace(" ", "")[:40]
            if not code or not code.replace("-", "").replace("_", "").isalnum():
                raise ValueError(T("Alleen letters, cijfers, - en _."))
            if Discount.objects.filter(code=code).exclude(pk=x.pk).exists():
                raise ValueError(T("Deze code bestaat al."))
            x.code = code
        if "description" in d:
            x.description = clean_text(d["description"], 200, T("Omschrijving"))
        if "kind" in d:
            if d["kind"] not in ("percent", "fixed"):
                raise ValueError(T("Kies percentage of vast bedrag."))
            x.kind = d["kind"]
        if "value" in d or not x.pk:
            x.value = dec(d.get("value"), T("Waarde"), lo=Decimal("0.01"), hi=Decimal(100 if (d.get("kind") or x.kind) == "percent" else 100000))
        if "min_subtotal" in d:
            x.min_subtotal = dec(d["min_subtotal"] or 0, T("Minimaal bedrag"))
        if "max_uses" in d:
            x.max_uses = None if f(d["max_uses"]) is None else max(1, int(d["max_uses"]))
        for k in ("starts_at", "ends_at"):
            if k in d:
                setattr(x, k, d[k] or None)
        if "active" in d:
            x.active = bool(d["active"])
        x.save()

    def products_admin():
        return Product.objects.select_related("group").prefetch_related("images__media")

    def free_group(g):
        Product.objects.filter(group=g).update(group=None)
        Group.objects.filter(parent=g).update(parent=None)

    crud("groups", Group, g_out, apply_group, before_delete=free_group)
    crud("products", Product, p_out, apply_product, order=products_admin, before_delete=lambda p: Image.objects.filter(product=p).delete())
    crud("methods", Method, m_out, apply_method)
    crud("carriers", Carrier, c_out, apply_carrier)

    @system.route("GET", "admin/ship")
    def ship_get(request):
        cfg = ship_config()
        return {"choice": cfg.choice, "default_carrier": cfg.default_carrier_id}

    @system.route("POST", "admin/ship")
    def ship_set(request):
        if not lvl(request, 3):
            return bad(T("Je hebt hier geen rechten voor."), 403)
        d, cfg = body(request), ship_config()
        if "choice" in d:
            if d["choice"] not in ("customer", "fixed"):
                return bad(T("Kies of de klant de transporteur kiest of dat hij vaststaat."))
            cfg.choice = d["choice"]
        if "default_carrier" in d:
            try:
                cfg.default_carrier_id = carrier_pk(d["default_carrier"])
            except ValueError as e:
                return bad(str(e))
        cfg.save()
        return {"choice": cfg.choice, "default_carrier": cfg.default_carrier_id}

    @system.route("POST", "admin/carriers/examples")
    def carrier_examples(request):
        if not lvl(request, 3):
            return bad(T("Je hebt hier geen rechten voor."), 403)
        return {"created": make_example_carriers()}
    crud("discounts", Discount, d_out, apply_discount)
    crud("designs", Design, design_out, apply_design, after_delete=sync_objects)

    # ── vertalen: producten en groepen in alle actieve talen (met Claude, als die is gekoppeld) ──
    def translate_state(source=None):
        """(available, simulated, [(code, name)], source): Claude is linked (or the sandbox simulates it), and the languages that are on besides the language of the texts (the default language)."""
        from apps.core.models import Language
        from apps.integrations import ai
        from apps.sandbox import service as sandbox

        real = ai.available()
        sim = not real and sandbox.active("integrations")
        default = Language.objects.filter(is_default=True).values_list("code", flat=True).first() or "nl"
        source = source or default
        langs = [(l.code, l.name) for l in Language.objects.filter(enabled=True).order_by("order") if l.code != source]
        return real or sim, sim, langs, source

    def translate_one(kind, obj, langs, default, simulated, overwrite):
        """Fill obj.i18n for the languages that are still empty (all of them with overwrite). Returns the number of languages done."""
        from apps.core import themeimport
        from apps.integrations import ai

        fields = ("name", "summary", "description") if kind == "product" else ("name", "description")
        todo = [(c, n) for c, n in langs if overwrite or not (obj.i18n or {}).get(c)]
        src = {k: getattr(obj, k) for k in fields}
        if not todo or not any(src.values()):
            return 0
        got = dict(obj.i18n or {})
        for i in range(0, len(todo), 6):
            chunk = todo[i:i + 6]
            if simulated:
                out = {c: {k: (f"{v} [{c}]" if v else "") for k, v in src.items()} for c, _n in chunk}
            else:
                system_msg = ("You translate the texts of a product (or product group) of a webshop. Keep names short and natural, keep brand names and numbers, keep the HTML tags of the description as they are. "
                              "Answer with ONE JSON object only, no text around it: {\"translations\": {code: {" + ", ".join(f'\"{k}\": text' for k in fields) + "}}} with an entry for every requested language code.")
                prompt = json.dumps({"source_language": default, "texts": src, "languages": [{"code": c, "name": n} for c, n in chunk]}, ensure_ascii=False)
                try:
                    out = themeimport._parse_json(ai.claude(system_msg, prompt, max_tokens=4000, timeout=120), need=("translations",))["translations"]
                except (ValueError, KeyError) as e:
                    raise ValueError(T("Claude kon de teksten niet vertalen: {0}", str(e)))
            for c, _n in chunk:
                row = out.get(c) if isinstance(out, dict) else None
                if isinstance(row, dict):
                    clean = {k: (richtext.clean(str(row.get(k) or "")) if k == "description" and kind == "product" else str(row.get(k) or "").strip()) for k in fields}
                    limits = {"name": 200 if kind == "product" else 100, "summary": 300, "description": 20000 if kind == "product" else 500}
                    got[c] = {k: v[:limits[k]] for k, v in clean.items() if v}
        obj.i18n = got
        obj.save(update_fields=["i18n"])
        return len([c for c, _n in todo if got.get(c)])

    def translate_objects(kinds_objs, overwrite=False, source=None):
        ok, sim, langs, default = translate_state(source)
        if not ok:
            raise ValueError(T("Koppel Claude eerst bij Admin → API keys (Anthropic) en zet de koppeling aan."))
        if not langs:
            raise ValueError(T("Er zijn geen andere actieve talen dan de standaardtaal."))
        n = 0
        for kind, obj in kinds_objs:
            n += translate_one(kind, obj, langs, default, sim, overwrite)
        return {"translated": n, "languages": len(langs), "simulated": sim}

    @system.route("GET", "admin/translate")
    def translate_info(request):
        if not lvl(request, 2):
            return bad(T("Je hebt hier geen rechten voor."), 403)
        ok, sim, langs, _d = translate_state()
        return {"available": ok, "simulated": sim, "languages": [{"code": c, "name": n} for c, n in langs]}

    @system.route("POST", "admin/translate")
    def translate_run(request):
        """Translate products (ids, or all / the demo products) and their groups into every active language."""
        if not lvl(request, 2):
            return bad(T("Je hebt hier geen rechten voor."), 403)
        b = body(request)
        ids = [i for i in (b.get("ids") or []) if isinstance(i, int)][:200]
        if b.get("all"):
            prods = Product.objects.all()
        elif ids:
            prods = Product.objects.filter(pk__in=ids)
        elif b.get("demo"):
            prods = Product.objects.filter(demo=True)
        else:
            prods = Product.objects.none()
        demo = bool(b.get("demo"))
        groups = Group.objects.filter(pk__in={p.group_id for p in prods if p.group_id} | ({g.pk for g in Group.objects.filter(demo=True)} if demo and not ids else set()))
        try:
            # the demo texts are Dutch, whatever the default language of the site is: they are translated into every other active language (the default one included)
            return translate_objects([("group", g) for g in groups] + [("product", p) for p in prods], overwrite=bool(b.get("overwrite")), source="nl" if demo else None)
        except ValueError as e:
            return bad(str(e))

    # ── demo-inhoud ───────────────────────────────────────────────────────────
    def demo_module():
        import importlib.util

        spec = importlib.util.spec_from_file_location("webshop_demo", system.dir / "demo.py")
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)  # (read again every time: a changed demo.py is used at once)
        return mod

    def demo_ctx():
        from types import SimpleNamespace

        return SimpleNamespace(Carrier=Carrier, make_example_carriers=make_example_carriers, Group=Group, Product=Product, Image=Image, Method=Method, Discount=Discount, Design=Design, MediaItem=MediaItem, unique_slug=unique_slug, slugify=slugify, design_data=design_data, sync_objects=sync_objects,
                               User=system.User, orders=commerce.orders, create_order=lambda data, items, method, code, user: Catalog().create_order(data, items, method, code, user))

    @system.route("GET", "admin/demo")
    def demo_list(request):
        if not request.user.is_staff:  # demo content: superadmins only
            return bad(T("Alleen superadmins maken demo-inhoud."), 403)
        return {"sets": demo_module().sets(), "demo_products": Product.objects.filter(demo=True).count(), "products": Product.objects.count(), "counts": demo_module().counts(demo_ctx())}

    @system.route("POST", "admin/demo")
    def demo_make(request):
        if not request.user.is_staff:  # demo content: superadmins only
            return bad(T("Alleen superadmins maken demo-inhoud."), 403)
        b = body(request)
        mod = demo_module()
        if b.get("set") not in mod.SETS:
            return bad(T("Kies een van de voorbeelden."))
        try:
            with transaction.atomic():
                made = mod.build(demo_ctx(), b["set"], replace=bool(b.get("replace")), use_media=bool(b.get("use_media")))
        except Exception as e:  # noqa: BLE001
            system.log.exception("Demo-inhoud maken mislukt")
            return bad(T("De demo-inhoud kon niet worden gemaakt: {0}", str(e)[:200]), 500)
        return Response(made, status=201)

    @system.route("POST", "admin/demo/remove")
    def demo_remove(request):
        """Remove what the superadmin chose: products and groups, pictures, system objects, orders, fake users."""
        if not request.user.is_staff:  # demo content: superadmins only
            return bad(T("Alleen superadmins maken demo-inhoud."), 403)
        mod = demo_module()
        what = [x for x in (body(request).get("what") or []) if x in mod.PARTS]
        if not what:
            return bad(T("Kies wat je wilt verwijderen."))
        with transaction.atomic():
            done = mod.remove(demo_ctx(), what)
        return {"removed": done, "counts": mod.counts(demo_ctx())}

    def parts():
        """Blocks for pages (system objects): the product overview in every design that is on."""
        return [{"key": f"producten-{x.slug}"[:60], "title": T("Productenoverzicht: {0}", x.name), "file": "web/products.html", "query": {"design": x.slug}} for x in Design.objects.filter(active=True)]

    system.provide("parts", parts)

    @system.route("GET", "admin/settings")
    def settings_admin(request):
        s = shop.settings()
        return {"vat_tariffs": s["vat_tariffs"], "default_tariff": s["default_tariff"], "vat_rates": s["vat_rates"], "default_vat": s["default_vat"], "prices_include_vat": s["prices_include_vat"], "img_default": img_default(), "page_cfg": page_cfg(), "level": min(3, max(0, level(request.user, "orders")))}

    # ── what the system may ask the plugin ────────────────────────────────────
    class Catalog:
        def products_detail(self):
            """For an order made by hand (Orders -> New order): the products with their variants and prices."""
            return [{"id": p.id, "name": p.name, "sku": p.sku, "price": str(p.price), "stock": total_stock(p),
                     "variants": [{"key": v["key"], "label": v["label"], "price": v.get("price")} for v in (p.variants or [])],
                     "sizes": [{"key": x["key"], "label": x["label"]} for x in (p.sizes or [])]} for p in Product.objects.filter(active=True)]

        def methods(self):
            return [{"id": m.id, "name": m.name, "price": str(m.price)} for m in Method.objects.filter(active=True)]

        def create_order(self, data, items, method_id=None, code="", user=None):
            """One order for the given customer and items (prices, VAT, stock and discount as in the shop). Raises ValueError with a message for the screen."""
            try:
                return make_order(data, items, method_id, code, user, check=False)
            except OrderError as e:
                raise ValueError(str(e))

        def carriers(self):
            return [{"slug": c.slug, "name": c.name} for c in Carrier.objects.filter(active=True).order_by("order", "name")]

        def carrier_of_method(self, name):
            m = Method.objects.filter(name=name).select_related("carrier").first()
            return {"slug": m.carrier.slug, "name": m.carrier.name} if m and m.carrier else None

        def products(self):
            return [{"id": p.id, "name": p.name} for p in Product.objects.filter(active=True)]

        def product(self, pk):
            p = Product.objects.filter(pk=pk).first() if str(pk).isdigit() else None
            return {"id": p.id, "name": p.name} if p else None

        def low_stock(self):
            rows = [(total_stock(p), p) for p in Product.objects.filter(active=True)]
            return [{"id": p.id, "name": p.name, "stock": n} for n, p in sorted((x for x in rows if x[0] is not None and x[0] <= 5), key=lambda x: x[0])[:8]]

        def sitemap(self):
            return [(f"/producten/{slug}", name) for slug, name in Product.objects.filter(active=True).values_list("slug", "name")]

        def restock(self, order):
            """A cancelled order: the stock and the use of the discount code go back."""
            for it in order.items.all():
                if not it.product:
                    continue
                p = Product.objects.filter(pk=it.product).first()
                if not p:
                    continue
                if per_option(p) and getattr(it, "option", ""):
                    m = dict(p.stock_map or {})
                    row = dict(m.get(it.option) or {})
                    row["stock"] = int(row.get("stock") or 0) + it.quantity
                    m[it.option] = row
                    Product.objects.filter(pk=p.pk).update(stock_map=m)
                elif p.stock is not None:
                    Product.objects.filter(pk=p.pk).update(stock=F("stock") + it.quantity)
            if order.discount_code:
                Discount.objects.filter(code=order.discount_code, used_count__gt=0).update(used_count=F("used_count") - 1)

    system.provide("catalog", Catalog())

    class ShopDemo:
        """For Super admin -> Demo-gegevens: all four example sets (clothing, furniture, grocery, standard) with groups, products, pictures, designs, shipping and orders."""
        def counts(self):
            c = demo_module().counts(demo_ctx())
            return {"products": c["products"], "designs": c["designs"], "orders": c["orders"], "users": c["users"]}

        def _built(self, key):
            """Is this example shop already there? (its first product)"""
            names = [x[0] for x in demo_module().SETS[key]["products"]][:2]
            return Product.objects.filter(demo=True, name__in=names).exists()

        def create(self, objects=True, orders=True, use_media=False, sets=None):
            """sets: which example shops (clothing, furniture, grocery, standard); None = all four. A shop that is already there is not made twice."""
            mod, ctx, made = demo_module(), demo_ctx(), {}
            first = not Design.objects.filter(demo=True).exists()
            for key in [k for k in mod.SETS if sets is None or k in sets]:
                if self._built(key):
                    continue
                with transaction.atomic():
                    r = mod.build(ctx, key, replace=False, use_media=use_media, designs=objects and first, orders=False)  # (the orders follow once, over all the example shops)
                first = False
                for k, v in r.items():
                    made[k] = made.get(k, 0) + (v if isinstance(v, int) else 0)
            if orders and commerce.orders():
                for k, v in mod.make_orders(ctx).items():
                    made[k] = made.get(k, 0) + v
            made["images_linked"] = self.repair()
            return made

        def repair(self):
            """Give the demo products and groups the pictures they miss (the pictures of the media demo when they are there, else drawn ones). Returns the number of products fixed."""
            import io as _io

            from django.core.files.base import ContentFile
            from django.core.files.storage import default_storage

            from apps.medialib import areas

            mod = demo_module()
            pool = list(MediaItem.objects.filter(source="media-demo", kind="image").exclude(name__startswith="Hero ").order_by("id"))
            drawn = []

            def pick(i, label, rgb):
                if pool:
                    return pool[i % len(pool)]
                key = default_storage.save(areas.site_path("library", f"shop-demo/{slugify(label)[:60]}-{i}.png"), ContentFile(mod.png(label, "", rgb, i % 3)))
                item = MediaItem.objects.get(key=key)
                item.name, item.source, item.tags = f"{label}.png"[:255], "shop-demo", ["demo", "webshop", "product"]
                item.save(update_fields=["name", "source", "tags"])
                drawn.append(item.id)
                return item

            fixed = 0
            for i, p in enumerate(Product.objects.filter(demo=True).prefetch_related("images")):
                if any(im.media_id and MediaItem.objects.filter(pk=im.media_id).exists() for im in p.images.all()):
                    continue
                p.images.all().delete()
                rgb = mod.PALETTE[i % len(mod.PALETTE)]
                for n in range(3):
                    Image.objects.create(product=p, media=pick(i * 3 + n, f"{p.name} {n + 1}", rgb), alt=p.name, order=n)
                fixed += 1
            for i, g in enumerate(Group.objects.filter(demo=True, parent__isnull=True, media__isnull=True)):
                g.media = pick(i, f"Groep {g.name}", mod.PALETTE[i % len(mod.PALETTE)])
                g.save(update_fields=["media"])
            return fixed

        def remove(self):
            with transaction.atomic():
                return demo_module().remove(demo_ctx())

    system.provide("demo", ShopDemo())


def ensure_columns(conn, wanted):
    """Add the columns a newer version of the plugin needs to tables that already exist (the plugin keeps its data when it is updated).
    Plain ALTER TABLE ... ADD COLUMN: adding a field the usual way makes SQLite rebuild the table, and a column that is not there yet is then filled with its own name."""
    for model, names in wanted:
        for n in names:
            have = {c.name for c in conn.introspection.get_table_description(conn.cursor(), model._meta.db_table)}
            f = model._meta.get_field(n)
            if f.column in have:
                continue
            with conn.schema_editor() as se:
                sql, params = se.column_sql(model, f, include_default=True)
                se.execute("ALTER TABLE %s ADD COLUMN %s %s" % (se.quote_name(model._meta.db_table), se.quote_name(f.column), sql), params)


def _import_legacy(conn, system, by_name):
    """First start on a system that had the webshop built in: copy the rows (same numbers) from the old tables into the tables of the plugin."""
    existing = set(conn.introspection.table_names())
    if any(by_name[n].objects.exists() for n in by_name):
        return
    todo = [(old, new) for old, new in LEGACY if old in existing]
    if not todo:
        return
    qn = conn.ops.quote_name
    with transaction.atomic(), conn.cursor() as cur:
        for old, new in todo:  # the order matters: groups and products before the things that point at them
            m = by_name[new]
            have = {c.name for c in conn.introspection.get_table_description(cur, old)}
            cols = [fld.column for fld in m._meta.concrete_fields if fld.column in have]
            if not cols:
                continue
            c = ", ".join(qn(x) for x in cols)
            cur.execute(f"INSERT INTO {qn(m._meta.db_table)} ({c}) SELECT {c} FROM {qn(old)}")  # noqa: S608
        for sql in conn.ops.sequence_reset_sql(__import__("django.core.management.color", fromlist=["no_style"]).no_style(), list(by_name.values())):
            cur.execute(sql)
    system.log.info("Webshop: gegevens van de ingebouwde webshop overgenomen.")
