"""Agenda (plugin). Afspraken van gebruikers en groepen, afspraken tussen leden, en evenementen van de beheerders.
De gegevens staan in de database van het systeem (tabellen plg_agenda_*). Gebruikers, groepen en blokkades komen van het systeem; meldingen gaan via de module Notificaties.
Teksten staan in T("…") zodat het systeem ze in alle talen kan leveren.

Routes: /api/plugins/run/agenda/<pad>  (zie onderaan `register`); de pagina's staan in web/."""
import calendar as cal
import logging
import re
from datetime import date, datetime, timedelta, timezone as dt_tz

from django.db import models
from django.db.models import Q
from django.http import HttpResponse
from django.utils import timezone
from django.utils.dateparse import parse_date, parse_datetime
from rest_framework.response import Response

logger = logging.getLogger(__name__)
KINDS = ("personal", "appointment", "group", "public")  # eigen · met een ander lid · voor een groep · evenement van de beheerder (voor alle leden)
RECUR = ("", "daily", "weekly", "monthly", "yearly")
COLORS = ("blue", "orange", "green", "pink", "purple", "teal", "red", "gray")
RSVP = ("invited", "accepted", "declined", "maybe", "proposed")
MAX_OCC = 400


def register(system):
    from apps.accounts.access import level
    from apps.plugins.facade import community as social  # (the plugin Community; without it: no profiles, nobody hidden)

    T = system.t
    U, label = system.User, system.app_label
    bad = lambda msg, code=400: Response({"detail": msg}, status=code)  # noqa: E731

    def table(name):
        return type("Meta", (), {"app_label": label, "db_table": system.db_prefix + name})

    class Event(models.Model):
        owner = models.ForeignKey(U, null=True, blank=True, on_delete=models.SET_NULL, related_name="+")
        title = models.CharField(max_length=160)
        description = models.TextField(blank=True)
        location = models.CharField(max_length=160, blank=True)
        starts_at = models.DateTimeField()
        ends_at = models.DateTimeField(null=True, blank=True)
        all_day = models.BooleanField(default=False)  # a day without a time: the date is the UTC date of starts_at
        kind = models.CharField(max_length=12, default="personal")
        group_id = models.PositiveIntegerField(null=True, blank=True)  # a user group of the system
        calendar = models.CharField(max_length=60, blank=True)  # a named agenda of the beheerders (events of one group on a page)
        color = models.CharField(max_length=8, default="blue")
        capacity = models.PositiveIntegerField(null=True, blank=True)
        open_signup = models.BooleanField(default=False)  # members may sign up themselves (public events)
        on_site = models.BooleanField(default=False)  # also visible to visitors in a block on a page
        system_object = models.BooleanField(default=False)  # may be put on a page as a system object
        recurrence = models.CharField(max_length=8, blank=True)
        until = models.DateField(null=True, blank=True)
        source = models.CharField(max_length=40, blank=True)  # where it came from: "marketplace:12"
        status = models.CharField(max_length=10, default="active")  # active | cancelled
        created_at = models.DateTimeField(auto_now_add=True)
        updated_at = models.DateTimeField(auto_now=True)
        Meta = table("event")

    class Attendee(models.Model):
        event = models.ForeignKey(Event, on_delete=models.CASCADE, related_name="attendees")
        user = models.ForeignKey(U, on_delete=models.CASCADE, related_name="+")
        status = models.CharField(max_length=10, default="invited")
        host = models.BooleanField(default=False)
        note = models.CharField(max_length=300, blank=True)
        proposed_at = models.DateTimeField(null=True, blank=True)  # "another moment" suggested by this person
        reminded = models.BooleanField(default=False)
        created_at = models.DateTimeField(auto_now_add=True)
        Meta = table("attendee")

    system.sync_models(Event, Attendee)
    cfg = system.config

    # ── helpers ──
    def is_admin(u):
        return bool(u.is_staff or level(u, "plugins") >= 2)

    def name(uid):
        u = U.objects.filter(pk=uid).first()
        return social.display_name(u) if u else "?"

    def my_groups(u):
        return set(u.user_groups.values_list("id", flat=True))

    def group_name(gid):
        from apps.accounts.models import UserGroup

        g = UserGroup.objects.filter(pk=gid).first()
        return g.name if g else ""

    def dt(v, all_day=False):
        """ISO text -> aware datetime. A day without a time is stored at 12:00 UTC so every time zone shows the same date."""
        if v in (None, ""):
            return None
        s = str(v)
        if all_day:
            d = parse_date(s[:10])
            if not d:
                raise ValueError(T("Geef een geldige datum."))
            return datetime(d.year, d.month, d.day, 12, 0, tzinfo=dt_tz.utc)
        d = parse_datetime(s)
        if not d:
            raise ValueError(T("Geef een geldige datum en tijd."))
        return d if timezone.is_aware(d) else timezone.make_aware(d)

    def visible_q(u):
        """The events this person may see."""
        q = Q(owner=u) | Q(pk__in=Attendee.objects.filter(user=u).values("event_id")) | Q(kind="public")  # (no reverse lookups: plugin models are not in the app registry)
        gs = my_groups(u)
        if gs and cfg.get("group_events", True) is not False:
            q |= Q(kind="group", group_id__in=gs)
        return Q(status__in=("active", "cancelled")) & q

    def add_months(d, n):
        m = d.month - 1 + n
        y, m = d.year + m // 12, m % 12 + 1
        return d.replace(year=y, month=m, day=min(d.day, cal.monthrange(y, m)[1]))

    def occurrences(e, start, end):
        """The moments (start, end) of an event within [start, end): one, or the repeats."""
        length = (e.ends_at - e.starts_at) if e.ends_at else timedelta(0)
        if not e.recurrence:
            if e.starts_at < end and (e.ends_at or e.starts_at) >= start:
                yield e.starts_at, e.ends_at
            return
        cur, n = e.starts_at, 0
        limit = datetime.combine(e.until, datetime.max.time(), tzinfo=dt_tz.utc) if e.until else None
        while n < MAX_OCC and cur < end and (limit is None or cur <= limit):
            if cur + length >= start:
                yield cur, (cur + length if e.ends_at else None)
            n += 1
            if e.recurrence == "daily":
                cur = e.starts_at + timedelta(days=n)
            elif e.recurrence == "weekly":
                cur = e.starts_at + timedelta(weeks=n)
            elif e.recurrence == "monthly":
                cur = add_months(e.starts_at, n)
            else:
                cur = add_months(e.starts_at, 12 * n)

    def mine(e, u):
        return next((a for a in e.attendees.all() if a.user_id == u.id), None)

    def can_edit(e, u):
        return is_admin(u) or e.owner_id == u.id

    def out(e, u, when=None, full=False):
        a = mine(e, u)
        going = sum(1 for x in e.attendees.all() if x.status == "accepted")
        d = {"id": e.id, "title": e.title, "location": e.location, "starts_at": (when or (e.starts_at, e.ends_at))[0], "ends_at": (when or (e.starts_at, e.ends_at))[1], "all_day": e.all_day,
             "kind": e.kind, "color": e.color, "calendar": e.calendar, "status": e.status, "recurrence": e.recurrence, "my_status": a.status if a else ("owner" if e.owner_id == u.id else ""),
             "host": e.owner_id == u.id, "can_edit": can_edit(e, u), "going": going, "capacity": e.capacity, "open_signup": e.open_signup, "group": ({"id": e.group_id, "name": group_name(e.group_id)} if e.group_id else None),
             "owner": ({"id": e.owner_id, "name": name(e.owner_id)} if e.owner_id else None), "source": e.source}
        if full:
            d.update(description=e.description, until=e.until, on_site=e.on_site, system_object=e.system_object, first_start=e.starts_at, first_end=e.ends_at,
                     attendees=[{"id": x.user_id, "name": name(x.user_id), "status": x.status, "host": x.host, "note": x.note, "proposed_at": x.proposed_at} for x in e.attendees.all()])
        return d

    def notify(user, title, body="", url="/dashboard/plugins/agenda"):
        try:
            from apps.notifications.service import notify as _notify

            return _notify(user, "agenda", title, body, url=url)
        except Exception:  # noqa: BLE001  (notifications are optional)
            return None

    def fmt(e):
        d = timezone.localtime(e.starts_at)
        return d.strftime("%d-%m-%Y") if e.all_day else d.strftime("%d-%m-%Y %H:%M")

    def sync_objects():
        try:
            from apps.sysobjects import service as so

            so.sync()
        except Exception:  # noqa: BLE001
            pass

    def parts():
        """Parts for pages (system objects): every admin event that ticked 'systeemobject', and one block per named agenda."""
        out_ = []
        for e in Event.objects.filter(system_object=True, status="active", kind="public"):
            out_.append({"key": f"event-{e.id}", "title": T("Evenement: {0}", e.title), "file": "web/upcoming.html", "query": {"event": e.id}})
        for c in sorted(set(Event.objects.filter(system_object=True, status="active", kind="public").exclude(calendar="").values_list("calendar", flat=True))):
            slug = re.sub(r"[^a-z0-9]+", "-", c.lower()).strip("-")[:40] or "agenda"
            out_.append({"key": f"cal-{slug}", "title": T("Agenda: {0}", c), "file": "web/upcoming.html", "query": {"calendar": c}})
        return out_

    system.provide("parts", parts)

    def findable(me):
        """The members this person may find and invite: the same rules as the member search of the community (Zoeken & matchen): a public profile that wants to be found,
        visible to this person, nobody who blocked or is hidden, and the person has to take part himself when the community asks for it. Returns (queryset of profiles or None, locked)."""
        from apps.plugins import facade

        disc = facade.mod("community", "discover")
        if disc is None:  # without the plugin Community nobody can be found
            return None, True
        if social.get()["discover"]["require_to_search"] and not disc._my_profile(me):  # noqa: SLF001
            return None, True
        return disc._base(me), False  # noqa: SLF001

    def can_find(me, uid):
        qs, locked = findable(me)
        if qs is None:
            return False
        p = qs.filter(user_id=uid).first()
        return bool(p and social.can_view(me, p, None))

    def drop(e):
        """Delete an event with its attendees (the plugin's models are not in the app registry: a delete does not cascade by itself)."""
        Attendee.objects.filter(event=e).delete()
        e.delete()

    def set_attendees(e, ids, host_id=None):
        """Invite people (never twice, and only members the host may find in the community search)."""
        hidden = social.hidden_ids(e.owner) if e.owner else set()
        added = []
        for uid in ids:
            if not str(uid).isdigit() or int(uid) == e.owner_id or int(uid) in hidden:
                continue
            if e.owner and not can_find(e.owner, int(uid)):
                continue
            u = U.objects.filter(pk=int(uid), is_active=True).first()
            if not u or e.attendees.filter(user=u).exists():
                continue
            Attendee.objects.create(event=e, user=u, status="invited")
            added.append(u)
        return added

    def fill(e, data, me, creating):
        """Copy the fields of a request into an event (with the rules); raises ValueError with a message."""
        d = data
        if "title" in d or creating:
            e.title = str(d.get("title") or "").strip()[:160]
            if not e.title:
                raise ValueError(T("Geef de afspraak een titel."))
        for f, n in (("description", 4000), ("location", 160)):
            if f in d:
                setattr(e, f, str(d.get(f) or "").strip()[:n])
        if "all_day" in d:
            e.all_day = bool(d["all_day"])
        if "starts_at" in d or creating:
            e.starts_at = dt(d.get("starts_at"), e.all_day)
            if not e.starts_at:
                raise ValueError(T("Geef een begintijd op."))
        if "ends_at" in d:
            e.ends_at = dt(d.get("ends_at"), e.all_day)
        if e.ends_at and e.ends_at < e.starts_at:
            raise ValueError(T("Het einde ligt voor het begin."))
        if d.get("color") in COLORS:
            e.color = d["color"]
        if "recurrence" in d:
            e.recurrence = d["recurrence"] if d["recurrence"] in RECUR else ""
        if "until" in d:
            e.until = parse_date(str(d["until"])[:10]) if d.get("until") else None
        kind = d.get("kind", e.kind if not creating else "personal")
        if kind not in KINDS:
            raise ValueError(T("Onbekende soort afspraak."))
        admin = is_admin(me)
        if kind == "public" and not admin:
            raise ValueError(T("Alleen beheerders maken evenementen voor alle leden."))
        if kind == "personal" and creating and cfg.get("members_create", True) is False and not admin:
            raise ValueError(T("Je mag zelf geen afspraken maken."))
        if kind == "appointment" and cfg.get("appointments", True) is False:
            raise ValueError(T("Afspraken met andere leden staan uit."))
        e.kind = kind
        if kind == "group":
            gid = int(d.get("group_id") or e.group_id or 0)
            if not gid or (gid not in my_groups(me) and not admin) or cfg.get("group_events", True) is False and not admin:
                raise ValueError(T("Kies een groep waar je lid van bent."))
            e.group_id = gid
        else:
            e.group_id = None
        if kind == "public":
            e.calendar = str(d.get("calendar") or "").strip()[:60]
            for f in ("open_signup", "on_site", "system_object"):
                if f in d:
                    setattr(e, f, bool(d[f]))
            if "capacity" in d:
                e.capacity = max(1, int(d["capacity"])) if str(d.get("capacity") or "").isdigit() else None
        return e

    # ── routes ──
    @system.route("GET", "config")
    def config(request):
        me = request.user
        try:
            theme = social.get()["profiles"]["theme"]
        except Exception:  # noqa: BLE001
            theme = "normal"
        from apps.accounts.models import UserGroup

        groups = UserGroup.objects.all() if is_admin(me) else UserGroup.objects.filter(members=me)
        return {"theme": theme, "week_start": 0 if cfg.get("week_start") == "zondag" else 1, "default_view": {"week": "week", "dag": "day", "lijst": "list"}.get(cfg.get("default_view"), "month"),
                "members_create": cfg.get("members_create", True) is not False, "group_events": cfg.get("group_events", True) is not False, "appointments": cfg.get("appointments", True) is not False,
                "admin": is_admin(me), "me": {"id": me.id, "name": social.display_name(me)}, "groups": [{"id": g.id, "name": g.name} for g in groups], "colors": COLORS}

    @system.route("GET", "settings")
    def get_settings(request):
        """The person's own choice: an e-mail about invitations (the same switch as Meldingen → Instellingen → Agenda)."""
        try:
            from apps.notifications import service as ns

            p = ns.prefs_of(request.user).get("agenda") or {}
            return {"email_invites": bool(p.get("email")), "email_possible": bool(ns.get_settings().get("email"))}
        except Exception:  # noqa: BLE001
            return {"email_invites": False, "email_possible": False}

    @system.route("PUT", "settings")
    def put_settings(request):
        try:
            from apps.notifications.models import NotificationPref

            NotificationPref.objects.update_or_create(user=request.user, kind="agenda", defaults={"show": True, "email": bool(request.data.get("email_invites"))})
        except Exception:  # noqa: BLE001
            return bad(T("Instellen is niet gelukt."))
        return get_settings(request)

    @system.route("GET", "person/<id>")
    def person(request, id):
        u = U.objects.filter(pk=id, is_active=True).exclude(pk=request.user.pk).first() if str(id).isdigit() else None
        if not u or u.pk in social.hidden_ids(request.user) or not can_find(request.user, u.pk):
            return bad(T("Dit lid kun je niet uitnodigen."), 404)
        return {"id": u.id, "name": social.display_name(u)}

    @system.route("GET", "people")
    def people(request):
        """Search members to invite: only those the community search would show this person."""
        me, q = request.user, str(request.query_params.get("q") or "").strip()
        if len(q) < 2:
            return {"items": [], "locked": False}
        qs, locked = findable(me)
        if qs is None:
            return {"items": [], "locked": True}
        qs = qs.filter(Q(user__display_name__icontains=q) | Q(user__first_name__icontains=q) | Q(user__last_name__icontains=q) | Q(headline__icontains=q))[:60]
        out_ = [p.user for p in qs if social.can_view(me, p, None)][:12]
        return {"items": [{"id": u.id, "name": social.display_name(u)} for u in out_], "locked": False}

    def remind(me):
        """Reminders are sent when the person looks at the agenda (there is no timer): once per event and person."""
        mins = int(cfg.get("reminder_minutes") or 0)
        if mins <= 0:
            return
        now = timezone.now()
        for a in Attendee.objects.filter(user=me, reminded=False, status__in=("accepted", "maybe", "invited"), event__status="active", event__starts_at__gt=now, event__starts_at__lte=now + timedelta(minutes=mins)).select_related("event"):
            notify(me, T("Herinnering: {0}", a.event.title), T("Om {0}", fmt(a.event)))
            a.reminded = True
            a.save(update_fields=["reminded"])

    @system.route("GET", "events")
    def events(request):
        me, q = request.user, request.query_params
        try:
            start, end = dt(q.get("from")) or timezone.now() - timedelta(days=31), dt(q.get("to")) or timezone.now() + timedelta(days=62)
        except ValueError as e:
            return bad(str(e))
        if end - start > timedelta(days=400):
            end = start + timedelta(days=400)
        rows = []
        qs = Event.objects.filter(visible_q(me)).filter(Q(recurrence="") & Q(starts_at__lt=end) & (Q(ends_at__gte=start) | Q(ends_at__isnull=True, starts_at__gte=start)) | ~Q(recurrence="") & Q(starts_at__lt=end)).distinct().prefetch_related("attendees")
        for e in qs:
            for when in occurrences(e, start, end):
                rows.append(out(e, me, when))
        rows.sort(key=lambda r: r["starts_at"])
        return rows[:1500]

    @system.route("GET", "upcoming")
    def upcoming(request):
        me, q = request.user, request.query_params
        remind(me)
        now = timezone.now()
        try:
            limit = max(1, min(30, int(q.get("limit") or 6)))
        except ValueError:
            limit = 6
        rows = []
        for e in Event.objects.filter(visible_q(me), status="active").distinct().prefetch_related("attendees"):
            if q.get("calendar") and e.calendar != q["calendar"]:
                continue
            for when in occurrences(e, now - timedelta(hours=1), now + timedelta(days=120)):
                r = out(e, me, when)
                if r["my_status"] != "declined":
                    rows.append(r)
                break
        rows.sort(key=lambda r: r["starts_at"])
        inv = Attendee.objects.filter(user=me, status="invited", event__status="active", event__starts_at__gte=now).select_related("event").order_by("event__starts_at")
        invites = [{"id": a.event_id, "title": a.event.title, "starts_at": a.event.starts_at, "all_day": a.event.all_day, "color": a.event.color, "location": a.event.location,
                    "from": name(a.event.owner_id) if a.event.owner_id else ""} for a in inv[:5]]
        return {"items": rows[:limit], "pending": inv.count(), "invites": invites, "today": sum(1 for r in rows if timezone.localtime(r["starts_at"]).date() == timezone.localdate())}

    @system.route("GET", "public", public=True)
    def public(request):
        """For the blocks on pages (also for visitors): events the beheerders marked for the website."""
        q = request.query_params
        now = timezone.now()
        qs = Event.objects.filter(kind="public", status="active", on_site=True).prefetch_related("attendees")
        if q.get("calendar"):
            qs = qs.filter(calendar=q["calendar"])
        if str(q.get("event") or "").isdigit():
            qs = Event.objects.filter(pk=int(q["event"]), kind="public", status="active", system_object=True).prefetch_related("attendees")
        rows = []
        for e in qs:
            for s, en in occurrences(e, now - timedelta(hours=3), now + timedelta(days=365)):
                rows.append({"id": e.id, "title": e.title, "description": e.description, "location": e.location, "starts_at": s, "ends_at": en, "all_day": e.all_day, "color": e.color,
                             "calendar": e.calendar, "going": sum(1 for a in e.attendees.all() if a.status == "accepted"), "capacity": e.capacity, "open_signup": e.open_signup})
                break
        rows.sort(key=lambda r: r["starts_at"])
        try:
            theme = social.get()["profiles"]["theme"]
        except Exception:  # noqa: BLE001
            theme = "normal"
        return {"items": rows[:30], "theme": theme}

    @system.route("POST", "events")
    def create(request):
        me, d = request.user, request.data
        e = Event(owner=me)
        try:
            fill(e, d, me, True)
        except (ValueError, TypeError) as err:
            return bad(str(err))
        e.save()
        Attendee.objects.create(event=e, user=me, status="accepted", host=True)
        invited = set_attendees(e, d.get("invite") or [])
        if e.kind == "appointment" and not invited:
            drop(e)
            return bad(T("Kies met wie je een afspraak wilt maken. Je kunt alleen leden uitnodigen die gevonden willen worden."))
        for u in invited:
            notify(u, T("{0} nodigt je uit: {1}", social.display_name(me), e.title), T("Op {0}", fmt(e)))
        system.emit("agenda_event_created", agenda_event={"id": e.id, "title": e.title, "kind": e.kind}, user=me)
        if e.system_object:
            sync_objects()
        e = Event.objects.prefetch_related("attendees").get(pk=e.pk)
        return Response(out(e, me, None, True), status=201)

    def get_event(id, me):
        e = Event.objects.prefetch_related("attendees").filter(pk=id).first() if str(id).isdigit() else None
        if not e or not Event.objects.filter(visible_q(me), pk=e.pk).exists():
            return None
        return e

    @system.route("GET", "events/<id>")
    def one(request, id):
        e = get_event(id, request.user)
        return Response(out(e, request.user, None, True)) if e else bad(T("Deze afspraak bestaat niet of is niet zichtbaar."), 404)

    @system.route("PATCH", "events/<id>")
    def update(request, id):
        me = request.user
        e = get_event(id, me)
        if not e:
            return bad(T("Deze afspraak bestaat niet of is niet zichtbaar."), 404)
        if not can_edit(e, me):
            return bad(T("Alleen de maker kan dit wijzigen."), 403)
        before = (e.starts_at, e.location, e.status)
        try:
            fill(e, request.data, me, False)
            if request.data.get("status") in ("active", "cancelled"):
                e.status = request.data["status"]
        except (ValueError, TypeError) as err:
            return bad(str(err))
        e.save()
        if "invite" in request.data:
            for u in set_attendees(e, request.data.get("invite") or []):
                notify(u, T("{0} nodigt je uit: {1}", social.display_name(me), e.title), T("Op {0}", fmt(e)))
        if (e.starts_at, e.location, e.status) != before:
            for a in e.attendees.exclude(user=me):
                notify(a.user, (T("Afgelast: {0}", e.title) if e.status == "cancelled" else T("Gewijzigd: {0}", e.title)), T("Op {0}", fmt(e)))
                if e.starts_at != before[0]:
                    a.reminded = False
                    a.save(update_fields=["reminded"])
        sync_objects()
        e = Event.objects.prefetch_related("attendees").get(pk=e.pk)
        return out(e, me, None, True)

    @system.route("DELETE", "events/<id>")
    def delete(request, id):
        me = request.user
        e = get_event(id, me)
        if not e:
            return bad(T("Deze afspraak bestaat niet of is niet zichtbaar."), 404)
        if not can_edit(e, me):
            return bad(T("Alleen de maker kan dit verwijderen."), 403)
        for a in e.attendees.exclude(user=me):
            notify(a.user, T("Afgelast: {0}", e.title), T("Op {0}", fmt(e)))
        drop(e)
        sync_objects()
        return Response(status=204)

    @system.route("POST", "events/<id>/respond")
    def respond(request, id):
        """{status: accepted|declined|maybe, proposed_at?, note?}: an invited person answers; with proposed_at he suggests another moment."""
        me, d = request.user, request.data
        e = get_event(id, me)
        if not e or e.status != "active":
            return bad(T("Deze afspraak bestaat niet of is niet zichtbaar."), 404)
        status = d.get("status")
        if status not in ("accepted", "declined", "maybe", "proposed"):
            return bad(T("Onbekend antwoord."))
        a = mine(e, me)
        if not a:
            if e.kind == "public" and e.open_signup and status in ("accepted", "maybe"):
                taken = e.attendees.filter(status="accepted").count()
                if e.capacity and status == "accepted" and taken >= e.capacity:
                    return bad(T("Het is vol."))
                a = Attendee.objects.create(event=e, user=me, status=status)
            else:
                return bad(T("Je bent hiervoor niet uitgenodigd."), 403)
        if status == "accepted" and e.capacity and a.status != "accepted" and e.attendees.filter(status="accepted").count() >= e.capacity:
            return bad(T("Het is vol."))
        a.status, a.note = status, str(d.get("note") or "")[:300]
        a.proposed_at = dt(d.get("proposed_at")) if status == "proposed" and d.get("proposed_at") else None
        a.save()
        if e.owner_id and e.owner_id != me.id:
            who = social.display_name(me)
            titles = {"accepted": T("{0} komt naar: {1}", who, e.title), "declined": T("{0} kan niet: {1}", who, e.title), "maybe": T("{0} komt misschien: {1}", who, e.title),
                      "proposed": T("{0} stelt een ander moment voor: {1}", who, e.title)}
            notify(e.owner, titles[status], (T("Voorstel: {0}", timezone.localtime(a.proposed_at).strftime("%d-%m-%Y %H:%M")) if a.proposed_at else a.note))
        system.emit("agenda_event_responded", agenda_event={"id": e.id, "title": e.title}, user=me, status=status)
        e = Event.objects.prefetch_related("attendees").get(pk=e.pk)
        return out(e, me, None, True)

    @system.route("POST", "events/<id>/accept-proposal")
    def accept_proposal(request, id):
        """The maker moves the event to the moment a guest suggested."""
        me, d = request.user, request.data
        e = get_event(id, me)
        if not e or not can_edit(e, me):
            return bad(T("Alleen de maker kan dit doen."), 403)
        a = e.attendees.filter(user_id=d.get("user"), status="proposed").first()
        if not a or not a.proposed_at:
            return bad(T("Er is geen voorstel."))
        length = (e.ends_at - e.starts_at) if e.ends_at else None
        e.starts_at, e.ends_at = a.proposed_at, (a.proposed_at + length) if length else None
        e.save()
        a.status, a.proposed_at = "accepted", None
        a.save()
        for o in e.attendees.exclude(user=me).exclude(pk=a.pk):
            o.status, o.reminded = "invited", False
            o.save()
        for o in e.attendees.exclude(user=me):
            notify(o.user, T("Nieuw moment: {0}", e.title), T("Op {0}", fmt(e)))
        e = Event.objects.prefetch_related("attendees").get(pk=e.pk)
        return out(e, me, None, True)

    @system.route("GET", "events/<id>/ics")
    def ics(request, id):
        e = get_event(id, request.user)
        if not e:
            return bad(T("Deze afspraak bestaat niet of is niet zichtbaar."), 404)
        f = lambda d: d.astimezone(dt_tz.utc).strftime("%Y%m%dT%H%M%SZ")  # noqa: E731
        esc = lambda s: str(s or "").replace("\\", "\\\\").replace(";", "\\;").replace(",", "\\,").replace("\n", "\\n")  # noqa: E731
        end = e.ends_at or e.starts_at + timedelta(hours=1)
        body = "\r\n".join(["BEGIN:VCALENDAR", "VERSION:2.0", "PRODID:-//Easy2edit//Agenda//NL", "BEGIN:VEVENT", f"UID:agenda-{e.id}@easy2edit", f"DTSTAMP:{f(timezone.now())}",
                            f"DTSTART:{f(e.starts_at)}", f"DTEND:{f(end)}", f"SUMMARY:{esc(e.title)}", f"LOCATION:{esc(e.location)}", f"DESCRIPTION:{esc(e.description)}", "END:VEVENT", "END:VCALENDAR", ""])
        r = HttpResponse(body, content_type="text/calendar; charset=utf-8")
        r["Content-Disposition"] = f'attachment; filename="agenda-{e.id}.ics"'
        return r

    @system.route("GET", "admin/events")
    def admin_events(request):
        me = request.user
        if not is_admin(me):
            return bad(T("Je hebt hier geen rechten voor."), 403)
        qs = Event.objects.filter(kind="public").prefetch_related("attendees").order_by("-starts_at")[:300]
        return {"items": [out(e, me, None, True) for e in qs], "calendars": sorted(set(Event.objects.filter(kind="public").exclude(calendar="").values_list("calendar", flat=True)))}

    # ── links with other modules and plugins ──
    if cfg.get("marketplace_link", True) is not False:
        def on_booking(booking=None, listing=None, user=None, **kw):
            """A booking in the marketplace (an appointment or a party) also lands in the agenda of the booker and of the seller."""
            try:
                start = parse_datetime(str(listing.get("starts_at") or ""))
                if not start or not listing.get("id"):
                    return
                owner = U.objects.filter(pk=(listing.get("owner") or {}).get("id")).first()
                src = f"marketplace:{listing['id']}"
                e = Event.objects.filter(source=src).first()
                if not e:
                    e = Event.objects.create(owner=owner, title=str(listing.get("title") or "")[:160], location=str(listing.get("location") or "")[:160], starts_at=start if timezone.is_aware(start) else timezone.make_aware(start),
                                             kind="appointment", color="orange", source=src)
                    if owner:
                        Attendee.objects.create(event=e, user=owner, status="accepted", host=True)
                if user and not e.attendees.filter(user=user).exists():
                    Attendee.objects.create(event=e, user=user, status="accepted")
                    notify(user, T("In je agenda: {0}", e.title), T("Op {0}", fmt(e)))
            except Exception:  # noqa: BLE001
                logger.warning("Agenda: booking not added", exc_info=True)

        system.on("booking_created", on_booking)
