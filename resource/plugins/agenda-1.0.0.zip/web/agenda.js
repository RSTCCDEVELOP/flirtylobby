// Copyright & Ownership Notice
// easy2Edit is the exclusive legal property of RST Coaching & Consultancy B.V. (RSTCC),
// owned by Ronald Stolk. All rights reserved. Any unauthorized use, copying, modification,
// reproduction, distribution, or commercial exploitation of Easy2Edit, including its source code,
// is strictly prohibited without prior written permission from Ronald Stolk or RSTCC.
// website https://rstcc.net

"use strict";
/* Agenda: the shared program of the pages (main agenda, blocks for pages and the dashboard, admin). Texts through t("…") so every language gets them. */
var ROUTE = "/plugins/run/agenda/";
var t = function () { return system.t.apply(system, arguments); };
var COLORS = ["blue", "orange", "green", "pink", "purple", "teal", "red", "gray"];
var HEX = { blue: "#3b82f6", orange: "#f97316", green: "#16a34a", pink: "#ec4899", purple: "#8b5cf6", teal: "#0d9488", red: "#dc2626", gray: "#64748b" };
var KIND = { personal: "Eigen afspraak", appointment: "Afspraak met een lid", group: "Groepsafspraak", public: "Evenement" };
var STATUS = { invited: ["Uitgenodigd", "warn"], accepted: ["Komt", "ok"], declined: ["Komt niet", "no"], maybe: ["Misschien", ""], proposed: ["Ander moment", "warn"] };
/* texts that are shown through a variable, listed here so that every language gets them:
   t("Eigen afspraak") t("Afspraak met een lid") t("Groepsafspraak") t("Evenement") t("Uitgenodigd") t("Komt") t("Komt niet") t("Misschien") t("Ander moment")
   t("Niet") t("Elke dag") t("Elke week") t("Elke maand") t("Elk jaar") t("Dag") t("Week") t("Maand") t("Jaar") t("Agenda") t("Alles") t("Mijn afspraken") t("Groepen") t("Evenementen") t("Uitnodigingen")
   t("Leden kunnen zich zelf aanmelden") t("Ook tonen aan bezoekers van de website") t("Beschikbaar als systeemobject voor pagina's") */
var app = document.getElementById("app");
var CFG = null;

function h(tag, props) {
  var el = document.createElement(tag), kids = Array.prototype.slice.call(arguments, 2);
  Object.keys(props || {}).forEach(function (k) {
    var v = props[k];
    if (k === "class") el.className = v; else if (k.indexOf("on") === 0) el.addEventListener(k.slice(2), v);
    else if (k === "style") el.style.cssText = v; else if (k === "value") el.value = v; else if (v === true) el.setAttribute(k, ""); else if (v !== false && v != null) el.setAttribute(k, v);
  });
  (function add(list) { list.forEach(function (c) { if (Array.isArray(c)) add(c); else if (c != null && c !== false) el.appendChild(typeof c === "object" ? c : document.createTextNode(String(c))); }); })(kids);
  return el;
}
var call = function (path, method, body) { return system.api(ROUTE + path, { method: method || "GET", body: body }); };
var pad = function (n) { return (n < 10 ? "0" : "") + n; };
var ymd = function (d) { return d.getFullYear() + "-" + pad(d.getMonth() + 1) + "-" + pad(d.getDate()); };
var lang = function () { return document.documentElement.lang || "nl"; };
var dayKey = function (e) { return e.all_day ? String(e.starts_at).slice(0, 10) : ymd(new Date(e.starts_at)); };
var fmtTime = function (e) { return e.all_day ? t("Hele dag") : new Date(e.starts_at).toLocaleTimeString(lang(), { hour: "2-digit", minute: "2-digit" }) + (e.ends_at ? "–" + new Date(e.ends_at).toLocaleTimeString(lang(), { hour: "2-digit", minute: "2-digit" }) : ""); };
var fmtDate = function (e, opts) { var d = e.all_day ? new Date(String(e.starts_at).slice(0, 10) + "T12:00:00") : new Date(e.starts_at); return d.toLocaleDateString(lang(), opts || { weekday: "long", day: "numeric", month: "long" }); };
var toLocalInput = function (iso) { var d = new Date(iso); return d.getFullYear() + "-" + pad(d.getMonth() + 1) + "-" + pad(d.getDate()) + "T" + pad(d.getHours()) + ":" + pad(d.getMinutes()); };
var toIso = function (v) { return v ? new Date(v).toISOString() : null; };
function fail(e) { var box = document.getElementById("msg"); if (box) { box.textContent = e.message; box.className = "alert"; } else alert(e.message); }
function monthName(m) { return new Date(2021, m, 1).toLocaleDateString(lang(), { month: "long" }); }
function dowNames(start) { var out = []; for (var i = 0; i < 7; i++) out.push(new Date(2021, 7, 1 + ((i + start) % 7)).toLocaleDateString(lang(), { weekday: "short" })); return out; }
var sameDay = function (a, b) { return ymd(a) === ymd(b); };
function chip(e, onclick) {
  return h("button", { class: "ev c-" + e.color + " " + (e.status === "cancelled" ? "cancelled " : "") + (e.my_status === "invited" ? "invited " : "") + (e.my_status === "declined" ? "declined" : ""), title: e.title, onclick: onclick },
    (e.all_day ? "" : new Date(e.starts_at).toLocaleTimeString(lang(), { hour: "2-digit", minute: "2-digit" }) + " ") + e.title);
}
function modal(content, onclose) {
  var ov = h("div", { class: "overlay", onclick: function (ev) { if (ev.target === ov) close(); } }, h("div", { class: "modal" }, content));
  function close() { ov.remove(); if (onclose) onclose(); }
  document.body.appendChild(ov);
  return close;
}

// ── event detail ──
function detail(id, after) {
  call("events/" + id).then(function (e) {
    var close;
    var me = CFG && CFG.me;
    var mineA = e.attendees.filter(function (a) { return me && a.id === me.id; })[0];
    var respond = function (status, extra) { call("events/" + id + "/respond", "POST", Object.assign({ status: status }, extra || {})).then(function () { close(); after(); detail(id, after); }).catch(fail); };
    var rows = e.attendees.map(function (a) {
      var st = STATUS[a.status] || ["", ""];
      return h("div", { class: "who" }, h("span", {}, a.name + (a.host ? " (" + t("organisator") + ")" : "")),
        h("span", { class: "row" }, a.proposed_at ? h("small", { class: "muted" }, new Date(a.proposed_at).toLocaleString(lang(), { dateStyle: "medium", timeStyle: "short" })) : null,
          a.status === "proposed" && e.can_edit ? h("button", { class: "sm primary", onclick: function () { call("events/" + id + "/accept-proposal", "POST", { user: a.id }).then(function () { close(); after(); detail(id, after); }).catch(fail); } }, t("Neem over")) : null,
          h("span", { class: "badge " + st[1] }, t(st[0]))));
    });
    var canAnswer = e.status === "active" && (mineA && !mineA.host || (!mineA && e.kind === "public" && e.open_signup));
    var full = e.capacity && e.going >= e.capacity;
    var tab = "info", box = h("div", { class: "etab" }), tabbar = h("div", { class: "etabs", role: "tablist" });
    var answer = canAnswer ? h("div", { class: "row" },
      h("button", { class: "primary", disabled: full && !(mineA && mineA.status === "accepted"), onclick: function () { respond("accepted"); } }, full ? t("Vol") : (mineA && mineA.status === "invited" ? t("Accepteren") : t("Ik kom"))),
      h("button", { onclick: function () { respond("maybe"); } }, t("Misschien")),
      h("button", { class: "danger", onclick: function () { respond("declined"); } }, mineA && mineA.status === "invited" ? t("Afwijzen") : t("Ik kan niet")),
      e.kind === "appointment" ? h("button", { onclick: function () { prompt1(); } }, t("Ander moment")) : null) : null;
    function paint() {
      tabbar.innerHTML = ""; box.innerHTML = "";
      [["info", "Info", null], ["people", "Deelnemers", rows.length || null]].forEach(function (x) { if (x[0] === "people" && !rows.length) return; tabbar.appendChild(h("button", { type: "button", class: tab === x[0] ? "on" : "", onclick: function () { tab = x[0]; paint(); } }, t(x[1]), x[2] ? h("span", { class: "badge" }, x[2]) : null)); });
      if (tab === "info") {
        if (mineA && mineA.status === "invited" && e.status === "active") box.appendChild(h("div", { class: "note" }, "✉ " + t("Je bent uitgenodigd. Accepteer de uitnodiging om hem in je agenda te zetten.")));
        if (e.status === "cancelled") box.appendChild(h("div", { class: "alert" }, t("Deze afspraak is afgelast.")));
        box.appendChild(h("div", {}, h("strong", {}, fmtDate(e)), " · ", fmtTime(e), e.recurrence ? h("small", { class: "muted" }, " · " + t({ daily: "Elke dag", weekly: "Elke week", monthly: "Elke maand", yearly: "Elk jaar" }[e.recurrence])) : null));
        if (e.location) box.appendChild(h("div", {}, "📍 " + e.location));
        box.appendChild(h("div", { class: "row" }, h("span", { class: "badge" }, t(KIND[e.kind])), e.group ? h("span", { class: "badge" }, e.group.name) : null, e.calendar ? h("span", { class: "badge" }, e.calendar) : null, e.capacity ? h("span", { class: "badge" }, t("{0} van {1} plaatsen", e.going, e.capacity)) : null));
        if (e.description) box.appendChild(h("p", { style: "white-space:pre-wrap;margin:0" }, e.description));
        if (e.owner) box.appendChild(h("small", { class: "muted" }, t("Gemaakt door {0}", e.owner.name)));
        if (answer) box.appendChild(answer);
      } else box.appendChild(h("div", {}, rows));
    }
    paint();
    close = modal(h("div", { class: "editor" },
      h("div", { class: "ehead c-" + e.color }, h("div", { class: "row between" }, h("small", {}, t(KIND[e.kind])), h("button", { class: "sm", style: "background:rgba(255,255,255,.2);color:#fff;border-color:rgba(255,255,255,.4)", onclick: function () { close(); } }, "✕")), h("h2", { style: "margin:0;color:#fff" }, e.title)),
      tabbar, box,
      h("div", { class: "efoot row between" },
        h("button", { class: "sm", onclick: function () { downloadIcs(e); } }, t("Naar mijn agenda (.ics)")),
        e.can_edit ? h("span", { class: "row" },
          h("button", { class: "sm", onclick: function () { close(); editor(e, after); } }, t("Wijzigen")),
          e.status === "active" ? h("button", { class: "sm", onclick: function () { call("events/" + id, "PATCH", { status: "cancelled" }).then(function () { close(); after(); }).catch(fail); } }, t("Afgelasten")) : h("button", { class: "sm", onclick: function () { call("events/" + id, "PATCH", { status: "active" }).then(function () { close(); after(); }).catch(fail); } }, t("Weer activeren")),
          h("button", { class: "sm danger", onclick: function () { system.confirm(t("Deze afspraak verwijderen?"), { danger: true, okLabel: t("Verwijderen") }).then(function (ok) { if (ok) call("events/" + id, "DELETE").then(function () { close(); after(); }).catch(fail); }); } }, t("Verwijderen"))) : null)));
    function prompt1() {
      var inp = h("input", { type: "datetime-local", value: toLocalInput(e.first_start) });
      var c2 = modal(h("div", { class: "stack" }, h("h3", {}, t("Stel een ander moment voor")), inp, h("div", { class: "row" },
        h("button", { class: "primary", onclick: function () { var v = inp.value; c2(); close(); respond("proposed", { proposed_at: toIso(v) }); } }, t("Voorstel versturen")), h("button", { onclick: function () { c2(); } }, t("Annuleren")))));
    }
  }).catch(fail);
}
function downloadIcs(e) {
  var f = function (iso) { return new Date(iso).toISOString().replace(/[-:]/g, "").replace(/\.\d+/, ""); };
  var end = e.ends_at || new Date(new Date(e.first_start).getTime() + 3600000).toISOString();
  var body = ["BEGIN:VCALENDAR", "VERSION:2.0", "PRODID:-//Easy2edit//Agenda//NL", "BEGIN:VEVENT", "UID:agenda-" + e.id + "@easy2edit", "DTSTAMP:" + f(new Date().toISOString()), "DTSTART:" + f(e.first_start), "DTEND:" + f(end),
    "SUMMARY:" + (e.title || "").replace(/[\;,]/g, "\\$&"), "LOCATION:" + (e.location || "").replace(/[\;,]/g, "\\$&"), "END:VEVENT", "END:VCALENDAR"].join("\r\n");
  var a = document.createElement("a");
  a.href = "data:text/calendar;charset=utf-8," + encodeURIComponent(body); a.download = "agenda-" + e.id + ".ics"; document.body.appendChild(a); a.click(); a.remove();
}

// ── create / edit: one pop-up with tabs ──
function editor(e, after, preset) {
  var isNew = !e || !e.id;
  var v = Object.assign({ title: "", kind: "personal", all_day: false, color: "blue", location: "", description: "", recurrence: "", until: "", group_id: "", calendar: "", capacity: "", open_signup: false, on_site: false, system_object: false }, preset || {},
    e ? { title: e.title, kind: e.kind, all_day: e.all_day, color: e.color, location: e.location, description: e.description || "", recurrence: e.recurrence || "", until: e.until || "", group_id: e.group ? e.group.id : "", calendar: e.calendar || "",
      capacity: e.capacity || "", open_signup: e.open_signup, on_site: !!e.on_site, system_object: !!e.system_object } : {});
  var start = e && e.first_start ? (v.all_day ? String(e.first_start).slice(0, 10) : toLocalInput(e.first_start)) : (v.date ? v.date + "T" + (v.time || "09:00") : toLocalInput(new Date(Math.ceil(Date.now() / 3600000) * 3600000)));
  var end = e && e.first_end ? (v.all_day ? String(e.first_end).slice(0, 10) : toLocalInput(e.first_end)) : "";
  var picked = v.withUser ? [v.withUser] : [];
  var existing = e && e.attendees ? e.attendees.filter(function (a) { return !a.host; }) : [];
  var kinds = ["personal"].concat(CFG.appointments ? ["appointment"] : []).concat(CFG.groups.length && CFG.group_events ? ["group"] : []).concat(CFG.admin ? ["public"] : []);
  if (!CFG.members_create && !CFG.admin) kinds = kinds.filter(function (k) { return k !== "personal"; });
  if (e && e.kind && kinds.indexOf(e.kind) < 0) kinds.push(e.kind);
  var tab = "when", close, sel = {}, msg = h("div", { id: "msg" }), body = h("div", { class: "etab" }), bar = h("div", { class: "etabs", role: "tablist" });
  var field = function (k, el) { sel[k] = el; return el; };
  function keep() {
    Object.keys(sel).forEach(function (k) { var el = sel[k]; if (!el || !el.isConnected) return; var val = el.type === "checkbox" ? el.checked : el.value; if (k === "start") start = val; else if (k === "end") end = val; else v[k] = val; });
  }
  var hasPeople = function () { return v.kind === "personal" || v.kind === "appointment" || v.kind === "group"; };
  function tabs() {
    var list = [["when", "Wanneer"], ["where", "Plaats & info"]];
    if (hasPeople() || v.kind === "public") list.push(["people", "Deelnemers", picked.length + existing.length || null]);
    if (v.kind === "public") list.push(["more", "Opties"]);
    if (list.every(function (x) { return x[0] !== tab; })) tab = "when";
    bar.innerHTML = "";
    list.forEach(function (x) { bar.appendChild(h("button", { type: "button", role: "tab", class: tab === x[0] ? "on" : "", onclick: function () { keep(); tab = x[0]; draw(); } }, t(x[1]), x[2] ? h("span", { class: "badge" }, x[2]) : null)); });
  }
  var found = h("div"), peopleBox = h("div", { class: "stack", style: "gap:.2rem" });
  function drawPeople() {
    peopleBox.innerHTML = "";
    existing.forEach(function (a) { var st = STATUS[a.status] || ["", ""]; peopleBox.appendChild(h("div", { class: "who" }, h("span", {}, a.name), h("span", { class: "badge " + st[1] }, t(st[0])))); });
    picked.forEach(function (p) { peopleBox.appendChild(h("div", { class: "who" }, h("span", {}, p.name), h("span", { class: "row" }, h("span", { class: "badge warn" }, t("Wordt uitgenodigd")), h("button", { class: "sm", type: "button", onclick: function () { picked = picked.filter(function (x) { return x.id !== p.id; }); drawPeople(); tabs(); } }, "✕")))); });
  }
  function draw() {
    keep(); tabs(); body.innerHTML = ""; sel = { title: sel.title };
    if (tab === "when") {
      body.appendChild(h("div", { class: "grid2" }, h("label", {}, t("Soort"), field("kind", h("select", { onchange: function () { keep(); v.kind = sel.kind.value; draw(); } }, kinds.map(function (k) { return h("option", { value: k, selected: k === v.kind }, t(KIND[k])); })))),
        v.kind === "group" ? h("label", {}, t("Groep"), field("group_id", h("select", {}, CFG.groups.map(function (g) { return h("option", { value: g.id, selected: String(g.id) === String(v.group_id) }, g.name); })))) : h("span")));
      body.appendChild(h("label", { class: "chk" }, field("all_day", h("input", { type: "checkbox", checked: !!v.all_day, onchange: function () { keep(); start = start.slice(0, 10) + (v.all_day ? "" : "T09:00"); end = end ? end.slice(0, 10) + (v.all_day ? "" : "T10:00") : ""; draw(); } })), t("Hele dag")));
      body.appendChild(h("div", { class: "grid2" }, h("label", {}, t("Begin"), field("start", h("input", { type: v.all_day ? "date" : "datetime-local", value: v.all_day ? start.slice(0, 10) : start, required: true }))),
        h("label", {}, t("Einde (optioneel)"), field("end", h("input", { type: v.all_day ? "date" : "datetime-local", value: v.all_day ? end.slice(0, 10) : end })))));
      body.appendChild(h("div", { class: "grid2" }, h("label", {}, t("Herhalen"), field("recurrence", h("select", { onchange: function () { keep(); draw(); } }, [["", "Niet"], ["daily", "Elke dag"], ["weekly", "Elke week"], ["monthly", "Elke maand"], ["yearly", "Elk jaar"]].map(function (o) { return h("option", { value: o[0], selected: o[0] === v.recurrence }, t(o[1])); })))),
        v.recurrence ? h("label", {}, t("Tot en met"), field("until", h("input", { type: "date", value: v.until || "" }))) : h("span")));
    } else if (tab === "where") {
      body.appendChild(h("label", {}, t("Plaats"), field("location", h("input", { value: v.location, maxlength: 160, placeholder: t("bv. Utrecht, of een link naar een videogesprek") }))));
      body.appendChild(h("label", {}, t("Omschrijving"), field("description", h("textarea", { rows: 5, value: v.description }))));
      body.appendChild(h("div", {}, h("small", { class: "muted" }, t("Kleur")), h("div", { class: "swatches", style: "margin-top:.3rem" }, COLORS.map(function (c) { return h("button", { type: "button", class: "c-" + c + (v.color === c ? " on" : ""), "aria-label": c, onclick: function () { v.color = c; draw(); } }); }))));
    } else if (tab === "people") {
      if (hasPeople()) {
        body.appendChild(h("div", { class: "note" }, "✉ " + t("Uitgenodigde leden krijgen een uitnodiging (melding en, als ze dat willen, een e-mail) en staan pas in de agenda als ze die accepteren. Je kunt alleen leden uitnodigen die in hun profiel hebben aangegeven gevonden te willen worden, net als bij Zoeken & matchen.")));
        var search = h("input", { placeholder: t("Zoek een lid op naam"), oninput: function () {
          var q = search.value.trim(); if (q.length < 2) { found.innerHTML = ""; return; }
          call("people?q=" + encodeURIComponent(q)).then(function (res) {
            var list = res.items || []; found.innerHTML = "";
            if (res.locked) { found.appendChild(h("div", { class: "note" }, t("Je kunt alleen leden vinden en uitnodigen als je zelf meedoet in de community. Zet je profiel aan bij Mijn profiel."))); return; }
            if (!list.length && q.length > 1) found.appendChild(h("small", { class: "muted" }, t("Geen leden gevonden. Je kunt alleen leden uitnodigen die gevonden willen worden.")));
            var free = list.filter(function (p) { return !picked.some(function (x) { return x.id === p.id; }) && !existing.some(function (x) { return x.id === p.id; }); });
            if (free.length) found.appendChild(h("div", { class: "pick" }, free.map(function (p) { return h("button", { type: "button", onclick: function () { picked.push(p); search.value = ""; found.innerHTML = ""; drawPeople(); tabs(); } }, p.name); })));
          }).catch(function () {});
        } });
        body.appendChild(h("label", {}, v.kind === "appointment" ? t("Met wie?") : t("Uitnodigen"), search)); body.appendChild(found); drawPeople(); body.appendChild(peopleBox);
      }
      if (v.kind === "public") {
        body.appendChild(h("div", { class: "grid2" }, h("label", {}, t("Aantal plaatsen (leeg = onbeperkt)"), field("capacity", h("input", { type: "number", min: 1, value: v.capacity }))),
          h("label", { class: "chk", style: "align-self:end" }, field("open_signup", h("input", { type: "checkbox", checked: !!v.open_signup })), t("Leden kunnen zich zelf aanmelden"))));
        if (existing.length) { body.appendChild(h("h3", {}, t("Deelnemers"))); body.appendChild(peopleBox); drawPeople(); }
      }
    } else if (tab === "more") {
      body.appendChild(h("label", {}, t("Agenda (groep van evenementen)"), field("calendar", h("input", { value: v.calendar, maxlength: 60, placeholder: t("bv. Feesten") }))));
      body.appendChild(h("label", { class: "chk" }, field("on_site", h("input", { type: "checkbox", checked: !!v.on_site })), t("Ook tonen aan bezoekers van de website")));
      body.appendChild(h("label", { class: "chk" }, field("system_object", h("input", { type: "checkbox", checked: !!v.system_object })), t("Beschikbaar als systeemobject voor pagina's")));
    }
  }
  var titleInput = h("input", { value: v.title, maxlength: 160, required: true, placeholder: t("Titel van de afspraak"), class: "ttl-in", autofocus: true });
  sel.title = titleInput;
  draw();
  close = modal(h("form", { class: "stack editor", onsubmit: function (ev) {
    ev.preventDefault(); keep();
    var allDay = v.all_day, body_ = { title: v.title, kind: v.kind, all_day: allDay, color: v.color, location: v.location, description: v.description, recurrence: v.recurrence, until: v.until || null,
      starts_at: allDay ? start.slice(0, 10) : toIso(start), ends_at: end ? (allDay ? end.slice(0, 10) : toIso(end)) : null, invite: picked.map(function (p) { return p.id; }) };
    if (v.kind === "group") body_.group_id = v.group_id || (CFG.groups[0] && CFG.groups[0].id);
    if (v.kind === "public") { body_.calendar = v.calendar; body_.capacity = v.capacity; body_.open_signup = !!v.open_signup; body_.on_site = !!v.on_site; body_.system_object = !!v.system_object; }
    if (!start) { msg.className = "alert"; msg.textContent = t("Geef een begintijd op."); return; }
    call(isNew ? "events" : "events/" + e.id, isNew ? "POST" : "PATCH", body_).then(function () { close(); after(); }).catch(function (er) { msg.className = "alert"; msg.textContent = er.message; });
  } },
    h("div", { class: "ehead c-" + v.color }, h("small", {}, isNew ? t("Nieuwe afspraak") : t("Afspraak wijzigen")), titleInput),
    bar, body, msg,
    h("div", { class: "efoot row between" }, h("button", { type: "button", onclick: function () { close(); } }, t("Annuleren")), h("button", { class: "primary" }, isNew && picked.length ? t("Opslaan en uitnodigen") : t("Opslaan")))));
}

// ── the main agenda: day, week, month and year, with a mini calendar next to it ──
var HOUR_PX = 46;
function mainView() {
  var today = new Date();
  var S = { view: CFG.default_view === "list" ? "list" : CFG.default_view, cursor: new Date(today.getFullYear(), today.getMonth(), today.getDate()), hide: {}, list: [], full: false };
  var wrap = h("div", { class: "cal" });
  app.innerHTML = ""; app.appendChild(wrap);
  var d0 = function (d) { return new Date(d.getFullYear(), d.getMonth(), d.getDate()); };
  var addDays = function (d, n) { return new Date(d.getFullYear(), d.getMonth(), d.getDate() + n); };
  var weekStart = function (d) { return addDays(d, -((d.getDay() - CFG.week_start + 7) % 7)); };
  function range() {
    var c = S.cursor, a, b;
    if (S.view === "month") { a = weekStart(new Date(c.getFullYear(), c.getMonth(), 1)); b = addDays(a, 42); }
    else if (S.view === "week") { a = weekStart(c); b = addDays(a, 7); }
    else if (S.view === "day") { a = d0(c); b = addDays(a, 1); }
    else if (S.view === "year") { a = new Date(c.getFullYear(), 0, 1); b = new Date(c.getFullYear() + 1, 0, 1); }
    else { a = d0(c); b = addDays(a, 90); }
    return [a, b];
  }
  function load() {
    var r = range();
    call("events?from=" + encodeURIComponent(addDays(r[0], -1).toISOString()) + "&to=" + encodeURIComponent(addDays(r[1], 1).toISOString())).then(function (l) { S.list = l; draw(); }).catch(fail);
  }
  var shown = function () { return S.list.filter(function (e) { return !S.hide[e.kind === "personal" || e.kind === "appointment" ? "mine" : e.kind]; }); };
  function endKey(e) { return e.all_day ? String((e.ends_at || e.starts_at)).slice(0, 10) : ymd(new Date(e.ends_at || e.starts_at)); }
  function covers(e, key) {
    var sk = dayKey(e), ek = endKey(e);
    if (e.all_day) return sk <= key && key <= ek;
    var s = new Date(e.starts_at), en = new Date(e.ends_at || e.starts_at), ds = new Date(key + "T00:00:00"), de = new Date(ds.getTime() + 86400000);
    return s < de && (en >= ds && (en > ds || s >= ds));
  }
  function move(dir) {
    var c = S.cursor;
    if (S.view === "year") S.cursor = new Date(c.getFullYear() + dir, 0, 1);
    else if (S.view === "month") S.cursor = new Date(c.getFullYear(), c.getMonth() + dir, 1);
    else S.cursor = addDays(c, dir * (S.view === "week" ? 7 : S.view === "day" ? 1 : 30));
    load();
  }
  function title() {
    var c = S.cursor;
    if (S.view === "year") return String(c.getFullYear());
    if (S.view === "month") return monthName(c.getMonth()) + " " + c.getFullYear();
    if (S.view === "week") { var r = range(); return r[0].toLocaleDateString(lang(), { day: "numeric", month: "short" }) + " – " + addDays(r[1], -1).toLocaleDateString(lang(), { day: "numeric", month: "short", year: "numeric" }) + " · " + t("week {0}", weekNo(r[0])); }
    if (S.view === "day") return c.toLocaleDateString(lang(), { weekday: "long", day: "numeric", month: "long", year: "numeric" });
    return t("Komende afspraken");
  }
  function weekNo(d) { var x = new Date(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate() + 3 - ((d.getDay() + 6) % 7))); var y = new Date(Date.UTC(x.getUTCFullYear(), 0, 4)); return 1 + Math.round(((x - y) / 86400000 - 3 + ((y.getUTCDay() + 6) % 7)) / 7); }
  function newOn(date, time) { editor(null, load, { date: date, kind: "personal", time: time }); }
  function open(e) { detail(e.id, load); }

  // ── sidebar ──
  function mini() {
    var c = S.cursor, first = new Date(c.getFullYear(), c.getMonth(), 1), start = weekStart(first), cells = dowNames(CFG.week_start).map(function (d) { return h("span", { class: "h" }, d.slice(0, 2)); });
    var marks = {}; S.list.forEach(function (e) { marks[dayKey(e)] = true; });
    for (var i = 0; i < 42; i++) {
      var d = addDays(start, i), k = ymd(d);
      (function (d, k) {
        cells.push(h("button", { class: (d.getMonth() !== c.getMonth() ? "o " : "") + (sameDay(d, today) ? "t " : "") + (sameDay(d, c) ? "s " : "") + (marks[k] ? "e" : ""), onclick: function () { S.cursor = d; if (S.view === "year" || S.view === "month" || S.view === "list") S.view = S.view === "list" ? "list" : "day"; load(); } }, d.getDate()));
      })(d, k);
    }
    return h("div", { class: "mini card" }, h("div", { class: "row between" }, h("strong", {}, monthName(c.getMonth()) + " " + c.getFullYear()),
      h("span", { class: "row", style: "gap:.2rem" }, h("button", { class: "sm", onclick: function () { S.cursor = new Date(c.getFullYear(), c.getMonth() - 1, 1); load(); } }, "‹"), h("button", { class: "sm", onclick: function () { S.cursor = new Date(c.getFullYear(), c.getMonth() + 1, 1); load(); } }, "›"))),
      h("div", { class: "mgrid" }, cells));
  }
  var mail = null;
  call("settings").then(function (m) { mail = m; draw(); }).catch(function () {});
  function mailCard() {
    if (!mail || !mail.email_possible) return null;
    return h("div", { class: "card stack", style: "gap:.4rem" }, h("strong", {}, t("Uitnodigingen")),
      h("label", { class: "chk" }, h("input", { type: "checkbox", checked: !!mail.email_invites, onchange: function (ev) { var on = ev.target.checked; call("settings", "PUT", { email_invites: on }).then(function (m) { mail = m; draw(); }).catch(fail); } }), t("Stuur mij een e-mail bij uitnodigingen")),
      h("small", { class: "muted" }, t("Je krijgt altijd een melding. Je kunt dit ook aanpassen bij Meldingen.")));
  }
  function side() {
    var pend = S.list.filter(function (e) { return e.my_status === "invited" && e.status === "active"; });
    var seen = {}, nextUp = S.list.filter(function (e) { return e.status === "active" && e.my_status !== "declined" && new Date(e.ends_at || e.starts_at) >= new Date() && !seen[e.id + e.starts_at] && (seen[e.id + e.starts_at] = true); }).slice(0, 5);
    var filt = [["mine", "Mijn afspraken", "blue"], ["group", "Groepen", "purple"], ["public", "Evenementen", "orange"]];
    return h("aside", { class: "side" }, h("button", { class: "primary big-btn", onclick: function () { newOn(ymd(S.cursor)); } }, "+ " + t("Nieuwe afspraak")), mini(),
      h("div", { class: "card stack", style: "gap:.4rem" }, h("strong", {}, t("Agenda's")), filt.map(function (f) {
        return h("label", { class: "chk" }, h("input", { type: "checkbox", checked: !S.hide[f[0]], onchange: function (ev) { S.hide[f[0]] = !ev.target.checked; draw(); } }), h("span", { class: "dot c-" + f[2] }), t(f[1]));
      })),
      mailCard(),
      pend.length ? h("div", { class: "card stack", style: "gap:.4rem" }, h("strong", {}, t("{0} uitnodigingen wachten op je antwoord", pend.length)), pend.slice(0, 4).map(function (e) { return h("button", { class: "sm", style: "text-align:left", onclick: function () { open(e); } }, e.title); })) : null,
      nextUp.length ? h("div", { class: "card stack", style: "gap:.4rem" }, h("strong", {}, t("Komende afspraken")), nextUp.map(function (e) {
        return h("button", { class: "up", onclick: function () { open(e); } }, h("span", { class: "dot c-" + e.color }), h("span", { class: "grow", style: "text-align:left" }, h("strong", {}, e.title), h("small", { class: "muted", style: "display:block" }, fmtDate(e, { day: "numeric", month: "short" }) + " · " + fmtTime(e))));
      })) : null);
  }

  // ── toolbar ──
  function bar() {
    return h("div", { class: "bar row between" },
      h("div", { class: "row" }, h("button", { onclick: function () { move(-1); } }, "‹"), h("button", { onclick: function () { S.cursor = d0(new Date()); load(); } }, t("Vandaag")), h("button", { onclick: function () { move(1); } }, "›"), h("h1", { class: "ttl" }, title())),
      h("div", { class: "tabs" }, [["day", "Dag"], ["week", "Week"], ["month", "Maand"], ["year", "Jaar"], ["list", "Agenda"]].map(function (o) { return h("button", { class: S.view === o[0] ? "on" : "", onclick: function () { S.view = o[0]; load(); } }, t(o[1])); })));
  }

  // ── hour grid (day and week) ──
  function hourGrid(days) {
    var list = shown(), timed = list.filter(function (e) { return !e.all_day; }), from = S.full ? 0 : 7, to = S.full ? 24 : 21;
    timed.forEach(function (e) { var st = new Date(e.starts_at), en = new Date(e.ends_at || e.starts_at); if (!S.full) { from = Math.min(from, st.getHours()); if (en.getHours() >= to) to = Math.min(24, en.getHours() + 1); } });
    var H = (to - from) * HOUR_PX, nowMin = (today.getHours() * 60 + today.getMinutes());
    var head = h("div", { class: "hg-head" }, h("div", { class: "gut" }), days.map(function (d) {
      var key = ymd(d), allday = list.filter(function (e) { return e.all_day && covers(e, key); });
      return h("div", { class: "hd" + (sameDay(d, today) ? " today" : "") }, h("button", { class: "dn", onclick: function () { S.cursor = d; S.view = "day"; load(); } }, h("small", {}, d.toLocaleDateString(lang(), { weekday: "short" })), h("b", {}, d.getDate())),
        allday.map(function (e) { return chip(e, function () { open(e); }); }));
    }));
    var gut = h("div", { class: "gut", style: "height:" + H + "px" }), cols = [];
    for (var hr = from; hr < to; hr++) gut.appendChild(h("div", { class: "hl", style: "height:" + HOUR_PX + "px" }, h("span", {}, pad(hr) + ":00")));
    days.forEach(function (d) {
      var key = ymd(d), ds = d0(d).getTime(), col = h("div", { class: "dcol" + (sameDay(d, today) ? " today" : ""), style: "height:" + H + "px", onclick: function (ev) { if (ev.target !== col) return; var y = ev.offsetY / HOUR_PX + from, hh = Math.floor(y); newOn(key, pad(hh) + ":" + (y - hh >= .5 ? "30" : "00")); } });
      for (var i = 0; i < to - from; i++) col.appendChild(h("div", { class: "hr", style: "top:" + i * HOUR_PX + "px" }));
      var evs = timed.filter(function (e) { return covers(e, key); }).map(function (e) {
        var s = Math.max(new Date(e.starts_at).getTime(), ds), en = Math.min(new Date(e.ends_at || new Date(e.starts_at).getTime() + 3600000).getTime(), ds + 86400000);
        return { e: e, s: (s - ds) / 60000, en: Math.max((en - ds) / 60000, (s - ds) / 60000 + 30) };
      }).sort(function (a, b) { return a.s - b.s || b.en - a.en; });
      var cluster = [], clusterEnd = -1, flush = function () { var n = 0; cluster.forEach(function (x) { n = Math.max(n, x.col + 1); }); cluster.forEach(function (x) { x.n = n; }); cluster = []; };
      evs.forEach(function (x) { if (x.s >= clusterEnd && cluster.length) { flush(); clusterEnd = -1; } var used = cluster.filter(function (y) { return y.en > x.s; }).map(function (y) { return y.col; }), c = 0; while (used.indexOf(c) >= 0) c++; x.col = c; cluster.push(x); clusterEnd = Math.max(clusterEnd, x.en); });
      flush();
      evs.forEach(function (x) {
        var e = x.e, top = (x.s / 60 - from) * HOUR_PX, ht = Math.max(((x.en - x.s) / 60) * HOUR_PX - 2, 20);
        col.appendChild(h("button", { class: "blk c-" + e.color + (e.status === "cancelled" ? " cancelled" : "") + (e.my_status === "invited" ? " invited" : "") + (e.my_status === "declined" ? " declined" : ""), style: "top:" + top + "px;height:" + ht + "px;left:" + (x.col / x.n * 100) + "%;width:" + (100 / x.n - 1) + "%", onclick: function (ev) { ev.stopPropagation(); open(e); } },
          h("strong", {}, e.title), h("small", {}, fmtTime(e)), ht > 48 && e.location ? h("small", {}, "📍 " + e.location) : null));
      });
      if (sameDay(d, today)) col.appendChild(h("div", { class: "now", style: "top:" + ((nowMin / 60 - from) * HOUR_PX) + "px" }));
      cols.push(col);
    });
    var body = h("div", { class: "hg-body" }, gut, cols);
    return h("div", { class: "hgrid", style: "--cols:" + days.length }, head, body, h("div", { class: "row", style: "justify-content:flex-end;padding:.3rem" }, h("button", { class: "sm", onclick: function () { S.full = !S.full; draw(); } }, S.full ? t("Werkuren tonen") : t("Hele dag (24 uur) tonen"))));
  }

  // ── month ──
  function monthGrid() {
    var r = range(), list = shown(), cur = S.cursor.getMonth(), cells = [h("div", { class: "dow wk" }, "#")], dow = dowNames(CFG.week_start);
    dow.forEach(function (n) { cells.push(h("div", { class: "dow" }, n)); });
    for (var i = 0; i < 42; i++) {
      var d = addDays(r[0], i), key = ymd(d);
      if (i % 7 === 0) cells.push(h("div", { class: "wk" }, weekNo(d)));
      (function (key, d) {
        var evs = list.filter(function (e) { return covers(e, key); });
        cells.push(h("div", { class: "day" + (d.getMonth() !== cur ? " other" : "") + (sameDay(d, today) ? " today" : ""), onclick: function () { newOn(key); } },
          h("button", { class: "n", onclick: function (ev) { ev.stopPropagation(); S.cursor = d; S.view = "day"; load(); } }, d.getDate()), evs.slice(0, 3).map(function (e) { return chip(e, function (ev) { ev.stopPropagation(); open(e); }); }),
          evs.length > 3 ? h("button", { class: "more", onclick: function (ev) { ev.stopPropagation(); S.cursor = d; S.view = "day"; load(); } }, t("+{0} meer", evs.length - 3)) : null));
      })(key, d);
    }
    return h("div", { class: "month2" }, cells);
  }

  // ── year ──
  function yearGrid() {
    var y = S.cursor.getFullYear(), list = shown(), months = [], marks = {}, count = {};
    list.forEach(function (e) { marks[dayKey(e)] = (marks[dayKey(e)] || 0) + 1; });
    for (var m = 0; m < 12; m++) {
      (function (m) {
        var first = new Date(y, m, 1), start = weekStart(first), cells = dowNames(CFG.week_start).map(function (d) { return h("span", { class: "h" }, d.slice(0, 1)); });
        for (var i = 0; i < 42; i++) {
          var d = addDays(start, i), k = ymd(d), inM = d.getMonth() === m;
          cells.push(inM ? h("button", { class: (sameDay(d, today) ? "t " : "") + (marks[k] ? "e" : ""), title: marks[k] ? t("{0} afspraken", marks[k]) : "", onclick: function () { S.cursor = new Date(y, m, parseInt(this.textContent, 10)); S.view = "day"; load(); } }, d.getDate()) : h("span"));
        }
        var n = list.filter(function (e) { return dayKey(e).slice(0, 7) === y + "-" + pad(m + 1); }).length;
        months.push(h("div", { class: "ym card" }, h("button", { class: "ymt", onclick: function () { S.cursor = new Date(y, m, 1); S.view = "month"; load(); } }, monthName(m), n ? h("span", { class: "badge" }, n) : null), h("div", { class: "mgrid" }, cells)));
      })(m);
    }
    return h("div", { class: "year" }, months);
  }

  // ── agenda list ──
  function itemRow(e) {
    var st = STATUS[e.my_status];
    return h("button", { class: "item" + (e.status === "cancelled" ? " cancelled" : "") + (e.my_status === "declined" ? " declined" : ""), onclick: function () { open(e); } },
      h("span", { class: "bar c-" + e.color }), h("span", { class: "time" }, fmtTime(e)),
      h("span", { class: "grow", style: "text-align:left" }, h("strong", {}, e.title), e.location ? h("div", { class: "muted" }, "📍 " + e.location) : null,
        h("div", { class: "row" }, h("small", { class: "muted" }, t(KIND[e.kind]) + (e.group ? " · " + e.group.name : "")), st ? h("span", { class: "badge " + st[1] }, t(st[0])) : null)));
  }
  function listView() {
    var r = range(), box = h("div", {}), last = "", rows = shown().filter(function (e) { var k = dayKey(e); return k >= ymd(r[0]) && k < ymd(r[1]); });
    if (!rows.length) box.appendChild(h("div", { class: "card muted" }, t("Geen afspraken in deze periode.")));
    rows.forEach(function (e) { var k = dayKey(e); if (k !== last) { last = k; box.appendChild(h("div", { class: "dayhead" }, fmtDate(e))); } box.appendChild(h("div", { style: "margin-bottom:.4rem" }, itemRow(e))); });
    return box;
  }
  function draw() {
    wrap.innerHTML = "";
    var main = h("div", { class: "main stack" }, bar(), h("div", { id: "msg" }));
    if (S.view === "day") main.appendChild(hourGrid([d0(S.cursor)]));
    else if (S.view === "week") { var r = range(), days = []; for (var i = 0; i < 7; i++) days.push(addDays(r[0], i)); main.appendChild(hourGrid(days)); }
    else if (S.view === "month") main.appendChild(monthGrid());
    else if (S.view === "year") main.appendChild(yearGrid());
    else main.appendChild(listView());
    wrap.appendChild(side()); wrap.appendChild(main);
  }
  load();
  var q = (system.route && system.route.query) || {};
  if (q.with) call("person/" + encodeURIComponent(q.with)).then(function (p) { editor(null, load, { kind: "appointment", withUser: p }); }).catch(function () {});
}

// ── blocks for pages and the dashboard tile ──
function partView(route) {
  var q = (route && route.query) || {}, layout = q.layout || "list";
  var load = function () {
    var path = CFG ? "upcoming?limit=" + (q.limit || 6) + (q.calendar ? "&calendar=" + encodeURIComponent(q.calendar) : "") : "public?" + (q.calendar ? "calendar=" + encodeURIComponent(q.calendar) + "&" : "") + (q.event ? "event=" + encodeURIComponent(q.event) : "");
    return call(path);
  };
  load().then(function (d) {
    if (!CFG && d.theme) document.documentElement.setAttribute("data-ptheme", d.theme);
    app.innerHTML = "";
    var items = d.items || [], open = function (e) { if (CFG) detail(e.id, function () { partView(route); }); };
    if (q.view === "month") { app.appendChild(miniMonth(items, open)); return; }
    if (!items.length) { app.appendChild(h("div", { class: "card muted" }, t("Geen komende afspraken."))); return; }
    if (layout === "cards") app.appendChild(h("div", { class: "cards" }, items.map(function (e) { return h("div", { class: "evcard", style: "cursor:pointer", onclick: function () { open(e); } }, h("div", { class: "top c-" + e.color }, h("div", { class: "big" }, new Date(e.starts_at).getDate()), h("small", {}, new Date(e.starts_at).toLocaleDateString(lang(), { month: "long", weekday: "short" }))),
      h("div", { class: "body" }, h("strong", {}, e.title), h("small", { class: "muted" }, fmtTime(e)), e.location ? h("small", { class: "muted" }, "📍 " + e.location) : null)); })));
    else app.appendChild(h("div", { class: "blk" }, q.event || q.calendar ? null : null, items.map(function (e) {
      return h("button", { class: "item", onclick: function () { open(e); } }, h("span", { class: "bar c-" + e.color }), h("span", { class: "time" }, fmtDate(e, { day: "numeric", month: "short" }) + " " + (e.all_day ? "" : fmtTime(e).slice(0, 5))),
        h("span", { class: "grow", style: "text-align:left" }, h("strong", {}, e.title), e.location ? h("div", { class: "muted" }, "📍 " + e.location) : null, e.description && !CFG ? h("div", { class: "muted" }, e.description.slice(0, 140)) : null));
    })));
  }).catch(function (e) { app.innerHTML = ""; app.appendChild(h("div", { class: "alert" }, e.message)); });
}
function miniMonth(items, open) {
  var now = new Date(), first = new Date(now.getFullYear(), now.getMonth(), 1), dow = dowNames((CFG && CFG.week_start) || 1), lead = (first.getDay() - ((CFG && CFG.week_start) || 1) + 7) % 7, n = new Date(now.getFullYear(), now.getMonth() + 1, 0).getDate();
  var marks = {}; items.forEach(function (e) { marks[dayKey(e)] = true; });
  var cells = dow.map(function (d) { return h("span", { class: "h" }, d.slice(0, 2)); });
  for (var i = 0; i < lead; i++) cells.push(h("span"));
  for (var d = 1; d <= n; d++) { var k = now.getFullYear() + "-" + pad(now.getMonth() + 1) + "-" + pad(d); cells.push(h("span", { class: (d === now.getDate() ? "t " : "") + (marks[k] ? "e" : "") }, d)); }
  return h("div", { class: "card" }, h("strong", {}, monthName(now.getMonth()) + " " + now.getFullYear()), h("div", { class: "minimonth", style: "margin-top:.4rem" }, cells));
}

// ── admin: events for all members ──
function adminView() {
  function load() {
    call("admin/events").then(function (d) {
      app.innerHTML = "";
      app.appendChild(h("div", { class: "hero" }, h("div", {}, h("h1", {}, t("Evenementen")), h("small", {}, t("Evenementen voor alle leden. Zet 'systeemobject' aan om ze op een pagina te plaatsen."))),
        h("button", { class: "primary", onclick: function () { editor(null, load, { kind: "public" }); } }, "+ " + t("Nieuw evenement"))));
      app.appendChild(h("div", { id: "msg" }));
      if (d.calendars.length) app.appendChild(h("p", { class: "muted" }, t("Agenda's") + ": " + d.calendars.join(", ")));
      if (!d.items.length) app.appendChild(h("div", { class: "card muted" }, t("Nog geen evenementen.")));
      app.appendChild(h("div", { class: "stack" }, d.items.map(function (e) {
        return h("button", { class: "item", onclick: function () { editor(e, load); } }, h("span", { class: "bar c-" + e.color }), h("span", { class: "time" }, new Date(e.first_start).toLocaleDateString(lang(), { day: "numeric", month: "short", year: "numeric" })),
          h("span", { class: "grow", style: "text-align:left" }, h("strong", {}, e.title), h("div", { class: "row" }, e.calendar ? h("span", { class: "badge" }, e.calendar) : null, e.system_object ? h("span", { class: "badge ok" }, t("Systeemobject")) : null, e.on_site ? h("span", { class: "badge" }, t("Op de website")) : null,
            e.status === "cancelled" ? h("span", { class: "badge no" }, t("Afgelast")) : null, h("small", { class: "muted" }, t("{0} aanmeldingen", e.going)))));
      })));
    }).catch(fail);
  }
  load();
}

function start(mode) {
  system.ready.then(function (ctx) {
    var route = ctx.route || {}; system.route = route;
    if (mode === "month") { route = Object.assign({}, route, { query: Object.assign({}, route.query || {}, { view: "month" }) }); mode = "part"; }
    if (mode === "part") {
      call("config").then(function (c) { CFG = c; document.documentElement.setAttribute("data-ptheme", c.theme); partView(route); }).catch(function () { CFG = null; partView(route); });
      return;
    }
    call("config").then(function (c) { CFG = c; document.documentElement.setAttribute("data-ptheme", c.theme); if (mode === "admin") adminView(); else mainView(); }).catch(fail);
  });
}
