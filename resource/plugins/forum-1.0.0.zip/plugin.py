# Copyright & Ownership Notice
# easy2Edit is the exclusive legal property of RST Coaching & Consultancy B.V. (RSTCC),
# owned by Ronald Stolk. All rights reserved. Any unauthorized use, copying, modification,
# reproduction, distribution, or commercial exploitation of Easy2Edit, including its source code,
# is strictly prohibited without prior written permission from Ronald Stolk or RSTCC.
# website https://rstcc.net

"""Forum (plugin). Users make forums; a forum has groups and subgroups (categories); in a group people start discussions (threads), answer each other (posts, also on a post), add photos,
videos and files, like and report. Everybody can follow a forum, a group or a discussion and gets a notification (and an e-mail when they want it, see Meldingen).

Rights, three layers that work together:
  1. the system rights of the record (Admin -> Rechten, `facade.rights`): who may view, edit or delete a forum;
  2. per forum a table of actions (view, create_category, create_thread, reply, upload, react, edit_own, delete_own, moderate): for each the lowest level that may do it
     (visitors < members < moderators < admins) plus extra users and user groups;
  3. managers: whoever makes a forum is its owner, whoever makes a group is its owner (and so a manager of everything below it). An administrator (or an owner) adds managers; an owner removes them.
Levels: 0 visitor, 1 member, 2 manager (of the forum, or of a group above), 3 owner of the forum or an administrator of the site.

Routes: /api/plugins/run/forum/<path>   (all answers are JSON). Written for the pages in web/ (index, admin, block) and documented in md/modules/forum.md of the system.
  home                                   GET   public     forums I may see, latest discussions, who I am, what I may do
  forums                                 POST             make a forum {title, description, visibility: public|members|private}
  forums/<id>                            GET public       one forum with its groups (tree), counts, my level and rights;  PUT edit {title, description, icon, color, status};  DELETE
  forums/<id>/settings                   GET / PUT        the table of actions {perms}, features {allow_attachments, allow_files, require_approval, ...}, visibility
  forums/<id>/rights                     GET / PUT        the system rights lists (view, edit, delete: users and groups)
  forums/<id>/managers                   GET / POST       list / add {user_id, role: manager|owner, category_id?}
  managers/<id>                          DELETE           take the rights of a manager away
  forums/<id>/categories                 POST             make a group or subgroup {title, description, parent_id}
  categories/<id>                        GET public       a group: subgroups, discussions (?q ?sort=latest|new|popular ?page), managers;  PUT edit;  DELETE
  categories/<id>/threads                POST             start a discussion {title, body, attachments: [ids]}
  threads/<id>                           GET public       a discussion with its posts (?page);  PUT edit {title, body};  DELETE
  threads/<id>/action                    POST             {action: pin|unpin|lock|unlock|hide|unhide|approve|move, category_id}
  threads/<id>/posts                     POST             answer {body, parent_id?, attachments}
  posts/<id>                             PUT / DELETE     edit / delete an answer;   posts/<id>/action  POST {action: hide|unhide|approve}
  react                                  POST             {thread_id | post_id} toggles a like
  report                                 POST             {thread_id | post_id, reason}
  follow                                 POST / GET       {kind: forum|category|thread, id, level: all|replies|off|none} / my follows
  search                                 GET public       ?q= in the forums I may see
  upload                                 POST (file)      a photo, video or file for a discussion or answer (kept as a draft until it is posted);  attachments/<id> DELETE
  get/<token>                            GET public       the file itself (the links in the answers are signed)
  people                                 GET              ?q= find users (to add managers)
  admin/overview, admin/forums, admin/forums/<id>, admin/groups, admin/managers, admin/reports, admin/reports/<id>, admin/board   for administrators
  blocks/forums, blocks/latest, blocks/popular, blocks/forum/<id>      for the blocks on pages (system objects)"""
import logging
import mimetypes
import re
import secrets
from datetime import timedelta
from pathlib import Path

from django.core import signing
from django.db import models
from django.db.models import Q
from django.db.models.signals import post_delete
from django.http import HttpResponse, StreamingHttpResponse
from django.utils import timezone
from rest_framework.response import Response

logger = logging.getLogger(__name__)
ACTIONS = ("view", "create_category", "create_thread", "reply", "upload", "react", "edit_own", "delete_own", "moderate")
LEVELS = {"visitors": 0, "members": 1, "moderators": 2, "admins": 3, "nobody": 9}
DEFAULT_PERMS = {"view": "members", "create_category": "moderators", "create_thread": "members", "reply": "members", "upload": "members", "react": "members", "edit_own": "members", "delete_own": "members", "moderate": "moderators"}
FEATURES = ("allow_attachments", "allow_photos", "allow_videos", "allow_files", "require_approval", "allow_reports", "reactions", "subgroup_depth")
DEFAULT_BOARD = {
    "members_create_forums": True, "max_forums_per_user": 5, "default_visibility": "members", "perms": DEFAULT_PERMS,
    "allow_attachments": True, "allow_photos": True, "allow_videos": True, "allow_files": False, "max_photo_mb": 10, "max_video_mb": 200, "max_file_mb": 25, "max_attachments": 10,
    "require_approval": False, "edit_window_minutes": 30, "threads_per_page": 20, "posts_per_page": 20, "subgroup_depth": 3, "auto_follow": True, "reactions": True, "allow_reports": True,
    "owners_add_managers": True, "flood_seconds": 10, "welcome_text": "",
}
PHOTO = {".jpg", ".jpeg", ".png", ".gif", ".webp"}
VIDEO = {".mp4", ".webm", ".mov", ".m4v"}
FILES = {".pdf", ".txt", ".csv", ".doc", ".docx", ".xls", ".xlsx", ".ppt", ".pptx", ".zip", ".odt", ".ods"}
MAGIC = {".png": [b"\x89PNG"], ".jpg": [b"\xff\xd8"], ".jpeg": [b"\xff\xd8"], ".gif": [b"GIF8"], ".webp": [b"RIFF"], ".pdf": [b"%PDF"], ".zip": [b"PK"]}
LINK_SALT, LINK_HOURS = "forum-file", 12


def register(system):
    from apps.accounts.access import level as module_level
    from apps.accounts.models import UserGroup
    from apps.core import richtext
    from apps.plugins.facade import community as social, rights

    T = system.t
    U, label = system.User, system.app_label
    cfg = system.config
    bad = lambda msg, code=400: Response({"detail": msg}, status=code)  # noqa: E731
    now = timezone.now

    def table(name):
        return type("Meta", (), {"app_label": label, "db_table": system.db_prefix + name})

    class Settings(models.Model):
        data = models.JSONField(default=dict, blank=True)
        Meta = table("settings")

    class Forum(models.Model):
        title = models.CharField(max_length=120)
        slug = models.SlugField(max_length=140, unique=True)
        description = models.TextField(blank=True)
        status = models.CharField(max_length=10, default="open")  # open | closed (nobody may write) | archived (hidden from lists) | pending (waits for an administrator)
        icon = models.CharField(max_length=40, blank=True)
        color = models.CharField(max_length=9, blank=True)
        perms = models.JSONField(default=dict, blank=True)  # {action: {"level": "members", "users": [], "groups": []}}
        features = models.JSONField(default=dict, blank=True)  # overrides of the standard board
        created_by = models.ForeignKey(U, null=True, blank=True, on_delete=models.SET_NULL, related_name="+", db_constraint=False)
        created_at = models.DateTimeField(auto_now_add=True)
        updated_at = models.DateTimeField(auto_now=True)
        Meta = table("forum")

    class Category(models.Model):
        forum = models.ForeignKey(Forum, on_delete=models.CASCADE, related_name="categories")
        parent = models.ForeignKey("self", null=True, blank=True, on_delete=models.CASCADE, related_name="children")
        title = models.CharField(max_length=120)
        description = models.TextField(blank=True)
        position = models.IntegerField(default=0)
        locked = models.BooleanField(default=False)
        created_by = models.ForeignKey(U, null=True, blank=True, on_delete=models.SET_NULL, related_name="+", db_constraint=False)
        created_at = models.DateTimeField(auto_now_add=True)
        Meta = table("category")

    class Manager(models.Model):
        forum = models.ForeignKey(Forum, on_delete=models.CASCADE, related_name="managers")
        category = models.ForeignKey(Category, null=True, blank=True, on_delete=models.CASCADE, related_name="managers")
        user = models.ForeignKey(U, on_delete=models.CASCADE, related_name="+", db_constraint=False)
        role = models.CharField(max_length=10, default="manager")  # owner | manager
        added_by = models.ForeignKey(U, null=True, blank=True, on_delete=models.SET_NULL, related_name="+", db_constraint=False)
        created_at = models.DateTimeField(auto_now_add=True)
        Meta = table("manager")

    class Thread(models.Model):
        forum = models.ForeignKey(Forum, on_delete=models.CASCADE, related_name="threads")
        category = models.ForeignKey(Category, on_delete=models.CASCADE, related_name="threads")
        title = models.CharField(max_length=200)
        body = models.TextField(blank=True)
        author = models.ForeignKey(U, null=True, blank=True, on_delete=models.SET_NULL, related_name="+", db_constraint=False)
        status = models.CharField(max_length=10, default="published")  # published | pending | hidden
        pinned = models.BooleanField(default=False)
        locked = models.BooleanField(default=False)
        views = models.PositiveIntegerField(default=0)
        reply_count = models.PositiveIntegerField(default=0)
        last_post_at = models.DateTimeField(default=timezone.now)
        created_at = models.DateTimeField(auto_now_add=True)
        edited_at = models.DateTimeField(null=True, blank=True)
        Meta = table("thread")

    class Post(models.Model):
        thread = models.ForeignKey(Thread, on_delete=models.CASCADE, related_name="posts")
        parent = models.ForeignKey("self", null=True, blank=True, on_delete=models.SET_NULL, related_name="answers")
        author = models.ForeignKey(U, null=True, blank=True, on_delete=models.SET_NULL, related_name="+", db_constraint=False)
        body = models.TextField()
        status = models.CharField(max_length=10, default="published")
        created_at = models.DateTimeField(auto_now_add=True)
        edited_at = models.DateTimeField(null=True, blank=True)
        Meta = table("post")

    class Attachment(models.Model):
        owner = models.ForeignKey(U, null=True, blank=True, on_delete=models.SET_NULL, related_name="+", db_constraint=False)
        thread = models.ForeignKey(Thread, null=True, blank=True, on_delete=models.CASCADE, related_name="attachments")
        post = models.ForeignKey(Post, null=True, blank=True, on_delete=models.CASCADE, related_name="attachments")
        kind = models.CharField(max_length=6)  # photo | video | file
        name = models.CharField(max_length=200)
        mime = models.CharField(max_length=100, blank=True)
        size = models.BigIntegerField(default=0)
        key = models.CharField(max_length=60)
        created_at = models.DateTimeField(auto_now_add=True)
        Meta = table("attachment")

    class Reaction(models.Model):
        user = models.ForeignKey(U, on_delete=models.CASCADE, related_name="+", db_constraint=False)
        thread = models.ForeignKey(Thread, null=True, blank=True, on_delete=models.CASCADE, related_name="reactions")
        post = models.ForeignKey(Post, null=True, blank=True, on_delete=models.CASCADE, related_name="reactions")
        created_at = models.DateTimeField(auto_now_add=True)
        Meta = table("reaction")

    class Follow(models.Model):
        user = models.ForeignKey(U, on_delete=models.CASCADE, related_name="+", db_constraint=False)
        kind = models.CharField(max_length=10)  # forum | category | thread
        target = models.PositiveIntegerField()
        level = models.CharField(max_length=8, default="all")  # all | replies | off
        created_at = models.DateTimeField(auto_now_add=True)
        Meta = table("follow")

    class Report(models.Model):
        reporter = models.ForeignKey(U, null=True, blank=True, on_delete=models.SET_NULL, related_name="+", db_constraint=False)
        thread = models.ForeignKey(Thread, null=True, blank=True, on_delete=models.CASCADE, related_name="reports")
        post = models.ForeignKey(Post, null=True, blank=True, on_delete=models.CASCADE, related_name="reports")
        reason = models.TextField(blank=True)
        status = models.CharField(max_length=8, default="open")  # open | done
        handled_by = models.ForeignKey(U, null=True, blank=True, on_delete=models.SET_NULL, related_name="+", db_constraint=False)
        created_at = models.DateTimeField(auto_now_add=True)
        Meta = table("report")

    system.sync_models(Settings, Forum, Category, Manager, Thread, Post, Attachment, Reaction, Follow, Report)

    def gone(sender, instance, **kw):  # (a table of a plugin is not known to the database cascade of the system: what belongs to a deleted person goes by hand)
        Follow.objects.filter(user_id=instance.pk).delete()
        Reaction.objects.filter(user_id=instance.pk).delete()
        Manager.objects.filter(user_id=instance.pk).delete()

    post_delete.disconnect(dispatch_uid="forum-user-deleted")
    post_delete.connect(gone, sender=U, dispatch_uid="forum-user-deleted", weak=False)

    # ───────────── settings, people and rights ─────────────
    def board():
        row = Settings.objects.filter(pk=1).first()
        d = {**DEFAULT_BOARD, **((row.data if row else {}) or {})}
        d["perms"] = {a: _perm((d.get("perms") or {}).get(a), DEFAULT_PERMS[a]) for a in ACTIONS}
        return d

    def _perm(v, default):
        if isinstance(v, str):
            v = {"level": v}
        v = v if isinstance(v, dict) else {}
        lvl = v.get("level") if v.get("level") in LEVELS else default
        ids = lambda k: sorted({int(x) for x in v.get(k) or [] if str(x).isdigit()})[:100]  # noqa: E731
        return {"level": lvl, "users": ids("users"), "groups": ids("groups")}

    def authed(u):
        return bool(u and getattr(u, "is_authenticated", False))

    def site_admin(u):
        return bool(authed(u) and (u.is_staff or module_level(u, "plugins") >= 2))

    def name(u):
        return social.display_name(u) if u else T("Verwijderde gebruiker")

    def person(u):
        n = name(u)
        return {"id": u.id if u else None, "name": n, "initials": "".join(w[0] for w in n.split()[:2]).upper() or "?"}

    def my_groups(u):
        return set(u.user_groups.values_list("id", flat=True)) if authed(u) else set()

    def ancestors(cat):
        out, cur = [], cat
        while cur is not None and len(out) < 12:
            out.append(cur)
            cur = cur.parent
        return out

    def user_level(u, forum, cat=None):
        if not authed(u):
            return 0
        if site_admin(u) or forum.created_by_id == u.id:
            return 3
        rows = list(Manager.objects.filter(forum=forum, user=u))
        if any(r.category_id is None and r.role == "owner" for r in rows):
            return 3
        if any(r.category_id is None for r in rows):
            return 2
        if cat is not None:
            ids = {c.id for c in ancestors(cat)}
            if any(r.category_id in ids for r in rows):
                return 2
        return 1

    def perm_of(forum, action):
        return _perm((forum.perms or {}).get(action), board()["perms"][action]["level"])

    def feature(forum, key):
        v = (forum.features or {}).get(key)
        return board()[key] if v is None else v

    def allowed(u, forum, action, cat=None):
        p = perm_of(forum, action)
        if user_level(u, forum, cat) >= LEVELS[p["level"]]:
            return True
        return bool(authed(u) and (u.id in p["users"] or (set(p["groups"]) & my_groups(u))))

    def may_view(u, forum):
        if forum.status in ("archived", "pending") and user_level(u, forum) < 3:
            return False
        if not allowed(u, forum, "view"):
            return False
        return bool(site_admin(u) or user_level(u, forum) >= 2 or rights.can(u, "forum", "forum", forum.pk, "view"))

    def visible_forums(u):
        qs = Forum.objects.all()
        if not site_admin(u):
            qs = qs.exclude(status__in=("archived", "pending")) | (Forum.objects.filter(created_by=u, status__in=("archived", "pending")) if authed(u) else Forum.objects.none())
        return [f for f in qs.distinct().order_by("title") if may_view(u, f)]

    def rich(v, limit=20000):
        v = richtext.clean_small(v, limit)
        return v

    def forum_of(ident):
        if str(ident).isdigit():
            return Forum.objects.filter(pk=ident).first()
        return Forum.objects.filter(slug=str(ident)).first()

    def unique_slug(title, own=None):
        base = re.sub(r"[^a-z0-9]+", "-", str(title).lower()).strip("-")[:60] or "forum"
        slug, n = base, 2
        while Forum.objects.filter(slug=slug).exclude(pk=own).exists():
            slug, n = f"{base}-{n}", n + 1
        return slug

    # ───────────── attachments (files) ─────────────
    def files_dir():
        d = Path(system.data_dir) / "files"
        d.mkdir(parents=True, exist_ok=True)
        return d

    def file_url(att):
        return "/api/plugins/run/forum/get/" + signing.dumps({"a": att.id}, salt=LINK_SALT)

    def att_json(att):
        return {"id": att.id, "kind": att.kind, "name": att.name, "mime": att.mime, "size": att.size, "url": file_url(att)}

    def attach(ids, owner, thread=None, post=None):
        """Draft attachments of this person (uploaded before the text was sent) are tied to the discussion or answer."""
        ids = [int(i) for i in ids or [] if str(i).isdigit()][: board()["max_attachments"]]
        Attachment.objects.filter(pk__in=ids, owner=owner, thread__isnull=True, post__isnull=True).update(thread=thread, post=post)

    def check_upload(f, forum):
        ext = Path(f.name or "").suffix.lower()
        b = board()
        if not feature(forum, "allow_attachments"):
            raise ValueError(T("In dit forum kun je geen bijlagen toevoegen."))
        if ext in PHOTO and feature(forum, "allow_photos"):
            kind, mb = "photo", b["max_photo_mb"]
        elif ext in VIDEO and feature(forum, "allow_videos"):
            kind, mb = "video", b["max_video_mb"]
        elif ext in FILES and feature(forum, "allow_files"):
            kind, mb = "file", b["max_file_mb"]
        else:
            raise ValueError(T("Dit soort bestand is hier niet toegestaan."))
        if f.size > int(mb) * 1024 * 1024:
            raise ValueError(T("Het bestand is te groot (maximaal {0} MB).", mb))
        head = f.read(12)
        f.seek(0)
        if ext in MAGIC and not any(head.startswith(m) for m in MAGIC[ext]):
            raise ValueError(T("Het bestand lijkt niet bij zijn soort te horen."))
        if ext in (".mp4", ".mov", ".m4v") and b"ftyp" not in head:
            raise ValueError(T("Het bestand lijkt niet bij zijn soort te horen."))
        return kind, ext

    @system.route("POST", "upload")
    def upload(request):
        me = request.user
        forum = forum_of(request.data.get("forum_id") or 0)
        f = request.FILES.get("file")
        if not forum or not f or not may_view(me, forum) or not allowed(me, forum, "upload"):
            return bad(T("Je mag hier geen bestanden toevoegen."), 403)
        try:
            kind, ext = check_upload(f, forum)
        except ValueError as e:
            return bad(str(e))
        Attachment.objects.filter(thread__isnull=True, post__isnull=True, created_at__lt=now() - timedelta(days=1)).delete()  # old drafts that were never posted
        key = secrets.token_hex(16) + ext
        with open(files_dir() / key, "wb") as out:
            for chunk in f.chunks():
                out.write(chunk)
        att = Attachment.objects.create(owner=me, kind=kind, name=re.sub(r"[\r\n\t]+", " ", f.name or "bestand")[:200], mime=mimetypes.guess_type(key)[0] or "", size=f.size, key=key)
        return att_json(att)

    @system.route("DELETE", "attachments/<id>")
    def del_attachment(request, id):  # noqa: A002
        att = Attachment.objects.filter(pk=id).first()
        if not att or (att.owner_id != request.user.id and not site_admin(request.user)):
            return bad(T("Niet gevonden."), 404)
        try:
            (files_dir() / att.key).unlink(missing_ok=True)
        except OSError:
            pass
        att.delete()
        return {"ok": True}

    @system.route("GET", "get/<token>", public=True)
    def get_file(request, token):
        try:
            data = signing.loads(token, salt=LINK_SALT, max_age=LINK_HOURS * 3600)
        except signing.BadSignature:
            return bad(T("Deze link is verlopen."), 404)
        att = Attachment.objects.filter(pk=data.get("a")).first()
        path = files_dir() / att.key if att else None
        if not att or not path.is_file():
            return bad(T("Niet gevonden."), 404)
        size = path.stat().st_size
        ctype = att.mime or "application/octet-stream"
        start, end, status_code = 0, size - 1, 200
        m = re.match(r"bytes=(\d*)-(\d*)", request.META.get("HTTP_RANGE", ""))  # (videos need partial answers to jump around)
        if m and (m.group(1) or m.group(2)):
            start = int(m.group(1)) if m.group(1) else max(0, size - int(m.group(2)))
            end = min(int(m.group(2)), size - 1) if m.group(1) and m.group(2) else size - 1
            status_code = 206 if start <= end else 416
            if status_code == 416:
                return HttpResponse(status=416)

        def stream():
            with open(path, "rb") as fh:
                fh.seek(start)
                left = end - start + 1
                while left > 0:
                    chunk = fh.read(min(65536, left))
                    if not chunk:
                        break
                    left -= len(chunk)
                    yield chunk

        resp = StreamingHttpResponse(stream(), status=status_code, content_type=ctype)
        resp["Content-Length"] = str(end - start + 1)
        resp["Accept-Ranges"] = "bytes"
        resp["X-Content-Type-Options"] = "nosniff"
        if status_code == 206:
            resp["Content-Range"] = f"bytes {start}-{end}/{size}"
        if att.kind == "file":
            resp["Content-Disposition"] = 'attachment; filename="' + re.sub(r'[^A-Za-z0-9._ -]', "_", att.name) + '"'
        return resp

    # ───────────── notifications ─────────────
    def notify(users, title, body, url):
        try:
            from apps.notifications.service import notify as _notify
        except Exception:  # noqa: BLE001 - notifications are optional
            return
        for u in users:
            _notify(u, "forum", title, body, url=url)

    def followers(forum, cat, thread, level_in=("all",)):
        """The people who follow this discussion, its group (or a group above it) or the forum; a mute on the discussion wins."""
        ids = set()
        cats = [c.id for c in ancestors(cat)] if cat else []
        q = Q(kind="forum", target=forum.id) | (Q(kind="category", target__in=cats) if cats else Q(pk__in=[]))
        if thread:
            muted = set(Follow.objects.filter(kind="thread", target=thread.id, level="off").values_list("user_id", flat=True))
            q |= Q(kind="thread", target=thread.id)
        else:
            muted = set()
        for f in Follow.objects.filter(q):
            if f.level in level_in and f.user_id not in muted:
                ids.add(f.user_id)
        return ids

    def auto_follow(u, kind, target):
        if board()["auto_follow"] and authed(u):
            Follow.objects.get_or_create(user=u, kind=kind, target=target, defaults={"level": "replies"})

    def snippet(html, n=140):
        return richtext.plain(str(html)[5:] if str(html).startswith("html:") else str(html)).strip()[:n]

    def link(thread):
        return f"/dashboard/plugins/forum?thread={thread.id}"

    # ───────────── serializers ─────────────
    def mgr_ids(forum):
        return set(Manager.objects.filter(forum=forum, category__isnull=True).values_list("user_id", flat=True)) | ({forum.created_by_id} if forum.created_by_id else set())

    def thread_row(t, me, mgrs=None):
        return {"id": t.id, "title": t.title, "pinned": t.pinned, "locked": t.locked, "status": t.status, "views": t.views, "replies": t.reply_count, "category_id": t.category_id, "forum_id": t.forum_id,
                "author": person(t.author), "created_at": t.created_at, "last_post_at": t.last_post_at, "excerpt": snippet(t.body), "likes": t.reactions.count()}

    def forum_row(f, me):
        threads = Thread.objects.filter(forum=f, status="published")
        last = threads.order_by("-last_post_at").first()
        return {"id": f.id, "title": f.title, "slug": f.slug, "description": f.description, "icon": f.icon, "color": f.color, "status": f.status, "visibility": visibility_of(f), "created_at": f.created_at, "pending": Thread.objects.filter(forum=f, status="pending").count() + Post.objects.filter(thread__forum=f, status="pending").count(),
                "groups": Category.objects.filter(forum=f).count(), "threads": threads.count(), "posts": Post.objects.filter(thread__forum=f, status="published").count(),
                "owner": person(f.created_by) if f.created_by_id else None, "last": ({"thread_id": last.id, "title": last.title, "at": last.last_post_at, "author": person(last.author)} if last else None),
                "level": user_level(me, f), "following": authed(me) and Follow.objects.filter(user=me, kind="forum", target=f.id).exclude(level="off").exists()}

    def visibility_of(f):
        lvl = perm_of(f, "view")["level"]
        return "public" if lvl == "visitors" else "members" if lvl == "members" else "private"

    def cat_row(c, me):
        n = Thread.objects.filter(category=c, status="published").count()
        last = Thread.objects.filter(category=c, status="published").order_by("-last_post_at").first()
        return {"id": c.id, "forum_id": c.forum_id, "parent_id": c.parent_id, "title": c.title, "description": c.description, "locked": c.locked, "position": c.position, "threads": n,
                "last": ({"thread_id": last.id, "title": last.title, "at": last.last_post_at} if last else None), "created_by": person(c.created_by) if c.created_by_id else None}

    def cat_tree(forum, me):
        rows = [cat_row(c, me) for c in Category.objects.filter(forum=forum).order_by("position", "title")]
        by = {r["id"]: {**r, "children": []} for r in rows}
        roots = []
        for r in by.values():
            (by[r["parent_id"]]["children"] if r["parent_id"] in by else roots).append(r)
        return roots

    def my_perms(me, forum, cat=None):
        return {a: allowed(me, forum, a, cat) for a in ACTIONS} | {"level": user_level(me, forum, cat), "site_admin": site_admin(me), "open": forum.status == "open"}

    def depth(cat):
        return len(ancestors(cat))

    def can_edit_item(me, forum, obj, cat):
        if allowed(me, forum, "moderate", cat):
            return True
        if not (authed(me) and obj.author_id == me.id and allowed(me, forum, "edit_own", cat) and forum.status == "open"):
            return False
        minutes = board()["edit_window_minutes"]
        return not minutes or now() - obj.created_at <= timedelta(minutes=int(minutes))

    def can_delete_item(me, forum, obj, cat):
        return allowed(me, forum, "moderate", cat) or bool(authed(me) and obj.author_id == me.id and allowed(me, forum, "delete_own", cat))

    def flooded(me, forum, cat):
        secs = int(board()["flood_seconds"] or 0)
        if not secs or allowed(me, forum, "moderate", cat):
            return False
        since = now() - timedelta(seconds=secs)
        return Thread.objects.filter(author=me, created_at__gte=since).exists() or Post.objects.filter(author=me, created_at__gte=since).exists()

    def pending_needed(me, forum, cat):
        return bool(feature(forum, "require_approval") and not allowed(me, forum, "moderate", cat))

    # ───────────── home and forums ─────────────
    @system.route("GET", "home", public=True)
    def home(request):
        me = request.user
        b = board()
        forums = visible_forums(me)
        ids = [f.id for f in forums]
        latest = Thread.objects.filter(forum_id__in=ids, status="published").select_related("author").order_by("-last_post_at")[:10]
        mine = Forum.objects.filter(created_by=me).count() if authed(me) else 0
        can_create = bool(authed(me) and (site_admin(me) or (b["members_create_forums"] and (not b["max_forums_per_user"] or mine < b["max_forums_per_user"]))))
        return {"me": ({**person(me), "admin": site_admin(me)} if authed(me) else None), "can_create_forum": can_create, "welcome": b["welcome_text"], "forums": [forum_row(f, me) for f in forums],
                "latest": [{**thread_row(t, me), "forum": t.forum.title} for t in latest], "visibility": b["default_visibility"], "board": {k: b[k] for k in ("reactions", "allow_reports", "allow_attachments")}, "limits": limits()}

    @system.route("POST", "forums")
    def forum_create(request):
        me, d, b = request.user, request.data, board()
        mine = Forum.objects.filter(created_by=me).count()
        if not (site_admin(me) or (b["members_create_forums"] and (not b["max_forums_per_user"] or mine < b["max_forums_per_user"]))):
            return bad(T("Je kunt geen forum meer maken."), 403)
        title = str(d.get("title") or "").strip()[:120]
        if not title:
            return bad(T("Geef het forum een naam."))
        vis = d.get("visibility") if d.get("visibility") in ("public", "members", "private") else b["default_visibility"]
        f = Forum.objects.create(title=title, slug=unique_slug(title), description=rich(d.get("description"), 4000), created_by=me, perms=perms_for_visibility(vis, {}), icon=str(d.get("icon") or "")[:40], color=str(d.get("color") or "")[:9])
        Manager.objects.create(forum=f, user=me, role="owner", added_by=me)
        rights.protect("forum", "forum", f.pk, owner=me)
        auto_follow(me, "forum", f.id)
        return forum_detail(request, id=f.id)

    def perms_for_visibility(vis, perms):
        p = dict(perms or {})
        p["view"] = {"level": {"public": "visitors", "members": "members", "private": "moderators"}[vis], "users": (p.get("view") or {}).get("users", []) if isinstance(p.get("view"), dict) else [], "groups": (p.get("view") or {}).get("groups", []) if isinstance(p.get("view"), dict) else []}
        return p

    @system.route("GET", "forums/<id>", public=True)
    def forum_detail(request, id):  # noqa: A002
        me = request.user
        f = forum_of(id)
        if not f or not may_view(me, f):
            return bad(T("Dit forum bestaat niet of is niet voor jou."), 404)
        recent = Thread.objects.filter(forum=f, status="published").select_related("author", "category").order_by("-pinned", "-last_post_at")[:15]
        return {"forum": forum_row(f, me), "tree": cat_tree(f, me), "recent": [{**thread_row(t, me), "category": t.category.title} for t in recent], "can": my_perms(me, f),
                "managers": [{"id": m.id, "user": person(m.user), "role": m.role} for m in f.managers.filter(category__isnull=True).select_related("user")]}

    @system.route("PUT", "forums/<id>")
    def forum_edit(request, id):  # noqa: A002
        f = forum_of(id)
        if not f or user_level(request.user, f) < 3:
            return bad(T("Alleen de beheerder van het forum mag dit."), 403)
        d = request.data
        if "title" in d:
            t = str(d.get("title") or "").strip()[:120]
            if not t:
                return bad(T("Geef het forum een naam."))
            f.title = t
        if "description" in d:
            f.description = rich(d.get("description"), 4000)
        for k, n in (("icon", 40), ("color", 9)):
            if k in d:
                setattr(f, k, str(d.get(k) or "")[:n])
        if d.get("status") in ("open", "closed", "archived") and (d["status"] != "archived" or True):
            f.status = d["status"]
        f.save()
        return forum_detail(request, id=f.id)

    def drop_forum(f):
        for att in Attachment.objects.filter(Q(thread__forum=f) | Q(post__thread__forum=f)):
            try:
                (files_dir() / att.key).unlink(missing_ok=True)
            except OSError:
                pass
        rights.forget("forum", "forum", f.pk)
        Follow.objects.filter(kind="forum", target=f.pk).delete()
        f.delete()

    @system.route("DELETE", "forums/<id>")
    def forum_delete(request, id):  # noqa: A002
        f = forum_of(id)
        if not f or not (site_admin(request.user) or rights.can(request.user, "forum", "forum", f.pk, "delete") and user_level(request.user, f) >= 3):
            return bad(T("Je mag dit forum niet verwijderen."), 403)
        drop_forum(f)
        return {"ok": True}

    # ───────────── forum settings, rights and managers ─────────────
    def limits():
        b = board()
        return {"photo_mb": b["max_photo_mb"], "video_mb": b["max_video_mb"], "file_mb": b["max_file_mb"], "max_attachments": b["max_attachments"], "photo": sorted(PHOTO), "video": sorted(VIDEO), "file": sorted(FILES)}

    def people_names(f):
        """{id: name} of the extra users in the table of actions and in the system rights lists (the lists only hold ids)."""
        ids = set()
        for a in ACTIONS:
            ids |= set(perm_of(f, a)["users"])
        for r in (rights.rules_of("forum", "forum", f.pk) or {}).values():
            ids |= {int(x) for x in (r.get("users") or [])} if isinstance(r, dict) else set()
        return {str(u.id): name(u) for u in U.objects.filter(pk__in=ids)}

    def settings_view(f, me):
        return {"forum_id": f.id, "visibility": visibility_of(f), "perms": {a: perm_of(f, a) for a in ACTIONS}, "features": {k: feature(f, k) for k in FEATURES}, "standard": {k: board()[k] for k in FEATURES},
                "levels": list(LEVELS), "actions": list(ACTIONS), "standard_perms": {k: v["level"] for k, v in board()["perms"].items()}, "people": people_names(f), "limits": limits(), "rules": rights.rules_of("forum", "forum", f.pk) or {}, "members_may_set": rights.members_may_set("forum") or site_admin(me), "status": f.status,
                "groups": [{"id": g.id, "name": g.name} for g in UserGroup.objects.order_by("name")[:200]]}

    @system.route("GET", "forums/<id>/settings")
    def forum_settings(request, id):  # noqa: A002
        f = forum_of(id)
        if not f or user_level(request.user, f) < 3:
            return bad(T("Alleen de beheerder van het forum mag dit."), 403)
        return settings_view(f, request.user)

    @system.route("PUT", "forums/<id>/settings")
    def forum_settings_put(request, id):  # noqa: A002
        f = forum_of(id)
        if not f or user_level(request.user, f) < 3:
            return bad(T("Alleen de beheerder van het forum mag dit."), 403)
        d = request.data
        perms = {a: _perm((d.get("perms") or {}).get(a), perm_of(f, a)["level"]) for a in ACTIONS}
        if d.get("visibility") in ("public", "members", "private"):
            perms = perms_for_visibility(d["visibility"], perms) | {a: perms[a] for a in ACTIONS if a != "view"}
        f.perms = perms
        feats = d.get("features") if isinstance(d.get("features"), dict) else {}
        f.features = {k: (int(feats[k]) if k == "subgroup_depth" and str(feats[k]).isdigit() else bool(feats[k])) for k in FEATURES if k in feats}
        f.save()
        return settings_view(f, request.user)

    @system.route("PUT", "forums/<id>/rights")
    def forum_rights(request, id):  # noqa: A002
        f = forum_of(id)
        if not f or user_level(request.user, f) < 3 or not (rights.members_may_set("forum") or site_admin(request.user)):
            return bad(T("Je mag de rechten van dit forum niet instellen."), 403)
        rights.protect("forum", "forum", f.pk, owner=f.created_by, rules=request.data.get("rules") or {})
        return settings_view(f, request.user)

    def can_manage_managers(me, forum, cat):
        if site_admin(me):
            return True
        if not board()["owners_add_managers"]:
            return False
        if cat is None:
            return user_level(me, forum) >= 3
        return bool(authed(me) and Manager.objects.filter(forum=forum, category__in=ancestors(cat), user=me, role="owner").exists()) or user_level(me, forum) >= 3

    def manager_row(m):
        return {"id": m.id, "user": person(m.user), "role": m.role, "category_id": m.category_id, "category": m.category.title if m.category_id else None, "forum_id": m.forum_id, "forum": m.forum.title,
                "added_by": person(m.added_by) if m.added_by_id else None, "created_at": m.created_at}

    @system.route("GET", "forums/<id>/managers")
    def managers_list(request, id):  # noqa: A002
        f = forum_of(id)
        if not f or user_level(request.user, f) < 2:
            return bad(T("Dit is voor beheerders."), 403)
        return {"managers": [manager_row(m) for m in Manager.objects.filter(forum=f).select_related("user", "category", "forum", "added_by")], "can_add": can_manage_managers(request.user, f, None)}

    @system.route("POST", "forums/<id>/managers")
    def managers_add(request, id):  # noqa: A002
        me, d = request.user, request.data
        f = forum_of(id)
        cat = Category.objects.filter(pk=d.get("category_id"), forum=f).first() if f and d.get("category_id") else None
        if not f or not can_manage_managers(me, f, cat):
            return bad(T("Je mag hier geen beheerders toevoegen."), 403)
        u = U.objects.filter(pk=d.get("user_id"), is_active=True).first() if str(d.get("user_id") or "").isdigit() else None
        if not u:
            return bad(T("Kies een gebruiker."))
        role = "owner" if d.get("role") == "owner" and site_admin(me) else "manager"
        m, made = Manager.objects.get_or_create(forum=f, category=cat, user=u, defaults={"role": role, "added_by": me})
        if not made and role == "owner" and m.role != "owner":
            m.role = "owner"
            m.save(update_fields=["role"])
        if made:
            notify([u], T("Je bent beheerder van {0}", cat.title if cat else f.title), T("{0} heeft je als beheerder toegevoegd.", name(me)), f"/dashboard/plugins/forum?forum={f.id}")
        return managers_list(request, id=f.id)

    @system.route("DELETE", "managers/<id>")
    def managers_delete(request, id):  # noqa: A002
        m = Manager.objects.filter(pk=id).select_related("forum", "category").first()
        me = request.user
        if not m or not can_manage_managers(me, m.forum, m.category):
            return bad(T("Je mag deze beheerder niet verwijderen."), 403)
        if m.role == "owner" and not site_admin(me) and m.user_id != me.id and Manager.objects.filter(forum=m.forum, category=m.category, role="owner").count() <= 1:
            return bad(T("De laatste eigenaar kan niet worden verwijderd."))
        m.delete()
        return {"ok": True}

    @system.route("GET", "people")
    def people(request):
        q = str(request.query_params.get("q") or "").strip()
        if len(q) < 2 or not authed(request.user):
            return {"people": []}
        qs = U.objects.filter(is_active=True).filter(Q(first_name__icontains=q) | Q(last_name__icontains=q) | Q(display_name__icontains=q) | Q(email__istartswith=q))[:12]
        return {"people": [person(u) | {"email": u.email if site_admin(request.user) else ""} for u in qs]}

    # ───────────── groups (categories) ─────────────
    def cat_of(pk):
        return Category.objects.filter(pk=pk).select_related("forum", "parent").first() if str(pk).isdigit() else None

    @system.route("POST", "forums/<id>/categories")
    def cat_create(request, id):  # noqa: A002
        me, d = request.user, request.data
        f = forum_of(id)
        parent = Category.objects.filter(pk=d.get("parent_id"), forum=f).first() if f and d.get("parent_id") else None
        if not f or not may_view(me, f) or not allowed(me, f, "create_category", parent) or f.status != "open":
            return bad(T("Je mag hier geen groep maken."), 403)
        if parent and depth(parent) >= int(feature(f, "subgroup_depth") or 3):
            return bad(T("Er mogen niet meer lagen subgroepen in dit forum."))
        title = str(d.get("title") or "").strip()[:120]
        if not title:
            return bad(T("Geef de groep een naam."))
        c = Category.objects.create(forum=f, parent=parent, title=title, description=rich(d.get("description"), 2000), created_by=me, position=Category.objects.filter(forum=f, parent=parent).count())
        Manager.objects.create(forum=f, category=c, user=me, role="owner", added_by=me)  # whoever makes a group is its owner
        auto_follow(me, "category", c.id)
        return cat_detail(request, id=c.id)

    @system.route("GET", "categories/<id>", public=True)
    def cat_detail(request, id):  # noqa: A002
        me, q = request.user, request.query_params
        c = cat_of(id)
        if not c or not may_view(me, c.forum):
            return bad(T("Deze groep bestaat niet of is niet voor jou."), 404)
        b = board()
        mod = allowed(me, c.forum, "moderate", c)
        qs = Thread.objects.filter(category=c).select_related("author")
        qs = qs if mod else qs.filter(Q(status="published") | (Q(author=me, status="pending") if authed(me) else Q(pk__in=[])))
        if q.get("q"):
            qs = qs.filter(Q(title__icontains=q["q"]) | Q(body__icontains=q["q"]))
        order = {"new": ("-pinned", "-created_at"), "popular": ("-pinned", "-reply_count", "-last_post_at")}.get(q.get("sort"), ("-pinned", "-last_post_at"))
        qs = qs.order_by(*order)
        per = int(b["threads_per_page"])
        page = max(1, int(q.get("page") or 1)) if str(q.get("page") or "1").isdigit() else 1
        total = qs.count()
        return {"category": cat_row(c, me), "forum": {"id": c.forum_id, "title": c.forum.title, "status": c.forum.status}, "path": [{"id": a.id, "title": a.title} for a in reversed(ancestors(c))],
                "subgroups": [cat_row(x, me) for x in c.children.order_by("position", "title")], "threads": [thread_row(t, me) for t in qs[(page - 1) * per: page * per]], "total": total, "page": page, "pages": max(1, -(-total // per)),
                "can": my_perms(me, c.forum, c) | {"can_start": bool(allowed(me, c.forum, "create_thread", c) and c.forum.status == "open" and not c.locked), "can_subgroup": bool(allowed(me, c.forum, "create_category", c) and depth(c) < int(feature(c.forum, "subgroup_depth") or 3))},
                "managers": [{"id": m.id, "user": person(m.user), "role": m.role} for m in Manager.objects.filter(category__in=ancestors(c)).select_related("user")],
                "following": (Follow.objects.filter(user=me, kind="category", target=c.id).values_list("level", flat=True).first() or "") if authed(me) else ""}

    @system.route("PUT", "categories/<id>")
    def cat_edit(request, id):  # noqa: A002
        c = cat_of(id)
        if not c or not allowed(request.user, c.forum, "moderate", c):
            return bad(T("Je mag deze groep niet wijzigen."), 403)
        d = request.data
        if "title" in d:
            t = str(d.get("title") or "").strip()[:120]
            if not t:
                return bad(T("Geef de groep een naam."))
            c.title = t
        if "description" in d:
            c.description = rich(d.get("description"), 2000)
        if "locked" in d:
            c.locked = bool(d.get("locked"))
        if str(d.get("position") or "").lstrip("-").isdigit():
            c.position = int(d["position"])
        c.save()
        return cat_detail(request, id=c.id)

    @system.route("DELETE", "categories/<id>")
    def cat_delete(request, id):  # noqa: A002
        c = cat_of(id)
        if not c or not (user_level(request.user, c.forum) >= 3 or allowed(request.user, c.forum, "moderate", c) and Manager.objects.filter(category__in=ancestors(c), user=request.user, role="owner").exists()):
            return bad(T("Je mag deze groep niet verwijderen."), 403)
        for att in Attachment.objects.filter(Q(thread__category=c) | Q(post__thread__category=c)):
            try:
                (files_dir() / att.key).unlink(missing_ok=True)
            except OSError:
                pass
        c.delete()
        return {"ok": True}

    # ───────────── discussions and answers ─────────────
    def body_ok(v, what):
        v = rich(v)
        if not v.strip():
            raise ValueError(T("Schrijf eerst een tekst."))
        return v

    @system.route("POST", "categories/<id>/threads")
    def thread_create(request, id):  # noqa: A002
        me, d = request.user, request.data
        c = cat_of(id)
        if not c or not may_view(me, c.forum) or not allowed(me, c.forum, "create_thread", c) or c.forum.status != "open" or c.locked:
            return bad(T("Je mag hier geen onderwerp starten."), 403)
        title = str(d.get("title") or "").strip()[:200]
        if not title:
            return bad(T("Geef het onderwerp een titel."))
        try:
            body = body_ok(d.get("body"), "")
        except ValueError as e:
            return bad(str(e))
        if flooded(me, c.forum, c):
            return bad(T("Even rustig: wacht een paar seconden voor je opnieuw schrijft."), 429)
        pending = pending_needed(me, c.forum, c)
        t = Thread.objects.create(forum=c.forum, category=c, title=title, body=body, author=me, status="pending" if pending else "published")
        attach(d.get("attachments"), me, thread=t)
        auto_follow(me, "thread", t.id)
        if pending:
            notify([m for m in U.objects.filter(pk__in=mgr_ids(c.forum))], T("Wacht op goedkeuring: {0}", title), T("{0} wil een onderwerp plaatsen in {1}.", name(me), c.title), link(t))
        else:
            notify([u for u in U.objects.filter(pk__in=followers(c.forum, c, None)) if u.pk != me.pk], T("Nieuw onderwerp in {0}", c.title), f"{name(me)}: {title}", link(t))
        return {"id": t.id, "status": t.status}

    def post_row(p, me, forum, cat, mgrs):
        return {"id": p.id, "parent_id": p.parent_id, "body": p.body, "status": p.status, "author": person(p.author) | {"badge": ("manager" if p.author_id in mgrs else "")}, "created_at": p.created_at, "edited_at": p.edited_at,
                "likes": p.reactions.count(), "liked": authed(me) and p.reactions.filter(user=me).exists(), "attachments": [att_json(a) for a in p.attachments.all()],
                "can_edit": can_edit_item(me, forum, p, cat), "can_delete": can_delete_item(me, forum, p, cat), "reported": False}

    @system.route("GET", "threads/<id>", public=True)
    def thread_detail(request, id):  # noqa: A002
        me, q = request.user, request.query_params
        t = Thread.objects.filter(pk=id).select_related("forum", "category", "author").first() if str(id).isdigit() else None
        if not t or not may_view(me, t.forum):
            return bad(T("Dit onderwerp bestaat niet of is niet voor jou."), 404)
        f, c = t.forum, t.category
        mod = allowed(me, f, "moderate", c)
        if t.status != "published" and not (mod or (authed(me) and t.author_id == me.id)):
            return bad(T("Dit onderwerp bestaat niet of is niet voor jou."), 404)
        Thread.objects.filter(pk=t.pk).update(views=models.F("views") + 1)
        qs = t.posts.select_related("author").prefetch_related("attachments")
        qs = qs if mod else qs.filter(Q(status="published") | (Q(author=me, status="pending") if authed(me) else Q(pk__in=[])))
        per = int(board()["posts_per_page"])
        total = qs.count()
        page = int(q.get("page")) if str(q.get("page") or "").isdigit() and int(q.get("page")) > 0 else 1
        if q.get("page") == "last":
            page = max(1, -(-total // per))
        mgrs = mgr_ids(f)
        rows = list(qs.order_by("created_at")[(page - 1) * per: page * per])
        first = {"id": 0, "body": t.body, "author": person(t.author) | {"badge": ("manager" if t.author_id in mgrs else "")}, "created_at": t.created_at, "edited_at": t.edited_at, "likes": t.reactions.count(),
                 "liked": authed(me) and t.reactions.filter(user=me).exists(), "attachments": [att_json(a) for a in t.attachments.all()], "can_edit": can_edit_item(me, f, t, c), "can_delete": can_delete_item(me, f, t, c)}
        can = my_perms(me, f, c)
        can["can_reply"] = bool(allowed(me, f, "reply", c) and f.status == "open" and not t.locked and not c.locked)
        follow = (Follow.objects.filter(user=me, kind="thread", target=t.id).values_list("level", flat=True).first() or "") if authed(me) else ""
        return {"thread": {**thread_row(t, me), "body": t.body, "edited_at": t.edited_at}, "first": first, "posts": [post_row(p, me, f, c, mgrs) for p in rows], "total": total, "page": page, "pages": max(1, -(-total // per)),
                "forum": {"id": f.id, "title": f.title}, "path": [{"id": a.id, "title": a.title} for a in reversed(ancestors(c))], "can": can, "following": follow, "settings": {"reactions": bool(feature(f, "reactions")), "reports": bool(feature(f, "allow_reports")), "attachments": bool(feature(f, "allow_attachments") and allowed(me, f, "upload", c))}}

    @system.route("PUT", "threads/<id>")
    def thread_edit(request, id):  # noqa: A002
        t = Thread.objects.filter(pk=id).select_related("forum", "category").first() if str(id).isdigit() else None
        if not t or not can_edit_item(request.user, t.forum, t, t.category):
            return bad(T("Je mag dit onderwerp niet wijzigen."), 403)
        d = request.data
        if "title" in d:
            title = str(d.get("title") or "").strip()[:200]
            if not title:
                return bad(T("Geef het onderwerp een titel."))
            t.title = title
        if "body" in d:
            try:
                t.body = body_ok(d.get("body"), "")
            except ValueError as e:
                return bad(str(e))
        t.edited_at = now()
        t.save()
        attach(d.get("attachments"), request.user, thread=t)
        return thread_detail(request, id=t.id)

    @system.route("DELETE", "threads/<id>")
    def thread_delete(request, id):  # noqa: A002
        t = Thread.objects.filter(pk=id).select_related("forum", "category").first() if str(id).isdigit() else None
        if not t or not can_delete_item(request.user, t.forum, t, t.category):
            return bad(T("Je mag dit onderwerp niet verwijderen."), 403)
        for att in Attachment.objects.filter(Q(thread=t) | Q(post__thread=t)):
            try:
                (files_dir() / att.key).unlink(missing_ok=True)
            except OSError:
                pass
        Follow.objects.filter(kind="thread", target=t.pk).delete()
        t.delete()
        return {"ok": True}

    @system.route("POST", "threads/<id>/action")
    def thread_action(request, id):  # noqa: A002
        me, d = request.user, request.data
        t = Thread.objects.filter(pk=id).select_related("forum", "category").first() if str(id).isdigit() else None
        if not t or not allowed(me, t.forum, "moderate", t.category):
            return bad(T("Je mag dit niet doen."), 403)
        a = d.get("action")
        if a in ("pin", "unpin"):
            t.pinned = a == "pin"
        elif a in ("lock", "unlock"):
            t.locked = a == "lock"
        elif a in ("hide", "unhide"):
            t.status = "hidden" if a == "hide" else "published"
        elif a == "approve":
            t.status = "published"
            notify([t.author] if t.author_id else [], T("Je onderwerp is goedgekeurd"), t.title, link(t))
            notify([u for u in U.objects.filter(pk__in=followers(t.forum, t.category, None)) if u.pk != t.author_id], T("Nieuw onderwerp in {0}", t.category.title), t.title, link(t))
        elif a == "move":
            dest = Category.objects.filter(pk=d.get("category_id"), forum=t.forum).first()
            if not dest:
                return bad(T("Kies een groep in dit forum."))
            t.category = dest
        else:
            return bad(T("Onbekende actie."))
        t.save()
        return thread_detail(request, id=t.id)

    @system.route("POST", "threads/<id>/posts")
    def post_create(request, id):  # noqa: A002
        me, d = request.user, request.data
        t = Thread.objects.filter(pk=id).select_related("forum", "category", "author").first() if str(id).isdigit() else None
        if not t or not may_view(me, t.forum) or t.status == "hidden":
            return bad(T("Dit onderwerp bestaat niet of is niet voor jou."), 404)
        f, c = t.forum, t.category
        if not allowed(me, f, "reply", c) or f.status != "open" or t.locked or c.locked:
            return bad(T("Je mag hier niet reageren."), 403)
        try:
            body = body_ok(d.get("body"), "")
        except ValueError as e:
            return bad(str(e))
        if flooded(me, f, c):
            return bad(T("Even rustig: wacht een paar seconden voor je opnieuw schrijft."), 429)
        parent = Post.objects.filter(pk=d.get("parent_id"), thread=t).select_related("author").first() if d.get("parent_id") else None
        pending = pending_needed(me, f, c)
        p = Post.objects.create(thread=t, parent=parent, author=me, body=body, status="pending" if pending else "published")
        attach(d.get("attachments"), me, post=p)
        auto_follow(me, "thread", t.id)
        if not pending:
            Thread.objects.filter(pk=t.pk).update(reply_count=Post.objects.filter(thread=t, status="published").count(), last_post_at=now())
            told = {me.pk}
            direct = []
            for u in (parent.author if parent and parent.author_id else None, t.author):  # the person you answer and the starter of the discussion
                if u and u.pk not in told:
                    told.add(u.pk)
                    direct.append(u)
            notify(direct, T("{0} reageert op je bericht", name(me)), f"{t.title}: {snippet(body, 100)}", link(t))
            rest = followers(f, c, t, level_in=("all",)) - told
            notify(list(U.objects.filter(pk__in=rest)), T("Nieuwe reactie: {0}", t.title), f"{name(me)}: {snippet(body, 100)}", link(t))
        else:
            notify(list(U.objects.filter(pk__in=mgr_ids(f))), T("Wacht op goedkeuring: {0}", t.title), T("{0} heeft gereageerd.", name(me)), link(t))
        return {"id": p.id, "status": p.status}

    @system.route("PUT", "posts/<id>")
    def post_edit(request, id):  # noqa: A002
        p = Post.objects.filter(pk=id).select_related("thread__forum", "thread__category").first() if str(id).isdigit() else None
        if not p or not can_edit_item(request.user, p.thread.forum, p, p.thread.category):
            return bad(T("Je mag dit bericht niet wijzigen."), 403)
        try:
            p.body = body_ok(request.data.get("body"), "")
        except ValueError as e:
            return bad(str(e))
        p.edited_at = now()
        p.save()
        attach(request.data.get("attachments"), request.user, post=p)
        return {"id": p.id}

    @system.route("DELETE", "posts/<id>")
    def post_delete_(request, id):  # noqa: A002
        p = Post.objects.filter(pk=id).select_related("thread__forum", "thread__category").first() if str(id).isdigit() else None
        if not p or not can_delete_item(request.user, p.thread.forum, p, p.thread.category):
            return bad(T("Je mag dit bericht niet verwijderen."), 403)
        for att in p.attachments.all():
            try:
                (files_dir() / att.key).unlink(missing_ok=True)
            except OSError:
                pass
        t = p.thread
        p.delete()
        Thread.objects.filter(pk=t.pk).update(reply_count=Post.objects.filter(thread=t, status="published").count())
        return {"ok": True}

    @system.route("POST", "posts/<id>/action")
    def post_action(request, id):  # noqa: A002
        p = Post.objects.filter(pk=id).select_related("thread__forum", "thread__category", "author").first() if str(id).isdigit() else None
        if not p or not allowed(request.user, p.thread.forum, "moderate", p.thread.category):
            return bad(T("Je mag dit niet doen."), 403)
        a = request.data.get("action")
        if a not in ("hide", "unhide", "approve"):
            return bad(T("Onbekende actie."))
        p.status = "hidden" if a == "hide" else "published"
        p.save(update_fields=["status"])
        t = p.thread
        Thread.objects.filter(pk=t.pk).update(reply_count=Post.objects.filter(thread=t, status="published").count())
        if a == "approve":
            notify([p.author] if p.author_id else [], T("Je reactie is goedgekeurd"), t.title, link(t))
        return {"id": p.id, "status": p.status}

    # ───────────── likes, reports, following, search ─────────────
    def target(d):
        if str(d.get("post_id") or "").isdigit():
            p = Post.objects.filter(pk=d["post_id"]).select_related("thread__forum", "thread__category").first()
            return (p, p.thread) if p else (None, None)
        if str(d.get("thread_id") or "").isdigit():
            t = Thread.objects.filter(pk=d["thread_id"]).select_related("forum", "category").first()
            return (None, t)
        return (None, None)

    @system.route("POST", "react")
    def react(request):
        me = request.user
        p, t = target(request.data)
        if not t or not may_view(me, t.forum) or not allowed(me, t.forum, "react", t.category) or not feature(t.forum, "reactions"):
            return bad(T("Je mag hier niet op reageren."), 403)
        qs = Reaction.objects.filter(user=me, post=p) if p else Reaction.objects.filter(user=me, thread=t, post__isnull=True)
        if qs.exists():
            qs.delete()
            liked = False
        else:
            Reaction.objects.create(user=me, thread=None if p else t, post=p)
            liked = True
            owner = (p.author if p else t.author)
            if owner and owner.pk != me.pk:
                notify([owner], T("{0} vindt je bericht leuk", name(me)), t.title, link(t))
        count = Reaction.objects.filter(post=p).count() if p else Reaction.objects.filter(thread=t).count()
        return {"liked": liked, "count": count}

    @system.route("POST", "report")
    def report(request):
        me = request.user
        p, t = target(request.data)
        if not t or not may_view(me, t.forum) or not feature(t.forum, "allow_reports"):
            return bad(T("Je kunt dit niet melden."), 403)
        Report.objects.create(reporter=me, thread=None if p else t, post=p, reason=str(request.data.get("reason") or "")[:1000])
        notify(list(U.objects.filter(pk__in=mgr_ids(t.forum))), T("Bericht gemeld in {0}", t.forum.title), t.title, link(t))
        return {"ok": True}

    @system.route("POST", "follow")
    def follow(request):
        me, d = request.user, request.data
        kind, pk, level = d.get("kind"), d.get("id"), d.get("level") or "all"
        obj = {"forum": Forum, "category": Category, "thread": Thread}.get(kind)
        o = obj.objects.filter(pk=pk).first() if obj and str(pk).isdigit() else None
        fo = o if kind == "forum" else (o.forum if o else None)
        if not o or not may_view(me, fo):
            return bad(T("Niet gevonden."), 404)
        if level == "none":
            Follow.objects.filter(user=me, kind=kind, target=o.pk).delete()
            return {"level": ""}
        if level not in ("all", "replies", "off"):
            return bad(T("Onbekende keuze."))
        Follow.objects.update_or_create(user=me, kind=kind, target=o.pk, defaults={"level": level})
        return {"level": level}

    @system.route("GET", "follow")
    def follows(request):
        me, out = request.user, []
        for f in Follow.objects.filter(user=me).exclude(level="off").order_by("-created_at")[:200]:
            o = {"forum": Forum, "category": Category, "thread": Thread}[f.kind].objects.filter(pk=f.target).first()
            if o:
                out.append({"kind": f.kind, "id": f.target, "level": f.level, "title": o.title})
        return {"follows": out}

    @system.route("GET", "search", public=True)
    def search(request):
        me, q = request.user, str(request.query_params.get("q") or "").strip()
        if len(q) < 2:
            return {"threads": []}
        ids = [f.id for f in visible_forums(me)]
        mod_forums = {f.id for f in Forum.objects.filter(pk__in=ids) if user_level(me, f) >= 2}
        with_post = set(Post.objects.filter(body__icontains=q, thread__forum_id__in=ids).values_list("thread_id", flat=True))  # (no reverse names in a query: the models of a plugin are not in the registry of the system)
        qs = Thread.objects.filter(forum_id__in=ids).filter(Q(title__icontains=q) | Q(body__icontains=q) | Q(pk__in=with_post)).select_related("author", "forum").order_by("-last_post_at")[:60]
        rows = [t for t in qs if t.status == "published" or t.forum_id in mod_forums or (authed(me) and t.author_id == me.id)]
        return {"threads": [{**thread_row(t, me), "forum": t.forum.title} for t in rows[:40]]}

    @system.route("GET", "mine")
    def mine(request):
        me = request.user
        return {"threads": [thread_row(t, me) | {"forum": t.forum.title} for t in Thread.objects.filter(author=me).select_related("forum", "author").order_by("-created_at")[:30]],
                "forums": [forum_row(f, me) for f in Forum.objects.filter(Q(created_by=me) | Q(pk__in=list(Manager.objects.filter(user=me).values_list("forum_id", flat=True)))).distinct()[:30]]}

    # ───────────── administrators ─────────────
    def admin_only(request):
        return None if site_admin(request.user) else bad(T("Alleen voor beheerders."), 403)

    @system.route("GET", "admin/overview")
    def admin_overview(request):
        if (r := admin_only(request)):
            return r
        week = now() - timedelta(days=7)
        size = Attachment.objects.aggregate(s=models.Sum("size"))["s"] or 0
        return {"forums": Forum.objects.count(), "groups": Category.objects.count(), "threads": Thread.objects.count(), "posts": Post.objects.count(), "managers": Manager.objects.count(), "follows": Follow.objects.count(),
                "attachments": Attachment.objects.count(), "attachment_bytes": size, "reports": Report.objects.filter(status="open").count(), "pending": Thread.objects.filter(status="pending").count() + Post.objects.filter(status="pending").count(),
                "threads_week": Thread.objects.filter(created_at__gte=week).count(), "posts_week": Post.objects.filter(created_at__gte=week).count(),
                "active_users": len(set(Thread.objects.filter(created_at__gte=week).values_list("author_id", flat=True)) | set(Post.objects.filter(created_at__gte=week).values_list("author_id", flat=True))),
                "latest": [thread_row(t, request.user) | {"forum": t.forum.title} for t in Thread.objects.select_related("forum", "author").order_by("-created_at")[:8]]}

    @system.route("GET", "admin/forums")
    def admin_forums(request):
        if (r := admin_only(request)):
            return r
        return {"forums": [forum_row(f, request.user) for f in Forum.objects.order_by("-created_at")]}

    @system.route("PUT", "admin/forums/<id>")
    def admin_forum_put(request, id):  # noqa: A002
        if (r := admin_only(request)):
            return r
        f = forum_of(id)
        if not f:
            return bad(T("Niet gevonden."), 404)
        d = request.data
        if d.get("status") in ("open", "closed", "archived", "pending"):
            f.status = d["status"]
        if str(d.get("owner_id") or "").isdigit() and U.objects.filter(pk=d["owner_id"]).exists():
            f.created_by_id = int(d["owner_id"])
            Manager.objects.get_or_create(forum=f, category=None, user_id=int(d["owner_id"]), defaults={"role": "owner", "added_by": request.user})
        f.save()
        return forum_row(f, request.user)

    @system.route("DELETE", "admin/forums/<id>")
    def admin_forum_delete(request, id):  # noqa: A002
        if (r := admin_only(request)):
            return r
        f = forum_of(id)
        if not f:
            return bad(T("Niet gevonden."), 404)
        drop_forum(f)
        return {"ok": True}

    @system.route("GET", "admin/groups")
    def admin_groups(request):
        if (r := admin_only(request)):
            return r
        rows = []
        for c in Category.objects.select_related("forum", "parent", "created_by").order_by("forum__title", "parent_id", "position")[:1000]:
            rows.append(cat_row(c, request.user) | {"forum": c.forum.title, "depth": depth(c) - 1, "parent": c.parent.title if c.parent_id else None,
                                                    "managers": [person(m.user) | {"role": m.role} for m in Manager.objects.filter(category=c).select_related("user")]})
        return {"groups": rows}

    @system.route("GET", "admin/managers")
    def admin_managers(request):
        if (r := admin_only(request)):
            return r
        return {"managers": [manager_row(m) for m in Manager.objects.select_related("user", "category", "forum", "added_by").order_by("forum__title", "category_id", "role")[:1000]]}

    @system.route("GET", "admin/reports")
    def admin_reports(request):
        if (r := admin_only(request)):
            return r
        rows = []
        for rp in Report.objects.select_related("reporter", "thread__forum", "post__thread__forum").order_by("status", "-created_at")[:200]:
            t = rp.thread or (rp.post.thread if rp.post_id else None)
            rows.append({"id": rp.id, "status": rp.status, "reason": rp.reason, "reporter": person(rp.reporter), "created_at": rp.created_at, "thread_id": t.id if t else None, "title": t.title if t else "", "forum": t.forum.title if t else "",
                         "excerpt": snippet(rp.post.body if rp.post_id else (t.body if t else "")), "post_id": rp.post_id})
        return {"reports": rows}

    @system.route("POST", "admin/reports/<id>")
    def admin_report_do(request, id):  # noqa: A002
        if (r := admin_only(request)):
            return r
        rp = Report.objects.filter(pk=id).select_related("thread", "post").first()
        if not rp:
            return bad(T("Niet gevonden."), 404)
        a = request.data.get("action")
        if a == "hide":
            if rp.post_id:
                Post.objects.filter(pk=rp.post_id).update(status="hidden")
            elif rp.thread_id:
                Thread.objects.filter(pk=rp.thread_id).update(status="hidden")
        elif a == "delete":
            target_obj = rp.post or rp.thread
            for att in (target_obj.attachments.all() if target_obj else []):
                try:
                    (files_dir() / att.key).unlink(missing_ok=True)
                except OSError:
                    pass
            if target_obj:
                target_obj.delete()
            return {"ok": True}
        elif a != "dismiss":
            return bad(T("Onbekende actie."))
        rp.status, rp.handled_by = "done", request.user
        rp.save(update_fields=["status", "handled_by"])
        return {"ok": True}

    @system.route("GET", "admin/board")
    def admin_board_get(request):
        if (r := admin_only(request)):
            return r
        return {"board": board(), "levels": list(LEVELS), "actions": list(ACTIONS), "groups": [{"id": g.id, "name": g.name} for g in UserGroup.objects.order_by("name")[:200]]}

    @system.route("PUT", "admin/board")
    def admin_board_put(request):
        if (r := admin_only(request)):
            return r
        d, cur = request.data, board()
        new = dict(cur)
        for k, v in DEFAULT_BOARD.items():
            if k not in d or k == "perms":
                continue
            if isinstance(v, bool):
                new[k] = bool(d[k])
            elif isinstance(v, int):
                try:
                    new[k] = max(0, min(int(d[k]), 100000))
                except (TypeError, ValueError):
                    pass
            elif k == "welcome_text":
                new[k] = rich(d[k], 2000)
            elif k == "default_visibility" and d[k] in ("public", "members", "private"):
                new[k] = d[k]
        if isinstance(d.get("perms"), dict):
            new["perms"] = {a: _perm(d["perms"].get(a), DEFAULT_PERMS[a]) for a in ACTIONS}
        Settings.objects.update_or_create(pk=1, defaults={"data": new})
        return admin_board_get(request)

    # ───────────── blocks on pages (system objects) ─────────────
    def block_limit(request, n=6):
        v = str(request.query_params.get("limit") or "")
        return min(max(int(v), 1), 30) if v.isdigit() else n

    @system.route("GET", "blocks/forums", public=True)
    def blocks_forums(request):
        me = request.user
        return {"forums": [forum_row(f, me) for f in visible_forums(me)[: block_limit(request, 12)]], "can_create": bool(authed(me) and board()["members_create_forums"])}

    @system.route("GET", "blocks/latest", public=True)
    def blocks_latest(request):
        me = request.user
        ids = [f.id for f in visible_forums(me)]
        fid = request.query_params.get("forum")
        qs = Thread.objects.filter(forum_id__in=ids, status="published").select_related("author", "forum")
        qs = qs.filter(forum_id=fid) if str(fid or "").isdigit() else qs
        return {"threads": [thread_row(t, me) | {"forum": t.forum.title} for t in qs.order_by("-last_post_at")[: block_limit(request)]]}

    @system.route("GET", "blocks/popular", public=True)
    def blocks_popular(request):
        me = request.user
        ids = [f.id for f in visible_forums(me)]
        qs = Thread.objects.filter(forum_id__in=ids, status="published", last_post_at__gte=now() - timedelta(days=60)).select_related("author", "forum").order_by("-reply_count", "-views")
        return {"threads": [thread_row(t, me) | {"forum": t.forum.title} for t in qs[: block_limit(request)]]}

    @system.route("GET", "blocks/forum/<id>", public=True)
    def blocks_forum(request, id):  # noqa: A002
        me = request.user
        f = forum_of(id)
        if not f or not may_view(me, f):
            return bad(T("Dit forum bestaat niet of is niet voor jou."), 404)
        return {"forum": forum_row(f, me), "tree": cat_tree(f, me)}

    @system.route("GET", "blocks/choices", public=True)
    def blocks_choices(request):
        return {"forums": [{"id": f.id, "title": f.title, "slug": f.slug} for f in visible_forums(request.user)]}

    def parts():
        return [
            {"key": "forums", "title": "Forum: alle forums", "file": "web/block.html", "query": {"view": "forums"}},
            {"key": "latest", "title": "Forum: laatste onderwerpen", "file": "web/block.html", "query": {"view": "latest", "limit": "6"}},
            {"key": "popular", "title": "Forum: populaire onderwerpen", "file": "web/block.html", "query": {"view": "popular", "limit": "6"}},
            {"key": "forum", "title": "Forum: één forum met zijn groepen", "file": "web/block.html", "query": {"view": "forum"}},
            {"key": "start", "title": "Forum: nieuw onderwerp starten", "file": "web/block.html", "query": {"view": "start"}},
            {"key": "search", "title": "Forum: zoeken", "file": "web/block.html", "query": {"view": "search"}},
        ]

    system.provide("parts", parts)
