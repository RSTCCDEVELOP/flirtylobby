// Copyright & Ownership Notice
// easy2Edit is the exclusive legal property of RST Coaching & Consultancy B.V. (RSTCC),
// owned by Ronald Stolk. All rights reserved. Any unauthorized use, copying, modification,
// reproduction, distribution, or commercial exploitation of Easy2Edit, including its source code,
// is strictly prohibited without prior written permission from Ronald Stolk or RSTCC.
// website https://rstcc.net

"use strict";
/* Forum: the user pages (home, forum, group, discussion, forum settings). All texts go through t("…") so every language gets them.
   Texts that are only shown via a variable, listed here so they are found:
   t("Openbaar") t("Leden") t("Privé") t("Bezoekers") t("Beheerders van groep/forum") t("Alleen eigenaars en admins") t("Niemand") t("Gesloten") t("Gearchiveerd") t("Wacht op goedkeuring")
   t("Alles") t("Alleen reacties op mij") t("Dempen") t("Niet volgen") t("Laatste activiteit") t("Nieuwste") t("Populair") t("Open") t("Algemeen") t("Wie mag wat") t("Beheerders") t("Systeemrechten")
   t("Bekijken") t("Bewerken") t("Verwijderen") t("Forum en groepen bekijken") t("Groepen maken") t("Onderwerpen starten") t("Reageren") t("Bijlagen toevoegen") t("Waarderen (hartje)")
   t("Eigen berichten wijzigen") t("Eigen berichten verwijderen") t("Modereren") t("Bijlagen toestaan") t("Foto's toestaan") t("Video's toestaan") t("Bestanden toestaan (pdf, zip, …)")
   t("Nieuwe berichten eerst laten goedkeuren") t("Melden toestaan") t("Hartjes (waarderingen)") t("Niveaus van subgroepen") t("Eigenaar") t("Beheerder") */
var ROUTE = "/plugins/run/forum/";
var t = function () { return system.t.apply(system, arguments); };
var app = document.getElementById("app");
var S = { me: null, origin: "", slug: "", stack: [], cur: null, follows: null, names: {}, board: {} };
var NS = "http://www.w3.org/2000/svg";

// ── small helpers ──
function h(tag, props) {
  var el = document.createElement(tag), kids = Array.prototype.slice.call(arguments, 2);
  Object.keys(props || {}).forEach(function (k) {
    var v = props[k];
    if (k === "class") el.className = v; else if (k.indexOf("on") === 0) el.addEventListener(k.slice(2), v);
    else if (k === "style") el.style.cssText = v; else if (k === "value") el.value = v; else if (v === true) el.setAttribute(k, ""); else if (v !== false && v != null) el.setAttribute(k, v);
  });
  (function add(list) { list.forEach(function (c) { if (Array.isArray(c)) add(c); else if (c != null && c !== false) el.appendChild(typeof c === "object" ? c : document.createTextNode(String(c))); }); })(kids);
  return el;
}
var ICONS = {
  chat: '<path d="M21 12a8 8 0 0 1-11.6 7.1L4 20l1-4.6A8 8 0 1 1 21 12z"/>', folder: '<path d="M3 6a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>',
  plus: '<path d="M12 5v14M5 12h14"/>', pin: '<path d="M12 17v5M9 3h6l-1 6 3 3v2H7v-2l3-3z"/>', lock: '<rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/>',
  heart: '<path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.7l-1-1.1a5.5 5.5 0 0 0-7.8 7.8l1 1.1L12 21l7.8-7.5 1-1.1a5.5 5.5 0 0 0 0-7.8z"/>', flag: '<path d="M4 22V4M4 4h13l-2 4 2 4H4"/>',
  photo: '<rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><path d="M21 15l-5-5L5 21"/>', video: '<rect x="2" y="5" width="14" height="14" rx="2"/><path d="M16 10l6-3v10l-6-3"/>',
  paperclip: '<path d="M21 11l-9 9a5 5 0 0 1-7-7l9-9a3.5 3.5 0 0 1 5 5l-9 9a2 2 0 0 1-3-3l8-8"/>', bell: '<path d="M18 8a6 6 0 0 0-12 0c0 7-3 9-3 9h18s-3-2-3-9M13.7 21a2 2 0 0 1-3.4 0"/>',
  "bell-off": '<path d="M13.7 21a2 2 0 0 1-3.4 0M18.6 13A17 17 0 0 1 18 8a6 6 0 0 0-11.7-1.7M6 8c0 7-3 9-3 9h14M2 2l20 20"/>', edit: '<path d="M12 20h9M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4z"/>',
  trash: '<path d="M3 6h18M8 6V4h8v2M19 6l-1 14H6L5 6M10 11v6M14 11v6"/>', more: '<circle cx="5" cy="12" r="1"/><circle cx="12" cy="12" r="1"/><circle cx="19" cy="12" r="1"/>',
  search: '<circle cx="11" cy="11" r="7"/><path d="M21 21l-4.3-4.3"/>', shield: '<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>',
  users: '<path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.9M16 3.1a4 4 0 0 1 0 7.8"/>',
  settings: '<path d="M4 21v-7M4 10V3M12 21v-9M12 8V3M20 21v-5M20 12V3M1 14h6M9 8h6M17 16h6"/>', reply: '<path d="M9 14L4 9l5-5M4 9h10a6 6 0 0 1 6 6v3"/>', check: '<path d="M20 6L9 17l-5-5"/>',
  x: '<path d="M18 6L6 18M6 6l12 12"/>', right: '<path d="M9 6l6 6-6 6"/>', down: '<path d="M6 9l6 6 6-6"/>', back: '<path d="M19 12H5M12 19l-7-7 7-7"/>', eye: '<path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8S1 12 1 12z"/><circle cx="12" cy="12" r="3"/>',
  bold: '<path d="M6 4h8a4 4 0 0 1 0 8H6zM6 12h9a4 4 0 0 1 0 8H6z"/>', italic: '<path d="M19 4h-9M14 20H5M15 4L9 20"/>', ul: '<path d="M8 6h13M8 12h13M8 18h13M3 6h.01M3 12h.01M3 18h.01"/>',
  ol: '<path d="M10 6h11M10 12h11M10 18h11M4 6h1v4M4 10h2M6 18H4c0-1 2-2 2-3s-1-1.5-2-1"/>', link: '<path d="M10 13a5 5 0 0 0 7.5.5l3-3a5 5 0 0 0-7-7l-1.7 1.7M14 11a5 5 0 0 0-7.5-.5l-3 3a5 5 0 0 0 7 7l1.7-1.7"/>',
  quote: '<path d="M3 21c3 0 7-1 7-8V5H3v8h4c0 3-2 4-4 4zM14 21c3 0 7-1 7-8V5h-7v8h4c0 3-2 4-4 4z"/>', file: '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8zM14 2v6h6"/>',
  move: '<path d="M5 9l-3 3 3 3M9 5l3-3 3 3M15 19l-3 3-3-3M19 9l3 3-3 3M2 12h20M12 2v20"/>', clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>'
};
function icon(name, size) {
  var s = document.createElementNS(NS, "svg");
  s.setAttribute("viewBox", "0 0 24 24"); s.setAttribute("width", size || 18); s.setAttribute("height", size || 18); s.setAttribute("fill", "none"); s.setAttribute("stroke", "currentColor");
  s.setAttribute("stroke-width", "2"); s.setAttribute("stroke-linecap", "round"); s.setAttribute("stroke-linejoin", "round"); s.setAttribute("aria-hidden", "true"); s.setAttribute("class", "ico");
  s.innerHTML = ICONS[name] || ICONS.chat;  // (own static strings only)
  return s;
}
function iconBtn(name, label, fn, cls) { return h("button", { type: "button", class: "ib " + (cls || ""), "aria-label": label, title: label, onclick: fn }, icon(name)); }
function btn(label, cls, fn, ic) { return h("button", { type: "button", class: "btn " + (cls || ""), onclick: fn }, ic ? icon(ic, 16) : null, label); }
var call = function (path, method, body) { return system.api(ROUTE + path, { method: method || "GET", body: body }); };
/* where dialogs, menus and lightboxes go: the layer on top of the whole page when the page runs inside the dashboard (system.portal), else the body of the frame */
function layer() { return (window.system && system.portal) ? system.portal() : document.body; }
var lang = function () { return document.documentElement.lang || "nl"; };
function ago(iso) {
  if (!iso) return "";
  var d = new Date(iso), s = (d - Date.now()) / 1000;
  if (isNaN(d)) return "";
  try {
    var r = new Intl.RelativeTimeFormat(lang(), { numeric: "auto" }), a = Math.abs(s);
    if (a < 60) return r.format(0, "second");
    if (a < 3600) return r.format(Math.round(s / 60), "minute");
    if (a < 86400) return r.format(Math.round(s / 3600), "hour");
    if (a < 86400 * 30) return r.format(Math.round(s / 86400), "day");
  } catch (e) { /* fall through to a date */ }
  return d.toLocaleDateString(lang(), { day: "numeric", month: "short", year: "numeric" });
}
function timeEl(iso) { return h("time", { datetime: iso || "", title: iso ? new Date(iso).toLocaleString(lang()) : "" }, ago(iso)); }
function size(n) { n = Number(n) || 0; return n < 1024 ? n + " B" : n < 1048576 ? (n / 1024).toFixed(0) + " KB" : (n / 1048576).toFixed(1) + " MB"; }
function furl(u) { return /^https?:/i.test(u || "") ? u : (S.origin || "") + (u || ""); }
function errText(e) { return e && e.message ? e.message : String(e || ""); }
function alertBox(text, ok) { return h("div", { class: "alert" + (ok ? " ok" : ""), role: ok ? "status" : "alert" }, text); }
function avatar(p, big) { p = p || {}; return h("span", { class: "avatar" + (big ? " big" : ""), "aria-hidden": "true" }, p.initials || "?"); }
function seq(list) { return list.reduce(function (a, b) { return a.concat(b); }, []); }
var VIS = { public: "Openbaar", members: "Leden", private: "Privé" };
function visBadge(v) { return h("span", { class: "badge" }, icon(v === "public" ? "eye" : v === "members" ? "users" : "lock", 12), t(VIS[v] || VIS.members)); }
function statusBadge(st) {
  if (st === "closed") return h("span", { class: "badge warn" }, t("Gesloten"));
  if (st === "archived") return h("span", { class: "badge" }, t("Gearchiveerd"));
  if (st === "pending") return h("span", { class: "badge warn" }, t("Wacht op goedkeuring"));
  return null;
}
function stat(ic, n, label) { return h("span", { class: "stat", title: label }, icon(ic, 14), h("b", {}, String(n || 0)), h("span", { class: "sr" }, label)); }
function empty(text, ic) { return h("div", { class: "empty" }, icon(ic || "chat", 28), h("p", {}, text)); }
function loginNote() { return h("div", { class: "note" }, icon("lock", 16), h("span", {}, t("Log in om mee te doen."))); }

// ── rich text: own sanitizing pass (also for what the server sends) ──
var ALLOWED = { b: 1, strong: 1, i: 1, em: 1, u: 1, s: 1, p: 1, br: 1, ul: 1, ol: 1, li: 1, a: 1, blockquote: 1, code: 1, h2: 1, h3: 1, span: 1 };
var DROP = /^(script|style|iframe|object|embed|svg|math|template|noscript|link|meta|form|textarea|select|button|input|video|audio|img)$/;
function cleanInto(src, dst) {
  Array.prototype.forEach.call(src.childNodes, function (n) {
    if (n.nodeType === 3) { dst.appendChild(document.createTextNode(n.nodeValue)); return; }
    if (n.nodeType !== 1) return;
    var tag = n.tagName.toLowerCase();
    if (DROP.test(tag)) return;
    if (!ALLOWED[tag]) { cleanInto(n, dst); return; }
    var el = document.createElement(tag);
    if (tag === "a") {
      var href = (n.getAttribute("href") || "").trim();
      if (/^(https?:|mailto:|tel:)/i.test(href)) { el.setAttribute("href", href); el.setAttribute("target", "_blank"); el.setAttribute("rel", "noopener noreferrer nofollow"); }
    }
    cleanInto(n, el); dst.appendChild(el);
  });
}
function cleanHtml(html) {
  var doc = new DOMParser().parseFromString("<body>" + html, "text/html"), out = document.createElement("div");
  cleanInto(doc.body, out);
  return out;
}
function isRich(v) { return typeof v === "string" && v.indexOf("html:") === 0; }
function richEl(v, cls) {
  var el = h("div", { class: "rich " + (cls || "") });
  v = v == null ? "" : String(v);
  if (isRich(v)) Array.prototype.slice.call(cleanHtml(v.slice(5)).childNodes).forEach(function (n) { el.appendChild(n); });
  else { el.textContent = v; el.classList.add("plain"); }
  return el;
}
function plainOf(v) { v = String(v || ""); if (!isRich(v)) return v; return cleanHtml(v.slice(5)).textContent; }

// ── modal and menu ──
function modal(title, content, wide) {
  var prev = document.activeElement;
  var ov = h("div", { class: "overlay", onmousedown: function (ev) { if (ev.target === ov) close(); } },
    h("div", { class: "modal" + (wide ? " wide" : ""), role: "dialog", "aria-modal": "true", "aria-label": title },
      h("div", { class: "row between" }, h("h2", {}, title), iconBtn("x", t("Sluiten"), function () { close(); })), content));
  function key(ev) { if (!ov.isConnected) { document.removeEventListener("keydown", key); return; } if (ev.key === "Escape") close(); }
  function close() { document.removeEventListener("keydown", key); ov.remove(); if (prev && prev.focus) try { prev.focus(); } catch (e) { /* gone */ } }
  document.addEventListener("keydown", key);
  layer().appendChild(ov);
  var f = ov.querySelector("input,select,[contenteditable],textarea"); if (f) f.focus();
  return close;
}
function menu(anchorBtn, items) {
  var box = null;
  function shut() { if (box) { box.remove(); box = null; document.removeEventListener("mousedown", out, true); } }
  function out(ev) { if (box && !box.isConnected) { shut(); return; } if (box && !box.contains(ev.target) && ev.target !== anchorBtn) shut(); }
  anchorBtn.addEventListener("click", function () {
    if (box) { shut(); return; }
    box = h("div", { class: "menu", role: "menu" }, items.filter(Boolean).map(function (it) {
      return h("button", { type: "button", role: "menuitem", class: it.danger ? "danger" : "", onclick: function () { shut(); it.fn(); } }, icon(it.icon || "check", 15), it.label);
    }));
    anchorBtn.parentNode.appendChild(box);
    document.addEventListener("mousedown", out, true);
  });
}
function tabs(list, current, pick) {
  return h("div", { class: "tabs", role: "tablist" }, list.map(function (x) {
    return h("button", { type: "button", role: "tab", class: x[0] === current ? "on" : "", "aria-selected": x[0] === current ? "true" : "false", onclick: function () { pick(x[0]); } }, x[1]);
  }));
}
function pager(page, pages, go) {
  if (pages < 2) return null;
  return h("nav", { class: "pager", "aria-label": t("Pagina's") },
    h("button", { type: "button", class: "btn", disabled: page <= 1, onclick: function () { go(page - 1); } }, t("Vorige")),
    h("span", { class: "muted" }, t("Pagina {0} van {1}", page, pages)),
    h("button", { type: "button", class: "btn", disabled: page >= pages, onclick: function () { go(page + 1); } }, t("Volgende")));
}

// ── editor: a small rich text editor (value "html:" + html) ──
function editor(initial, opts) {
  opts = opts || {};
  var area = h("div", { class: "ed-area rich", contenteditable: "true", role: "textbox", "aria-multiline": "true", "aria-label": opts.label || t("Tekst"), "data-ph": opts.placeholder || "" });
  var v = initial == null ? "" : String(initial);
  if (isRich(v)) Array.prototype.slice.call(cleanHtml(v.slice(5)).childNodes).forEach(function (n) { area.appendChild(n); });
  else if (v) v.split("\n").forEach(function (line, i) { if (i) area.appendChild(document.createElement("br")); area.appendChild(document.createTextNode(line)); });
  var saved = null, linkRow = null, urlIn = h("input", { type: "url", placeholder: "https://", "aria-label": t("Webadres") });
  function mark() { area.classList.toggle("empty", !area.textContent.trim()); }
  area.addEventListener("input", mark); mark();
  area.addEventListener("paste", function (ev) { ev.preventDefault(); var txt = (ev.clipboardData || window.clipboardData).getData("text/plain"); document.execCommand("insertText", false, txt); });
  function cmd(name, val) { area.focus(); document.execCommand(name, false, val || null); mark(); }
  function selSave() { var s = window.getSelection(); if (s.rangeCount && area.contains(s.anchorNode)) saved = s.getRangeAt(0).cloneRange(); }
  function tool(ic, label, fn, onDown) { return h("button", { type: "button", class: "ib", "aria-label": label, title: label, onmousedown: function (ev) { ev.preventDefault(); if (onDown) onDown(); }, onclick: fn }, icon(ic, 16)); }
  function applyLink() {
    var url = urlIn.value.trim(); if (!url) { closeLink(); return; }
    if (!/^(https?:|mailto:|tel:)/i.test(url)) url = "https://" + url;
    area.focus();
    if (saved) { var s = window.getSelection(); s.removeAllRanges(); s.addRange(saved); }
    if (window.getSelection().isCollapsed) document.execCommand("insertHTML", false, '<a href="' + url.replace(/"/g, "%22") + '">' + url.replace(/</g, "&lt;") + "</a>"); else document.execCommand("createLink", false, url);
    closeLink(); mark();
  }
  function closeLink() { if (linkRow) { linkRow.remove(); linkRow = null; } urlIn.value = ""; }
  urlIn.addEventListener("keydown", function (ev) { if (ev.key === "Enter") { ev.preventDefault(); applyLink(); } else if (ev.key === "Escape") { ev.stopPropagation(); closeLink(); } });
  var bar = h("div", { class: "ed-bar", role: "toolbar", "aria-label": t("Opmaak") },
    tool("bold", t("Vet"), function () { cmd("bold"); }), tool("italic", t("Cursief"), function () { cmd("italic"); }),
    tool("ul", t("Opsomming"), function () { cmd("insertUnorderedList"); }), tool("ol", t("Genummerde lijst"), function () { cmd("insertOrderedList"); }),
    tool("link", t("Link"), function () {
      if (linkRow) { closeLink(); return; }
      linkRow = h("div", { class: "ed-link" }, urlIn, btn(t("Toevoegen"), "primary", applyLink), iconBtn("x", t("Annuleren"), closeLink));
      box.insertBefore(linkRow, area); urlIn.focus();
    }, selSave),
    tool("quote", t("Citaat"), function () { var inQ = window.getSelection().anchorNode && (window.getSelection().anchorNode.parentElement || area).closest("blockquote"); cmd("formatBlock", inQ ? "p" : "blockquote"); }));
  var box = h("div", { class: "ed" }, bar, area);
  return {
    el: box, area: area, focus: function () { area.focus(); },
    empty: function () { return !area.textContent.trim(); },
    value: function () { var c = cleanHtml(area.innerHTML); return area.textContent.trim() ? "html:" + c.innerHTML : ""; },
    clear: function () { area.innerHTML = ""; mark(); }
  };
}

// ── attachments: button + drag and drop, each file uploaded at once ──
function uploader(forumId, on) {
  var items = [], list = h("ul", { class: "upl" }), file = h("input", { type: "file", multiple: true, class: "hide", "aria-label": t("Bestanden kiezen") });
  var zone = h("div", { class: "drop" }, btn(t("Bijlage toevoegen"), "", function () { file.click(); }, "paperclip"), h("span", { class: "muted" }, t("of sleep foto's, video's of bestanden hierheen. De beheerder stelt de toegestane soorten en groottes in.")), file);
  var el = h("div", { class: "uploader" }, zone, list);
  function add(files) {
    Array.prototype.forEach.call(files, function (f) {
      var it = { f: f, id: null, state: "up", msg: "" }, thumb = /^image\//.test(f.type) ? h("img", { src: URL.createObjectURL(f), alt: "" }) : icon(/^video\//.test(f.type) ? "video" : "file", 20);
      var status = h("span", { class: "muted" }, t("Bezig met uploaden…")), rm = iconBtn("x", t("Verwijderen"), function () {
        if (it.id) call("attachments/" + it.id, "DELETE").catch(function () { /* draft removed later by the server */ });
        items = items.filter(function (x) { return x !== it; }); li.remove(); if (on) on();
      });
      var li = h("li", { class: "up-" + it.state }, h("span", { class: "thumb" }, thumb), h("span", { class: "grow" }, h("b", {}, f.name), " ", h("small", { class: "muted" }, size(f.size)), h("br"), status), rm);
      it.li = li; items.push(it); list.appendChild(li);
      system.upload(ROUTE + "upload", f, { forum_id: forumId }).then(function (r) {
        it.id = r.id; it.state = "ok"; status.textContent = t("Klaar"); li.className = "up-ok"; if (on) on();
      }).catch(function (e) { it.state = "err"; li.className = "up-err"; status.textContent = errText(e); status.className = "bad"; if (on) on(); });
    });
  }
  file.addEventListener("change", function () { add(file.files); file.value = ""; });
  ["dragenter", "dragover"].forEach(function (n) { zone.addEventListener(n, function (ev) { ev.preventDefault(); zone.classList.add("over"); }); });
  ["dragleave", "drop"].forEach(function (n) { zone.addEventListener(n, function (ev) { ev.preventDefault(); zone.classList.remove("over"); }); });
  zone.addEventListener("drop", function (ev) { if (ev.dataTransfer && ev.dataTransfer.files) add(ev.dataTransfer.files); });
  return {
    el: el,
    ids: function () { return items.filter(function (x) { return x.state === "ok"; }).map(function (x) { return x.id; }); },
    busy: function () { return items.some(function (x) { return x.state === "up"; }); },
    reset: function () { items = []; list.innerHTML = ""; }
  };
}

// ── people picker (search through `people`) ──
function userPicker(onPick) {
  var timer = null, res = h("ul", { class: "picks", role: "listbox" }), inp = h("input", { type: "search", placeholder: t("Zoek een gebruiker (min. 2 tekens)"), "aria-label": t("Zoek een gebruiker") });
  inp.addEventListener("input", function () {
    clearTimeout(timer); var q = inp.value.trim(); res.innerHTML = "";
    if (q.length < 2) return;
    timer = setTimeout(function () {
      call("people?q=" + encodeURIComponent(q)).then(function (d) {
        res.innerHTML = "";
        (d.people || []).forEach(function (p) {
          S.names[p.id] = p.name;
          res.appendChild(h("li", {}, h("button", { type: "button", role: "option", onclick: function () { res.innerHTML = ""; inp.value = ""; onPick(p); } }, avatar(p), h("span", {}, p.name, p.email ? h("small", { class: "muted" }, " " + p.email) : null))));
        });
        if (!res.childNodes.length) res.appendChild(h("li", { class: "muted pad" }, t("Niemand gevonden.")));
      }).catch(function () { /* ignore: typing goes on */ });
    }, 250);
  });
  return h("div", { class: "picker" }, inp, res);
}
// chips of extra users and groups: obj = {users:[ids], groups:[ids]}
function accessPicker(obj, groups) {
  obj.users = obj.users || []; obj.groups = obj.groups || [];
  var box = h("div", { class: "stack-s" });
  function draw() {
    box.innerHTML = "";
    var chips = h("div", { class: "chips" });
    obj.groups.forEach(function (g) {
      var gr = (groups || []).filter(function (x) { return x.id === g; })[0];
      chips.appendChild(h("span", { class: "chip" }, icon("users", 13), gr ? gr.name : "#" + g, h("button", { type: "button", "aria-label": t("Verwijderen"), onclick: function () { obj.groups = obj.groups.filter(function (x) { return x !== g; }); draw(); } }, icon("x", 12))));
    });
    obj.users.forEach(function (u) {
      chips.appendChild(h("span", { class: "chip" }, S.names[u] || t("Gebruiker {0}", u), h("button", { type: "button", "aria-label": t("Verwijderen"), onclick: function () { obj.users = obj.users.filter(function (x) { return x !== u; }); draw(); } }, icon("x", 12))));
    });
    box.appendChild(chips);
    var avail = (groups || []).filter(function (g) { return obj.groups.indexOf(g.id) < 0; });
    var gs = h("select", { "aria-label": t("Groep toevoegen"), onchange: function () { if (gs.value) { obj.groups.push(Number(gs.value)); draw(); } } }, h("option", { value: "" }, t("+ Groep toevoegen")), avail.map(function (g) { return h("option", { value: g.id }, g.name); }));
    box.appendChild(h("div", { class: "grid2" }, avail.length ? gs : null, userPicker(function (p) { if (obj.users.indexOf(p.id) < 0) obj.users.push(p.id); draw(); })));
  }
  draw();
  return box;
}

// ── follow ──
var FOLLOW = [["all", "Alles"], ["replies", "Alleen reacties op mij"], ["off", "Dempen"], ["", "Niet volgen"]];
function followSelect(kind, id, current) {
  if (!S.me) return null;
  var sel = h("select", { "aria-label": t("Volgen"), onchange: function () { call("follow", "POST", { kind: kind, id: id, level: sel.value || "none" }).then(function () { S.follows = null; }).catch(function (e) { sel.parentNode.appendChild(alertBox(errText(e))); }); } },
    FOLLOW.map(function (o) { return h("option", { value: o[0], selected: (current || "") === o[0] }, t(o[1])); }));
  return h("label", { class: "follow" }, icon((current || "") === "off" ? "bell-off" : "bell", 16), sel);
}
function bell(forum) {
  if (!S.me) return null;
  var on = !!forum.following, b = h("button", { type: "button", class: "ib" + (on ? " on" : ""), "aria-pressed": on ? "true" : "false", "aria-label": on ? t("Niet meer volgen") : t("Volgen"), title: on ? t("Niet meer volgen") : t("Volgen") }, icon(on ? "bell" : "bell-off"));
  b.addEventListener("click", function (ev) {
    ev.stopPropagation(); ev.preventDefault();
    call("follow", "POST", { kind: "forum", id: forum.id, level: on ? "none" : "all" }).then(function () { forum.following = !on; S.follows = null; var n = bell(forum); b.replaceWith(n); n.focus(); }).catch(function () { /* ignore */ });
  });
  return b;
}

// ── navigation: own view stack (no history API in a sandboxed frame) ──
function same(a, b) { return a && b && a.type === b.type && String(a.id || "") === String(b.id || ""); }
function show(view) { S.stack.push(view); S.cur = view; render(); }
function goto(view) {
  for (var i = S.stack.length - 1; i >= 0; i--) if (same(S.stack[i], view)) { S.stack.length = i; break; }
  show(view);
}
function back() { if (S.stack.length > 1) { S.stack.pop(); S.cur = S.stack[S.stack.length - 1]; render(); } }
function render(keepScroll) {
  var v = S.cur, token = (S.token = (S.token || 0) + 1), y = window.pageYOffset;
  app.innerHTML = ""; app.appendChild(h("p", { class: "muted pad" }, t("Laden…")));
  var fn = { home: vHome, forum: vForum, category: vCategory, thread: vThread, settings: vSettings }[v.type];
  fn(v).then(function (r) {
    if (token !== S.token) return;
    app.innerHTML = "";
    var crumbs = (r.crumbs || []).map(function (c, i, a) { return [i ? h("span", { class: "sep", "aria-hidden": "true" }, icon("right", 12)) : null, i === a.length - 1 ? h("span", { class: "cur", "aria-current": "page" }, c.label) : h("button", { type: "button", class: "link", onclick: function () { goto(c.view); } }, c.label)]; });
    if (S.stack.length > 1 || crumbs.length > 1) app.appendChild(h("div", { class: "topbar" }, S.stack.length > 1 ? btn(t("Terug"), "", back, "back") : null, h("nav", { class: "crumbs", "aria-label": t("Waar ben je") }, crumbs)));
    app.appendChild(r.node);
    if (keepScroll) window.scrollTo(0, y); else window.scrollTo(0, 0);
  }).catch(function (e) {
    if (token !== S.token) return;
    app.innerHTML = ""; app.appendChild(h("div", { class: "stack" }, alertBox(errText(e)), S.stack.length > 1 ? btn(t("Terug"), "", back, "back") : btn(t("Opnieuw proberen"), "", function () { render(); })));
  });
}
function reload() { render(true); }
function homeCrumb() { return { label: t("Forums"), view: { type: "home" } }; }
function flatten(tree, depth, out) { out = out || []; (tree || []).forEach(function (n) { out.push({ id: n.id, title: n.title, depth: depth || 0 }); flatten(n.children, (depth || 0) + 1, out); }); return out; }

// ── thread rows ──
function threadRow(th, showForum) {
  var a = h("a", { class: "trow", href: "#", onclick: function (ev) { ev.preventDefault(); show({ type: "thread", id: th.id }); } },
    avatar(th.author),
    h("div", { class: "grow" },
      h("div", { class: "ttl" }, th.pinned ? h("span", { class: "badge", title: t("Vastgezet") }, icon("pin", 12), t("Vastgezet")) : null, th.locked ? h("span", { class: "badge", title: t("Gesloten") }, icon("lock", 12), t("Gesloten")) : null,
        th.status === "pending" ? h("span", { class: "badge warn" }, t("Wacht op goedkeuring")) : null, th.status === "hidden" ? h("span", { class: "badge bad" }, t("Verborgen")) : null, h("b", {}, th.title)),
      th.excerpt ? h("div", { class: "muted ex" }, th.excerpt) : null,
      h("div", { class: "muted meta" }, (th.author && th.author.name) || "", showForum && th.forum ? " · " + th.forum : "", " · ", timeEl(th.last_post_at || th.created_at))),
    h("div", { class: "stats" }, stat("chat", th.replies, t("reacties")), stat("eye", th.views, t("weergaven")), S.board.reactions !== false ? stat("heart", th.likes, t("hartjes")) : null));
  return a;
}
function threadList(rows, showForum, emptyText) {
  if (!rows || !rows.length) return empty(emptyText || t("Nog geen onderwerpen."));
  return h("div", { class: "card flush" }, rows.map(function (r) { return threadRow(r, showForum); }));
}

// ── HOME ──
function newForum() {
  var title = h("input", { maxlength: "120", "aria-label": t("Naam van het forum") }), ed = editor("", { label: t("Beschrijving"), placeholder: t("Waar gaat dit forum over?") }),
    vis = h("select", { "aria-label": t("Wie mag meelezen") }, Object.keys(VIS).map(function (k) { return h("option", { value: k, selected: k === "members" }, t(VIS[k])); })), msg = h("div"), go = btn(t("Forum maken"), "primary", save);
  function save() {
    msg.innerHTML = ""; go.disabled = true;
    call("forums", "POST", { title: title.value, description: ed.value(), visibility: vis.value }).then(function (d) { close(); show({ type: "forum", id: (d.forum || {}).id }); }).catch(function (e) { go.disabled = false; msg.appendChild(alertBox(errText(e))); });
  }
  var close = modal(t("Nieuw forum"), h("div", { class: "stack" }, h("label", {}, t("Naam"), title), h("label", {}, t("Beschrijving")), ed.el, h("label", {}, t("Wie mag meelezen?"), vis), msg, h("div", { class: "row end" }, go)));
}
function forumCard(f) {
  var st = statusBadge(f.status);
  var tile = h("span", { class: "tile", style: f.color ? "background:" + String(f.color).replace(/[^#0-9a-fA-F]/g, "") : "" }, icon(ICONS[f.icon] ? f.icon : "chat", 22));
  return h("article", { class: "card fcard" },
    h("div", { class: "row top" }, tile, h("div", { class: "grow" }, h("h3", {}, h("a", { href: "#", onclick: function (ev) { ev.preventDefault(); show({ type: "forum", id: f.id }); } }, f.title)), h("div", { class: "row tight" }, visBadge(f.visibility), st)), bell(f)),
    f.description ? richEl(f.description, "clamp") : null,
    h("div", { class: "stats" }, stat("folder", f.groups, t("groepen")), stat("chat", f.threads, t("onderwerpen")), stat("users", f.posts, t("berichten"))),
    f.last ? h("div", { class: "muted meta" }, t("Laatst: "), h("a", { href: "#", onclick: function (ev) { ev.preventDefault(); show({ type: "thread", id: f.last.thread_id }); } }, f.last.title), " · ", timeEl(f.last.at)) : h("div", { class: "muted meta" }, t("Nog geen activiteit.")));
}
function mySide() {
  if (!S.me) return null;
  var box = h("aside", { class: "card side" }, h("h2", { class: "sec" }, t("Ik volg")), h("p", { class: "muted" }, t("Laden…")));
  function fill(list) {
    box.innerHTML = ""; box.appendChild(h("h2", { class: "sec" }, t("Ik volg")));
    if (!list.length) { box.appendChild(h("p", { class: "muted" }, t("Je volgt nog niets. Kies het belletje bij een forum, groep of onderwerp."))); return; }
    box.appendChild(h("ul", { class: "plain-list" }, list.slice(0, 15).map(function (f) {
      return h("li", {}, h("a", { href: "#", onclick: function (ev) { ev.preventDefault(); show({ type: f.kind === "forum" ? "forum" : f.kind === "category" ? "category" : "thread", id: f.id }); } }, icon(f.kind === "forum" ? "chat" : f.kind === "category" ? "folder" : "reply", 14), f.title));
    })));
  }
  if (S.follows) fill(S.follows); else call("follow").then(function (d) { S.follows = d.follows || []; fill(S.follows); }).catch(function () { box.remove(); });
  return box;
}
function vHome(v) {
  return call("home").then(function (d) {
    S.me = d.me || null; S.board = d.board || {};
    var results = h("div"), q = h("input", { type: "search", placeholder: t("Zoek in alle forums…"), "aria-label": t("Zoeken") });
    var latest = h("section", { class: "stack-s" }, h("h2", { class: "sec" }, t("Laatste onderwerpen")), threadList(d.latest, true, t("Er zijn nog geen onderwerpen.")));
    function search(ev) {
      ev.preventDefault(); var s = q.value.trim();
      if (s.length < 2) { results.innerHTML = ""; latest.hidden = false; return; }
      call("search?q=" + encodeURIComponent(s)).then(function (r) {
        latest.hidden = true; results.innerHTML = "";
        results.appendChild(h("section", { class: "stack" }, h("div", { class: "row between" }, h("h2", {}, t("Zoekresultaten voor “{0}”", s)), btn(t("Wissen"), "", function () { q.value = ""; results.innerHTML = ""; latest.hidden = false; }, "x")), threadList(r.threads, true, t("Niets gevonden."))));
      }).catch(function (e) { results.innerHTML = ""; results.appendChild(alertBox(errText(e))); });
    }
    var head = h("div", { class: "hero" },
      h("div", { class: "grow lead" }, d.welcome ? richEl(d.welcome) : h("p", {}, t("Praat mee, stel vragen en deel ervaringen."))),
      d.can_create_forum ? btn(t("Nieuw forum"), "primary", newForum, "plus") : null);
    var forums = d.forums || [];
    var bar = h("form", { class: "searchbar card", role: "search", onsubmit: search }, icon("search", 18), q, h("button", { class: "btn primary", type: "submit" }, t("Zoeken")));
    var main = h("div", { class: "stack" }, results,
      h("section", { class: "stack-s" }, h("h2", { class: "sec" }, t("Forums")), forums.length ? h("div", { class: "cards" }, forums.map(forumCard)) : empty(S.me ? t("Er zijn nog geen forums.") : t("Er zijn nog geen openbare forums."), "folder")), latest,
      S.me ? null : loginNote());
    return { node: h("div", { class: "stack home" }, head, bar, h("div", { class: "cols" }, main, mySide())), crumbs: [{ label: t("Forums"), view: v }] };
  });
}

// ── groups ──
function groupModal(forumId, parent, done) {
  var title = h("input", { maxlength: "120", "aria-label": t("Naam van de groep") }), ed = editor("", { label: t("Beschrijving") }), msg = h("div"), go = btn(t("Maken"), "primary", save);
  function save() {
    msg.innerHTML = ""; go.disabled = true;
    call("forums/" + forumId + "/categories", "POST", { title: title.value, description: ed.value(), parent_id: parent ? parent.id : null }).then(function () { close(); done(); }).catch(function (e) { go.disabled = false; msg.appendChild(alertBox(errText(e))); });
  }
  var close = modal(parent ? t("Nieuwe subgroep in {0}", parent.title) : t("Nieuwe groep"), h("div", { class: "stack" }, h("label", {}, t("Naam"), title), h("label", {}, t("Beschrijving")), ed.el, msg, h("div", { class: "row end" }, go)));
}
function tree(nodes, forumId, can, open) {
  return h("ul", { class: "tree" }, nodes.map(function (n) {
    var kids = n.children || [], li = h("li", {}), sub = null, exp = open[n.id] !== false && (open[n.id] || kids.length < 8);
    function toggle() { exp = !exp; open[n.id] = exp; draw(); }
    function draw() {
      li.innerHTML = "";
      li.appendChild(h("div", { class: "node" },
        kids.length ? h("button", { type: "button", class: "ib twist" + (exp ? " open" : ""), "aria-expanded": exp ? "true" : "false", "aria-label": (exp ? t("Inklappen") : t("Uitklappen")) + " " + n.title, onclick: toggle }, icon("right", 16)) : h("span", { class: "twist-gap" }),
        h("span", { class: "grow" }, h("a", { href: "#", class: "gname", onclick: function (ev) { ev.preventDefault(); show({ type: "category", id: n.id }); } }, icon("folder", 16), n.title), n.locked ? h("span", { class: "badge" }, icon("lock", 12), t("Gesloten")) : null,
          n.description ? h("div", { class: "muted ex" }, plainOf(n.description)) : null),
        h("span", { class: "stats" }, stat("chat", n.threads, t("onderwerpen")), n.last ? h("span", { class: "muted meta hide-s" }, timeEl(n.last.at)) : null),
        can ? iconBtn("plus", t("Nieuwe subgroep in {0}", n.title), function () { groupModal(forumId, n, reload); }) : null));
      if (kids.length && exp) li.appendChild(tree(kids, forumId, can, open));
    }
    draw(); return li;
  }));
}

// ── FORUM ──
function vForum(v) {
  return call("forums/" + encodeURIComponent(v.id)).then(function (d) {
    var f = d.forum, can = d.can || {}, open = v.open = v.open || {};
    v.id = f.id;
    var head = h("div", { class: "card" },
      h("div", { class: "row top" }, h("span", { class: "tile", style: f.color ? "background:" + String(f.color).replace(/[^#0-9a-fA-F]/g, "") : "" }, icon(ICONS[f.icon] ? f.icon : "chat", 26)),
        h("div", { class: "grow" }, h("h1", {}, f.title), h("div", { class: "row tight" }, visBadge(f.visibility), statusBadge(f.status), h("span", { class: "badge" }, t(["Bezoeker", "Lid", "Beheerder", "Eigenaar"][can.level || 0] || "Lid")),
          f.owner ? h("span", { class: "muted meta" }, t("Eigenaar: {0}", f.owner.name)) : null)),
        h("div", { class: "row tight" }, bell(f), can.level >= 3 ? btn(t("Instellingen"), "", function () { show({ type: "settings", id: f.id }); }, "settings") : null)),
      f.description ? richEl(f.description) : null,
      h("div", { class: "stats" }, stat("folder", f.groups, t("groepen")), stat("chat", f.threads, t("onderwerpen")), stat("users", f.posts, t("berichten"))));
    var tr = d.tree || [];
    var groups = h("section", { class: "stack" }, h("div", { class: "row between" }, h("h2", {}, t("Groepen")), can.create_category && f.status === "open" ? btn(t("Nieuwe groep"), "primary", function () { groupModal(f.id, null, reload); }, "plus") : null),
      tr.length ? h("div", { class: "card flush" }, tree(tr, f.id, can.create_category && f.status === "open", open)) : empty(t("Dit forum heeft nog geen groepen."), "folder"));
    var mgrs = (d.managers || []).length ? h("div", { class: "card side" }, h("h3", {}, t("Beheerders")), h("ul", { class: "plain-list" }, d.managers.map(function (m) { return h("li", {}, avatar(m.user), " ", m.user.name, " ", h("small", { class: "muted" }, t(m.role === "owner" ? "Eigenaar" : "Beheerder"))); }))) : null;
    var recent = h("section", { class: "stack" }, h("h2", {}, t("Recente discussies")), threadList(d.recent, false, t("Nog geen onderwerpen.")));
    return { node: h("div", { class: "stack" }, head, !S.me ? loginNote() : null, h("div", { class: "cols" }, h("div", { class: "stack" }, groups, recent), h("div", { class: "stack" }, mgrs))), crumbs: [homeCrumb(), { label: f.title, view: v }] };
  });
}

// ── GROUP ──
function vCategory(v) {
  v.sort = v.sort || "latest"; v.page = v.page || 1; v.q = v.q || "";
  return call("categories/" + v.id + "?sort=" + v.sort + "&page=" + v.page + (v.q ? "&q=" + encodeURIComponent(v.q) : "")).then(function (d) {
    var c = d.category, can = d.can || {}, forum = d.forum || {}, fview = { type: "forum", id: forum.id };
    var crumbs = [homeCrumb(), { label: forum.title, view: fview }].concat((d.path || []).map(function (p) { return { label: p.title, view: { type: "category", id: p.id } }; }));
    if (!(d.path || []).some(function (p) { return p.id === c.id; })) crumbs.push({ label: c.title, view: v });
    var head = h("div", { class: "card" }, h("div", { class: "row top" }, h("div", { class: "grow" }, h("h1", {}, icon("folder", 22), c.title), h("div", { class: "row tight" }, c.locked ? h("span", { class: "badge" }, icon("lock", 12), t("Gesloten")) : null, statusBadge(forum.status))),
      h("div", { class: "row tight" }, followSelect("category", c.id, d.following), can.moderate ? btn(t("Groep beheren"), "", function () { groupSettings(c, forum, d.can, v); }, "settings") : null)),
      c.description ? richEl(c.description) : null);
    var actions = h("div", { class: "row tight" }, can.can_start ? btn(t("Nieuw onderwerp"), "primary", function () { composeThread(c, forum, v); }, "plus") : null, can.can_subgroup ? btn(t("Nieuwe subgroep"), "", function () { groupModal(forum.id, c, reload); }, "folder") : null);
    var subs = (d.subgroups || []).length ? h("section", { class: "stack" }, h("h2", {}, t("Subgroepen")), h("div", { class: "card flush" }, tree(d.subgroups.map(function (s) { return Object.assign({ children: [] }, s); }), forum.id, false, {}))) : null;
    var q = h("input", { type: "search", value: v.q, placeholder: t("Zoek in deze groep…"), "aria-label": t("Zoeken") });
    var sort = h("select", { "aria-label": t("Sorteren"), onchange: function () { v.sort = sort.value; v.page = 1; reload(); } }, [["latest", "Laatste activiteit"], ["new", "Nieuwste"], ["popular", "Populair"]].map(function (o) { return h("option", { value: o[0], selected: v.sort === o[0] }, t(o[1])); }));
    var bar = h("form", { class: "searchbar", role: "search", onsubmit: function (ev) { ev.preventDefault(); v.q = q.value.trim(); v.page = 1; reload(); } }, icon("search", 18), q, sort);
    var list = h("section", { class: "stack" }, h("div", { class: "row between" }, h("h2", {}, t("Onderwerpen"), " ", h("small", { class: "muted" }, "(" + (d.total || 0) + ")")), actions), bar,
      threadList(d.threads, false, v.q ? t("Niets gevonden.") : t("Nog geen onderwerpen. Begin het eerste gesprek!")), pager(d.page, d.pages, function (p) { v.page = p; reload(); }));
    var mg = (d.managers || []).length ? h("div", { class: "card side" }, h("h3", {}, t("Beheerders")), h("ul", { class: "plain-list" }, d.managers.map(function (m) { return h("li", {}, avatar(m.user), " ", m.user.name, " ", h("small", { class: "muted" }, t(m.role === "owner" ? "Eigenaar" : "Beheerder"))); }))) : null;
    return { node: h("div", { class: "stack" }, head, !S.me ? loginNote() : null, h("div", { class: "cols" }, h("div", { class: "stack" }, subs, list), h("div", { class: "stack" }, mg))), crumbs: crumbs };
  });
}
function composeThread(c, forum, v) {
  var title = h("input", { maxlength: "200", "aria-label": t("Titel") }), ed = editor("", { label: t("Bericht"), placeholder: t("Schrijf je bericht…") }), msg = h("div"), up = null;
  var go = btn(t("Plaatsen"), "primary", save);
  function save() {
    msg.innerHTML = "";
    if (up && up.busy()) { msg.appendChild(alertBox(t("Wacht tot de bijlagen klaar zijn."))); return; }
    go.disabled = true;
    call("categories/" + c.id + "/threads", "POST", { title: title.value, body: ed.value(), attachments: up ? up.ids() : [] }).then(function (r) { close(); if (r.status === "pending") S.flash = t("Je onderwerp wacht op goedkeuring van een beheerder."); show({ type: "thread", id: r.id }); })
      .catch(function (e) { go.disabled = false; msg.appendChild(alertBox(errText(e))); });
  }
  var parts = [h("label", {}, t("Titel"), title), h("label", {}, t("Bericht")), ed.el];
  if (S.board.allow_attachments !== false) { up = uploader(forum.id); parts.push(up.el); }
  var close = modal(t("Nieuw onderwerp"), h("div", { class: "stack" }, parts, msg, h("div", { class: "row end" }, go)), true);
}
function groupSettings(c, forum, can, v) {
  var title = h("input", { value: c.title, maxlength: "120", "aria-label": t("Naam") }), ed = editor(c.description || "", { label: t("Beschrijving") }), locked = h("input", { type: "checkbox", checked: !!c.locked }), msg = h("div");
  function save() { msg.innerHTML = ""; call("categories/" + c.id, "PUT", { title: title.value, description: ed.value(), locked: locked.checked }).then(function () { close(); reload(); }).catch(function (e) { msg.appendChild(alertBox(errText(e))); }); }
  function del() {
    system.confirm(t("Weet je zeker dat je de groep “{0}” met alle onderwerpen wilt verwijderen?", c.title), { title: t("Groep verwijderen"), okLabel: t("Verwijderen"), danger: true }).then(function (ok) {
      if (!ok) return; call("categories/" + c.id, "DELETE").then(function () { close(); S.stack.pop(); S.cur = S.stack[S.stack.length - 1]; render(); }).catch(function (e) { msg.appendChild(alertBox(errText(e))); });
    });
  }
  var close = modal(t("Groep beheren"), h("div", { class: "stack" }, h("label", {}, t("Naam"), title), h("label", {}, t("Beschrijving")), ed.el, h("label", { class: "check" }, locked, t("Groep sluiten (niemand kan nieuwe onderwerpen starten)")), msg,
    h("div", { class: "row between" }, btn(t("Verwijderen"), "danger", del, "trash"), btn(t("Opslaan"), "primary", save))));
}

// ── DISCUSSION ──
function attachmentsEl(list) {
  if (!list || !list.length) return null;
  var photos = list.filter(function (a) { return a.kind === "photo"; }), videos = list.filter(function (a) { return a.kind === "video"; }), files = list.filter(function (a) { return a.kind === "file"; });
  return h("div", { class: "atts" },
    photos.length ? h("div", { class: "gallery" }, photos.map(function (a, i) { return h("button", { type: "button", class: "ph", "aria-label": t("Foto vergroten: {0}", a.name), onclick: function () { lightbox(photos, i); } }, h("img", { src: furl(a.url), alt: a.name, loading: "lazy" })); })) : null,
    videos.map(function (a) { return h("video", { class: "vid", controls: true, preload: "metadata", src: furl(a.url), "aria-label": a.name }); }),
    files.length ? h("div", { class: "chips" }, files.map(function (a) { return h("a", { class: "chip file", href: furl(a.url), target: "_blank", rel: "noopener", download: a.name }, icon("file", 14), a.name, h("small", { class: "muted" }, " " + size(a.size))); })) : null);
}
function lightbox(photos, i) {
  var img = h("img", { alt: "" }), cap = h("div", { class: "cap" }), ov;
  function set(n) { i = (n + photos.length) % photos.length; img.src = furl(photos[i].url); img.alt = photos[i].name; cap.textContent = photos[i].name + " (" + (i + 1) + "/" + photos.length + ")"; }
  function key(ev) { if (!ov.isConnected) { document.removeEventListener("keydown", key); return; } if (ev.key === "Escape") close(); else if (ev.key === "ArrowRight") set(i + 1); else if (ev.key === "ArrowLeft") set(i - 1); }
  function close() { document.removeEventListener("keydown", key); ov.remove(); }
  ov = h("div", { class: "lightbox", role: "dialog", "aria-modal": "true", "aria-label": t("Foto"), onclick: function (ev) { if (ev.target === ov || ev.target === img) close(); } }, img, cap,
    iconBtn("x", t("Sluiten"), close, "lb-x"), photos.length > 1 ? [iconBtn("back", t("Vorige foto"), function () { set(i - 1); }, "lb-l"), iconBtn("right", t("Volgende foto"), function () { set(i + 1); }, "lb-r")] : null);
  document.addEventListener("keydown", key); layer().appendChild(ov); set(i);
  ov.querySelector("button").focus();
}
function reportModal(target) {
  var reason = h("textarea", { rows: "4", maxlength: "1000", "aria-label": t("Reden") }), msg = h("div");
  var close = modal(t("Bericht melden"), h("div", { class: "stack" }, h("label", {}, t("Waarom meld je dit bericht?"), reason), msg, h("div", { class: "row end" }, btn(t("Melden"), "primary", function () {
    call("report", "POST", Object.assign({ reason: reason.value }, target)).then(function () { close(); S.flash = t("Bedankt, de beheerders kijken ernaar."); reload(); }).catch(function (e) { msg.innerHTML = ""; msg.appendChild(alertBox(errText(e))); });
  }))));
}
function vThread(v) {
  return call("threads/" + v.id + (v.page ? "?page=" + v.page : "")).then(function (d) {
    var th = d.thread, can = d.can || {}, st = d.settings || {}, forum = d.forum || {}, posts = d.posts || [], first = d.first || {};
    var byId = {}; posts.forEach(function (p) { byId[p.id] = p; });
    var target = { id: null, name: "" }, chip = h("div", { class: "replyto", hidden: true }), editorBox = null, flash = S.flash; S.flash = null;
    var crumbs = [homeCrumb(), { label: forum.title, view: { type: "forum", id: forum.id } }].concat((d.path || []).map(function (p) { return { label: p.title, view: { type: "category", id: p.id } }; })).concat([{ label: th.title, view: v }]);

    function setTarget(p) {
      target = p ? { id: p.id, name: p.author.name } : { id: null, name: "" };
      chip.hidden = !p; chip.innerHTML = "";
      if (p) chip.appendChild(h("span", {}, icon("reply", 14), t("In reactie op {0}", p.author.name), " ", iconBtn("x", t("Reactie annuleren"), function () { setTarget(null); })));
      if (p && editorBox) { editorBox.scrollIntoView({ behavior: "smooth", block: "center" }); ed.focus(); }
    }
    function likeBtn(p, isFirst) {
      if (st.reactions === false) return null;
      var count = p.likes || 0, liked = !!p.liked, b = h("button", { type: "button", class: "btn like" + (liked ? " on" : ""), "aria-pressed": liked ? "true" : "false", disabled: !can.react || !S.me }), n = h("span", {}, String(count));
      function paint() { b.className = "btn like" + (liked ? " on" : ""); b.setAttribute("aria-pressed", liked ? "true" : "false"); b.setAttribute("aria-label", t("Hartje: {0}", count)); n.textContent = String(count); }
      b.appendChild(icon("heart", 16)); b.appendChild(n); paint();
      b.addEventListener("click", function () { call("react", "POST", isFirst ? { thread_id: th.id } : { post_id: p.id }).then(function (r) { liked = r.liked; count = r.count; paint(); }).catch(function (e) { b.parentNode.appendChild(alertBox(errText(e))); }); });
      return b;
    }
    function postEl(p, isFirst) {
      var body = h("div", { class: "pbody" }, richEl(p.body)), parent = !isFirst && p.parent_id ? byId[p.parent_id] : null, art = h("article", { class: "post card" + (p.status === "hidden" ? " dim" : ""), id: "post-" + p.id });
      var mod = can.moderate;
      var items = [];
      if (S.me && st.reports !== false) items.push({ label: t("Melden"), icon: "flag", fn: function () { reportModal(isFirst ? { thread_id: th.id } : { post_id: p.id }); } });
      if (mod && !isFirst) {
        if (p.status === "hidden") items.push({ label: t("Weer tonen"), icon: "eye", fn: function () { postAction(p, "unhide"); } }); else items.push({ label: t("Verbergen"), icon: "lock", fn: function () { postAction(p, "hide"); } });
        if (p.status === "pending") items.push({ label: t("Goedkeuren"), icon: "check", fn: function () { postAction(p, "approve"); } });
      }
      var more = items.length ? h("span", { class: "menuwrap" }, h("button", { type: "button", class: "ib", "aria-label": t("Meer acties"), "aria-haspopup": "menu", title: t("Meer acties") }, icon("more"))) : null;
      if (more) menu(more.firstChild, items);
      var acts = h("div", { class: "row tight acts" }, likeBtn(p, isFirst),
        can.can_reply && !isFirst ? btn(t("Reageer"), "", function () { setTarget(p); }, "reply") : null,
        p.can_edit ? btn(t("Wijzig"), "", function () { editPost(p, isFirst, body); }, "edit") : null,
        p.can_delete ? btn(t("Verwijder"), "danger", function () { delPost(p, isFirst); }, "trash") : null, more);
      art.appendChild(h("header", { class: "phead" }, avatar(p.author, true), h("div", { class: "grow" }, h("b", {}, p.author.name), " ", p.author.badge === "manager" ? h("span", { class: "badge ok" }, icon("shield", 12), t("Beheerder")) : null,
        p.status === "pending" ? h("span", { class: "badge warn" }, t("Wacht op goedkeuring")) : null, p.status === "hidden" ? h("span", { class: "badge bad" }, t("Verborgen")) : null,
        h("div", { class: "muted meta" }, timeEl(p.created_at), p.edited_at ? [" · ", h("span", { title: new Date(p.edited_at).toLocaleString(lang()) }, t("bewerkt"))] : null))));
      if (p.parent_id) art.appendChild(h("div", { class: "quote" }, h("div", { class: "muted meta" }, icon("reply", 13), parent ? t("In reactie op {0}", parent.author.name) : t("In reactie op een eerder bericht"), " ",
        parent ? h("a", { href: "#post-" + parent.id, onclick: function (ev) { ev.preventDefault(); var e = document.getElementById("post-" + parent.id); if (e) { e.scrollIntoView({ behavior: "smooth", block: "center" }); e.classList.add("flash"); setTimeout(function () { e.classList.remove("flash"); }, 1500); } } }, t("ga naar bericht")) : null),
        parent ? h("div", { class: "ex" }, plainOf(parent.body).slice(0, 160)) : null));
      art.appendChild(body); art.appendChild(attachmentsEl(p.attachments)); art.appendChild(acts);
      return art;
    }
    function editPost(p, isFirst, bodyEl) {
      var e = editor(p.body, { label: t("Bericht wijzigen") }), title = isFirst ? h("input", { value: th.title, maxlength: "200", "aria-label": t("Titel") }) : null, msg = h("div");
      var form = h("div", { class: "stack" }, title, e.el, msg, h("div", { class: "row end" }, btn(t("Annuleren"), "", function () { form.replaceWith(bodyEl); }), btn(t("Opslaan"), "primary", function () {
        var data = { body: e.value() }; if (isFirst) data.title = title.value;
        call(isFirst ? "threads/" + th.id : "posts/" + p.id, "PUT", data).then(reload).catch(function (er) { msg.innerHTML = ""; msg.appendChild(alertBox(errText(er))); });
      })));
      bodyEl.replaceWith(form); e.focus();
    }
    function delPost(p, isFirst) {
      system.confirm(isFirst ? t("Weet je zeker dat je dit hele onderwerp wilt verwijderen?") : t("Weet je zeker dat je dit bericht wilt verwijderen?"), { title: t("Verwijderen"), okLabel: t("Verwijderen"), danger: true }).then(function (ok) {
        if (!ok) return;
        call(isFirst ? "threads/" + th.id : "posts/" + p.id, "DELETE").then(function () { if (isFirst) { S.stack.pop(); S.cur = S.stack[S.stack.length - 1]; render(); } else reload(); }).catch(function (e) { alertTop(errText(e)); });
      });
    }
    function postAction(p, action) { call("posts/" + p.id + "/action", "POST", { action: action }).then(reload).catch(function (e) { alertTop(errText(e)); }); }
    var topAlert = h("div");
    function alertTop(text) { topAlert.innerHTML = ""; topAlert.appendChild(alertBox(text)); }
    function threadAction(action, extra) { call("threads/" + th.id + "/action", "POST", Object.assign({ action: action }, extra || {})).then(reload).catch(function (e) { alertTop(errText(e)); }); }
    function moveModal() {
      call("forums/" + forum.id).then(function (f) {
        var sel = h("select", { "aria-label": t("Nieuwe groep") }, flatten(f.tree).map(function (n) { return h("option", { value: n.id, selected: n.id === th.category_id }, new Array(n.depth + 1).join("— ") + n.title); }));
        var close = modal(t("Verplaats naar een andere groep"), h("div", { class: "stack" }, h("label", {}, t("Nieuwe groep"), sel), h("div", { class: "row end" }, btn(t("Verplaatsen"), "primary", function () { close(); threadAction("move", { category_id: Number(sel.value) }); }))));
      }).catch(function (e) { alertTop(errText(e)); });
    }
    var modItems = can.moderate ? [
      { label: th.pinned ? t("Losmaken") : t("Vastzetten"), icon: "pin", fn: function () { threadAction(th.pinned ? "unpin" : "pin"); } },
      { label: th.locked ? t("Heropenen") : t("Sluiten voor reacties"), icon: "lock", fn: function () { threadAction(th.locked ? "unlock" : "lock"); } },
      { label: th.status === "hidden" ? t("Weer tonen") : t("Verbergen"), icon: "eye", fn: function () { threadAction(th.status === "hidden" ? "unhide" : "hide"); } },
      th.status === "pending" ? { label: t("Goedkeuren"), icon: "check", fn: function () { threadAction("approve"); } } : null,
      { label: t("Verplaatsen…"), icon: "move", fn: moveModal }] : null;
    var modBtn = modItems ? h("span", { class: "menuwrap" }, h("button", { type: "button", class: "btn", "aria-haspopup": "menu" }, icon("shield", 16), t("Modereren"), icon("down", 14))) : null;
    if (modBtn) menu(modBtn.firstChild, modItems);

    var head = h("div", { class: "card thead" }, h("div", { class: "row top" }, h("h1", { class: "grow" }, th.title), h("div", { class: "row tight" }, followSelect("thread", th.id, d.following), modBtn)),
      h("div", { class: "row tight" }, th.pinned ? h("span", { class: "badge" }, icon("pin", 12), t("Vastgezet")) : null, th.locked ? h("span", { class: "badge" }, icon("lock", 12), t("Gesloten")) : null,
        th.status === "pending" ? h("span", { class: "badge warn" }, t("Wacht op goedkeuring")) : null, th.status === "hidden" ? h("span", { class: "badge bad" }, t("Verborgen")) : null,
        stat("eye", th.views, t("weergaven")), stat("chat", d.total, t("reacties"))));
    var ed = editor("", { label: t("Je reactie"), placeholder: t("Schrijf een reactie…") }), up = st.attachments ? uploader(forum.id) : null, msg = h("div"), send = btn(t("Reactie plaatsen"), "primary", function () {
      msg.innerHTML = "";
      if (ed.empty()) { msg.appendChild(alertBox(t("Schrijf eerst een tekst."))); return; }
      if (up && up.busy()) { msg.appendChild(alertBox(t("Wacht tot de bijlagen klaar zijn."))); return; }
      send.disabled = true;
      call("threads/" + th.id + "/posts", "POST", { body: ed.value(), parent_id: target.id || null, attachments: up ? up.ids() : [] }).then(function (r) {
        if (r.status === "pending") S.flash = t("Je reactie wacht op goedkeuring van een beheerder.");
        v.page = "last"; render();
      }).catch(function (e) { send.disabled = false; msg.appendChild(alertBox(errText(e))); });
    });
    editorBox = h("section", { class: "card composer", id: "composer" }, h("h2", {}, t("Reageer")), chip, ed.el, up ? up.el : null, msg, h("div", { class: "row end" }, send));
    var bottom = can.can_reply ? editorBox : S.me ? h("div", { class: "note" }, icon("lock", 16), h("span", {}, th.locked ? t("Dit onderwerp is gesloten voor reacties.") : t("Je kunt hier niet reageren."))) : loginNote();
    var pg = pager(d.page, d.pages, function (p) { v.page = p; render(); });
    return { node: h("div", { class: "stack" }, flash ? alertBox(flash, true) : null, topAlert, head, postEl(Object.assign({ author: first.author || {}, can_edit: first.can_edit }, first, { id: 0, status: th.status }), true),
      posts.length ? h("h2", { class: "repl" }, t("Reacties")) : null, h("div", { class: "stack" }, posts.map(function (p) { return postEl(p, false); })), pg, bottom), crumbs: crumbs };
  });
}

// ── FORUM SETTINGS (tabs: Algemeen, Wie mag wat, Beheerders, Systeemrechten) ──
var ACTION_LABELS = { view: "Forum en groepen bekijken", create_category: "Groepen maken", create_thread: "Onderwerpen starten", reply: "Reageren", upload: "Bijlagen toevoegen", react: "Waarderen (hartje)", edit_own: "Eigen berichten wijzigen", delete_own: "Eigen berichten verwijderen", moderate: "Modereren" };
var LEVEL_LABELS = { visitors: "Bezoekers", members: "Leden", moderators: "Beheerders van groep/forum", admins: "Alleen eigenaars en admins", nobody: "Niemand" };
var FEATURE_LABELS = { allow_attachments: "Bijlagen toestaan", allow_photos: "Foto's toestaan", allow_videos: "Video's toestaan", allow_files: "Bestanden toestaan (pdf, zip, …)", require_approval: "Nieuwe berichten eerst laten goedkeuren", allow_reports: "Melden toestaan", reactions: "Hartjes (waarderingen)", subgroup_depth: "Niveaus van subgroepen" };
function onoff(v) { return v === true ? t("aan") : v === false ? t("uit") : String(v); }
function vSettings(v) {
  v.tab = v.tab || "general";
  return Promise.all([call("forums/" + v.id), call("forums/" + v.id + "/settings")]).then(function (r) {
    var d = r[0], st = r[1], f = d.forum, body = h("div", { class: "stack" });
    var crumbs = [homeCrumb(), { label: f.title, view: { type: "forum", id: f.id } }, { label: t("Instellingen"), view: v }];
    function pick(tab) { v.tab = tab; draw(); }
    function draw() {
      body.innerHTML = "";
      body.appendChild(tabs([["general", t("Algemeen")], ["perms", t("Wie mag wat")], ["managers", t("Beheerders")], ["rights", t("Systeemrechten")]], v.tab, pick));
      body.appendChild({ general: tabGeneral, perms: tabPerms, managers: tabManagers, rights: tabRights }[v.tab](f, st, d));
    }
    draw();
    return { node: h("div", { class: "stack" }, h("div", { class: "hero" }, h("div", { class: "grow" }, h("h1", {}, t("Instellingen van {0}", f.title)), h("p", { class: "muted" }, t("Alleen eigenaars en beheerders van de site zien deze pagina.")))), h("div", { class: "card" }, body)), crumbs: crumbs };
  });
}
function tabGeneral(f, st, d) {
  var title = h("input", { value: f.title, maxlength: "120", "aria-label": t("Naam") }), ed = editor(f.description || "", { label: t("Beschrijving") }), msg = h("div"), color = f.color || "";
  var ic = h("select", { "aria-label": t("Pictogram") }, [""].concat(["chat", "folder", "heart", "shield", "users", "photo", "video", "flag", "bell"]).map(function (n) { return h("option", { value: n, selected: (f.icon || "") === n }, n ? n.charAt(0).toUpperCase() + n.slice(1) : t("Standaard")); }));
  var col = h("input", { type: "color", value: /^#[0-9a-fA-F]{6}$/.test(color) ? color : "#3b82f6", "aria-label": t("Kleur"), oninput: function () { color = col.value; } });
  var stt = h("select", { "aria-label": t("Status") }, [["open", "Open"], ["closed", "Gesloten"], ["archived", "Gearchiveerd"]].map(function (o) { return h("option", { value: o[0], selected: (st.status || f.status) === o[0] }, t(o[1])); }));
  function save() { msg.innerHTML = ""; call("forums/" + f.id, "PUT", { title: title.value, description: ed.value(), icon: ic.value, color: color, status: stt.value }).then(function () { msg.appendChild(alertBox(t("Opgeslagen."), true)); }).catch(function (e) { msg.appendChild(alertBox(errText(e))); }); }
  function del() {
    system.confirm(t("Weet je zeker dat je het forum “{0}” met alle groepen, onderwerpen en bijlagen wilt verwijderen? Dit kan niet ongedaan worden gemaakt.", f.title), { title: t("Forum verwijderen"), okLabel: t("Verwijderen"), danger: true }).then(function (ok) {
      if (!ok) return; call("forums/" + f.id, "DELETE").then(function () { S.stack = [{ type: "home" }]; S.cur = S.stack[0]; render(); }).catch(function (e) { msg.appendChild(alertBox(errText(e))); });
    });
  }
  return h("div", { class: "stack" }, h("label", {}, t("Naam"), title), h("label", {}, t("Beschrijving")), ed.el,
    h("div", { class: "grid2" }, h("label", {}, t("Pictogram (optioneel)"), ic), h("label", {}, t("Kleur (optioneel)"), h("span", { class: "row tight" }, col, btn(t("Geen kleur"), "", function () { color = ""; col.value = "#3b82f6"; })))),
    h("label", {}, t("Status"), stt), h("p", { class: "muted" }, t("Bij Gesloten kan niemand nieuwe berichten schrijven. Gearchiveerde forums staan niet meer in de lijsten.")), msg, h("div", { class: "row end" }, btn(t("Opslaan"), "primary", save)),
    h("div", { class: "danger-zone" }, h("h3", {}, t("Gevarenzone")), h("p", { class: "muted" }, t("Het forum en alles erin wordt definitief verwijderd.")), btn(t("Forum verwijderen"), "danger", del, "trash")));
}
function tabPerms(f, st) {
  var perms = JSON.parse(JSON.stringify(st.perms || {})), vis = st.visibility || "members", feats = Object.assign({}, st.features), msg = h("div");
  var visSel = h("select", { "aria-label": t("Zichtbaarheid"), onchange: function () { vis = visSel.value; var lv = { public: "visitors", members: "members", private: "moderators" }[vis]; if (perms.view) perms.view.level = lv; lvSel.view.value = lv; } }, Object.keys(VIS).map(function (k) { return h("option", { value: k, selected: vis === k }, t(VIS[k])); }));
  var lvSel = {}, rows = (st.actions || Object.keys(ACTION_LABELS)).map(function (a) {
    var p = perms[a] = perms[a] || { level: "members", users: [], groups: [] }, sel = lvSel[a] = h("select", { "aria-label": t(ACTION_LABELS[a] || a), onchange: function () { p.level = sel.value; if (a === "view") { vis = { visitors: "public", members: "members" }[sel.value] || "private"; visSel.value = vis; } } },
      (st.levels || Object.keys(LEVEL_LABELS)).map(function (l) { return h("option", { value: l, selected: p.level === l }, t(LEVEL_LABELS[l] || l)); }));
    var more = h("div", { class: "hide" }, accessPicker(p, st.groups)), tog = btn(t("Extra"), "sm", function () { more.classList.toggle("hide"); }, "users");
    var n = (p.users || []).length + (p.groups || []).length;
    return h("tr", {}, h("td", {}, h("b", {}, t(ACTION_LABELS[a] || a))), h("td", {}, sel), h("td", {}, h("div", { class: "row tight" }, tog, n ? h("small", { class: "muted" }, t("{0} extra", n)) : null), more));
  });
  var featRows = Object.keys(FEATURE_LABELS).filter(function (k) { return k in feats; }).map(function (k) {
    var std = (st.standard || {})[k], inp = typeof feats[k] === "boolean" ? h("input", { type: "checkbox", checked: feats[k], onchange: function () { feats[k] = inp.checked; } }) : h("input", { type: "number", min: "1", max: "8", value: feats[k], onchange: function () { feats[k] = Number(inp.value) || 1; } });
    return h("label", { class: "setrow" }, h("span", { class: "grow" }, h("span", { class: "setlbl" }, t(FEATURE_LABELS[k])), std !== undefined ? h("small", { class: "muted" }, t("(standaard: {0})", onoff(std))) : null), inp);
  });
  function save() { msg.innerHTML = ""; call("forums/" + f.id + "/settings", "PUT", { visibility: vis, perms: perms, features: feats }).then(function () { msg.appendChild(alertBox(t("Opgeslagen."), true)); }).catch(function (e) { msg.appendChild(alertBox(errText(e))); }); }
  return h("div", { class: "stack" }, h("label", {}, t("Wie mag dit forum zien?"), visSel),
    h("h2", { class: "sec" }, t("Wie mag wat")), h("div", { class: "tablewrap card flush" }, h("table", {}, h("thead", {}, h("tr", {}, h("th", {}, t("Actie")), h("th", {}, t("Wie mag dit")), h("th", {}, t("Extra personen en groepen")))), h("tbody", {}, rows))),
    h("h2", { class: "sec" }, t("Mogelijkheden")), h("div", { class: "setlist" }, featRows), msg, h("div", { class: "row end" }, btn(t("Opslaan"), "primary", save)));
}
function tabManagers(f, st, d) {
  var box = h("div", { class: "stack" }), msg = h("div"), cats = flatten(d.tree);
  function load() {
    call("forums/" + f.id + "/managers").then(function (r) {
      box.innerHTML = "";
      var list = r.managers || [], forumLevel = list.filter(function (m) { return !m.category_id; }), groupLevel = list.filter(function (m) { return m.category_id; });
      function row(m) {
        return h("li", { class: "mrow" }, avatar(m.user), h("span", { class: "grow" }, h("b", {}, m.user.name), " ", h("span", { class: "badge" }, t(m.role === "owner" ? "Eigenaar" : "Beheerder")), m.category ? h("small", { class: "muted" }, " " + m.category) : null),
          iconBtn("trash", t("Beheerder weghalen: {0}", m.user.name), function () {
            system.confirm(t("{0} niet langer beheerder laten zijn?", m.user.name), { title: t("Beheerder weghalen"), okLabel: t("Weghalen"), danger: true }).then(function (ok) { if (ok) call("managers/" + m.id, "DELETE").then(load).catch(function (e) { box.prepend(alertBox(errText(e))); }); });
          }));
      }
      box.appendChild(h("p", { class: "muted" }, t("Wie een groep maakt is automatisch eigenaar. Een eigenaar kan beheerders weghalen. Een admin voegt beheerders toe.")));
      box.appendChild(h("h3", {}, t("Beheerders van het forum"))); box.appendChild(forumLevel.length ? h("ul", { class: "plain-list" }, forumLevel.map(row)) : h("p", { class: "muted" }, t("Geen.")));
      box.appendChild(h("h3", {}, t("Beheerders van groepen"))); box.appendChild(groupLevel.length ? h("ul", { class: "plain-list" }, groupLevel.map(row)) : h("p", { class: "muted" }, t("Geen.")));
      if (r.can_add) {
        var chosen = null, who = h("div", { class: "muted" }, t("Nog niemand gekozen.")), role = h("select", { "aria-label": t("Rol") }, h("option", { value: "manager" }, t("Beheerder")), S.me && S.me.admin ? h("option", { value: "owner" }, t("Eigenaar")) : null),
          cat = h("select", { "aria-label": t("Waar") }, h("option", { value: "" }, t("Het hele forum")), cats.map(function (c) { return h("option", { value: c.id }, new Array(c.depth + 1).join("— ") + c.title); }));
        box.appendChild(h("div", { class: "card inner stack" }, h("h3", {}, t("Beheerder toevoegen")), userPicker(function (p) { chosen = p; who.textContent = ""; who.appendChild(avatar(p)); who.appendChild(document.createTextNode(" " + p.name)); }), who,
          h("div", { class: "grid2" }, h("label", {}, t("Rol"), role), h("label", {}, t("Waar"), cat)), msg,
          h("div", { class: "row end" }, btn(t("Toevoegen"), "primary", function () {
            msg.innerHTML = ""; if (!chosen) { msg.appendChild(alertBox(t("Kies een gebruiker."))); return; }
            call("forums/" + f.id + "/managers", "POST", { user_id: chosen.id, role: role.value, category_id: cat.value ? Number(cat.value) : null }).then(load).catch(function (e) { msg.appendChild(alertBox(errText(e))); });
          }))));
      } else box.appendChild(h("p", { class: "muted" }, t("Alleen een admin of eigenaar kan beheerders toevoegen.")));
    }).catch(function (e) { box.innerHTML = ""; box.appendChild(alertBox(errText(e))); });
  }
  load(); return box;
}
function tabRights(f, st) {
  if (!st.members_may_set) return h("div", { class: "note" }, icon("lock", 16), h("span", {}, t("De rechten van dit forum worden door de beheerders van de site ingesteld.")));
  var rules = {}, msg = h("div"), names = { view: "Bekijken", edit: "Bewerken", delete: "Verwijderen" };
  ["view", "edit", "delete"].forEach(function (k) { var r = (st.rules || {})[k] || {}; rules[k] = { users: (r.users || []).slice(), groups: (r.groups || []).slice() }; });
  function save() { msg.innerHTML = ""; call("forums/" + f.id + "/rights", "PUT", { rules: rules }).then(function () { msg.appendChild(alertBox(t("Opgeslagen."), true)); }).catch(function (e) { msg.appendChild(alertBox(errText(e))); }); }
  return h("div", { class: "stack" }, h("p", { class: "muted" }, t("Naast de regels bij Wie mag wat bepaalt het systeem wie dit forum als object mag bekijken, bewerken of verwijderen.")),
    ["view", "edit", "delete"].map(function (k) { return h("div", { class: "card inner stack" }, h("h3", {}, t(names[k])), accessPicker(rules[k], st.groups)); }), msg, h("div", { class: "row end" }, btn(t("Opslaan"), "primary", save)));
}

// ── start ──
function start() {
  system.ready.then(function (r) {
    S.me = r.user && r.user.id ? r.user : null;
    S.origin = r.siteOrigin || ""; if (!S.origin) { try { S.origin = new URL(r.apiBase).origin; } catch (e) { S.origin = ""; } }
    var q = (r.route && r.route.query) || {}, p = (r.route && r.route.params) || {}, home = { type: "home" }, view = null;
    if (q.thread) view = { type: "thread", id: q.thread }; else if (q.category) view = { type: "category", id: q.category }; else if (q.forum) view = { type: "forum", id: q.forum }; else if (p.slug) view = { type: "forum", id: p.slug };
    S.stack = view ? [home, view] : [home]; S.cur = S.stack[S.stack.length - 1];
    if (!view) { render(); return; }
    call("home").then(function (d) { S.me = d.me || null; S.board = d.board || {}; }).catch(function () { /* the page itself shows the error */ }).then(function () { render(); });
  });
}
