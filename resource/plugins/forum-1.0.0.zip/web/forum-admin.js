// Copyright & Ownership Notice
// easy2Edit is the exclusive legal property of RST Coaching & Consultancy B.V. (RSTCC),
// owned by Ronald Stolk. All rights reserved. Any unauthorized use, copying, modification,
// reproduction, distribution, or commercial exploitation of Easy2Edit, including its source code,
// is strictly prohibited without prior written permission from Ronald Stolk or RSTCC.
// website https://rstcc.net

"use strict";
/* Forumbeheer: het beheerscherm van de forum-plugin (tabs: overview, forums, groups, managers, reports, board). Teksten gaan door t("…"). */
var ROUTE = "/plugins/run/forum/";
var t = function () { return system.t.apply(system, arguments); };
/* teksten die via een variabele worden getoond, hier opgesomd zodat elke taal ze krijgt:
   t("Overzicht") t("Forums") t("Groepen") t("Beheerders") t("Meldingen") t("Standaardboard") t("Open") t("Gesloten") t("Gearchiveerd") t("Wacht op goedkeuring")
   t("Openbaar") t("Leden") t("Privé") t("Bezoekers") t("Alleen eigenaars en admins") t("Niemand") t("Eigenaar") t("Beheerder") t("Bekijken") t("Groep maken") t("Onderwerp starten")
   t("Reageren") t("Bestanden toevoegen") t("Reacties (vind ik leuk)") t("Eigen berichten wijzigen") t("Eigen berichten verwijderen") t("Modereren") t("Wie mag wat") t("Bestanden") t("Moderatie") t("Weergave") */
var TABS = [["overview", "Overzicht", "chart"], ["forums", "Forums", "chat"], ["groups", "Groepen", "folder"], ["managers", "Beheerders", "user"], ["reports", "Meldingen", "flag"], ["board", "Standaardboard", "sliders"]];
var STATUS = [["open", "Open"], ["closed", "Gesloten"], ["archived", "Gearchiveerd"], ["pending", "Wacht op goedkeuring"]];
var VIS = { public: "Openbaar", members: "Leden", private: "Privé" };
var ACTIONS = [["view", "Bekijken"], ["create_category", "Groep maken"], ["create_thread", "Onderwerp starten"], ["reply", "Reageren"], ["upload", "Bestanden toevoegen"], ["react", "Reacties (vind ik leuk)"], ["edit_own", "Eigen berichten wijzigen"], ["delete_own", "Eigen berichten verwijderen"], ["moderate", "Modereren"]];
var LEVELS = [["visitors", "Bezoekers"], ["members", "Leden"], ["moderators", "Beheerders"], ["admins", "Alleen eigenaars en admins"], ["nobody", "Niemand"]];
var SUBS = [["forums", "Forums"], ["perms", "Wie mag wat"], ["files", "Bestanden"], ["moderation", "Moderatie"], ["view", "Weergave"]];
var app = document.getElementById("app");
var S = { tab: "overview", sub: "forums", cache: {}, error: null, msg: null, forumFilter: "", groupForum: "", seq: 0 };

var ICONS = {
  chart: "M4 20V10M10 20V4M16 20v-7M22 20H2", chat: "M21 12a8 8 0 0 1-11.6 7.1L3 21l1.9-5.4A8 8 0 1 1 21 12z", folder: "M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z",
  user: "M20 21a8 8 0 0 0-16 0M12 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8z", flag: "M5 21V4M5 4h11l-2 4 2 4H5", sliders: "M4 6h10M18 6h2M4 12h4M12 12h8M4 18h12M20 18h0M14 4v4M8 10v4M16 16v4",
  trash: "M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3", swap: "M7 4 3 8l4 4M3 8h14M17 20l4-4-4-4M21 16H7", bold: "M7 5h6a3.5 3.5 0 0 1 0 7H7zM7 12h7a3.5 3.5 0 0 1 0 7H7z", italic: "M19 4h-9M14 20H5M15 4 9 20",
  list: "M9 6h12M9 12h12M9 18h12M4 6h.01M4 12h.01M4 18h.01", link: "M10 14a5 5 0 0 0 7 0l3-3a5 5 0 0 0-7-7l-1 1M14 10a5 5 0 0 0-7 0l-3 3a5 5 0 0 0 7 7l1-1", check: "M5 12l5 5L20 7", eye: "M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12zM12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6z",
  x: "M6 6l12 12M18 6 6 18", plus: "M12 5v14M5 12h14", clock: "M12 7v5l3 2M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18z"
};
function svg(name) {
  var s = document.createElementNS("http://www.w3.org/2000/svg", "svg");
  ["viewBox:0 0 24 24", "width:18", "height:18", "fill:none", "stroke:currentColor", "stroke-width:2", "stroke-linecap:round", "stroke-linejoin:round", "aria-hidden:true", "focusable:false"].forEach(function (a) { var p = a.split(":"); s.setAttribute(p[0], p[1]); });
  var p = document.createElementNS("http://www.w3.org/2000/svg", "path"); p.setAttribute("d", ICONS[name] || ""); s.appendChild(p); return s;
}
function h(tag, props) {
  var el = document.createElement(tag), kids = Array.prototype.slice.call(arguments, 2);
  Object.keys(props || {}).forEach(function (k) {
    var v = props[k];
    if (k === "class") el.className = v; else if (k.indexOf("on") === 0) el.addEventListener(k.slice(2), v);
    else if (k === "style") el.style.cssText = v; else if (k === "value") el.value = v; else if (v === true) el.setAttribute(k, ""); else if (v !== false && v != null) el.setAttribute(k, v);
  });
  (function add(list) { list.forEach(function (c) { if (Array.isArray(c)) add(c); else if (c != null && c !== false) el.appendChild(typeof c === "object" ? c : document.createTextNode(String(c))); }); })(kids);
  return el;
}
var call = function (path, method, body) { return system.api(ROUTE + path, { method: method || "GET", body: body }); };
var lang = function () { return document.documentElement.lang || "nl"; };
function when(iso) { return iso ? new Date(iso).toLocaleDateString(lang(), { day: "numeric", month: "short", year: "numeric" }) : ""; }
function mb(n) { return ((Number(n) || 0) / 1048576).toFixed(1); }
function plain(s) { var d = new DOMParser().parseFromString(String(s || "").replace(/^html:/, ""), "text/html"); return (d.body.textContent || "").trim(); }
function fail(e) { S.msg = { ok: false, text: e && e.message ? e.message : String(e) }; draw(); }
function flash(text) { S.msg = { ok: true, text: text }; draw(); setTimeout(function () { if (S.msg && S.msg.text === text) { S.msg = null; draw(); } }, 3500); }
function badge(text, kind) { return h("span", { class: "badge" + (kind ? " " + kind : "") }, text); }
function icoBtn(icon, label, fn, cls) { return h("button", { type: "button", class: "btn sm icon " + (cls || ""), title: label, "aria-label": label, onclick: fn }, svg(icon)); }
function empty(text) { return h("div", { class: "empty" }, text); }
function table(heads, rows) { return h("div", { class: "tw" }, h("table", {}, h("thead", {}, h("tr", {}, heads.map(function (x) { return h("th", {}, x); }))), h("tbody", {}, rows))); }
function field(label, input, help) { return h("label", { class: "fld" }, h("span", {}, label), input, help ? h("small", { class: "muted" }, help) : null); }

/* ── load data of a tab (cached until it changes) ── */
function need(key, path) {
  if (S.cache[key]) return Promise.resolve(S.cache[key]);
  return call(path).then(function (d) { S.cache[key] = d; return d; });
}
function forget() { S.cache = {}; }
function show(tab, sub) {
  S.tab = tab; if (sub) S.sub = sub; S.error = null; var me = ++S.seq;
  draw();
  var jobs = { overview: ["overview", "admin/overview"], forums: ["forums", "admin/forums"], groups: ["groups", "admin/groups"], managers: ["managers", "admin/managers"], reports: ["reports", "admin/reports"], board: ["board", "admin/board"] }[tab];
  var list = [need(jobs[0], jobs[1])];
  if (tab === "groups" || tab === "managers") list.push(need("forums", "admin/forums"));
  Promise.all(list).then(function () { if (me === S.seq) { if (tab === "board" && !S.board) { S.board = JSON.parse(JSON.stringify(S.cache.board.board)); } draw(); } }).catch(function (e) { if (me === S.seq) { S.error = e.message || String(e); draw(); } });
}

/* ── frame ── */
function draw() {
  var keep = document.activeElement && document.activeElement.id;
  var top = [h("div", { class: "hero" }, h("div", {}, h("h1", {}, t("Forumbeheer")), h("p", { class: "muted" }, t("Forums, groepen, beheerders en meldingen van het hele systeem."))))];
  var bar = h("div", { class: "tabs", role: "tablist" }, TABS.map(function (x) {
    var n = S.cache.overview && (x[0] === "reports" ? S.cache.overview.reports : 0);
    return h("button", { type: "button", class: S.tab === x[0] ? "on" : "", role: "tab", "aria-selected": S.tab === x[0] ? "true" : "false", onclick: function () { show(x[0]); } }, svg(x[2]), h("span", {}, t(x[1])), n ? h("span", { class: "dot" }, n) : null);
  }));
  var body;
  if (S.error) body = h("div", { class: "alert", role: "alert" }, S.error);
  else if (!S.cache[{ overview: "overview", forums: "forums", groups: "groups", managers: "managers", reports: "reports", board: "board" }[S.tab]] || ((S.tab === "groups" || S.tab === "managers") && !S.cache.forums)) body = h("p", { class: "muted" }, t("Laden…"));
  else body = { overview: vOverview, forums: vForums, groups: vGroups, managers: vManagers, reports: vReports, board: vBoard }[S.tab]();
  app.innerHTML = "";
  app.append.apply(app, top.concat([bar, S.msg ? h("div", { class: "alert" + (S.msg.ok ? " ok" : ""), role: "status" }, S.msg.text) : null, h("div", { class: "panel", role: "tabpanel" }, body)]));
  if (keep) { var el = document.getElementById(keep); if (el) { el.focus(); try { el.setSelectionRange(el.value.length, el.value.length); } catch (x) { /* not a text field */ } } }
}

/* ── person search with suggestions ── */
function picker(onPick, id) {
  var box = h("div", { class: "picker" }), inp = h("input", { type: "search", id: id || null, placeholder: t("Zoek een gebruiker (minstens 2 letters)…"), autocomplete: "off", "aria-label": t("Zoek een gebruiker") }), list = h("ul", { class: "suggest", role: "listbox" }), timer = null, n = 0;
  inp.addEventListener("input", function () {
    clearTimeout(timer); var q = inp.value.trim(), me = ++n; list.innerHTML = "";
    if (q.length < 2) return;
    timer = setTimeout(function () {
      call("people?q=" + encodeURIComponent(q)).then(function (r) {
        if (me !== n) return; list.innerHTML = "";
        if (!r.people.length) list.appendChild(h("li", { class: "muted" }, t("Niemand gevonden.")));
        r.people.forEach(function (p) { list.appendChild(h("li", { role: "option", tabindex: "0", onclick: pick, onkeydown: function (e) { if (e.key === "Enter") pick(); } }, h("span", { class: "av" }, p.initials), h("span", { class: "grow" }, p.name, p.email ? h("small", { class: "muted" }, " " + p.email) : null)));
          function pick() { inp.value = p.name; list.innerHTML = ""; onPick(p); } });
      }).catch(fail);
    }, 250);
  });
  box.append(inp, list); return box;
}
function dialog(title, content, ok) {
  var ov = h("div", { class: "overlay", onclick: function (e) { if (e.target === ov) close(); } }), prev = document.activeElement;
  function close() { ov.remove(); if (prev && prev.focus) prev.focus(); }
  ov.appendChild(h("div", { class: "modal", role: "dialog", "aria-modal": "true", "aria-label": title }, h("div", { class: "row between" }, h("h2", {}, title), icoBtn("x", t("Sluiten"), close, "ghost")), content, h("div", { class: "row end" }, h("button", { type: "button", class: "btn", onclick: close }, t("Annuleren")))));
  ov.addEventListener("keydown", function (e) { if (e.key === "Escape") close(); });
  document.body.appendChild(ov); var f = ov.querySelector("input"); if (f) f.focus();
  return close;
}

/* ── 1. overview ── */
function vOverview() {
  var o = S.cache.overview;
  var stats = [["Forums", o.forums], ["Groepen", o.groups], ["Onderwerpen", o.threads], ["Berichten", o.posts], ["Beheerders", o.managers], ["Volgers", o.follows], ["Bijlagen", o.attachments + " · " + mb(o.attachment_bytes) + " MB"],
    ["Onderwerpen (7 dagen)", o.threads_week], ["Berichten (7 dagen)", o.posts_week], ["Actieve gebruikers (7 dagen)", o.active_users]];
  return h("div", { class: "stack" },
    h("div", { class: "stats" }, stats.map(function (s) { return h("div", { class: "stat" }, h("div", { class: "num" }, s[1]), h("small", { class: "muted" }, t(s[0]))); })),
    h("div", { class: "short" },
      h("button", { type: "button", class: "btn short-b", onclick: function () { show("reports"); } }, svg("flag"), h("span", {}, t("Meldingen")), badge(o.reports, o.reports ? "bad" : "ok")),
      h("button", { type: "button", class: "btn short-b", onclick: function () { show("forums"); } }, svg("clock"), h("span", {}, t("Wacht op goedkeuring")), badge(o.pending, o.pending ? "warn" : "ok")),
      h("button", { type: "button", class: "btn short-b", onclick: function () { show("managers"); } }, svg("user"), h("span", {}, t("Beheerders"))),
      h("button", { type: "button", class: "btn short-b", onclick: function () { show("board"); } }, svg("sliders"), h("span", {}, t("Standaardboard")))),
    h("div", { class: "card" }, h("h2", {}, t("Laatste onderwerpen")),
      o.latest.length ? h("ul", { class: "plain" }, o.latest.map(function (x) { return h("li", {}, h("div", { class: "grow" }, h("strong", {}, x.title), h("div", { class: "muted small" }, x.forum + " · " + x.author.name + " · " + when(x.created_at))), x.status !== "published" ? badge(x.status === "pending" ? t("Wacht op goedkeuring") : t("Verborgen"), "warn") : null, h("span", { class: "muted small" }, x.replies + " " + t("reacties"))); })) : empty(t("Nog geen onderwerpen."))));
}

/* ── 2. forums ── */
function vForums() {
  var all = S.cache.forums.forums, q = S.forumFilter.toLowerCase();
  var rows = all.filter(function (f) { return !q || (f.title + " " + (f.owner ? f.owner.name : "")).toLowerCase().indexOf(q) >= 0; });
  var inp = h("input", { type: "search", id: "ffilter", value: S.forumFilter, placeholder: t("Zoek een forum of eigenaar…"), "aria-label": t("Zoek een forum of eigenaar") });
  inp.addEventListener("input", function () { S.forumFilter = inp.value; draw(); });
  return h("div", { class: "stack" },
    h("div", { class: "hint" }, t("De rechten van elk forum (wie het mag bekijken, wijzigen of verwijderen als systeemrecord) beheer je onder Admin → Rechten.")), inp,
    rows.length ? table([t("Forum"), t("Eigenaar"), t("Zichtbaar voor"), t("Status"), t("Inhoud"), ""], rows.map(forumRow)) : empty(t("Geen forums gevonden.")));
}
function forumRow(f) {
  var sel = h("select", { "aria-label": t("Status van {0}", f.title) }, STATUS.map(function (s) { return h("option", { value: s[0], selected: f.status === s[0] }, t(s[1])); }));
  sel.addEventListener("change", function () { call("admin/forums/" + f.id, "PUT", { status: sel.value }).then(function () { forget(); flash(t("Opgeslagen.")); show("forums"); }).catch(function (e) { forget(); fail(e); show("forums"); }); });
  return h("tr", {}, h("td", {}, h("strong", {}, f.title), h("div", { class: "muted small" }, "/forum/" + f.slug)), h("td", {}, f.owner ? f.owner.name : "-"), h("td", {}, badge(t(VIS[f.visibility] || f.visibility), f.visibility === "public" ? "ok" : "")), h("td", {}, sel),
    h("td", { class: "small" }, f.groups + " " + t("groepen") + ", " + f.threads + " " + t("onderwerpen") + ", " + f.posts + " " + t("berichten")),
    h("td", { class: "acts" }, icoBtn("swap", t("Eigenaar wijzigen"), function () { ownerDialog(f); }), icoBtn("trash", t("Forum verwijderen"), function () { delForum(f); }, "danger")));
}
function ownerDialog(f) {
  var close = dialog(t("Eigenaar van {0}", f.title), h("div", { class: "stack" }, h("p", { class: "muted" }, t("Huidige eigenaar: {0}", f.owner ? f.owner.name : "-")),
    picker(function (p) { call("admin/forums/" + f.id, "PUT", { owner_id: p.id }).then(function () { close(); forget(); flash(t("Eigenaar gewijzigd.")); show("forums"); }).catch(function (e) { close(); fail(e); }); })));
}
function delForum(f) {
  system.confirm(t("Het forum “{0}” met alle groepen, onderwerpen, berichten en bijlagen definitief verwijderen?", f.title), { title: t("Forum verwijderen"), okLabel: t("Verwijderen"), danger: true }).then(function (ok) {
    if (ok) call("admin/forums/" + f.id, "DELETE").then(function () { forget(); flash(t("Forum verwijderd.")); show("forums"); }).catch(fail);
  });
}

/* ── 3. groups ── */
function vGroups() {
  var forums = S.cache.forums.forums, rows = S.cache.groups.groups.filter(function (g) { return !S.groupForum || g.forum === S.groupForum; });
  var sel = h("select", { "aria-label": t("Filter op forum") }, h("option", { value: "" }, t("Alle forums")), forums.map(function (f) { return h("option", { value: f.title, selected: S.groupForum === f.title }, f.title); }));
  sel.addEventListener("change", function () { S.groupForum = sel.value; draw(); });
  return h("div", { class: "stack" }, h("div", { class: "row" }, h("label", { class: "fld inline" }, h("span", {}, t("Forum")), sel)),
    rows.length ? table([t("Groep"), t("Forum"), t("Onderwerpen"), t("Status"), t("Beheerders")], rows.map(function (g) {
      return h("tr", {}, h("td", {}, h("span", { class: "indent", style: "--d:" + (g.depth || 0) }, (g.depth ? "↳ " : "") + g.title)), h("td", {}, g.forum), h("td", {}, g.threads), h("td", {}, g.locked ? badge(t("Vergrendeld"), "warn") : badge(t("Open"), "ok")),
        h("td", {}, g.managers.length ? g.managers.map(function (m) { return h("span", { class: "chip" }, m.name, m.role === "owner" ? badge(t("Eigenaar")) : null); }) : h("span", { class: "muted" }, "-")));
    })) : empty(t("Geen groepen gevonden.")));
}

/* ── 4. managers ── */
function flat(tree, d, out) { (tree || []).forEach(function (c) { out.push({ id: c.id, title: c.title, depth: d }); flat(c.children, d + 1, out); }); return out; }
function vManagers() {
  var list = S.cache.managers.managers, forums = S.cache.forums.forums, A = S.add || (S.add = { forum: "", cat: "", user: null, role: "manager", groups: [] });
  var fsel = h("select", { id: "mf" }, h("option", { value: "" }, t("Kies een forum")), forums.map(function (f) { return h("option", { value: f.id, selected: String(A.forum) === String(f.id) }, f.title); }));
  fsel.addEventListener("change", function () { A.forum = fsel.value; A.cat = ""; A.groups = []; if (!A.forum) { draw(); return; } call("forums/" + A.forum).then(function (d) { A.groups = flat(d.tree, 0, []); draw(); }).catch(fail); draw(); });
  var csel = h("select", { id: "mc", disabled: !A.forum }, h("option", { value: "" }, t("Heel forum")), A.groups.map(function (g) { return h("option", { value: g.id, selected: String(A.cat) === String(g.id) }, "  ".repeat(g.depth) + g.title); }));
  csel.addEventListener("change", function () { A.cat = csel.value; });
  var rsel = h("select", { id: "mr" }, [["manager", "Beheerder"], ["owner", "Eigenaar"]].map(function (r) { return h("option", { value: r[0], selected: A.role === r[0] }, t(r[1])); }));
  rsel.addEventListener("change", function () { A.role = rsel.value; });
  var chosen = h("div", { class: "muted small", id: "mchosen" }, A.user ? t("Gekozen: {0}", A.user.name) : t("Nog niemand gekozen."));
  var go = h("button", { type: "button", class: "btn primary", onclick: function () {
    if (!A.forum || !A.user) { fail(new Error(t("Kies een forum en een gebruiker."))); return; }
    var body = { user_id: A.user.id, role: A.role }; if (A.cat) body.category_id = Number(A.cat);
    call("forums/" + A.forum + "/managers", "POST", body).then(function () { A.user = null; forget(); flash(t("Beheerder toegevoegd.")); show("managers"); }).catch(fail);
  } }, svg("plus"), h("span", {}, t("Toevoegen")));
  return h("div", { class: "stack" },
    h("div", { class: "card" }, h("h2", {}, t("Beheerder toevoegen")), h("div", { class: "hint" }, t("Wie een groep maakt is automatisch eigenaar en kan beheerders weghalen. Alleen een admin voegt beheerders toe.")),
      h("div", { class: "formgrid" }, field(t("Forum"), fsel), field(t("Groep"), csel), field(t("Gebruiker"), picker(function (p) { A.user = p; chosen.textContent = t("Gekozen: {0}", p.name); })), field(t("Rol"), rsel)), h("div", { class: "row" }, go, chosen)),
    list.length ? table([t("Forum"), t("Groep"), t("Persoon"), t("Rol"), t("Toegevoegd door"), t("Datum"), ""], list.map(function (m) {
      return h("tr", {}, h("td", {}, m.forum), h("td", {}, m.category || t("Heel forum")), h("td", {}, m.user.name), h("td", {}, badge(t(m.role === "owner" ? "Eigenaar" : "Beheerder"), m.role === "owner" ? "ok" : "")), h("td", {}, m.added_by ? m.added_by.name : "-"), h("td", { class: "small" }, when(m.created_at)),
        h("td", { class: "acts" }, icoBtn("trash", t("Beheerder verwijderen"), function () { delManager(m); }, "danger")));
    })) : empty(t("Nog geen beheerders.")));
}
function delManager(m) {
  system.confirm(t("{0} niet langer beheerder laten zijn van {1}?", m.user.name, m.category || m.forum), { title: t("Beheerder verwijderen"), okLabel: t("Verwijderen"), danger: true }).then(function (ok) {
    if (ok) call("managers/" + m.id, "DELETE").then(function () { forget(); flash(t("Beheerder verwijderd.")); show("managers"); }).catch(fail);
  });
}

/* ── 5. reports ── */
function vReports() {
  var rows = S.cache.reports.reports;
  if (!rows.length) return empty(t("Geen meldingen."));
  var open = rows.filter(function (r) { return r.status === "open"; }), done = rows.filter(function (r) { return r.status !== "open"; });
  function card(r) {
    var act = function (a, label, cls, confirm) { return h("button", { type: "button", class: "btn sm " + (cls || ""), onclick: function () {
      var run = function () { call("admin/reports/" + r.id, "POST", { action: a }).then(function () { forget(); flash(t("Gedaan.")); show("reports"); }).catch(fail); };
      if (confirm) system.confirm(t("Dit bericht definitief verwijderen?"), { title: label, okLabel: label, danger: true }).then(function (ok) { if (ok) run(); }); else run();
    } }, label); };
    return h("div", { class: "card report" }, h("div", { class: "row between" }, h("strong", {}, r.title || t("(verwijderd)")), badge(r.status === "open" ? t("Open") : t("Afgehandeld"), r.status === "open" ? "bad" : "ok")),
      h("div", { class: "muted small" }, r.forum + " · " + t("gemeld door {0}", r.reporter.name) + " · " + when(r.created_at) + (r.post_id ? " · " + t("reactie") : " · " + t("onderwerp"))),
      r.reason ? h("p", {}, h("strong", {}, t("Reden") + ": "), r.reason) : null, r.excerpt ? h("blockquote", {}, r.excerpt) : null,
      r.status === "open" ? h("div", { class: "row" }, act("dismiss", t("Negeren")), act("hide", t("Verbergen"), "warn"), act("delete", t("Verwijderen"), "danger", true)) : null);
  }
  return h("div", { class: "stack" }, open.length ? h("h2", {}, t("Open") + " (" + open.length + ")") : h("div", { class: "alert ok" }, t("Alle meldingen zijn afgehandeld.")), open.map(card), done.length ? h("h2", {}, t("Afgehandeld")) : null, done.map(card));
}

/* ── light rich text editor (bold, italic, list, link) ── */
var OKTAGS = { B: 1, STRONG: 1, I: 1, EM: 1, U: 1, UL: 1, OL: 1, LI: 1, P: 1, BR: 1, A: 1, DIV: 1 };
function clean(node, out) {
  Array.prototype.forEach.call(node.childNodes, function (c) {
    if (c.nodeType === 3) out.appendChild(document.createTextNode(c.nodeValue));
    else if (c.nodeType === 1 && OKTAGS[c.tagName]) {
      var e = document.createElement(c.tagName.toLowerCase());
      if (c.tagName === "A") { var href = c.getAttribute("href") || ""; if (/^(https?:|mailto:|\/)/i.test(href)) { e.setAttribute("href", href); e.setAttribute("rel", "noopener nofollow"); e.setAttribute("target", "_blank"); } }
      clean(c, e); out.appendChild(e);
    } else if (c.nodeType === 1 && !/^(SCRIPT|STYLE)$/.test(c.tagName)) clean(c, out);
  });
  return out;
}
function safeHtml(v) { v = String(v || ""); if (v.indexOf("html:") !== 0) { var d = document.createElement("div"); d.textContent = v; return d.innerHTML.replace(/\n/g, "<br>"); } var doc = new DOMParser().parseFromString(v.slice(5), "text/html"); return clean(doc.body, document.createElement("div")).innerHTML; }
function editor(value, onChange, label) {
  var area = h("div", { class: "rte", contenteditable: "true", role: "textbox", "aria-multiline": "true", "aria-label": label, tabindex: "0" }), saved = null, urlRow = h("div", { class: "row urlrow", hidden: true });
  area.innerHTML = safeHtml(value);
  var url = h("input", { type: "url", placeholder: "https://", "aria-label": t("Webadres van de link") });
  function keepSel() { var s = window.getSelection(); if (s.rangeCount && area.contains(s.anchorNode)) saved = s.getRangeAt(0).cloneRange(); }
  function cmd(c, arg) { area.focus(); if (saved) { var s = window.getSelection(); s.removeAllRanges(); s.addRange(saved); } document.execCommand(c, false, arg || null); keepSel(); onChange("html:" + clean(area, document.createElement("div")).innerHTML); }
  area.addEventListener("input", function () { keepSel(); onChange("html:" + clean(area, document.createElement("div")).innerHTML); });
  area.addEventListener("keyup", keepSel); area.addEventListener("mouseup", keepSel); area.addEventListener("blur", keepSel);
  function tb(icon, lab, fn) { var b = icoBtn(icon, lab, fn, "ghost"); b.addEventListener("mousedown", function (e) { e.preventDefault(); }); return b; }
  urlRow.append(url, h("button", { type: "button", class: "btn sm primary", onclick: function () { var u = url.value.trim(); if (/^(https?:\/\/|mailto:)/i.test(u)) { cmd("createLink", u); url.value = ""; urlRow.hidden = true; } else url.focus(); } }, t("Link plaatsen")));
  return h("div", { class: "rte-box" }, h("div", { class: "rte-bar", role: "toolbar", "aria-label": t("Opmaak") }, tb("bold", t("Vet"), function () { cmd("bold"); }), tb("italic", t("Cursief"), function () { cmd("italic"); }), tb("list", t("Lijst"), function () { cmd("insertUnorderedList"); }),
    h("button", { type: "button", class: "btn sm icon ghost", title: t("Link"), "aria-label": t("Link"), onclick: function () { keepSel(); urlRow.hidden = !urlRow.hidden; if (!urlRow.hidden) url.focus(); } }, svg("link"))), urlRow, area);
}

/* ── 6. board (default settings) ── */
function bool(key, label, help) { var c = h("input", { type: "checkbox", checked: !!S.board[key], id: "b_" + key }); c.addEventListener("change", function () { S.board[key] = c.checked; }); return h("div", { class: "fld check" }, h("label", { class: "chk" }, c, h("span", {}, label)), help ? h("small", { class: "muted" }, help) : null); }
function num(key, label, help, min) { var i = h("input", { type: "number", min: min == null ? 0 : min, id: "b_" + key, value: S.board[key] }); i.addEventListener("change", function () { S.board[key] = i.value === "" ? 0 : Number(i.value); }); return field(label, i, help); }
function vBoard() {
  var B = S.board;
  var subs = h("div", { class: "tabs sub", role: "tablist" }, SUBS.map(function (x) { return h("button", { type: "button", class: S.sub === x[0] ? "on" : "", role: "tab", "aria-selected": S.sub === x[0] ? "true" : "false", onclick: function () { S.sub = x[0]; draw(); } }, t(x[1])); }));
  var body;
  if (S.sub === "forums") {
    var vis = h("select", { id: "b_vis" }, Object.keys(VIS).map(function (k) { return h("option", { value: k, selected: B.default_visibility === k }, t(VIS[k])); })); vis.addEventListener("change", function () { B.default_visibility = vis.value; });
    body = h("div", { class: "stack" }, bool("members_create_forums", t("Leden mogen zelf forums maken"), t("Uit: alleen beheerders maken forums.")), num("max_forums_per_user", t("Maximaal aantal forums per gebruiker"), t("0 betekent geen grens. Beheerders vallen hier nooit onder.")),
      field(t("Standaard zichtbaarheid van een nieuw forum"), vis, t("Openbaar: iedereen, ook bezoekers. Leden: alleen ingelogde gebruikers. Privé: alleen beheerders.")),
      field(t("Welkomsttekst"), editor(B.welcome_text, function (v) { B.welcome_text = v; }, t("Welkomsttekst")), t("Wordt getoond boven de forums.")), bool("owners_add_managers", t("Eigenaars mogen beheerders toevoegen"), t("Uit: alleen een admin voegt beheerders toe.")),
      bool("auto_follow", t("Automatisch volgen"), t("Wie een forum, groep of onderwerp maakt of erop reageert, krijgt meldingen.")), num("subgroup_depth", t("Aantal lagen subgroepen"), t("Hoe diep groepen in groepen mogen."), 1));
  } else if (S.sub === "perms") {
    body = h("div", { class: "stack" }, h("div", { class: "hint" }, t("Per actie het laagste niveau dat het mag. Een forum kan dit zelf aanpassen. Een hoger niveau mag altijd alles wat een lager niveau mag.")),
      table([t("Actie"), t("Wie mag het")], ACTIONS.map(function (a) { var cur = B.perms[a[0]] || (B.perms[a[0]] = { level: "members" });
        var s = h("select", { "aria-label": t(a[1]) }, LEVELS.map(function (l) { return h("option", { value: l[0], selected: cur.level === l[0] }, t(l[1])); })); s.addEventListener("change", function () { cur.level = s.value; });
        return h("tr", {}, h("td", {}, t(a[1])), h("td", {}, s)); })));
  } else if (S.sub === "files") {
    body = h("div", { class: "stack" }, bool("allow_attachments", t("Bijlagen toestaan"), t("Hoofdschakelaar: uit betekent geen foto's, video's of bestanden.")), bool("allow_photos", t("Foto's toestaan"), "JPG, PNG, GIF, WebP."), bool("allow_videos", t("Video's toestaan"), "MP4, WebM, MOV."),
      bool("allow_files", t("Bestanden toestaan"), t("PDF, Office, tekst en zip. Standaard uit om misbruik te voorkomen.")), h("div", { class: "formgrid" }, num("max_photo_mb", t("Maximale grootte foto (MB)"), "", 1), num("max_video_mb", t("Maximale grootte video (MB)"), "", 1), num("max_file_mb", t("Maximale grootte bestand (MB)"), "", 1), num("max_attachments", t("Bijlagen per bericht"), t("Hoeveel bijlagen een bericht mag hebben."), 1)));
  } else if (S.sub === "moderation") {
    body = h("div", { class: "stack" }, bool("require_approval", t("Eerst goedkeuren"), t("Nieuwe onderwerpen en reacties van leden zijn pas zichtbaar na goedkeuring door een beheerder.")), bool("allow_reports", t("Leden mogen berichten melden"), t("Meldingen komen op het tabblad Meldingen.")),
      num("edit_window_minutes", t("Tijd om een eigen bericht te wijzigen (minuten)"), t("0 betekent altijd.")), num("flood_seconds", t("Wachttijd tussen berichten (seconden)"), t("Houdt spam tegen. 0 betekent geen wachttijd. Beheerders hebben nooit wachttijd.")));
  } else {
    body = h("div", { class: "stack" }, h("div", { class: "formgrid" }, num("threads_per_page", t("Onderwerpen per pagina"), "", 5), num("posts_per_page", t("Berichten per pagina"), "", 5)), bool("reactions", t("Reacties (vind ik leuk) tonen"), t("Leden kunnen een bericht leuk vinden.")));
  }
  return h("div", { class: "stack" }, h("div", { class: "hint" }, t("Dit zijn de standaardinstellingen voor nieuwe forums. Een forum kan ze zelf aanpassen.")), subs, h("div", { class: "card stack" }, body),
    h("div", { class: "row" }, h("button", { type: "button", class: "btn primary", id: "bsave", onclick: saveBoard }, svg("check"), h("span", {}, t("Opslaan"))), S.msg && S.msg.ok ? h("span", { class: "muted" }, S.msg.text) : null));
}
function saveBoard() {
  call("admin/board", "PUT", S.board).then(function (r) { S.cache.board = r; S.board = JSON.parse(JSON.stringify(r.board)); flash(t("Opgeslagen.")); }).catch(fail);
}

function start() {
  system.ready.then(function (r) {
    var q = (r.route && r.route.query) || {}, tab = q.tab;
    show(TABS.some(function (x) { return x[0] === tab; }) ? tab : "overview");
  });
}
