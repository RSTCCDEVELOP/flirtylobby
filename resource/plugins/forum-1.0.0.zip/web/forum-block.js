// Copyright & Ownership Notice
// easy2Edit is the exclusive legal property of RST Coaching & Consultancy B.V. (RSTCC),
// owned by Ronald Stolk. All rights reserved. Any unauthorized use, copying, modification,
// reproduction, distribution, or commercial exploitation of Easy2Edit, including its source code,
// is strictly prohibited without prior written permission from Ronald Stolk or RSTCC.
// website https://rstcc.net

"use strict";
/* Forum-blokken voor pagina's (view = forums | latest | popular | forum | start | search). Teksten gaan door t("…"). */
var ROUTE = "/plugins/run/forum/";
var t = function () { return system.t.apply(system, arguments); };
var app = document.getElementById("app");
var P = { view: "forums", limit: "", forum: "", q: "", signedIn: false };

var ICONS = { chat: "M21 12a8 8 0 0 1-11.6 7.1L3 21l1.9-5.4A8 8 0 1 1 21 12z", folder: "M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z", search: "M11 19a8 8 0 1 0 0-16 8 8 0 0 0 0 16zM21 21l-4.3-4.3", plus: "M12 5v14M5 12h14", reply: "M9 14 4 9l5-5M4 9h10a6 6 0 0 1 6 6v3" };
function svg(name) {
  var s = document.createElementNS("http://www.w3.org/2000/svg", "svg");
  ["viewBox:0 0 24 24", "width:18", "height:18", "fill:none", "stroke:currentColor", "stroke-width:2", "stroke-linecap:round", "stroke-linejoin:round", "aria-hidden:true", "focusable:false"].forEach(function (a) { var p = a.split(":"); s.setAttribute(p[0], p[1]); });
  var p = document.createElementNS("http://www.w3.org/2000/svg", "path"); p.setAttribute("d", ICONS[name] || ""); s.appendChild(p); return s;
}
function h(tag, props) {
  var el = document.createElement(tag), kids = Array.prototype.slice.call(arguments, 2);
  Object.keys(props || {}).forEach(function (k) {
    var v = props[k];
    if (k === "class") el.className = v; else if (k.indexOf("on") === 0) el.addEventListener(k.slice(2), v);
    else if (k === "style") el.style.cssText = v; else if (k === "value") el.value = v; else if (v === true) el.setAttribute(k, ""); else if (v !== false && v != null) el.setAttribute(k, v);
  });
  (function add(list) { list.forEach(function (c) { if (Array.isArray(c)) add(c); else if (c != null && c !== false) el.appendChild(typeof c === "object" ? c : document.createTextNode(String(c))); }); })(kids);
  return el;
}
var call = function (path) { return system.api(ROUTE + path, { method: "GET" }); };
var lang = function () { return document.documentElement.lang || "nl"; };
var editing = function () { return document.documentElement.getAttribute("data-editing") === "1"; };
function plain(s) { var d = new DOMParser().parseFromString(String(s || "").replace(/^html:/, ""), "text/html"); return (d.body.textContent || "").trim(); }
function ago(iso) {
  if (!iso) return "";
  var s = Math.max(0, (Date.now() - new Date(iso).getTime()) / 1000);
  try { var rf = new Intl.RelativeTimeFormat(lang(), { numeric: "auto" });
    if (s < 3600) return rf.format(-Math.max(1, Math.round(s / 60)), "minute"); if (s < 86400) return rf.format(-Math.round(s / 3600), "hour"); if (s < 2592000) return rf.format(-Math.round(s / 86400), "day"); } catch (x) { /* older browsers */ }
  return new Date(iso).toLocaleDateString(lang(), { day: "numeric", month: "short", year: "numeric" });
}
/* links: system.go opens an address of the website; the href stays a real link (target _top) for open-in-new-tab and crawlers */
function forumHref(f) { return "/forum/" + encodeURIComponent(f.slug); }
function threadHref(id) { return "/dashboard/plugins/forum?thread=" + id; }
function link(href, cls, label, kids) {
  return h("a", { href: href, target: "_top", class: cls, "aria-label": label || null, onclick: function (e) { if (e.ctrlKey || e.metaKey || e.shiftKey || e.button) return; e.preventDefault(); if (editing()) return; system.go(href); } }, kids);
}
function note(text, cls) { return h("div", { class: "fb-note " + (cls || "") }, text); }
function count(n, one, many) { return n + " " + (n === 1 ? one : many); }

/* ── cards and lists ── */
function forumCard(f) {
  var desc = plain(f.description);
  return link(forumHref(f), "fb-card", f.title, [h("span", { class: "fb-ico" }, svg("chat")), h("strong", { class: "fb-title" }, f.title), desc ? h("span", { class: "fb-desc" }, desc.length > 120 ? desc.slice(0, 117) + "…" : desc) : null,
    h("span", { class: "fb-meta" }, count(f.threads, t("onderwerp"), t("onderwerpen")) + " · " + count(f.posts, t("bericht"), t("berichten"))),
    h("span", { class: "fb-meta" }, f.last ? t("Laatste activiteit {0}", ago(f.last.at)) : t("Nog geen onderwerpen"))]);
}
function threadList(rows) {
  if (!rows.length) return note(t("Nog geen onderwerpen."));
  return h("ul", { class: "fb-list" }, rows.map(function (x) {
    return h("li", {}, link(threadHref(x.id), "fb-row", x.title, [h("span", { class: "fb-rt" }, h("strong", {}, x.title), h("span", { class: "fb-meta" }, [x.forum, x.author.name, ago(x.last_post_at)].filter(Boolean).join(" · "))),
      h("span", { class: "fb-count", title: t("Reacties") }, svg("reply"), " " + x.replies)]));
  }));
}
function tree(nodes, forum, depth) {
  return h("ul", { class: "fb-tree" }, nodes.map(function (n) {
    return h("li", { style: "--d:" + depth }, link(forumHref(forum) + "?group=" + n.id, "fb-row", n.title, [h("span", { class: "fb-ico sm" }, svg("folder")), h("span", { class: "fb-rt" }, h("strong", {}, n.title), n.last ? h("span", { class: "fb-meta" }, t("Laatste activiteit {0}", ago(n.last.at))) : null), h("span", { class: "fb-count" }, count(n.threads, t("onderwerp"), t("onderwerpen")))]),
      n.children && n.children.length ? tree(n.children, forum, depth + 1) : null);
  }));
}
function fail(e) { app.innerHTML = ""; app.appendChild(h("div", { class: "fb-note err", role: "alert" }, e && e.message ? e.message : String(e))); done(); }
function done() { if (system.loaded) system.loaded(); }
function out() { app.innerHTML = ""; app.append.apply(app, Array.prototype.slice.call(arguments)); done(); }
function qs() { var a = []; if (P.limit) a.push("limit=" + encodeURIComponent(P.limit)); if (P.forum) a.push("forum=" + encodeURIComponent(P.forum)); return a.length ? "?" + a.join("&") : ""; }

/* ── a forum choice (for the views forum and start) ── */
function chooser(label, onPick, current) {
  var sel = h("select", { "aria-label": label }, h("option", { value: "" }, t("Kies een forum")));
  call("blocks/choices").then(function (r) { r.forums.forEach(function (f) { sel.appendChild(h("option", { value: f.slug || f.id, "data-id": f.id, selected: String(current) === String(f.id) }, f.title)); }); }).catch(function () { /* the note is enough */ });
  sel.addEventListener("change", function () { var o = sel.options[sel.selectedIndex]; if (sel.value) onPick(o.getAttribute("data-id")); });
  return sel;
}

/* ── views ── */
function vForums() {
  return call("blocks/forums" + qs()).then(function (r) {
    out(r.forums.length ? h("div", { class: "fb-grid" }, r.forums.map(forumCard)) : note(t("Er zijn nog geen forums.")));
  });
}
function vThreads(kind) {
  return call("blocks/" + kind + qs()).then(function (r) { out(threadList(r.threads)); });
}
function vForum() {
  if (!P.forum) {
    var kids = [note(t("Kies een forum in de instellingen van dit blok."))];
    if (editing()) kids.push(h("label", { class: "fb-pick" }, h("span", {}, t("Voorbeeld met forum")), chooser(t("Kies een forum"), function (id) { P.forum = id; vForum().catch(fail); })));
    out.apply(null, kids); return Promise.resolve();
  }
  return call("blocks/forum/" + encodeURIComponent(P.forum)).then(function (r) {
    var f = r.forum, desc = plain(f.description);
    out(h("div", { class: "fb-head" }, h("span", { class: "fb-ico" }, svg("chat")), h("div", { class: "grow" }, link(forumHref(f), "fb-h", f.title, h("strong", {}, f.title)), desc ? h("div", { class: "fb-desc" }, desc) : null,
      h("div", { class: "fb-meta" }, count(f.threads, t("onderwerp"), t("onderwerpen")) + " · " + count(f.posts, t("bericht"), t("berichten"))))),
      r.tree.length ? tree(r.tree, f, 0) : note(t("In dit forum zijn nog geen groepen.")));
  });
}
function vStart() {
  var sel = chooser(t("Kies een forum"), function (id) { go(id); }, P.forum), target = null;
  function go(id) { call("blocks/forum/" + encodeURIComponent(id)).then(function (r) { if (r.forum && r.forum.slug && !editing()) system.go("/forum/" + encodeURIComponent(r.forum.slug)); }).catch(fail); }
  if (P.forum) target = P.forum;
  out(h("div", { class: "fb-cta" }, h("span", { class: "fb-ico big" }, svg("plus")), h("div", { class: "grow" }, h("strong", { class: "fb-title" }, t("Start een gesprek")), h("div", { class: "fb-desc" }, t("Kies een forum en begin een nieuw onderwerp of lees mee met anderen."))),
    h("div", { class: "fb-ctas" }, h("label", { class: "sr" }, t("Kies een forum")), sel,
      target ? h("button", { type: "button", class: "btn primary", onclick: function () { go(target); } }, t("Naar het forum")) : null)));
  return Promise.resolve();
}
function vSearch() {
  var inp = h("input", { type: "search", id: "fq", placeholder: t("Zoek in de forums…"), "aria-label": t("Zoek in de forums"), value: P.q }), box = h("div", {}), timer = null, n = 0;
  function run() {
    var q = inp.value.trim(), me = ++n; box.innerHTML = "";
    if (q.length < 2) { box.appendChild(note(t("Typ minstens 2 letters om te zoeken."), "quiet")); return; }
    call("search?q=" + encodeURIComponent(q)).then(function (r) { if (me !== n) return; box.innerHTML = ""; box.appendChild(r.threads.length ? threadList(r.threads) : note(t("Niets gevonden."))); }).catch(function (e) { if (me === n) { box.innerHTML = ""; box.appendChild(h("div", { class: "fb-note err", role: "alert" }, e.message)); } });
  }
  inp.addEventListener("input", function () { clearTimeout(timer); timer = setTimeout(run, 300); });
  out(h("div", { class: "fb-search" }, svg("search"), inp), box); run();
  return Promise.resolve();
}

function start() {
  system.ready.then(function (r) {
    var q = (r.route && r.route.query) || {};
    P.view = q.view || "forums"; P.limit = q.limit || ""; P.forum = q.forum || "";
    var views = { forums: vForums, latest: function () { return vThreads("latest"); }, popular: function () { return vThreads("popular"); }, forum: vForum, start: vStart, search: vSearch };
    (views[P.view] || vForums)().catch(fail);
  });
}
