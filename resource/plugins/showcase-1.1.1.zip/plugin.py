# Copyright & Ownership Notice
# easy2Edit is the exclusive legal property of RST Coaching & Consultancy B.V. (RSTCC),
# owned by Ronald Stolk. All rights reserved. Any unauthorized use, copying, modification,
# reproduction, distribution, or commercial exploitation of Easy2Edit, including its source code,
# is strictly prohibited without prior written permission from Ronald Stolk or RSTCC.
# website https://rstcc.net

"""Showcase (plugin). Projects with pictures and videos and the fields goal, description, url, duration and budget (every field can be switched off), a status,
shared tags, groups with subgroups, and presentations (grid, list, table, masonry, scroller, slider; with search and filters; opening on a page, in a popup or in place).
Every presentation is a system object for pages (parts). Tables: plg_showcase_*. Routes: /api/plugins/run/showcase/<path>; the pages are in web/."""
import io
import re

from django.db import models, transaction
from django.utils.text import slugify
from rest_framework.response import Response

FIELDS = ("summary", "description", "goal", "url", "duration", "budget", "status", "tags", "images", "videos")  # every one can be switched off
STATUSES = ("active", "development", "offline")
LAYOUTS = ("grid", "list", "table", "masonry", "scroller", "slider")
OPENS = ("page", "popup", "inline", "none")
SORTS = ("order", "new", "title", "status")
I18N_FIELDS = ("title", "summary", "description", "goal")
LIMITS = {"title": 160, "summary": 300, "description": 20000, "goal": 1000, "duration": 80, "budget": 80, "url": 400}
PRESETS = {  # presentations that always exist (no design needed): the system objects "Showcase: ..."
    "_search": {"name": "Alle projecten met zoeken", "layout": "grid", "open": "page", "search": True, "f_tags": True, "f_groups": True, "f_status": True},
    "_scroller": {"name": "Scroller met projecten", "layout": "scroller", "open": "popup", "autoplay": True, "limit": 12},
    "_list": {"name": "Lijst met projecten", "layout": "list", "open": "page", "search": True},
}


def register(system):
    from apps.accounts.access import level
    from apps.core import richtext
    from apps.medialib.models import MediaItem
    from apps.security.words import find_forbidden
    from django.core.files.storage import default_storage

    T = system.t
    label = system.app_label
    cfg = system.config
    bad = lambda msg, code=400: Response({"detail": msg}, status=code)  # noqa: E731

    def table(name):
        return type("Meta", (), {"app_label": label, "db_table": system.db_prefix + name})

    class Group(models.Model):
        name = models.CharField(max_length=120)
        slug = models.SlugField(max_length=80, unique=True)
        parent = models.ForeignKey("self", null=True, blank=True, on_delete=models.SET_NULL, related_name="+")
        description = models.TextField(blank=True)
        media = models.ForeignKey(MediaItem, null=True, blank=True, on_delete=models.SET_NULL, related_name="+")
        order = models.PositiveIntegerField(default=0)
        active = models.BooleanField(default=True)
        i18n = models.JSONField(default=dict, blank=True)  # {"en": {"name": "..", "description": ".."}}
        demo = models.BooleanField(default=False)
        Meta = table("group")

    class Tag(models.Model):
        name = models.CharField(max_length=60)
        slug = models.SlugField(max_length=70, unique=True)
        demo = models.BooleanField(default=False)
        Meta = table("tag")

    class Item(models.Model):
        title = models.CharField(max_length=160)
        slug = models.SlugField(max_length=180, unique=True)
        summary = models.CharField(max_length=300, blank=True)
        description = models.TextField(blank=True)  # clean html (rich text)
        goal = models.TextField(blank=True)
        url = models.CharField(max_length=400, blank=True)
        duration = models.CharField(max_length=80, blank=True)  # looptijd, free text ("2023 - 2024", "6 maanden")
        budget = models.CharField(max_length=80, blank=True)  # free text ("€ 25.000")
        status = models.CharField(max_length=12, default="active")
        images = models.JSONField(default=list, blank=True)  # [{"media": id, "alt": "", "caption": ""}]
        videos = models.JSONField(default=list, blank=True)  # [{"url": "...", "title": ""}]
        featured = models.BooleanField(default=False)
        active = models.BooleanField(default=True)  # published
        order = models.PositiveIntegerField(default=0)
        i18n = models.JSONField(default=dict, blank=True)  # {"en": {"title", "summary", "description", "goal"}}
        demo = models.BooleanField(default=False)
        created_at = models.DateTimeField(auto_now_add=True)
        updated_at = models.DateTimeField(auto_now=True)
        Meta = table("item")

    class ItemTag(models.Model):
        item = models.ForeignKey(Item, on_delete=models.CASCADE, related_name="+")
        tag = models.ForeignKey(Tag, on_delete=models.CASCADE, related_name="+")
        Meta = table("itemtag")

    class ItemGroup(models.Model):
        item = models.ForeignKey(Item, on_delete=models.CASCADE, related_name="+")
        group = models.ForeignKey(Group, on_delete=models.CASCADE, related_name="+")
        Meta = table("itemgroup")

    class Design(models.Model):
        """A presentation: how a selection of projects is shown. Every active design is a system object (a part) for pages."""
        name = models.CharField(max_length=120)
        slug = models.SlugField(max_length=80, unique=True)
        title = models.CharField(max_length=160, blank=True)  # heading above the presentation
        intro = models.CharField(max_length=400, blank=True)
        layout = models.CharField(max_length=10, default="grid")
        open = models.CharField(max_length=8, default="page")  # page | popup | inline | none
        size = models.CharField(max_length=2, default="md")  # sm | md | lg
        ratio = models.CharField(max_length=5, default="4/3")
        fields = models.JSONField(default=list, blank=True)  # the fields shown in the cards and the detail ([] = all that are on)
        search = models.BooleanField(default=False)
        f_tags = models.BooleanField(default=False)
        f_groups = models.BooleanField(default=False)
        f_status = models.BooleanField(default=False)
        group = models.CharField(max_length=80, blank=True)  # only this group (and its subgroups)
        tags = models.JSONField(default=list, blank=True)  # only projects with one of these tags
        only_status = models.CharField(max_length=12, blank=True)
        featured_only = models.BooleanField(default=False)
        sort = models.CharField(max_length=8, default="order")
        limit = models.PositiveIntegerField(default=0)  # 0 = all
        autoplay = models.BooleanField(default=False)
        active = models.BooleanField(default=True)
        demo = models.BooleanField(default=False)
        Meta = table("design")

    system.sync_models(Group, Tag, Item, ItemTag, ItemGroup, Design)

    # ── helpers ──
    def is_admin(u):
        return bool(u.is_authenticated and (u.is_staff or level(u, "plugins") >= 2))

    def body(request):
        return request.data if isinstance(request.data, dict) else {}

    def media_url(m):
        return default_storage.url(m.key) if m else None

    def unique_slug(model, text, exclude=None):
        base, n = slugify(text)[:60] or "project", 2
        slug = base
        while model.objects.filter(slug=slug).exclude(pk=exclude).exists():
            slug, n = f"{base}-{n}", n + 1
        return slug

    def on(field):
        """Is this field switched on (plugin settings)?"""
        return cfg.get(f"show_{field}", True) is not False

    def enabled_fields():
        return [f for f in FIELDS if on(f)]

    def text(v, n, what="", required=False):
        v = " ".join(re.sub(r"<[^>]*>", " ", str(v or "")).split())[:n]  # plain text: no html
        if required and not v:
            raise ValueError(T("Vul {0} in.", what))
        if v and find_forbidden(v):
            raise ValueError(T("{0} bevat niet toegestane woorden.", what or T("Tekst")))
        return v

    def clean_url(v):
        v = str(v or "").strip()[:400]
        if v and not re.match(r"^https?://[^\s<>\"']+$", v, re.I):
            raise ValueError(T("Een link begint met http:// of https://."))
        return v

    def video_of(url):
        """{url, kind, embed}: a YouTube or Vimeo link (shown as an embed) or a direct video file."""
        url = clean_url(url)
        m = re.match(r"^https?://(?:www\.|m\.)?(?:youtube\.com/(?:watch\?(?:.*&)?v=|embed/|shorts/)|youtu\.be/)([\w-]{11})", url, re.I)
        if m:
            return {"url": url, "kind": "embed", "embed": f"https://www.youtube-nocookie.com/embed/{m.group(1)}"}
        m = re.match(r"^https?://(?:www\.)?vimeo\.com/(?:video/)?(\d{5,12})", url, re.I)
        if m:
            return {"url": url, "kind": "embed", "embed": f"https://player.vimeo.com/video/{m.group(1)}"}
        if re.search(r"\.(mp4|webm|ogv)(\?.*)?$", url, re.I):
            return {"url": url, "kind": "file", "embed": url}
        raise ValueError(T("Gebruik een YouTube- of Vimeo-link, of een link naar een mp4- of webm-bestand."))

    def tr(obj, lang):
        return (obj.i18n or {}).get(lang or "") or {}

    # ── reading: what the website shows ──
    def group_tree(only_active=True):
        qs = Group.objects.all().order_by("order", "name")
        if only_active:
            qs = qs.filter(active=True)
        return list(qs.select_related("parent", "media"))

    def descendants(slug):
        """The slugs-> ids of a group and all its subgroups."""
        groups = group_tree(False)
        root = next((g for g in groups if g.slug == slug), None)
        if not root:
            return set()
        ids, frontier = {root.id}, [root.id]
        while frontier:
            nxt = [g.id for g in groups if g.parent_id in frontier and g.id not in ids]
            ids |= set(nxt)
            frontier = nxt
        return ids

    def maps(items):
        ids = [i.id for i in items]
        tags, groups = {}, {}
        for it in ItemTag.objects.filter(item_id__in=ids).select_related("tag"):
            tags.setdefault(it.item_id, []).append(it.tag)
        for ig in ItemGroup.objects.filter(item_id__in=ids).select_related("group"):
            groups.setdefault(ig.item_id, []).append(ig.group)
        media_ids = {int(x["media"]) for i in items for x in (i.images or []) if str(x.get("media") or "").isdigit()}
        media = {m.id: m for m in MediaItem.objects.filter(pk__in=media_ids)}
        return tags, groups, media

    def pub(i, mp, lang=None, full=False):
        tags, groups, media = mp
        t_ = tr(i, lang)
        imgs = [{"url": media_url(media[int(x["media"])]), "alt": x.get("alt") or i.title, "caption": x.get("caption") or ""} for x in (i.images or []) if str(x.get("media") or "").isdigit() and int(x["media"]) in media]
        out = {"id": i.id, "slug": i.slug, "title": t_.get("title") or i.title, "featured": i.featured, "image": imgs[0]["url"] if imgs and on("images") else "",
               "groups": [{"name": tr(g, lang).get("name") or g.name, "slug": g.slug} for g in groups.get(i.id, []) if g.active], "updated": i.updated_at}
        if on("summary"):
            out["summary"] = t_.get("summary") or i.summary
        if on("status"):
            out["status"] = i.status
        if on("tags"):
            out["tags"] = [{"name": x.name, "slug": x.slug} for x in tags.get(i.id, [])]
        for f in ("goal", "url", "duration", "budget"):
            if on(f):
                out[f] = (t_.get(f) or getattr(i, f)) if f == "goal" else getattr(i, f)
        if full:
            if on("description"):
                out["description"] = t_.get("description") or i.description
            if on("images"):
                out["images"] = imgs
            if on("videos"):
                out["videos"] = [video_of(v["url"]) | {"title": v.get("title") or ""} for v in (i.videos or []) if v.get("url")]
        return out

    def design_dict(slug):
        if slug in PRESETS:
            return {**design_out(None), **PRESETS[slug], "slug": slug}
        d = Design.objects.filter(slug=slug, active=True).first()
        return design_out(d) if d else None

    def design_out(d):
        if d is None:
            return {"id": 0, "slug": "", "name": "", "title": "", "intro": "", "layout": "grid", "open": cfg.get("default_open") or "pagina", "size": "md", "ratio": "4/3", "fields": [], "search": False, "f_tags": False, "f_groups": False,
                    "f_status": False, "group": "", "tags": [], "only_status": "", "featured_only": False, "sort": "order", "limit": 0, "autoplay": False, "active": True, "demo": False}
        return {"id": d.id, "slug": d.slug, "name": d.name, "title": d.title, "intro": d.intro, "layout": d.layout, "open": d.open, "size": d.size, "ratio": d.ratio, "fields": d.fields or [], "search": d.search, "f_tags": d.f_tags, "f_groups": d.f_groups,
                "f_status": d.f_status, "group": d.group, "tags": d.tags or [], "only_status": d.only_status, "featured_only": d.featured_only, "sort": d.sort, "limit": d.limit, "autoplay": d.autoplay, "active": d.active, "demo": d.demo}

    def fix_open(d):
        if d.get("open") in ("pagina", "ter plekke"):
            d["open"] = {"pagina": "page", "ter plekke": "inline"}[d["open"]]
        return d

    def select(params, d):
        """The projects for these query parameters (q, tag, group, status, sort, limit, offset) within a design's selection."""
        qs = Item.objects.filter(active=True)
        status = params.get("status") or d.get("only_status") or ""
        if status in STATUSES:
            qs = qs.filter(status=status)
        if d.get("featured_only"):
            qs = qs.filter(featured=True)
        gslug = params.get("group") or d.get("group") or ""
        if gslug:
            qs = qs.filter(pk__in=ItemGroup.objects.filter(group_id__in=descendants(gslug)).values("item_id"))
        wanted = [x for x in str(params.get("tag") or "").split(",") if x]  # the visitor's choice: ALL of these tags
        for s in wanted:
            qs = qs.filter(pk__in=ItemTag.objects.filter(tag__slug=s).values("item_id"))
        if d.get("tags"):  # the design's selection: ONE of these tags
            qs = qs.filter(pk__in=ItemTag.objects.filter(tag__slug__in=d["tags"]).values("item_id"))
        sort = params.get("sort") or d.get("sort") or "order"
        qs = qs.order_by({"new": "-created_at", "title": "title", "status": "status"}.get(sort, "order"), "id")
        items = list(qs[:600])
        q = " ".join(str(params.get("q") or "").lower().split())
        lang = params.get("lang")
        mp = maps(items)
        if q:
            def hay(i):
                t_ = tr(i, lang)
                return " ".join([i.title, i.summary, i.goal, re.sub(r"<[^>]+>", " ", i.description), t_.get("title", ""), t_.get("summary", ""), t_.get("goal", ""), " ".join(x.name for x in mp[0].get(i.id, []))]).lower()

            items = [i for i in items if all(w in hay(i) for w in q.split())]
        total = len(items)
        try:
            offset = max(0, int(params.get("offset") or 0))
            limit = int(params.get("limit") or d.get("limit") or 0)
        except ValueError:
            offset, limit = 0, 0
        if d.get("limit") and (not limit or limit > d["limit"]):
            limit = d["limit"]
        items = items[offset:offset + limit] if limit else items[offset:]
        return items, total, mp

    @system.route("GET", "config", public=True)
    def config(request):
        return {"fields": enabled_fields(), "statuses": list(STATUSES), "default_open": fix_open({"open": cfg.get("default_open") or "pagina"})["open"], "per_page": int(cfg.get("per_page") or 12)}

    @system.route("GET", "designs/<slug>", public=True)
    def design_public(request, slug):
        d = design_dict(slug)
        return fix_open(d) if d else bad(T("Niet gevonden."), 404)

    @system.route("GET", "facets", public=True)
    def facets(request):
        """For the search options: the groups (with parents), the tags that are used and the statuses."""
        lang = request.query_params.get("lang")
        used = ItemTag.objects.filter(item__active=True).values_list("tag_id", flat=True)
        counts = {}
        for tid in used:
            counts[tid] = counts.get(tid, 0) + 1
        gcounts = {}
        for gid in ItemGroup.objects.filter(item__active=True).values_list("group_id", flat=True):
            gcounts[gid] = gcounts.get(gid, 0) + 1
        sc = {s: Item.objects.filter(active=True, status=s).count() for s in STATUSES}
        return {"tags": [{"name": x.name, "slug": x.slug, "count": counts[x.id]} for x in Tag.objects.all().order_by("name") if x.id in counts],
                "groups": [{"name": tr(g, lang).get("name") or g.name, "slug": g.slug, "parent": g.parent.slug if g.parent_id else None, "count": gcounts.get(g.id, 0)} for g in group_tree()],
                "statuses": [{"key": k, "count": v} for k, v in sc.items() if v]}

    @system.route("GET", "groups", public=True)
    def groups_public(request):
        lang = request.query_params.get("lang")
        return [{"name": tr(g, lang).get("name") or g.name, "slug": g.slug, "description": tr(g, lang).get("description") or g.description, "image": media_url(g.media), "parent": g.parent.slug if g.parent_id else None} for g in group_tree()]

    @system.route("GET", "items", public=True)
    def items_public(request):
        q = request.query_params
        d = fix_open(design_dict(q.get("design") or "") or design_out(None))
        items, total, mp = select(q, d)
        return {"items": [pub(i, mp, q.get("lang")) for i in items], "total": total, "design": d}

    @system.route("GET", "items/<slug>", public=True)
    def item_public(request, slug):
        i = Item.objects.filter(slug=slug, active=True).first()
        if not i:
            return bad(T("Niet gevonden."), 404)
        lang = request.query_params.get("lang")
        mp = maps([i])
        out = pub(i, mp, lang, full=True)
        tag_ids = [t.id for t in mp[0].get(i.id, [])]
        rel = Item.objects.filter(active=True, pk__in=ItemTag.objects.filter(tag_id__in=tag_ids).values("item_id")).exclude(pk=i.id).order_by("order")[:4] if tag_ids else []
        out["related"] = [pub(r, maps([r]), lang) for r in rel]
        return out

    # ── system objects (parts for pages) ──
    def sync_objects():
        try:
            from apps.sysobjects import service as so

            so.sync()
        except Exception:  # noqa: BLE001
            pass

    def parts():
        out_ = [{"key": f"showcase-preset-{k.strip('_')}", "title": T("Showcase: {0}", T(v["name"])), "file": "web/view.html", "query": {"design": k}} for k, v in PRESETS.items()]
        out_ += [{"key": f"showcase-{d.slug}"[:60], "title": T("Showcase: {0}", d.name), "file": "web/view.html", "query": {"design": d.slug}} for d in Design.objects.filter(active=True)]
        return out_

    system.provide("parts", parts)

    # ── admin ──
    def need_admin(request):
        return None if is_admin(request.user) else bad(T("Je hebt hier geen rechten voor."), 403)

    def item_admin(i, mp=None):
        mp = mp or maps([i])
        tags, groups, media = mp
        return {"id": i.id, "title": i.title, "slug": i.slug, "summary": i.summary, "description": i.description, "goal": i.goal, "url": i.url, "duration": i.duration, "budget": i.budget, "status": i.status,
                "images": [{"media": x.get("media"), "url": media_url(media.get(int(x["media"]))) if str(x.get("media") or "").isdigit() and int(x["media"]) in media else "", "alt": x.get("alt") or "", "caption": x.get("caption") or ""} for x in (i.images or [])],
                "videos": i.videos or [], "featured": i.featured, "active": i.active, "order": i.order, "i18n": i.i18n or {}, "tags": [x.name for x in tags.get(i.id, [])], "groups": [g.id for g in groups.get(i.id, [])], "demo": i.demo}

    def set_tags(i, names):
        keep = []
        for n in (names if isinstance(names, list) else [])[:20]:
            n = text(n, 60, T("De tag"))
            if not n:
                continue
            tg = Tag.objects.filter(name__iexact=n).first() or Tag.objects.create(name=n, slug=unique_slug(Tag, n))
            keep.append(tg.id)
        ItemTag.objects.filter(item=i).exclude(tag_id__in=keep).delete()
        have = set(ItemTag.objects.filter(item=i).values_list("tag_id", flat=True))
        for tid in keep:
            if tid not in have:
                ItemTag.objects.create(item=i, tag_id=tid)
                have.add(tid)

    def set_groups(i, ids):
        keep = [g for g in Group.objects.filter(pk__in=[x for x in (ids if isinstance(ids, list) else []) if str(x).isdigit()]).values_list("id", flat=True)]
        ItemGroup.objects.filter(item=i).exclude(group_id__in=keep).delete()
        have = set(ItemGroup.objects.filter(item=i).values_list("group_id", flat=True))
        for gid in keep:
            if gid not in have:
                ItemGroup.objects.create(item=i, group_id=gid)

    def clean_i18n(raw, fields):
        out = {}
        for code, row in (raw if isinstance(raw, dict) else {}).items():
            if not isinstance(row, dict) or not re.fullmatch(r"[a-z]{2,3}(-[A-Za-z0-9]{2,8})?", str(code)):
                continue
            c = {}
            for k in fields:
                v = str(row.get(k) or "").strip()
                if not v:
                    continue
                c[k] = richtext.clean(v)[:LIMITS["description"]] if k == "description" else text(v, LIMITS.get(k, 300), k)
            if c:
                out[code] = c
        return out

    def apply_item(i, d):
        if "title" in d or not i.pk:
            i.title = text(d.get("title"), LIMITS["title"], T("de titel"), required=True)
        if not i.slug:
            i.slug = unique_slug(Item, i.title)
        if "summary" in d:
            i.summary = text(d["summary"], LIMITS["summary"], T("de korte tekst"))
        if "description" in d:
            i.description = richtext.clean(str(d["description"] or ""))[:LIMITS["description"]]
        if "goal" in d:
            i.goal = text(d["goal"], LIMITS["goal"], T("het doel"))
        if "url" in d:
            i.url = clean_url(d["url"])
        for f in ("duration", "budget"):
            if f in d:
                setattr(i, f, text(d[f], 80, T("het veld")))
        if "status" in d:
            if d["status"] not in STATUSES:
                raise ValueError(T("Kies een geldige status."))
            i.status = d["status"]
        for f in ("featured", "active"):
            if f in d:
                setattr(i, f, bool(d[f]))
        if "order" in d:
            try:
                i.order = max(0, min(int(d["order"]), 100000))
            except (TypeError, ValueError):
                raise ValueError(T("De volgorde is een getal."))
        if "images" in d:
            imgs = []
            for x in (d["images"] if isinstance(d["images"], list) else [])[:40]:
                if isinstance(x, dict) and str(x.get("media") or "").isdigit() and MediaItem.objects.filter(pk=int(x["media"])).exists():
                    imgs.append({"media": int(x["media"]), "alt": text(x.get("alt"), 160), "caption": text(x.get("caption"), 200)})
            i.images = imgs
        if "videos" in d:
            vids = []
            for x in (d["videos"] if isinstance(d["videos"], list) else [])[:10]:
                if isinstance(x, dict) and str(x.get("url") or "").strip():
                    v = video_of(x["url"])
                    vids.append({"url": v["url"], "title": text(x.get("title"), 160)})
            i.videos = vids
        if "i18n" in d:
            i.i18n = clean_i18n(d["i18n"], I18N_FIELDS)
        i.save()
        if "tags" in d:
            set_tags(i, d["tags"])
        if "groups" in d:
            set_groups(i, d["groups"])
        sync_objects()

    @system.route("GET", "admin/items")
    def admin_items(request):
        if (r := need_admin(request)):
            return r
        q = (request.query_params.get("q") or "").strip().lower()
        items = list(Item.objects.all().order_by("order", "-id")[:600])
        mp = maps(items)
        rows = [item_admin(i, mp) for i in items]
        if q:
            rows = [r_ for r_ in rows if q in (r_["title"] + " " + r_["summary"] + " " + " ".join(r_["tags"])).lower()]
        return {"items": rows}

    @system.route("POST", "admin/items")
    def admin_item_add(request):
        if (r := need_admin(request)):
            return r
        try:
            with transaction.atomic():
                i = Item()
                apply_item(i, body(request))
        except ValueError as e:
            return bad(str(e))
        return Response(item_admin(i), status=201)

    @system.route("PATCH", "admin/items/<id>")
    def admin_item_change(request, id):  # noqa: A002
        if (r := need_admin(request)):
            return r
        i = Item.objects.filter(pk=id).first() if str(id).isdigit() else None
        if not i:
            return bad(T("Niet gevonden."), 404)
        try:
            with transaction.atomic():
                apply_item(i, body(request))
        except ValueError as e:
            return bad(str(e))
        return item_admin(i)

    @system.route("DELETE", "admin/items/<id>")
    def admin_item_delete(request, id):  # noqa: A002
        if (r := need_admin(request)):
            return r
        i = Item.objects.filter(pk=id).first() if str(id).isdigit() else None
        if not i:
            return bad(T("Niet gevonden."), 404)
        ItemTag.objects.filter(item=i).delete()
        ItemGroup.objects.filter(item=i).delete()
        i.delete()
        return Response(status=204)

    def group_admin(g):
        return {"id": g.id, "name": g.name, "slug": g.slug, "parent": g.parent_id, "description": g.description, "order": g.order, "active": g.active, "i18n": g.i18n or {}, "demo": g.demo,
                "count": ItemGroup.objects.filter(group=g).count()}

    def apply_group(g, d):
        if "name" in d or not g.pk:
            g.name = text(d.get("name"), 120, T("de naam"), required=True)
        if not g.slug:
            g.slug = unique_slug(Group, g.name)
        if "description" in d:
            g.description = text(d["description"], 600, T("de omschrijving"))
        if "parent" in d:
            pid = d["parent"] if str(d["parent"] or "").isdigit() else None
            if pid and g.pk and int(pid) in descendants(g.slug) | {g.pk}:
                raise ValueError(T("Een groep kan niet onder zichzelf of onder een eigen subgroep staan."))
            g.parent = Group.objects.filter(pk=pid).first() if pid else None
        if "order" in d:
            try:
                g.order = max(0, int(d["order"]))
            except (TypeError, ValueError):
                raise ValueError(T("De volgorde is een getal."))
        if "active" in d:
            g.active = bool(d["active"])
        if "i18n" in d:
            g.i18n = clean_i18n(d["i18n"], ("name", "description"))
        g.save()

    def tag_admin(x):
        return {"id": x.id, "name": x.name, "slug": x.slug, "count": ItemTag.objects.filter(tag=x).count(), "demo": x.demo}

    def apply_tag(x, d):
        x.name = text(d.get("name"), 60, T("de naam"), required=True)
        other = Tag.objects.filter(name__iexact=x.name).exclude(pk=x.pk).first()
        if other:
            raise ValueError(T("Deze tag bestaat al."))
        if not x.slug:
            x.slug = unique_slug(Tag, x.name)
        x.save()

    def design_data(x, d):
        if "name" in d or not x.pk:
            x.name = text(d.get("name"), 120, T("de naam"), required=True)
        if not x.slug:
            x.slug = unique_slug(Design, x.name)
        for f, n in (("title", 160), ("intro", 400)):
            if f in d:
                setattr(x, f, text(d[f], n, T("de tekst")))
        for f, allowed in (("layout", LAYOUTS), ("open", OPENS), ("size", ("sm", "md", "lg")), ("ratio", ("4/3", "3/2", "16/9", "1/1", "3/4")), ("sort", SORTS)):
            if f in d:
                if d[f] not in allowed:
                    raise ValueError(T("Ongeldige keuze: {0}.", f))
                setattr(x, f, d[f])
        if "only_status" in d:
            x.only_status = d["only_status"] if d["only_status"] in STATUSES else ""
        if "fields" in d:
            x.fields = [f for f in (d["fields"] if isinstance(d["fields"], list) else []) if f in FIELDS]
        if "tags" in d:
            x.tags = [s for s in (d["tags"] if isinstance(d["tags"], list) else []) if Tag.objects.filter(slug=s).exists()][:20]
        if "group" in d:
            x.group = d["group"] if Group.objects.filter(slug=d["group"]).exists() else ""
        if "limit" in d:
            try:
                x.limit = max(0, min(int(d["limit"] or 0), 200))
            except (TypeError, ValueError):
                raise ValueError(T("De limiet is een getal."))
        for f in ("search", "f_tags", "f_groups", "f_status", "featured_only", "autoplay", "active"):
            if f in d:
                setattr(x, f, bool(d[f]))
        x.save()
        sync_objects()

    def crud(name, model, out, apply, order, before_delete=None):
        @system.route("GET", f"admin/{name}")
        def lst(request):
            return need_admin(request) or {"items": [out(o) for o in order()]}

        @system.route("POST", f"admin/{name}")
        def add(request):
            if (r := need_admin(request)):
                return r
            try:
                with transaction.atomic():
                    o = model()
                    apply(o, body(request))
            except ValueError as e:
                return bad(str(e))
            return Response(out(o), status=201)

        @system.route("PATCH", f"admin/{name}/<id>")
        def change(request, id):  # noqa: A002
            if (r := need_admin(request)):
                return r
            o = model.objects.filter(pk=id).first() if str(id).isdigit() else None
            if not o:
                return bad(T("Niet gevonden."), 404)
            try:
                with transaction.atomic():
                    apply(o, body(request))
            except ValueError as e:
                return bad(str(e))
            return out(o)

        @system.route("DELETE", f"admin/{name}/<id>")
        def delete(request, id):  # noqa: A002
            if (r := need_admin(request)):
                return r
            o = model.objects.filter(pk=id).first() if str(id).isdigit() else None
            if not o:
                return bad(T("Niet gevonden."), 404)
            if before_delete:
                before_delete(o)
            o.delete()
            sync_objects()
            return Response(status=204)

    def free_group(g):
        Group.objects.filter(parent=g).update(parent=g.parent)  # the subgroups move up one level
        ItemGroup.objects.filter(group=g).delete()

    crud("groups", Group, group_admin, apply_group, lambda: Group.objects.all().order_by("order", "name"), free_group)
    crud("tags", Tag, tag_admin, apply_tag, lambda: Tag.objects.all().order_by("name"), lambda x: ItemTag.objects.filter(tag=x).delete())
    crud("designs", Design, lambda x: {**design_out(x), "parts_key": f"showcase-{x.slug}"}, design_data, lambda: Design.objects.all().order_by("name"))

    @system.route("GET", "admin/setup")
    def admin_setup(request):
        if (r := need_admin(request)):
            return r
        langs = []
        try:
            from apps.core.models import Language

            langs = [{"code": l.code, "name": l.name} for l in Language.objects.filter(enabled=True, is_default=False).order_by("order")]
        except Exception:  # noqa: BLE001
            pass
        return {"fields": enabled_fields(), "all_fields": list(FIELDS), "statuses": list(STATUSES), "layouts": list(LAYOUTS), "opens": list(OPENS), "languages": langs,
                "presets": [{"slug": k, "name": T(v["name"])} for k, v in PRESETS.items()]}

    # ── demo content (Super admin → Demo-gegevens): recognisable by demo=True, removed in one go ──
    def drawn(title, rgb, style):
        from PIL import Image as PImage, ImageDraw, ImageFont

        w, h = 1200, 800
        base = tuple(int(rgb[i:i + 2], 16) for i in (1, 3, 5))
        img = PImage.new("RGB", (w, h), base)
        dr = ImageDraw.Draw(img)
        light, dark = tuple(min(255, c + 50) for c in base), tuple(max(0, c - 55) for c in base)
        if style == 0:
            dr.rounded_rectangle([w * .12, h * .14, w * .88, h * .66], radius=28, fill=light)
            dr.rectangle([w * .12, h * .14, w * .88, h * .22], fill=dark)
            for k in range(3):
                dr.rounded_rectangle([w * (.18 + k * .24), h * .3, w * (.36 + k * .24), h * .56], radius=14, fill=dark)
        elif style == 1:
            for x in range(-h, w, 80):
                dr.polygon([(x, h), (x + 40, h), (x + 40 + h, 0), (x + h, 0)], fill=light)
            dr.ellipse([w * .34, h * .2, w * .66, h * .6], fill=dark)
        else:
            dr.ellipse([w * .08, h * .1, w * .62, h * .8], fill=light)
            dr.rounded_rectangle([w * .5, h * .3, w * .92, h * .72], radius=30, fill=dark)
        lum = .299 * base[0] + .587 * base[1] + .114 * base[2]
        ink = (20, 20, 20) if lum > 150 else (255, 255, 255)
        try:
            font = ImageFont.load_default(size=54)
        except TypeError:
            font = ImageFont.load_default()
        dr.text((w / 2, h * .85), title[:36], fill=ink, font=font, anchor="mm")
        buf = io.BytesIO()
        img.save(buf, "PNG")
        return buf.getvalue()

    PALETTE = ("#2f6fbd", "#2e9e83", "#c2703a", "#7a5cc4", "#c04a6a", "#4a8f3c", "#b8932f", "#3d7f9e")

    def demo_media(i, title, rgb, style):
        from django.core.files.base import ContentFile

        from apps.medialib import areas

        key = default_storage.save(areas.site_path("library", f"showcase-demo/{slugify(title)[:60]}-{i}.png"), ContentFile(drawn(title, rgb, style)))
        m = MediaItem.objects.get(key=key)
        m.name, m.source, m.tags = f"{title}.png"[:255], "showcase-demo", ["demo", "showcase"]
        m.save(update_fields=["name", "source", "tags"])
        return m

    DEMO_GROUPS = (("Websites", None, "Sites en webshops voor klanten."), ("Webshops", "Websites", "Winkels met producten en afrekenen."), ("Bedrijfssites", "Websites", "Zakelijke presentatiesites."), ("Campagnes", None, "Acties en campagnes."), ("Apps", None, "Apps en koppelingen."))
    DEMO_ITEMS = (  # title, summary, goal, url, duration, budget, status, tags, groups, video, featured
        ("Webshop Bakkerij Zon", "Een warme webshop voor een ambachtelijke bakkerij.", "Online bestellen van brood en gebak, met afhalen in de winkel.", "https://example.com/bakkerij", "3 maanden", "€ 12.500", "active", ("webshop", "mkb", "food"), ("Webshops",), "", True),
        ("Website Adviesbureau Noord", "Een rustige, zakelijke site met veel ruimte voor kennisartikelen.", "Meer aanvragen voor adviesgesprekken en een duidelijk overzicht van de diensten.", "https://example.com/advies", "2 maanden", "€ 8.000", "active", ("website", "zakelijk", "mkb"), ("Bedrijfssites",), "", False),
        ("Campagne Zomeractie", "Een landingspagina met actie, formulier en tellers.", "Duizend aanmeldingen in zes weken.", "", "6 weken", "€ 4.200", "active", ("campagne", "marketing"), ("Campagnes",), "https://www.youtube.com/watch?v=aqz-KE-bpKQ", True),
        ("Boekingsapp Sportschool", "Een app waarmee leden lessen reserveren.", "Minder telefoontjes en een volle agenda.", "", "5 maanden", "€ 21.000", "development", ("app", "sport", "mkb"), ("Apps",), "", False),
        ("Portfolio Fotostudio Lux", "Een beeldrijk portfolio met grote series.", "Opdrachten binnenhalen met een sterk visueel portfolio.", "https://example.com/lux", "6 weken", "€ 3.500", "active", ("website", "creatief"), ("Bedrijfssites",), "", False),
        ("Webshop Meubelmakerij Eik", "Maatwerkmeubels met configurator en offerte.", "Klanten zelf een tafel laten samenstellen en een offerte laten aanvragen.", "https://example.com/eik", "4 maanden", "€ 16.800", "development", ("webshop", "maatwerk"), ("Webshops",), "", True),
        ("Intranet Zorggroep West", "Een intranet met nieuws, documenten en rooster.", "Medewerkers vinden alles op één plek.", "", "9 maanden", "€ 34.000", "offline", ("intranet", "zorg"), ("Apps",), "", False),
        ("Evenementensite Zomerfestival", "Programma, kaartverkoop en praktische informatie.", "Kaartverkoop zonder drukte op de dag zelf.", "https://example.com/festival", "2 maanden", "€ 9.400", "offline", ("evenement", "campagne"), ("Campagnes",), "", False),
        ("Koppeling Boekhouding", "Facturen en betalingen automatisch doorgezet.", "Geen dubbel invoeren meer voor het kantoor.", "", "7 weken", "€ 6.000", "active", ("app", "koppeling", "zakelijk"), ("Apps",), "", False),
    )

    class ShowcaseDemo:
        def empty(self):  # the module has no content of its own yet (an import fills it with example content then)
            return not Item.objects.exists()

        def counts(self):
            return {"showcase_projecten": Item.objects.filter(demo=True).count(), "showcase_presentaties": Design.objects.filter(demo=True).count()}

        def create(self, objects=True, orders=True, use_media=False, sets=None):
            if Item.objects.filter(demo=True).exists():
                return {}
            made = {"projecten": 0}
            with transaction.atomic():
                groups = {}
                for n, (name, parent, desc) in enumerate(DEMO_GROUPS):
                    groups[name] = Group.objects.create(name=name, slug=unique_slug(Group, name), parent=groups.get(parent), description=desc, order=n, demo=True)
                pool = list(MediaItem.objects.filter(source="media-demo", kind="image").exclude(name__startswith="Hero ").order_by("id"))
                tags = {}
                for n, (title, summary, goal, url, dur, budget, status, tgs, grs, video, featured) in enumerate(DEMO_ITEMS):
                    i = Item.objects.create(title=title, slug=unique_slug(Item, title), summary=summary, goal=goal, url=url, duration=dur, budget=budget, status=status, featured=featured, order=n, demo=True,
                                            description=f"<p>{summary}</p><p>{goal} We werkten stap voor stap, met korte lijnen en regelmatig een demonstratie, zodat het resultaat precies aansluit op wat nodig is.</p><ul><li>Ontwerp en inhoud samen met de klant</li><li>Gebouwd en getest op telefoon, tablet en computer</li><li>Doorlopend beheer en uitleg</li></ul>")
                    imgs = []
                    for k in range(3):
                        m = pool[(n * 3 + k) % len(pool)] if pool else demo_media(n * 3 + k, title if k == 0 else f"{title} {k + 1}", PALETTE[n % len(PALETTE)], k)
                        imgs.append({"media": m.id, "alt": title, "caption": ""})
                    i.images = imgs
                    if video:
                        i.videos = [{"url": video, "title": "Film bij het project"}]
                    i.save()
                    for nm in tgs:
                        tg = tags.get(nm) or Tag.objects.create(name=nm, slug=unique_slug(Tag, nm), demo=True)
                        tags[nm] = tg
                        ItemTag.objects.create(item=i, tag=tg)
                    for g in grs:
                        ItemGroup.objects.create(item=i, group=groups[g])
                        if groups[g].parent_id:
                            ItemGroup.objects.create(item=i, group=groups[g].parent)
                    made["projecten"] += 1
                if objects:
                    for name, kw in (("Projecten met zoeken en filters", dict(layout="grid", open="page", search=True, f_tags=True, f_groups=True, f_status=True, title="Onze projecten", intro="Zoek op naam, tag of groep.")),
                                     ("Uitgelichte scroller", dict(layout="scroller", open="popup", featured_only=True, autoplay=True, title="Uitgelicht")),
                                     ("Projectenlijst in een popup", dict(layout="list", open="popup", search=True, f_status=True, title="Alle projecten")),
                                     ("Tabel met looptijd en budget", dict(layout="table", open="page", fields=["status", "duration", "budget", "tags"], title="Overzicht")),
                                     ("Fotomuur", dict(layout="masonry", open="popup", fields=["summary"], size="sm", title="Fotomuur")),
                                     ("Hero-slider", dict(layout="slider", open="page", featured_only=True, autoplay=True, ratio="16/9", title="")),):
                        Design.objects.create(name=name, slug=unique_slug(Design, name), demo=True, **kw)
                    made["presentaties"] = 6
            sync_objects()
            return made

        def remove(self):
            n = Item.objects.filter(demo=True).count()
            ids = list(Item.objects.filter(demo=True).values_list("id", flat=True))
            ItemTag.objects.filter(item_id__in=ids).delete()
            ItemGroup.objects.filter(item_id__in=ids).delete()
            Item.objects.filter(demo=True).delete()
            Tag.objects.filter(demo=True).delete()
            Group.objects.filter(demo=True).delete()
            Design.objects.filter(demo=True).delete()
            MediaItem.objects.filter(source="showcase-demo").delete()
            sync_objects()
            return {"showcase_projecten": n}

    class ShowcaseImport:
        """The projects of a design that is imported (the example cards of its showcase): made as real projects, once (a title that exists is left alone)."""

        def create(self, cards):
            made = 0
            for n, d in enumerate((cards if isinstance(cards, list) else [])[:40]):
                title = str(d.get("title") or "").strip()[:160]
                if not title or Item.objects.filter(title__iexact=title).exists():
                    continue
                groups = []
                gname = str(d.get("group") or "").strip()[:120]
                if gname:
                    g = Group.objects.filter(name__iexact=gname).first() or Group.objects.create(name=gname, slug=unique_slug(Group, gname), order=Group.objects.count())
                    groups.append(g.id)
                data = {"title": title, "summary": str(d.get("summary") or "")[:300], "duration": str(d.get("duration") or "")[:80], "status": d.get("status") if d.get("status") in STATUSES else "active",
                        "tags": [str(t)[:60] for t in (d.get("tags") or [])][:10], "groups": groups, "active": True, "order": n,
                        "images": [{"media": d["media"], "alt": str(d.get("alt") or title)[:160], "caption": ""}] if d.get("media") else []}
                try:
                    apply_item(Item(), data)
                    made += 1
                except ValueError:
                    continue
            return made

    system.provide("design_import", ShowcaseImport())
    system.provide("demo", ShowcaseDemo())  # the button "Maak demo content" / "Verwijder demo content" is on the plugin page of the system (Admin > Plugins > Showcase)
