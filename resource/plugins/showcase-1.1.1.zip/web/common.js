// Copyright & Ownership Notice
// easy2Edit is the exclusive legal property of RST Coaching & Consultancy B.V. (RSTCC),
// owned by Ronald Stolk. All rights reserved. Any unauthorized use, copying, modification,
// reproduction, distribution, or commercial exploitation of Easy2Edit, including its source code,
// is strictly prohibited without prior written permission from Ronald Stolk or RSTCC.
// website https://rstcc.net

/* Hulpfuncties voor de pagina's van Showcase (zonder framework). Gebruikt window.system uit het systeem. */
var t = function () { return system.t.apply(system, arguments); };
var $ = function (s, r) { return (r || document).querySelector(s); };
function esc(s) { return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); }
var RUN = "/plugins/run/showcase/";
var LANG = "", origin = "";
function api(path, opts) { return system.api(RUN + path + (LANG ? (path.indexOf("?") >= 0 ? "&" : "?") + "lang=" + encodeURIComponent(LANG) : ""), opts); }
function img(u) { return !u ? "" : (/^https?:/.test(u) ? u : origin + u); }
/* one-colour icons (currentColor) */
var ICON = {
  link: '<path d="M10 14a4 4 0 0 0 5.7 0l3-3a4 4 0 0 0-5.7-5.7l-1 1"/><path d="M14 10a4 4 0 0 0-5.7 0l-3 3A4 4 0 0 0 11 18.7l1-1"/>',
  clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
  coin: '<circle cx="12" cy="12" r="9"/><path d="M14.5 9.2a3 3 0 0 0-5 1.8c0 3 5 1.5 5 4.5a3 3 0 0 1-5 1.8M12 6.500v1.5m0 8v1.5"/>',
  target: '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1"/>',
  left: '<path d="M15 5l-7 7 7 7"/>', right: '<path d="M9 5l7 7-7 7"/>', close: '<path d="M6 6l12 12M18 6L6 18"/>',
  grid: '<rect x="4" y="4" width="7" height="7" rx="1"/><rect x="13" y="4" width="7" height="7" rx="1"/><rect x="4" y="13" width="7" height="7" rx="1"/><rect x="13" y="13" width="7" height="7" rx="1"/>',
  list: '<path d="M8 6h12M8 12h12M8 18h12M4 6h.01M4 12h.01M4 18h.01"/>', search: '<circle cx="11" cy="11" r="7"/><path d="M20 20l-4-4"/>',
  image: '<rect x="3" y="5" width="18" height="14" rx="2"/><circle cx="9" cy="10" r="1.5"/><path d="M21 16l-5-5-8 8"/>'
};
function icon(n, size) { return '<svg class="ic" width="' + (size || 16) + '" height="' + (size || 16) + '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + (ICON[n] || "") + "</svg>"; }
function statusLabel(s) { return { active: t("Actief"), development: t("In ontwikkeling"), offline: t("Offline") }[s] || s; }
function statusBadge(s) { return s ? '<span class="st st-' + esc(s) + '"><i></i>' + esc(statusLabel(s)) + "</span>" : ""; }
function height() {  /* a popup lies over the page: the frame must be as high as the popup, else it is cut off */
  var o = document.querySelector(".overlay"), m = o && o.firstElementChild, want = m ? Math.ceil(m.getBoundingClientRect().bottom + 24) + "px" : "";
  if (document.body.style.minHeight !== want) document.body.style.minHeight = want;
  system.resize(Math.ceil(Math.max(document.documentElement.scrollHeight, document.body.scrollHeight)));
}
new MutationObserver(height).observe(document.documentElement, { childList: true, subtree: true, attributes: true });
window.addEventListener("load", height); window.addEventListener("resize", height);
document.addEventListener("click", function (e) { var a = e.target.closest && e.target.closest("[data-go]"); if (a) { e.preventDefault(); system.go(a.getAttribute("data-go")); } });
/* is a field shown? the design may narrow it down (fields = [] means: every field that is on) */
function shows(D, item, f) { return item[f] !== undefined && item[f] !== null && item[f] !== "" && !(Array.isArray(item[f]) && !item[f].length) && (!D || !(D.fields || []).length || D.fields.indexOf(f) >= 0); }
/* the facts of a project (goal, link, duration, budget) as small rows */
function facts(D, p) {
  var rows = [];
  if (shows(D, p, "goal")) rows.push([icon("target"), t("Doel"), esc(p.goal)]);
  if (shows(D, p, "duration")) rows.push([icon("clock"), t("Looptijd"), esc(p.duration)]);
  if (shows(D, p, "budget")) rows.push([icon("coin"), t("Budget"), esc(p.budget)]);
  if (shows(D, p, "url")) rows.push([icon("link"), t("Link"), '<a href="' + esc(p.url) + '" target="_blank" rel="noopener noreferrer">' + esc(p.url.replace(/^https?:\/\/(www\.)?/, "").replace(/\/$/, "")) + "</a>"]);
  return rows.length ? '<dl class="facts">' + rows.map(function (r) { return "<div><dt>" + r[0] + "<span>" + esc(r[1]) + "</span></dt><dd>" + r[2] + "</dd></div>"; }).join("") + "</dl>" : "";
}
function tagList(D, p, clickable) { return shows(D, p, "tags") ? '<div class="tags">' + p.tags.map(function (x) { return '<' + (clickable ? 'button type="button" data-tag="' + esc(x.slug) + '"' : "span") + ' class="tg">' + esc(x.name) + "</" + (clickable ? "button" : "span") + ">"; }).join("") + "</div>" : ""; }
function videoHtml(v) { return '<div class="video">' + (v.kind === "file" ? '<video controls preload="metadata" src="' + esc(v.embed) + '"></video>' : '<iframe src="' + esc(v.embed) + '" title="' + esc(v.title || t("Video")) + '" loading="lazy" allowfullscreen referrerpolicy="strict-origin-when-cross-origin"></iframe>') + (v.title ? "<small>" + esc(v.title) + "</small>" : "") + "</div>"; }
/* the whole project: pictures (gallery), videos, text and facts */
function detailHtml(D, p) {
  var imgs = (p.images || []).filter(function () { return !D || !(D.fields || []).length || D.fields.indexOf("images") >= 0; });
  var vids = (p.videos || []).filter(function () { return !D || !(D.fields || []).length || D.fields.indexOf("videos") >= 0; });
  var gal = imgs.length ? '<div class="gallery"><img class="main" src="' + esc(img(imgs[0].url)) + '" alt="' + esc(imgs[0].alt) + '">' + (imgs.length > 1 ? '<div class="thumbs">' + imgs.map(function (x, n) { return '<img data-g="' + n + '" class="' + (n ? "" : "on") + '" src="' + esc(img(x.url)) + '" alt="' + esc(x.alt) + '">'; }).join("") + "</div>" : "") + "</div>" : "";
  return '<div class="detail"><div class="dmedia">' + gal + vids.map(videoHtml).join("") + '</div><div class="dtext"><div class="row">' + (shows(D, p, "status") ? statusBadge(p.status) : "") + "</div><h2>" + esc(p.title) + "</h2>" +
    (shows(D, p, "summary") ? '<p class="lead">' + esc(p.summary) + "</p>" : "") + facts(D, p) + (shows(D, p, "description") ? '<div class="rich">' + p.description + "</div>" : "") + tagList(D, p, false) + "</div></div>";
}
function wireGallery(root, p) {
  var main = $(".gallery .main", root);
  Array.prototype.forEach.call(root.querySelectorAll(".thumbs img"), function (th) { th.onclick = function () { main.src = th.src; main.alt = th.alt; Array.prototype.forEach.call(root.querySelectorAll(".thumbs img"), function (o) { o.classList.toggle("on", o === th); }); }; });
}
function pageDone() { try { system.loaded(); } catch (e) { /* an older system: the loader lets go by itself */ } }
function boot(fn) { system.ready.then(function (ctx) { origin = ctx.apiBase || ""; LANG = ctx.lang || ""; return fn(ctx); }).then(function () { setTimeout(pageDone, 60); }).catch(function (e) { document.body.innerHTML = '<div class="alert">' + esc(e.message || e) + "</div>"; }); }
