/* Hulpfuncties voor de pagina's van de webshop (zonder framework). Gebruikt window.system uit het systeem. */
var t = function () { return system.t.apply(system, arguments); };
var $ = function (s, r) { return (r || document).querySelector(s); };
function esc(s) { return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); }
var RUN = "/plugins/run/games/";
function api(path, opts) { return system.api(RUN + path, opts); }
function money(v) { try { return new Intl.NumberFormat(document.documentElement.lang || "nl", { style: "currency", currency: "EUR" }).format(Number(v)); } catch (e) { return "€ " + Number(v).toFixed(2); } }
var origin = "";
function img(u) { return !u ? "" : (/^https?:/.test(u) ? u : origin + u); }
function height() { system.resize(Math.ceil(document.documentElement.scrollHeight)); }
new MutationObserver(function () { height(); }).observe(document.documentElement, { childList: true, subtree: true, attributes: true });
window.addEventListener("load", height);
document.addEventListener("click", function (e) {  /* a link with data-go opens an address of the website */
  var a = e.target.closest && e.target.closest("[data-go]");
  if (a) { e.preventDefault(); system.go(a.getAttribute("data-go")); }
});
function boot(fn) { system.ready.then(function (ctx) { origin = ctx.apiBase || ""; return fn(ctx); }).catch(function (e) { document.body.innerHTML = '<div class="alert">' + esc(e.message || e) + "</div>"; }); }

/* Een formulier uit de opties van een spel (game.json: config / settings). onChange(key, value) wordt bij elke wijziging aangeroepen. */
function renderFields(el, schema, values, onChange) {
  el.innerHTML = schema.map(function (c) {
    var v = values[c.key], lab = esc(t(c.label)), hint = c.hint ? "<small class=\"muted\">" + esc(t(c.hint)) + "</small>" : "";
    if (c.type === "bool") return '<label class="check"><input type="checkbox" data-k="' + c.key + '"' + (v ? " checked" : "") + "> " + lab + " " + hint + "</label>";
    if (c.type === "select") return "<label>" + lab + '<select data-k="' + c.key + '">' + c.options.map(function (o) { var val = typeof o === "object" ? o.value : o, l = typeof o === "object" ? o.label : o; return '<option value="' + esc(val) + '"' + (String(v) === String(val) ? " selected" : "") + ">" + esc(t(l)) + "</option>"; }).join("") + "</select>" + hint + "</label>";
    if (c.type === "textarea") return "<label>" + lab + '<textarea rows="3" data-k="' + c.key + '">' + esc(v) + "</textarea>" + hint + "</label>";
    if (c.type === "color") return "<label>" + lab + '<input type="color" data-k="' + c.key + '" value="' + esc(v) + '" style="height:2.4rem;padding:2px">' + hint + "</label>";
    return "<label>" + lab + '<input data-k="' + c.key + '" type="' + (c.type === "number" ? "number" : "text") + '"' + (c.min != null ? ' min="' + c.min + '"' : "") + (c.max != null ? ' max="' + c.max + '"' : "") + ' value="' + esc(v) + '">' + hint + "</label>";
  }).join("");
  Array.prototype.forEach.call(el.querySelectorAll("[data-k]"), function (i) {
    var fire = function () { onChange(i.getAttribute("data-k"), i.type === "checkbox" ? i.checked : (i.type === "number" ? Number(i.value) : i.value)); };
    i.addEventListener(i.tagName === "SELECT" || i.type === "checkbox" || i.type === "color" ? "change" : "input", fire);
  });
}
/* Een venster (popup) in de pagina */
function modal(html, onClose) {
  var o = document.createElement("div"); o.className = "overlay"; o.innerHTML = '<div class="card modal">' + html + "</div>";
  o.addEventListener("mousedown", function (e) { if (e.target === o) close(); });
  function close() { o.remove(); if (onClose) onClose(); }
  document.body.appendChild(o);
  return { el: o.firstChild, close: close };
}
