// Copyright & Ownership Notice
// easy2Edit is the exclusive legal property of RST Coaching & Consultancy B.V. (RSTCC),
// owned by Ronald Stolk. All rights reserved. Any unauthorized use, copying, modification,
// reproduction, distribution, or commercial exploitation of Easy2Edit, including its source code,
// is strictly prohibited without prior written permission from Ronald Stolk or RSTCC.
// website https://rstcc.net

/* Game SDK: wordt door het systeem in elk spel gezet (niets om op te nemen).
   game.ready: resolves {user, best, state, lang, config, settings} zodra het spel is verbonden.
   config = de configuratie die de beheerder instelde, settings = de instellingen van dit lid (zie "config" en "settings" in game.json).
   game.players: { mode: "single"|"multi", max, chat, direct } wat de beheerder toestaat. Bij "multi": game.room.send(data, naar?), game.room.onMessage(fn), game.room.onPlayers(fn), game.room.players / me / code.
   game.onSettings(fn): de instellingen van het lid zijn veranderd terwijl het spel draait (fn krijgt de nieuwe settings).
   game.submitScore(score, extra): geeft een score door; resolves {best, rank, top, isBest}.
   game.save(data) / game.load(): voortgang van dit lid bij dit spel (JSON, max. 64 KB).
   game.onPause(fn) / game.onResume(fn): het kader is niet in beeld of terug.  game.fullscreen(): schermvullend. */
(function () {
  try { window.localStorage.getItem("x"); } catch (e) {  /* zonder opslag in de sandbox: een tijdelijke vervanger, zodat spellen niet breken */
    var mem = {}; var shim = { getItem: function (k) { return Object.prototype.hasOwnProperty.call(mem, k) ? mem[k] : null; }, setItem: function (k, v) { mem[k] = String(v); }, removeItem: function (k) { delete mem[k]; }, clear: function () { mem = {}; }, key: function (i) { return Object.keys(mem)[i] || null; }, get length() { return Object.keys(mem).length; } };
    try { Object.defineProperty(window, "localStorage", { value: shim }); Object.defineProperty(window, "sessionStorage", { value: shim }); } catch (e2) {}
  }
  var pending = {}, n = 0, hooks = { pause: [], resume: [], settings: [], players: [], msg: [] }, room = { players: [], me: null, code: null }, resolveReady, ready = new Promise(function (r) { resolveReady = r; });
  function call(type, extra) { return new Promise(function (resolve, reject) { var id = ++n; pending[id] = { resolve: resolve, reject: reject }; parent.postMessage(Object.assign({ game: type, id: id }, extra), "*"); }); }
  window.addEventListener("message", function (e) {
    if (e.source !== parent) return;
    var d = e.data || {};
    if (d.game === "init") resolveReady({ user: d.user, best: d.best, state: d.state, lang: d.lang, config: d.config || {}, settings: d.settings || {}, players: d.players || { mode: "single", max: 1, chat: false, direct: false } });
    if (d.game === "room") { if (d.event === "players") { room.players = d.players || []; room.me = d.me; room.code = d.code || null; hooks.players.forEach(function (f) { f(room.players, room.me); }); } if (d.event === "msg") hooks.msg.forEach(function (f) { f(d.data, d.from); }); }
    if (d.game === "settings") hooks.settings.forEach(function (f) { f(d.settings || {}); });
    if (d.game === "reply" && pending[d.id]) { var p = pending[d.id]; delete pending[d.id]; d.ok ? p.resolve(d.data) : p.reject(new Error(d.error || "Mislukt")); }
    if (d.game === "pause") hooks.pause.forEach(function (f) { f(); });
    if (d.game === "resume") hooks.resume.forEach(function (f) { f(); });
  });
  window.game = {
    ready: ready,
    submitScore: function (score, extra) { return call("score", { score: score, extra: extra || {} }); },
    save: function (data) { return call("save", { data: data }); },
    load: function () { return call("load", {}); },
    fullscreen: function () { parent.postMessage({ game: "fullscreen" }, "*"); },
    room: {  /* meerdere spelers: het systeem regelt de kamer (code, spelers); het spel stuurt en ontvangt eigen berichten */
      get players() { return room.players; }, get me() { return room.me; }, get code() { return room.code; },
      send: function (data, to) { parent.postMessage({ game: "room", op: "send", data: data, to: to }, "*"); },
      onMessage: function (f) { hooks.msg.push(f); },  /* f(data, fromPlayerIndex) */
      onPlayers: function (f) { hooks.players.push(f); }  /* f(players, myIndex): iemand kwam erbij of ging weg */
    },
    onSettings: function (f) { hooks.settings.push(f); }, onPause: function (f) { hooks.pause.push(f); }, onResume: function (f) { hooks.resume.push(f); }
  };
  parent.postMessage({ game: "hello" }, "*");
})();
