"""Spelletjes (plugin). Een spelletjeshal: elk spel is een eigen pakket (map of zip met game.json) in de map games van deze plugin.

Een spel draait in een afgeschermd kader (sandbox, geen toegang tot de login of het internet) en praat met de plugin via de game-SDK (window.game):
score doorgeven, voortgang bewaren en laden. De bestanden van de spellen staan in de map games/<naam>/ van de plugin (die niet bij de ondertekening hoort), de gegevens (spellen, configuratie, scores,
voortgang, instellingen van leden) in de database van het systeem (tabellen plg_games_*).

Routes: /api/plugins/run/games/<pad>. Voor leden: list, game/<naam>, start/<naam>, score/<naam>, scores/<naam>, state/<naam>, play/<naam>/<bestand>.
Voor beheer: admin/games, admin/upload, admin/game/<naam>, admin/example."""
import base64
import io
import json
import secrets
from datetime import timedelta
import mimetypes
import re
import shutil
import zipfile
from decimal import Decimal, InvalidOperation

from django.db import models
from django.http import HttpResponse
from django.utils import timezone
from rest_framework.response import Response

NAME_RE = re.compile(r"^[a-z][a-z0-9-]{1,38}[a-z0-9]$")
VER_RE = re.compile(r"^\d{1,4}\.\d{1,4}\.\d{1,4}$")
ALLOWED = {"html", "htm", "js", "mjs", "css", "json", "txt", "md", "png", "jpg", "jpeg", "gif", "webp", "svg", "ico", "mp3", "ogg", "wav", "m4a", "woff", "woff2", "ttf", "otf", "glb", "gltf", "bin", "wasm", "map"}
MAX_FILES, MAX_FILE_MB, MAX_UNPACKED_MB, MAX_STATE = 600, 12, 60, 64 * 1024

SDK_FILE = "web/game-sdk.js"  # the SDK that is put in every game (also used by the preview of the administrator)


def register(system):
    from apps.plugins.facade import community as social  # (the plugin Community; without it: no profiles, nobody hidden)

    T = system.t
    U, label = system.User, system.app_label
    game_sdk = (system.dir / SDK_FILE).read_text(encoding="utf-8")
    games_dir = system.dir / "games"  # the games themselves: <plugin>/games/<name>/ (plugin.json: content_dirs)
    games_dir.mkdir(exist_ok=True)
    bad = lambda msg, code=400: Response({"detail": msg}, status=code)  # noqa: E731

    def table(name):
        return type("Meta", (), {"app_label": label, "db_table": system.db_prefix + name})

    class Game(models.Model):
        slug = models.SlugField(max_length=40, unique=True)
        title = models.CharField(max_length=80)
        description = models.CharField(max_length=500, blank=True)
        version = models.CharField(max_length=20, default="1.0.0")
        author = models.CharField(max_length=80, blank=True)
        controls = models.CharField(max_length=200, blank=True)
        entry = models.CharField(max_length=120, default="index.html")
        thumb = models.CharField(max_length=160, blank=True)
        order_high = models.BooleanField(default=True)  # a higher score is better (False: lower, e.g. a time)
        unit = models.CharField(max_length=20, blank=True)
        categories = models.JSONField(default=list, blank=True)
        config_schema = models.JSONField(default=list, blank=True)  # the options of the administrator (game.json: config)
        settings_schema = models.JSONField(default=list, blank=True)  # the options of every member (game.json: settings)
        config = models.JSONField(default=dict, blank=True)
        enabled = models.BooleanField(default=True)
        plays = models.PositiveIntegerField(default=0)
        size = models.PositiveIntegerField(default=0)
        created_at = models.DateTimeField(auto_now_add=True)
        updated_at = models.DateTimeField(auto_now=True)
        Meta = table("game")

    class Score(models.Model):  # the best score of every member per game
        game = models.ForeignKey(Game, on_delete=models.CASCADE, related_name="scores")
        user = models.ForeignKey(U, on_delete=models.CASCADE, related_name="+")
        score = models.DecimalField(max_digits=16, decimal_places=3)
        extra = models.JSONField(default=dict, blank=True)
        tries = models.PositiveIntegerField(default=1)
        updated_at = models.DateTimeField(auto_now=True)
        Meta = type("Meta", (), {"app_label": label, "db_table": system.db_prefix + "score", "unique_together": [("game", "user")]})

    class State(models.Model):  # the progress of a member in a game
        game = models.ForeignKey(Game, on_delete=models.CASCADE, related_name="states")
        user = models.ForeignKey(U, on_delete=models.CASCADE, related_name="+")
        data = models.JSONField(default=dict, blank=True)
        updated_at = models.DateTimeField(auto_now=True)
        Meta = type("Meta", (), {"app_label": label, "db_table": system.db_prefix + "state", "unique_together": [("game", "user")]})

    class Pref(models.Model):  # the settings of a member for a game
        game = models.ForeignKey(Game, on_delete=models.CASCADE, related_name="prefs")
        user = models.ForeignKey(U, on_delete=models.CASCADE, related_name="+")
        data = models.JSONField(default=dict, blank=True)
        Meta = type("Meta", (), {"app_label": label, "db_table": system.db_prefix + "pref", "unique_together": [("game", "user")]})

    class Room(models.Model):  # a room of members who play one game together (a few hours at most)
        code = models.CharField(max_length=8, unique=True)
        game = models.ForeignKey(Game, on_delete=models.CASCADE, related_name="rooms")
        host = models.ForeignKey(U, on_delete=models.CASCADE, related_name="+")
        max_players = models.PositiveSmallIntegerField(default=2)
        chat = models.BooleanField(default=False)
        created_at = models.DateTimeField(auto_now_add=True)
        Meta = table("room")

    class Member(models.Model):
        room = models.ForeignKey(Room, on_delete=models.CASCADE, related_name="members")
        user = models.ForeignKey(U, on_delete=models.CASCADE, related_name="+")
        idx = models.PositiveSmallIntegerField()
        name = models.CharField(max_length=80)
        seen = models.DateTimeField(default=timezone.now)
        Meta = type("Meta", (), {"app_label": label, "db_table": system.db_prefix + "member", "unique_together": [("room", "user")]})

    class Msg(models.Model):
        room = models.ForeignKey(Room, on_delete=models.CASCADE, related_name="msgs")
        from_idx = models.PositiveSmallIntegerField()
        to_idx = models.SmallIntegerField(null=True, blank=True)  # None = everybody
        kind = models.CharField(max_length=8, default="game")
        data = models.JSONField(default=dict, blank=True)
        created_at = models.DateTimeField(auto_now_add=True)
        Meta = table("msg")

    system.sync_models(Game, Score, State, Pref, Room, Member, Msg)

    FIELD_TYPES = ("text", "textarea", "number", "bool", "select", "color")

    def clean_schema(raw):
        """The options a game offers (game.json: config / settings): [{key, label, type, default, options, min, max, hint}]."""
        out, seen = [], set()
        for c in (raw or [])[:30]:
            if not isinstance(c, dict) or not re.fullmatch(r"[a-z][a-z0-9_]{0,30}", str(c.get("key") or "")) or c["key"] in seen:
                raise ValueError(T("Een optie in game.json is ongeldig (sleutel: a-z, 0-9, _)."))
            t = c.get("type", "text")
            if t not in FIELD_TYPES:
                raise ValueError(T("Optie {0}: onbekend type.", c["key"]))
            seen.add(c["key"])
            opts = [str(o)[:60] if not isinstance(o, dict) else {"value": str(o.get("value"))[:60], "label": str(o.get("label") or o.get("value"))[:60]} for o in (c.get("options") or [])][:40] if t == "select" else []
            default = c.get("default", False if t == "bool" else (0 if t == "number" else ""))
            out.append({"key": c["key"], "label": str(c.get("label") or c["key"])[:80], "type": t, "default": default, "options": opts, "hint": str(c.get("hint") or "")[:200],
                        "min": c.get("min") if isinstance(c.get("min"), (int, float)) else None, "max": c.get("max") if isinstance(c.get("max"), (int, float)) else None})
        return out

    def values_of(schema, stored):
        """Defaults + what is stored, for every option of the schema."""
        stored = stored if isinstance(stored, dict) else {}
        return {c["key"]: stored.get(c["key"], c["default"]) for c in schema}

    def clean_values(schema, incoming, current):
        out = dict(current or {})
        for c in schema:
            if c["key"] not in incoming:
                continue
            v, t = incoming[c["key"]], c["type"]
            if t == "bool":
                v = bool(v)
            elif t == "number":
                try:
                    v = float(v) if "." in str(v) else int(v)
                except (TypeError, ValueError):
                    v = c["default"]
                if c["min"] is not None:
                    v = max(c["min"], v)
                if c["max"] is not None:
                    v = min(c["max"], v)
            elif t == "select":
                allowed = [o["value"] if isinstance(o, dict) else o for o in c["options"]]
                v = v if str(v) in allowed else c["default"]
            elif t == "color":
                v = v if re.fullmatch(r"#[0-9a-fA-F]{6}", str(v or "")) else c["default"]
            else:
                v = str(v or "")[:2000]
            out[c["key"]] = v
        return out

    def sync_games():
        """The games are folders in games/: register the new ones, update the changed ones, forget the ones that are gone."""
        found = set()
        for d in sorted(games_dir.iterdir()) if games_dir.is_dir() else []:
            if not d.is_dir() or d.name.startswith(".") or not NAME_RE.match(d.name):
                continue
            try:
                man = read_manifest((d / "game.json").read_bytes())
            except (OSError, ValueError):
                continue
            if man["name"] != d.name:
                continue
            found.add(d.name)
            g, created = Game.objects.get_or_create(slug=d.name, defaults={"title": man["title"]})
            if created or g.version != man["version"] or g.config_schema != man["config_schema"] or g.settings_schema != man["settings_schema"] or g.title == "":
                for k in ("title", "description", "version", "author", "controls", "entry", "thumb", "order_high", "unit", "categories", "config_schema", "settings_schema"):
                    if k == "title" and not created and g.title and g.version == man["version"]:
                        continue
                    setattr(g, k, man[k])
                g.size = sum(f.stat().st_size for f in d.rglob("*") if f.is_file())
                g.save()
        for gone in Game.objects.exclude(slug__in=found):  # (the cascade of the system does not know the models of a plugin)
            for r in Room.objects.filter(game=gone):
                Msg.objects.filter(room=r).delete(); Member.objects.filter(room=r).delete(); r.delete()
            Pref.objects.filter(game=gone).delete()
            Score.objects.filter(game=gone).delete()
            State.objects.filter(game=gone).delete()
            gone.delete()

    names = {}

    def name(uid):
        if uid not in names:
            u = U.objects.filter(pk=uid).first()
            names[uid] = social.display_name(u) if u else "?"
        return names[uid]

    def num(d):
        return float(d)

    def game_dir(slug):
        return games_dir / slug

    def best_of(g, user):
        s = Score.objects.filter(game=g, user=user).first()
        return num(s.score) if s else None

    def top(g, limit=10):
        qs = Score.objects.filter(game=g).order_by("-score" if g.order_high else "score", "updated_at")[:limit]
        return [{"rank": i + 1, "name": name(s.user_id), "score": num(s.score), "uid": s.user_id, "when": s.updated_at} for i, s in enumerate(qs)]

    def words(m, lang, default):
        """A text in the language of the visitor, else in Dutch, else what the game says itself."""
        return m.get(lang) or m.get((lang or "").split("-")[0]) or m.get("nl") or default

    def card(g, user, lang="nl"):
        meta = system.item(g.slug)["meta"]
        thumb = meta["image"] or g.thumb
        return {"slug": g.slug, "title": words(meta["titles"], lang, g.title), "description": words(meta["descriptions"], lang, g.description), "version": g.version, "author": g.author, "controls": g.controls, "thumb": f"play/{g.slug}/{thumb}" if thumb else "",
                "higher_is_better": g.order_high, "unit": g.unit, "categories": g.categories, "plays": g.plays, "best": best_of(g, user) if user else None, "public": system.item(g.slug)["public"], "min_age": system.item(g.slug)["min_age"], "about": {"layout": meta["about"]["layout"], "images": [f"play/{g.slug}/{x}" for x in meta["about"]["images"]], "text": words(meta["about"]["texts"], lang, "")}, "enabled": item_on(g.slug), "entry": g.entry, "has_settings": bool(g.settings_schema), "has_config": bool(g.config_schema)}

    def frame_rules(request=None):
        from apps.plugins.views import frame_ancestors

        return frame_ancestors(request)

    # ── for members ───────────────────────────────────────────────────────────
    @system.route("GET", "list")
    def games(request):
        sync_games()
        every = request.user.is_staff and request.query_params.get("all")
        lang = request.query_params.get("lang", "nl")[:10]
        return {"games": [card(g, request.user, lang) for g in Game.objects.order_by("title") if every or item_on(g.slug)], "scores_on": bool(system.config.get("scores_on"))}

    def item_on(slug):  # on or off: set by the superadmin in Admin -> Plugins -> Spellen
        return bool(system.item(slug)["enabled"])

    def find(slug, user, any_state=False):
        g = Game.objects.filter(slug=slug).first()
        return g if g and (item_on(slug) or (user.is_staff and any_state)) else None

    def age_of(user):
        """The age of the member from the birth date of the profile, or None when it is not known."""
        from datetime import date

        b = getattr(user, "birth_date", None)
        if not b:
            return None
        t = date.today()
        return t.year - b.year - ((t.month, t.day) < (b.month, b.day))

    def age_ok(g, user):
        """True: old enough (or no limit); False: too young; None: no limit known to be met (birth date unknown)."""
        m = system.item(g.slug)["min_age"]
        if not m:
            return True
        a = age_of(user)
        return None if a is None else a >= m

    @system.route("GET", "game/<slug>")
    def detail(request, slug):
        g = find(slug, request.user, True)
        if not g:
            return bad(T("Dit spel bestaat niet (meer)."), 404)
        out = card(g, request.user, request.query_params.get("lang", "nl")[:10])
        out["top"] = top(g) if system.config.get("scores_on") else []
        out["settings_schema"] = g.settings_schema
        out["settings"] = my_settings(g, request.user)
        out["players"] = system.item(slug, players=True)["players"]
        out["age_ok"] = age_ok(g, request.user)
        return out

    def my_settings(g, user):
        p = Pref.objects.filter(game=g, user=user).first()
        return values_of(g.settings_schema, p.data if p else {})

    @system.route("PUT", "settings/<slug>")
    def put_settings(request, slug):
        g = find(slug, request.user)
        if not g:
            return bad(T("Dit spel bestaat niet (meer)."), 404)
        d = request.data if isinstance(request.data, dict) else {}
        p = Pref.objects.filter(game=g, user=request.user).first()
        data = clean_values(g.settings_schema, d.get("settings") if isinstance(d.get("settings"), dict) else {}, p.data if p else {})
        Pref.objects.update_or_create(game=g, user=request.user, defaults={"data": data})
        return {"settings": values_of(g.settings_schema, data)}

    def locked(request, g=None, *keys):
        """The first of the actions (Admin -> Actions) this member does not have, as an answer; None when everything is allowed."""
        for key in ("games", *((f"game:{g.slug}",) if g else ()), *keys):
            if (r := system.gate(request.user, key)):
                return r
        return None

    @system.route("POST", "start/<slug>")
    def start(request, slug):
        g = find(slug, request.user)
        if not g:
            return bad(T("Dit spel bestaat niet (meer)."), 404)
        if age_ok(g, request.user) is False:
            return bad(T("Dit spel is voor {0} jaar en ouder.", system.item(g.slug)["min_age"]), 403)
        if (r := locked(request, g)):
            return r
        Game.objects.filter(pk=g.pk).update(plays=models.F("plays") + 1)
        st = State.objects.filter(game=g, user=request.user).first()
        return {"best": best_of(g, request.user), "state": st.data if st else None, "config": values_of(g.config_schema, system.item(g.slug)["config"]), "settings": my_settings(g, request.user), "players": system.item(g.slug, players=True)["players"]}

    @system.route("POST", "score/<slug>")
    def submit(request, slug):
        g = find(slug, request.user)
        d = request.data if isinstance(request.data, dict) else {}
        if not g:
            return bad(T("Dit spel bestaat niet (meer)."), 404)
        try:
            v = Decimal(str(d.get("score"))).quantize(Decimal("0.001"))
            if abs(v) > Decimal("1e12"):
                raise InvalidOperation
        except (InvalidOperation, ValueError):
            return bad(T("Ongeldige score."))
        if (lk := system.gate(request.user, "game_scores")):
            return lk
        extra = d.get("extra") if isinstance(d.get("extra"), dict) and len(json.dumps(d["extra"])) < 2000 else {}
        row = Score.objects.filter(game=g, user=request.user).first()
        better = (not row) or (v > row.score if g.order_high else v < row.score)
        if not row:
            Score.objects.create(game=g, user=request.user, score=v, extra=extra)
        else:
            row.tries += 1
            if better:
                row.score, row.extra = v, extra
            row.save()
        mine = best_of(g, request.user)
        ahead = Score.objects.filter(game=g, score__gt=mine).count() if g.order_high else Score.objects.filter(game=g, score__lt=mine).count()
        return {"best": mine, "rank": ahead + 1, "isBest": bool(better), "top": top(g, 10) if system.config.get("scores_on") else []}

    @system.route("GET", "scores/<slug>")
    def scores(request, slug):
        g = find(slug, request.user)
        if not g or not system.config.get("scores_on"):
            return {"top": []}
        return {"top": top(g, 25)}

    @system.route("GET", "state/<slug>")
    def get_state(request, slug):
        g = find(slug, request.user)
        st = State.objects.filter(game=g, user=request.user).first() if g else None
        return {"data": st.data if st else None}

    @system.route("PUT", "state/<slug>")
    def put_state(request, slug):
        g = find(slug, request.user)
        data = request.data.get("data") if isinstance(request.data, dict) else None
        if not g:
            return bad(T("Dit spel bestaat niet (meer)."), 404)
        if len(json.dumps(data)) > MAX_STATE:
            return bad(T("De voortgang is te groot om te bewaren."))
        State.objects.update_or_create(game=g, user=request.user, defaults={"data": data if data is not None else {}})
        return {"ok": True}

    # ── rooms: members who play a game together; the game sends its own messages through the room (game.room), a chat can run next to it ──
    ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"

    def clean_rooms():
        old = timezone.now() - timedelta(hours=3)
        for r in Room.objects.filter(created_at__lt=old):
            Msg.objects.filter(room=r).delete(); Member.objects.filter(room=r).delete(); r.delete()

    def room_out(r, me_idx):
        now = timezone.now()
        return {"code": r.code, "max": r.max_players, "chat": r.chat, "me": me_idx, "slug": r.game.slug,
                "players": [{"idx": m.idx, "name": m.name, "online": (now - m.seen).total_seconds() < 12} for m in Member.objects.filter(room=r).order_by("idx")]}

    def my_member(code, user):
        r = Room.objects.filter(code=str(code).upper()).select_related("game").first()
        m = Member.objects.filter(room=r, user=user).first() if r else None
        return (r, m) if r and m else (None, None)

    @system.route("POST", "room/create/<slug>")
    def room_create(request, slug):
        g = find(slug, request.user)
        pl = system.item(slug, players=True)["players"] if g else None
        if not g or pl["mode"] != "multi":
            return bad(T("Dit spel kan niet met meerdere spelers worden gespeeld."))
        if (r := locked(request, g, "game_rooms")):
            return r
        clean_rooms()
        code = "".join(secrets.choice(ALPHABET) for _ in range(5))
        while Room.objects.filter(code=code).exists():
            code = "".join(secrets.choice(ALPHABET) for _ in range(5))
        r = Room.objects.create(code=code, game=g, host=request.user, max_players=pl["max"], chat=pl["chat"])
        Member.objects.create(room=r, user=request.user, idx=0, name=social.display_name(request.user))
        return room_out(r, 0)

    @system.route("POST", "room/join/<slug>")
    def room_join(request, slug):
        d = request.data if isinstance(request.data, dict) else {}
        g = find(slug, request.user)
        r = Room.objects.filter(code=str(d.get("code") or "").strip().upper(), game=g).first() if g else None
        if not r:
            return bad(T("Deze code is onbekend of de kamer is gesloten."), 404)
        if (lk := locked(request, g, "game_rooms")):
            return lk
        mine = Member.objects.filter(room=r, user=request.user).first()
        if not mine:
            taken = set(Member.objects.filter(room=r).values_list("idx", flat=True))
            if len(taken) >= r.max_players:
                return bad(T("Deze kamer zit vol."))
            mine = Member.objects.create(room=r, user=request.user, idx=next(i for i in range(8) if i not in taken), name=social.display_name(request.user))
        return room_out(r, mine.idx)

    @system.route("GET", "room/state/<code>")
    def room_state(request, code):
        r, m = my_member(code, request.user)
        if not r:
            return bad(T("Je zit niet (meer) in deze kamer."), 404)
        Member.objects.filter(pk=m.pk).update(seen=timezone.now())
        try:
            after = int(request.query_params.get("after") or 0)
        except ValueError:
            after = 0
        msgs = [{"id": x.id, "from": x.from_idx, "kind": x.kind, "data": x.data} for x in Msg.objects.filter(room=r, id__gt=after).filter(models.Q(to_idx__isnull=True) | models.Q(to_idx=m.idx)).exclude(from_idx=m.idx).order_by("id")[:100]]
        Msg.objects.filter(room=r, created_at__lt=timezone.now() - timedelta(minutes=5)).delete()
        return {**room_out(r, m.idx), "msgs": msgs}

    @system.route("POST", "room/send/<code>")
    def room_send(request, code):
        r, m = my_member(code, request.user)
        d = request.data if isinstance(request.data, dict) else {}
        if not r:
            return bad(T("Je zit niet (meer) in deze kamer."), 404)
        kind = "chat" if d.get("kind") == "chat" else "game"
        if kind == "chat" and not r.chat:
            return bad(T("De chat staat bij dit spel niet aan."), 403)
        data = d.get("data")
        if len(json.dumps(data)) > 20000:
            return bad(T("Het bericht is te groot."))
        if kind == "chat":
            data = {"body": str(data.get("body", "") if isinstance(data, dict) else data)[:500], "name": m.name}
        to = d.get("to")
        Msg.objects.create(room=r, from_idx=m.idx, to_idx=int(to) if isinstance(to, int) and 0 <= to < 8 else None, kind=kind, data=data if data is not None else {})
        return {"ok": True}

    @system.route("POST", "room/leave/<code>")
    def room_leave(request, code):
        r, m = my_member(code, request.user)
        if r:
            m.delete()
            if not Member.objects.filter(room=r).exists():
                Msg.objects.filter(room=r).delete(); r.delete()
        return {"ok": True}

    # the games the superadmin made public: shown to visitors without an account (the others are only for logged-in members)
    @system.route("GET", "public/list", public=True)
    def public_list(request):
        lang = request.query_params.get("lang", "nl")[:10]
        return {"games": [{k: v for k, v in card(g, None, lang).items() if k != "best"} for g in Game.objects.order_by("title") if item_on(g.slug) and system.item(g.slug)["public"]]}

    # the games that may be played in the direct mode (two persons connected through a link): public, the guest has no login
    @system.route("GET", "direct/list", public=True)
    def direct_list(request):
        out = []
        for g in Game.objects.order_by("title"):
            it = system.item(g.slug, players=True)
            if it["enabled"] and it["players"]["direct"]:
                lang = request.query_params.get("lang", "nl")[:10]
                out.append({"slug": g.slug, "title": words(it["meta"]["titles"], lang, g.title), "description": words(it["meta"]["descriptions"], lang, g.description), "entry": g.entry, "thumb": f"play/{g.slug}/{it['meta']['image'] or g.thumb}" if (it["meta"]["image"] or g.thumb) else "", "config": values_of(g.config_schema, it["config"]), "controls": g.controls})
        return {"games": out}

    # ── the files of a game (public: the frame has no login; only games that are on) ──
    @system.route("GET", "play/sdk.js", public=True)
    def sdk(request):
        return HttpResponse(game_sdk, content_type="application/javascript")

    @system.route("GET", "play/<slug>/<*rest>", public=True)
    def play(request, slug, rest):
        g = Game.objects.filter(slug=slug).first() if item_on(slug) else None
        root = game_dir(slug).resolve()
        f = (root / rest).resolve()
        if not g or root not in f.parents or not f.is_file():
            return HttpResponse(status=404)
        ctype = mimetypes.guess_type(f.name)[0] or "application/octet-stream"
        if f.suffix.lower() in (".html", ".htm"):
            html = f.read_text(encoding="utf-8", errors="replace")
            tag = f"<script>{game_sdk}</script>"
            html = html.replace("<head>", "<head>" + tag, 1) if "<head>" in html else tag + html
            r = HttpResponse(html, content_type="text/html; charset=utf-8")
        else:
            r = HttpResponse(f.read_bytes(), content_type=ctype)
        # the game runs in its own sealed frame: no login, no storage of the system, no connections to other sites
        r["Content-Security-Policy"] = ("sandbox allow-scripts allow-pointer-lock; default-src 'none'; script-src 'self' 'unsafe-inline' 'unsafe-eval' blob:; style-src 'self' 'unsafe-inline'; "
                                        "img-src 'self' data: blob:; media-src 'self' data: blob:; font-src 'self' data:; connect-src 'self' data: blob:; worker-src 'self' blob:; form-action 'none'")
        r["X-Content-Type-Options"] = "nosniff"
        r["Cache-Control"] = "no-cache"
        return r

    # ── admin ─────────────────────────────────────────────────────────────────
    def staff(request):
        return None if request.user.is_staff else bad(T("Alleen beheerders mogen spellen beheren."), 403)

    @system.route("GET", "admin/games")
    def admin_games(request):
        if (e := staff(request)):
            return e
        sync_games()
        return {"games": [{**card(g, request.user), "size": g.size, "updated_at": g.updated_at, "players": Score.objects.filter(game=g).count()} for g in Game.objects.order_by("title")], "max_zip_mb": int(system.config.get("max_zip_mb") or 20)}

    def read_manifest(raw):
        try:
            d = json.loads(raw)
        except (TypeError, ValueError):
            raise ValueError(T("game.json is geen geldige JSON."))
        if not isinstance(d, dict):
            raise ValueError(T("game.json moet een object zijn."))
        nm = str(d.get("name") or "").strip()
        if not NAME_RE.match(nm):
            raise ValueError(T("De naam in game.json is ongeldig (3-40 tekens: a-z, 0-9 en -, begint met een letter)."))
        ver = str(d.get("version") or "1.0.0")
        if not VER_RE.match(ver):
            raise ValueError(T("Ongeldig versienummer in game.json: gebruik 1.2.3."))
        entry = str(d.get("entry") or "index.html")
        if entry.startswith("/") or ".." in entry.split("/") or not entry.lower().endswith((".html", ".htm")):
            raise ValueError(T("De entry in game.json moet een html-bestand in het pakket zijn."))
        sc = d.get("scores") if isinstance(d.get("scores"), dict) else {}
        return {"name": nm, "title": str(d.get("title") or nm)[:80], "description": str(d.get("description") or "")[:500], "version": ver, "author": str(d.get("author") or "")[:80],
                "controls": str(d.get("controls") or "")[:200], "entry": entry, "thumb": str(d.get("thumbnail") or "")[:160],
                "order_high": str(sc.get("order") or "high") != "low", "unit": str(sc.get("unit") or "")[:20], "categories": [str(c)[:30] for c in (d.get("categories") or []) if isinstance(c, str)][:6],
                "config_schema": clean_schema(d.get("config")), "settings_schema": clean_schema(d.get("settings"))}

    def install(data):
        limit = int(system.config.get("max_zip_mb") or 20)
        if len(data) > limit * 2**20:
            raise ValueError(T("Het zipbestand is groter dan {0} MB.", limit))
        try:
            zf = zipfile.ZipFile(io.BytesIO(data))
        except zipfile.BadZipFile:
            raise ValueError(T("Dit is geen geldig zipbestand."))
        infos = [i for i in zf.infolist() if not i.filename.endswith("/") and not i.filename.startswith("__MACOSX") and not i.filename.split("/")[-1].startswith(".")]
        if len(infos) > MAX_FILES:
            raise ValueError(T("Te veel bestanden in het pakket (maximaal {0}).", MAX_FILES))
        names_ = [i.filename for i in infos]
        prefix = ""
        if "game.json" not in names_:
            tops = {n.split("/")[0] for n in names_}
            if len(tops) == 1 and f"{next(iter(tops))}/game.json" in names_:
                prefix = next(iter(tops)) + "/"
            else:
                raise ValueError(T("game.json ontbreekt in het zipbestand."))
        man = read_manifest(zf.read(prefix + "game.json"))
        total = 0
        for i in infos:
            n = i.filename[len(prefix):] if i.filename.startswith(prefix) else None
            if n is None:
                continue
            ext = n.rsplit(".", 1)[-1].lower() if "." in n else ""
            if n.startswith("/") or ".." in n.split("/") or "\\" in n or ((i.external_attr >> 16) & 0o170000) == 0o120000:
                raise ValueError(T("Onveilig pad in het pakket: {0}", n))
            if ext not in ALLOWED:
                raise ValueError(T("Dit bestandstype is niet toegestaan in een spel: {0}", n))
            if i.file_size > MAX_FILE_MB * 2**20:
                raise ValueError(T("{0} is te groot (maximaal {1} MB per bestand).", n, MAX_FILE_MB))
            total += i.file_size
            if total > MAX_UNPACKED_MB * 2**20:
                raise ValueError(T("Het uitgepakte spel is te groot (maximaal {0} MB).", MAX_UNPACKED_MB))
        if not any(i.filename[len(prefix):] == man["entry"] for i in infos if i.filename.startswith(prefix)):
            raise ValueError(T("De entry {0} zit niet in het pakket.", man["entry"]))
        tmp = games_dir / f".{man['name']}.tmp"
        shutil.rmtree(tmp, ignore_errors=True)
        for i in infos:
            if not i.filename.startswith(prefix):
                continue
            dest = (tmp / i.filename[len(prefix):]).resolve()
            if tmp.resolve() not in dest.parents:
                raise ValueError(T("Onveilig pad in het pakket: {0}", i.filename))
            dest.parent.mkdir(parents=True, exist_ok=True)
            with zf.open(i) as src, open(dest, "wb") as out:
                shutil.copyfileobj(src, out)
        target = game_dir(man["name"])
        shutil.rmtree(target, ignore_errors=True)
        tmp.rename(target)
        g, created = Game.objects.get_or_create(slug=man["name"], defaults={"title": man["title"]})
        for k in ("title", "description", "version", "author", "controls", "entry", "thumb", "order_high", "unit", "categories", "config_schema", "settings_schema"):
            setattr(g, k, man[k])
        g.size = total
        g.save()
        return g, created

    @system.route("POST", "admin/upload")
    def admin_upload(request):
        if (e := staff(request)):
            return e
        f = request.FILES.get("file")
        if not f or not f.name.lower().endswith(".zip"):
            return bad(T("Kies een zipbestand met een spel."))
        try:
            g, created = install(f.read())
        except ValueError as ex:
            return bad(str(ex))
        system.log.info("Spel %s %s door %s", g.slug, "toegevoegd" if created else "bijgewerkt", request.user.email)
        return Response({**card(g, request.user), "created": created}, status=201 if created else 200)

    @system.route("DELETE", "admin/game/<slug>")
    def admin_delete(request, slug):
        if (e := staff(request)):
            return e
        g = Game.objects.filter(slug=slug).first()
        if not g:
            return bad(T("Dit spel bestaat niet."), 404)
        for r in Room.objects.filter(game=g):
            Msg.objects.filter(room=r).delete(); Member.objects.filter(room=r).delete(); r.delete()
        Pref.objects.filter(game=g).delete()
        Score.objects.filter(game=g).delete()  # (the models of a plugin are not known to the cascade of the system: remove what points at the game first)
        State.objects.filter(game=g).delete()
        g.delete()
        shutil.rmtree(game_dir(slug), ignore_errors=True)
        return Response(status=204)

    @system.route("DELETE", "admin/scores/<slug>")
    def admin_clear_scores(request, slug):
        if (e := staff(request)):
            return e
        g = Game.objects.filter(slug=slug).first()
        if not g:
            return bad(T("Dit spel bestaat niet."), 404)
        Score.objects.filter(game=g).delete()
        return Response(status=204)

    @system.route("GET", "admin/example")
    def admin_example(request):
        """The example game as a zip, to start from."""
        if (e := staff(request)):
            return e
        src = games_dir / "snake"
        if not src.is_dir():
            return bad(T("Het voorbeeldspel (games/snake) is niet aanwezig."), 404)
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
            for p in sorted(src.rglob("*")):
                if p.is_file():
                    z.write(p, p.relative_to(src).as_posix())
        return {"name": "voorbeeldspel-snake.zip", "b64": base64.b64encode(buf.getvalue()).decode()}  # the page makes the download of it (a frame cannot send a login with a link)

    sync_games()


def migrate(system, old, new):
    """Version 2: the options of a game (configuration and settings) are new columns of the table of the games."""
    from django.db import connection, models as m

    cols = {c.name for c in connection.introspection.get_table_description(connection.cursor(), system.db_prefix + "game")}
    with connection.schema_editor() as se:
        model = type("GameOld", (m.Model,), {"__module__": __name__, "Meta": type("Meta", (), {"app_label": system.app_label, "db_table": system.db_prefix + "game"}), "id": m.AutoField(primary_key=True)})
        for name_, field in (("config_schema", m.JSONField(default=list, blank=True)), ("settings_schema", m.JSONField(default=list, blank=True)), ("config", m.JSONField(default=dict, blank=True))):
            if name_ not in cols:
                field.set_attributes_from_name(name_)
                se.add_field(model, field)
