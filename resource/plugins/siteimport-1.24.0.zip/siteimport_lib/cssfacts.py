# Copyright & Ownership Notice
# easy2Edit is the exclusive legal property of RST Coaching & Consultancy B.V. (RSTCC),
# owned by Ronald Stolk. All rights reserved. Any unauthorized use, copying, modification,
# reproduction, distribution, or commercial exploitation of Easy2Edit, including its source code,
# is strictly prohibited without prior written permission from Ronald Stolk or RSTCC.
# website https://rstcc.net

"""The REAL values of the CSS of a page, worked out here without a browser: which rules apply to an element (selectors with classes, ids, descendants and children,
specificity and order), css variables (also when they are defined on another class of the same element or on a parent), color-mix(), and the layers of a background
(a gradient over a picture). The importer hands these facts to the AI per section, so the AI does not have to guess the cascade of a page that follows the Easy2edit prompt.
Desktop only (1440 px): @media rules with min-width/max-width are evaluated at that width, everything else (dark mode, print) is left out."""
import re

WIDTH = 1440
INHERITED = ("color", "font-size", "font-weight", "line-height", "text-align", "font-family", "letter-spacing", "text-transform")
SHOW = ("color", "font-size", "font-weight", "line-height", "text-align", "padding", "padding-top", "padding-bottom", "padding-left", "padding-right",
        "margin", "margin-top", "margin-bottom", "border", "border-top", "border-bottom", "border-color", "border-radius", "box-shadow", "max-width", "width", "min-height", "height", "display",
        "grid-template-columns", "flex-direction", "justify-content", "align-items", "gap", "text-transform", "letter-spacing", "opacity", "object-fit", "aspect-ratio", "background-size",
        "background-position")
RESETS = {"background": ("background-color", "background-image", "background-size", "background-position", "background-repeat"), "padding": ("padding-top", "padding-bottom", "padding-left", "padding-right"),
          "margin": ("margin-top", "margin-bottom", "margin-left", "margin-right"), "border": ("border-top", "border-bottom", "border-left", "border-right", "border-color", "border-width"),
          "font": ("font-size", "font-weight", "line-height")}
NAMED = {"white": "#ffffff", "black": "#000000", "transparent": "rgba(0,0,0,0)", "red": "#ff0000", "gray": "#808080", "grey": "#808080"}
SKIP_PSEUDO = re.compile(r":(hover|focus|active|visited|disabled|checked|before|after|first-letter|first-line|placeholder|selection|focus-visible|focus-within|target|empty|nth-|not|is|where|has|last-|only-)", re.I)
COLOR_RE = r"#[0-9a-fA-F]{3,8}\b|rgba?\([^)]*\)"


# ── parsing ─────────────────────────────────────────────────────────────────────────
def _blocks(css):
    """[(prelude, body)] at the top level of a css text (braces are matched; a nested block stays inside its body)."""
    out, i, n = [], 0, len(css)
    while i < n:
        j = css.find("{", i)
        if j < 0:
            break
        prelude, depth, k = css[i:j].strip(), 1, j + 1
        while k < n and depth:
            c = css[k]
            depth += (c == "{") - (c == "}")
            k += 1
        out.append((prelude, css[j + 1:k - 1]))
        i = k
    return out


def _px(v):
    m = re.fullmatch(r"\s*(-?[\d.]+)\s*(px|rem|em)?\s*", str(v or ""))
    if not m:
        return None
    x = float(m.group(1))
    return x * 16 if m.group(2) in ("rem", "em") else x


def _media_ok(cond):
    """Does this @media condition hold on a desktop screen of WIDTH px?"""
    c = cond.lower()
    if re.search(r"prefers-|print|orientation|hover|pointer|forced-colors|reduced", c):
        return False
    for kind, val in re.findall(r"\(\s*(min|max)-width\s*:\s*([^)]+)\)", c):
        w = _px(val)
        if w is None or (kind == "min" and WIDTH < w) or (kind == "max" and WIDTH > w):
            return False
    return True


def _split(text, sep):
    """Split at a separator that is not inside parentheses or quotes."""
    out, depth, cur, q = [], 0, [], ""
    for c in text:
        if q:
            cur.append(c)
            if c == q:
                q = ""
        elif c in "\"'":
            q = c
            cur.append(c)
        elif c == "(":
            depth += 1
            cur.append(c)
        elif c == ")":
            depth -= 1
            cur.append(c)
        elif c == sep and depth == 0:
            out.append("".join(cur))
            cur = []
        else:
            cur.append(c)
    out.append("".join(cur))
    return out


def _specificity(sel):
    s = sel.replace(":root", "html")
    return (len(re.findall(r"#[\w-]+", s)), len(re.findall(r"\.[\w-]+", s)) + len(re.findall(r"\[[^\]]+\]", s)), len(re.findall(r"(?:^|[\s>+~])[a-zA-Z][\w-]*", s)))


def parse_rules(css, _depth=0, _base=0):
    """[(selector, specificity, order, {prop: value}, important_props)] for every simple rule that applies on desktop; the order is the position in the css."""
    css = re.sub(r"/\*.*?\*/", "", css or "", flags=re.S)
    rules = []
    for prelude, body in _blocks(css):
        if prelude.startswith("@media"):
            if _depth < 3 and _media_ok(prelude[6:]):
                rules += parse_rules(body, _depth + 1, _base + len(rules))
            continue
        if prelude.startswith("@"):
            continue
        decls, important = {}, set()
        for part in _split(body, ";"):
            if ":" not in part:
                continue
            k, v = part.split(":", 1)
            k, v = k.strip(), v.strip()
            k = k if k.startswith("--") else k.lower()
            if re.search(r"!\s*important\s*$", v, re.I):
                v = re.sub(r"\s*!\s*important\s*$", "", v, flags=re.I)
                important.add(k)
            decls[k] = v
        for sel in _split(prelude, ","):
            sel = sel.strip()
            if sel and not SKIP_PSEUDO.search(sel.replace(":root", "")) and "::" not in sel:
                rules.append((sel, _specificity(sel), _base + len(rules), decls, important))
    return rules


# ── selectors ───────────────────────────────────────────────────────────────────────
def _compounds(sel):
    """[(combinator, compound)] of a selector, left to right."""
    sel = sel.replace(":root", "html").strip()
    toks = re.findall(r"[>+~]|[^\s>+~]+", sel)
    out, comb = [], " "
    for t in toks:
        if t in (">", "+", "~"):
            comb = t
        else:
            out.append((comb, t))
            comb = " "
    return out or None


def _match_compound(node, comp):
    tag = re.match(r"^[a-zA-Z][\w-]*", comp)
    if tag and tag.group(0).lower() != node.tag:
        return False
    classes = (node.attrs.get("class") or "").split()
    if any(c not in classes for c in re.findall(r"\.([\w-]+)", comp)):
        return False
    if any(i != node.attrs.get("id") for i in re.findall(r"#([\w-]+)", comp)):
        return False
    for a in re.findall(r"\[([^\]]+)\]", comp):
        k, _, v = a.partition("=")
        if k.strip() not in node.attrs or (v and node.attrs.get(k.strip()) != v.strip("\"' ")):
            return False
    return True


def _match(node, comps):
    if not comps or not _match_compound(node, comps[-1][1]):
        return False
    cur, i = node, len(comps) - 1
    while i > 0:
        comb = comps[i][0]
        i -= 1
        if comb == ">":
            cur = cur.parent
            if cur is None or not _match_compound(cur, comps[i][1]):
                return False
        elif comb == " ":
            cur = cur.parent
            while cur is not None and not _match_compound(cur, comps[i][1]):
                cur = cur.parent
            if cur is None:
                return False
        else:
            return False  # sibling combinators are not worked out
    return True


# ── colours and values ──────────────────────────────────────────────────────────────
def parse_color(v):
    v = str(v or "").strip().lower()
    v = NAMED.get(v, v)
    m = re.fullmatch(r"#([0-9a-f]{3,8})", v)
    if m:
        h = m.group(1)
        if len(h) in (3, 4):
            h = "".join(c * 2 for c in h)
        if len(h) in (6, 8):
            return (int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16), (int(h[6:8], 16) / 255) if len(h) == 8 else 1.0)
    m = re.fullmatch(r"rgba?\(\s*([\d.]+)[ ,]+([\d.]+)[ ,]+([\d.]+)(?:\s*[,/]\s*([\d.]+%?))?\s*\)", v)
    if m:
        a = m.group(4)
        alpha = float(a[:-1]) / 100 if a and a.endswith("%") else float(a) if a else 1.0
        return (float(m.group(1)), float(m.group(2)), float(m.group(3)), alpha)
    return None


def fmt_color(c):
    a = c[3]
    r, g, b = (max(0, min(255, round(x))) for x in c[:3])
    return f"#{r:02x}{g:02x}{b:02x}" if a >= 0.999 else f"rgba({r},{g},{b},{round(a, 2)})"


def _mix(args):
    """color-mix(in srgb, A p%, B q%) as one colour."""
    parts = [p.strip() for p in _split(args, ",")]
    if len(parts) < 3 or not parts[0].lower().startswith("in "):
        return None
    items = []
    for p in parts[1:3]:
        m = re.match(r"^(.*?)(?:\s+([\d.]+)%)?$", p)
        col = parse_color(m.group(1).strip())
        if col is None:
            return None
        items.append((col, float(m.group(2)) if m.group(2) else None))
    (c1, p1), (c2, p2) = items
    if p1 is None and p2 is None:
        p1 = p2 = 50.0
    elif p1 is None:
        p1 = 100.0 - p2
    elif p2 is None:
        p2 = 100.0 - p1
    total = p1 + p2
    w1, w2 = p1 / total, p2 / total
    a = c1[3] * w1 + c2[3] * w2
    if a <= 0:
        return (0, 0, 0, 0)
    ch = [(c1[i] * c1[3] * w1 + c2[i] * c2[3] * w2) / a for i in range(3)]
    return (ch[0], ch[1], ch[2], a * (total / 100 if total < 100 else 1))


def _fn(value, name, fn):
    """Replace every name(...) in a value (innermost first) by fn(args); what cannot be worked out is left as it is."""
    out, start = value, len(value)
    for _ in range(20):
        i = out.lower().rfind(name + "(", 0, start)
        if i < 0:
            break
        j, depth = i + len(name) + 1, 1
        while j < len(out) and depth:
            depth += (out[j] == "(") - (out[j] == ")")
            j += 1
        res = fn(out[i + len(name) + 1:j - 1])
        if res is None:
            start = i
            continue
        out = out[:i] + res + out[j:]
        start = len(out)
    return out


def resolve(value, props):
    """var(--x, fallback) filled in, color-mix() worked out."""
    v = str(value or "")
    for _ in range(10):
        m = re.search(r"var\(\s*(--[\w-]+)\s*(?:,\s*((?:[^()]|\([^()]*\))*))?\)", v)
        if not m:
            break
        got = props.get(m.group(1))
        v = v[:m.start()] + (got if got is not None else (m.group(2) or "")) + v[m.end():]
    v = _fn(v, "color-mix", lambda a: (lambda c: fmt_color(c) if c else None)(_mix(a)))
    return v.strip()


# ── the computed style of an element ────────────────────────────────────────────────
def _chain(node):
    out = []
    while node is not None:
        out.append(node)
        node = node.parent
    return out[::-1]


def _declared(node, compiled):
    """{property: raw value} of the rules that match this element, in cascade order; a shorthand resets the longhands that came before it."""
    hit = sorted(((r[2], r[1], r[3]) for c, r in compiled if c and _match(node, c)), key=lambda x: (x[1], x[0]))
    mine = {}
    for _order, _spec, body in hit:
        for k, v in body.items():
            for sub in RESETS.get(k, ()):
                mine.pop(sub, None)
            mine.pop(k, None)  # (the order of the keys is the order in which they were set)
            mine[k] = v
    return mine


def style_of(node, rules, compiled=None):
    """{property: resolved value} of one element, with the custom properties and the text properties of its parents."""
    compiled = compiled if compiled is not None else [(_compounds(r[0]), r) for r in rules]
    root_rules = [r for r in rules if r[0].strip() in (":root", "html")]
    props = {}
    for r in sorted(root_rules, key=lambda r: r[2]):
        for k, v in r[3].items():
            if k.startswith("--"):
                props[k] = resolve(v, props)
    inherited = {}
    for n in _chain(node):
        if n.tag in ("#root", "html"):
            continue
        mine = _declared(n, compiled)
        for k, v in mine.items():
            if k.startswith("--"):
                props[k] = resolve(v, props)
        if n is node:
            style = {k: resolve(v, props) for k, v in mine.items() if not k.startswith("--")}
            for k, v in inherited.items():
                if style.get(k, "inherit") == "inherit":  # (not set, or set to inherit)
                    style[k] = v
            return style
        for k in INHERITED:
            if k in mine:
                inherited[k] = resolve(mine[k], props)
    return {}


def background(style):
    """{bg, image, overlay, overlay_opacity} from the background declarations in the order they were set: the picture (a layer with url()), the gradient over it, the colour."""
    out = {}

    def layers(raw):
        res = {}
        for layer in _split(raw, ","):
            m = re.search(r"url\(\s*[\"']?([^)\"']+?)[\"']?\s*\)", layer)
            if m and not m.group(1).startswith("data:"):
                res["image"] = m.group(1).strip()
            elif "gradient(" in layer:
                cols = [parse_color(c) for c in re.findall(COLOR_RE, layer)]
                cols = [c for c in cols if c]
                if cols:
                    res["overlay"] = fmt_color((cols[0][0], cols[0][1], cols[0][2], 1.0))
                    res["overlay_opacity"] = round(sum(c[3] for c in cols) / len(cols), 2)
        return res

    for k, v in style.items():
        if k == "background":
            out = layers(v)
            col = re.search(COLOR_RE, re.sub(r"(url|[a-z-]*gradient)\((?:[^()]|\([^()]*\))*\)", "", v))
            c = parse_color(col.group(0)) if col else parse_color(v.strip())
            if c and c[3] > 0:
                out["bg"] = fmt_color(c)
        elif k == "background-image":
            for x in ("image", "overlay", "overlay_opacity"):
                out.pop(x, None)
            out.update(layers(v))
        elif k == "background-color":
            c = parse_color(v)
            out.pop("bg", None)
            if c and c[3] > 0:
                out["bg"] = fmt_color(c)
    return out


def facts_of(node, rules, compiled=None):
    st = style_of(node, rules, compiled)
    f = {k: st[k] for k in SHOW if st.get(k)}
    f.update(background(st))
    if st.get("color") and parse_color(st["color"]):
        f["color"] = fmt_color(parse_color(st["color"]))
    for side in ("top", "bottom"):  # the padding above and below in px (also out of the shorthand)
        v = st.get(f"padding-{side}")
        if v is None and st.get("padding"):
            parts = st["padding"].split()
            idx = {1: (0, 0), 2: (0, 0), 3: (0, 2), 4: (0, 2)}.get(len(parts))
            if idx:
                v = parts[idx[0] if side == "top" else idx[1]]
        if v is not None and _px(v) is not None:
            f[f"pad_{side}_px"] = round(_px(v))
    return f


def section_facts(section, rules, limit=24):
    """The facts of a section and of the kinds of elements in it (a tag with its classes): what a card, a heading, a button, a column really looks like."""
    compiled = [(_compounds(r[0]), r) for r in rules]
    out = {"section": facts_of(section, rules, compiled), "elements": {}}
    for n in section.walk():
        if n is section or n.tag in ("br", "hr", "svg", "path", "script", "style", "img", "source", "picture"):
            continue
        classes = sorted((n.attrs.get("class") or "").split())
        if not classes and n.tag not in ("h1", "h2", "h3", "p", "a", "li", "ul", "button"):
            continue
        key = n.tag + "".join("." + c for c in classes)
        if key in out["elements"] or len(out["elements"]) >= limit:
            continue
        f = facts_of(n, rules, compiled)
        if f:
            out["elements"][key] = f
    return out
