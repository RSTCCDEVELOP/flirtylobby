# Copyright & Ownership Notice
# easy2Edit is the exclusive legal property of RST Coaching & Consultancy B.V. (RSTCC),
# owned by Ronald Stolk. All rights reserved. Any unauthorized use, copying, modification,
# reproduction, distribution, or commercial exploitation of Easy2Edit, including its source code,
# is strictly prohibited without prior written permission from Ronald Stolk or RSTCC.
# website https://rstcc.net

"""A section that follows the Easy2edit design vocabulary (a band with a container, headings, texts, lists, buttons, pictures, grids of cards) as rows of the page builder,
worked out from the REAL css values (cssfacts.py): colours, sizes, margins, paddings, columns and the look of the cards. No AI is needed for such a section, the result is exact and
fast. Returns None when something in the section is not part of the vocabulary (a table, a form, an accordion, an own svg ...): the AI builds that section."""
import html as htmllib
import re

from . import cssfacts as CF

NOPAD = {"t": 0, "r": 0, "b": 0, "l": 0}  # (an item of the page builder has 10 px space inside by default: a design copies its own css instead)
INLINE_OK = {"p": "p", "ul": "ul", "ol": "ol", "li": "li", "strong": "strong", "b": "strong", "em": "em", "i": "em", "br": "br"}
WRAP = ("div", "section", "article", "header", "figure", "span", "main", "aside")
UNSUPPORTED = ("table", "form", "svg", "iframe", "video", "audio", "canvas", "input", "select", "textarea", "details", "picture", "object", "embed", "dl")


def rem(v):
    m = re.fullmatch(r"\s*(-?[\d.]+)\s*(rem|em|px)?\s*", str(v or ""))
    if not m:
        return None
    x = float(m.group(1))
    return x / 16 if m.group(2) == "px" else x


def px(v):
    r = rem(v)
    return None if r is None else r * 16


def margins(f):
    """(top, bottom) in rem from margin-top/-bottom or the margin shorthand."""
    top, bot = rem(f.get("margin-top")), rem(f.get("margin-bottom"))
    if f.get("margin") and (top is None or bot is None):
        parts = str(f["margin"]).split()
        idx = {1: (0, 0), 2: (0, 0), 3: (0, 2), 4: (0, 2)}.get(len(parts))
        if idx:
            top = rem(parts[idx[0]]) if top is None else top
            bot = rem(parts[idx[1]]) if bot is None else bot
    return (max(0.0, top or 0.0), max(0.0, bot or 0.0))


def hexc(v, over=None):
    """A colour as #rrggbb; a transparent colour is mixed over `over` (#rrggbb) so it can be used as a plain colour."""
    c = CF.parse_color(v)
    if not c:
        return ""
    if c[3] < 0.999:
        o = CF.parse_color(over or "#ffffff") or (255, 255, 255, 1)
        c = tuple(c[i] * c[3] + o[i] * (1 - c[3]) for i in range(3)) + (1.0,)
    return CF.fmt_color(c)


def kids(n):
    return [k for k in n.kids if not isinstance(k, str)]


def text_of(n):
    return " ".join(n.text().split())


def inline_html(n):
    out = []
    for k in n.kids:
        if isinstance(k, str):
            out.append(htmllib.escape(k))
            continue
        t = INLINE_OK.get(k.tag)
        if k.tag == "a":
            out.append(f'<a href="{htmllib.escape(k.attrs.get("href", "#"), quote=True)}">{inline_html(k)}</a>')
        elif k.tag == "br":
            out.append("<br>")
        elif t:
            out.append(f"<{t}>{inline_html(k)}</{t}>")
        elif k.tag in ("script", "style"):
            continue
        else:
            out.append(inline_html(k))  # a span or anything else: its text stays, its look is not copied
    return "".join(out)


class Convert:
    def __init__(self, section, rules, imgs):
        self.section, self.rules, self.imgs = section, rules, imgs
        self.compiled = [(CF._compounds(r[0]), r) for r in rules]
        self.sec = self.f(section)
        self.bg = self.sec.get("bg") or "#ffffff"
        self.ok = True

    def f(self, n):
        return CF.facts_of(n, self.rules, self.compiled)

    def media(self, url):
        return self.imgs.get(str(url or "").replace("__MEDIA__/", ""))

    def is_box(self, f):
        return bool(f.get("border") and "none" not in f["border"] and "0" != f["border"].split()[0][:1]) or bool(f.get("box-shadow") and f["box-shadow"] != "none") or (f.get("bg") and f.get("bg") != self.bg and bool(f.get("border-radius") or f.get("padding")))

    def grid_cols(self, f):
        g = f.get("grid-template-columns")
        if f.get("display") != "grid" or not g:
            return 0
        m = re.search(r"repeat\(\s*(\d+)", g)
        return int(m.group(1)) if m else len(re.findall(r"(?:\d[\w.%]*|minmax\([^)]*\)|auto)\s*", g))

    # ── one element as items ──
    def items(self, n, last_margin=None):
        """[item dicts in the answer format of the AI] for an element, or None when it is not part of the vocabulary."""
        f = self.f(n)
        t = n.tag
        mt, mb = margins(f)
        base = {}
        if mt:
            base["mt"] = round(mt, 2)
        base["mb"] = round(mb, 2)
        color = hexc(f.get("color"), self.bg)
        align = f.get("text-align") if f.get("text-align") in ("left", "center", "right") else None
        if n.attrs.get("data-sysobject"):
            return [{"type": "sysobject", "slug": n.attrs["data-sysobject"]}]
        if t in UNSUPPORTED:
            return None
        if t in ("h1", "h2", "h3", "h4", "h5", "h6"):
            size = rem(f.get("font-size")) or {"h1": 2.4, "h2": 1.8, "h3": 1.25}.get(t, 1.1)
            wt = rem(f.get("font-weight"))
            w = "800" if wt and wt >= 750 else "700" if wt and wt >= 650 else "600" if wt and wt >= 550 else "500" if wt and wt >= 450 else "400"
            title = text_of(n).upper() if f.get("text-transform") == "uppercase" else text_of(n)
            return [{"type": "heading", "html": title, "size": round(min(max(size, 0.8), 6), 2), "weight": w, "color": color, "align": align or "left", "pad": dict(NOPAD), **base}] if text_of(n) else []
        if t == "hr":
            return [{"type": "line"}]
        if t == "img":
            m = self.media(n.attrs.get("src"))
            if m is None:
                return None
            return [{"type": "image", "img": m, "align": align or "left", "radius": round(px(f.get("border-radius")) or 0), "w": "100%", **base}]
        if t == "a" and ("btn" in (n.attrs.get("class") or "") or f.get("display") in ("inline-block", "inline-flex", "inline")) and "btn" in (n.attrs.get("class") or ""):
            bgc = hexc(f.get("bg"), self.bg)
            bm = re.search(r"(#[0-9a-fA-F]{3,8}\b|rgba?\([^)]*\))", f.get("border-color") or f.get("border") or "")
            return [{"type": "button", "label": text_of(n)[:60], "href": n.attrs.get("href", "#"), "style": "primary" if bgc else "outline", "radius": round(px(f.get("border-radius")) or 0),
                     "bg": bgc or "transparent", "color": color, "border": hexc(bm.group(1), self.bg) if bm else "", **base}] if text_of(n) else []
        if t in ("p", "ul", "ol", "blockquote", "li", "a", "span", "small", "strong", "em", "label"):
            if not text_of(n):
                return []
            if t == "span" and kids(n) and any(k.tag in WRAP or k.tag in ("p", "ul", "ol") for k in kids(n)):
                return self.flatten(n)
            html = inline_html(n)
            body = html if t in ("ul", "ol") else f"<p>{html}</p>" if t != "p" else html if html.startswith("<p>") else f"<p>{html}</p>"
            if f.get("text-transform") == "uppercase":  # (only the text between the tags; letters and entities stay valid)
                html = re.sub(r">([^<]+)<", lambda m: ">" + htmllib.escape(htmllib.unescape(m.group(1)).upper(), quote=False) + "<", f">{html}<")[1:-1]
                body = f"<p>{html}</p>"
            it = {"type": "text", "html": f"<{t}>{html}</{t}>" if t in ("ul", "ol") else body if t != "p" else f"<p>{html}</p>", "size": round(min(max(rem(f.get("font-size")) or 1.0, 0.7), 4), 2), "color": color, "align": align or "left", "pad": dict(NOPAD), **base}
            bgc = hexc(f.get("bg"), self.bg)
            if bgc and bgc != self.bg:  # a label in a pill: its own background and rounded corners
                it["bg"] = bgc
            if (bgc and bgc != self.bg) or f.get("border"):
                it["radius"] = round(px(f.get("border-radius")) or 0)
                pt, pb = f.get("pad_top_px"), f.get("pad_bottom_px")
                pl = px((f.get("padding-left") or (f.get("padding") or "").split()[1] if len((f.get("padding") or "").split()) > 1 else None)) if (f.get("padding-left") or f.get("padding")) else None
                it["pad"] = {"t": int(pt or 0), "b": int(pb or 0), "l": int(pl or 0), "r": int(pl or 0)}
            return [it]
        if t in WRAP or t == "ul":
            return self.flatten(n)
        return None

    def flatten(self, n):
        """A plain wrapper (no box of its own): the items of its children; its bottom margin goes to the last item."""
        f = self.f(n)
        if self.is_box(f) or self.grid_cols(f) >= 2:
            return None
        out = []
        for k in kids(n):
            got = self.items(k)
            if got is None:
                return None
            out += got
        if not out and not text_of(n):
            return []
        _mt, mb = margins(f)
        if out and mb:
            out[-1]["mb"] = round(max(out[-1].get("mb", 0), mb), 2)
        # loose text in the wrapper (not inside an element): one text
        if not out and text_of(n):
            return [{"type": "text", "html": f"<p>{inline_html(n)}</p>", "size": round(rem(f.get("font-size")) or 1.0, 2), "color": hexc(f.get("color"), self.bg), "align": "left", "mb": round(mb, 2)}]
        return out

    # ── rows ──
    def card(self, f):
        c = {"radius": round(px(f.get("border-radius")) or 0), "pad": round(f.get("pad_top_px") or 0)}
        if hexc(f.get("bg"), self.bg):
            c["bg"] = hexc(f.get("bg"), self.bg)
        bm = re.search(r"(#[0-9a-fA-F]{3,8}\b|rgba?\([^)]*\))", f.get("border-color") or f.get("border") or "")
        if bm and f.get("border") and not str(f["border"]).startswith(("0", "none")):
            c["border"] = hexc(bm.group(1), c.get("bg") or self.bg)
        if f.get("box-shadow") and f["box-shadow"] != "none":
            c["shadow"] = True
        return c

    def cell_items(self, child):
        f = self.f(child)
        if self.is_box(f):
            its = []
            for k in kids(child):
                got = self.items(k)
                if got is None:
                    return None
                its += got
            if not its and text_of(child):
                its = [{"type": "text", "html": f"<p>{inline_html(child)}</p>", "size": 1.0, "color": hexc(f.get("color"), self.bg), "align": "left", "mb": 0}]
            return {"card": self.card(f), "items": its, "align": f.get("text-align")}
        got = self.items(child)
        return None if got is None else {"card": None, "items": got, "align": f.get("text-align")}

    def rows(self):
        parent = self.section
        for k in kids(self.section):  # the container of the band
            if k.tag == "div" and "container" in (k.attrs.get("class") or "") and len(kids(self.section)) == 1:
                parent = k
        rows, intro = [], []

        def flush():
            nonlocal intro
            if intro:
                rows.append({"cells": [{"width": "auto", "halign": "left", "valign": "top", "gap": 0, "card": None, "items": intro}], "gap": "md"})
                intro = []

        for k in kids(parent):
            f = self.f(k)
            n = self.grid_cols(f)
            if n >= 2:
                flush()
                n = min(n, 4)
                gap = px((f.get("gap") or "").split()[0]) if f.get("gap") else 24
                gmap = "sm" if (gap or 0) <= 16 else "md" if (gap or 0) <= 32 else "lg"
                children = kids(k)
                mt, _mb = margins(f)
                for i in range(0, len(children), n):
                    cells = []
                    for ch in children[i:i + n]:
                        c = self.cell_items(ch)
                        if c is None:
                            return None
                        if c["items"]:
                            cells.append({"width": "auto", "halign": c["align"] if c["align"] in ("left", "center", "right") else "left", "valign": "center" if f.get("align-items") == "center" else "top", "gap": 0, "card": c["card"], "items": c["items"]})
                    if cells:
                        rows.append({"cells": cells, "gap": gmap, "_mt": mt if i == 0 else 0})
                continue
            if self.is_box(f):  # a box of its own (a call to action, a callout): one row with a card
                flush()
                c = self.cell_items(k)
                if c is None:
                    return None
                rows.append({"cells": [{"width": "auto", "halign": "left", "valign": "top", "gap": 0, "card": c["card"], "items": c["items"]}], "gap": "md"})
                continue
            got = self.items(k)
            if got is None:
                return None
            intro += got
        flush()
        if not rows:
            return None
        sec = self.sec
        for i, r in enumerate(rows):
            last = i == len(rows) - 1
            for c in r["cells"]:
                if c["items"]:
                    c["items"][-1]["mb"] = 0 if last else c["items"][-1].get("mb", 0)
            r["pad_top"] = sec.get("pad_top_px", 0) if i == 0 else round((r.pop("_mt", 0) or 0) * 16)
            r["pad_bottom"] = sec.get("pad_bottom_px", 0) if last else 0
            r.pop("_mt", None)
            r.update({"title": str(self.section.attrs.get("id") or "Sectie")[:60], "anchor": "", "full": True, "bg": sec.get("bg", ""), "bg_image": None, "overlay": 0, "color": sec.get("color", ""), "radius": 0, "min_height": 0})
        if sec.get("image") and self.media(sec["image"]) is not None:
            rows[0]["bg_image"] = self.media(sec["image"])
            rows[0]["overlay"] = round(min(max(float(sec.get("overlay_opacity") or 0.4), 0), 0.9), 2)
            if sec.get("overlay"):
                rows[0]["bg"] = sec["overlay"]
        return rows


def rows_for(section, rules, imgs):
    """The rows of one section from the css, or None when the section is not part of the vocabulary."""
    try:
        return Convert(section, rules, imgs).rows()
    except Exception:  # noqa: BLE001 - never stop the import for this: the AI builds the section
        return None
