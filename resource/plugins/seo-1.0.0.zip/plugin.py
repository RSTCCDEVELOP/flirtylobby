# Copyright & Ownership Notice
# easy2Edit is the exclusive legal property of RST Coaching & Consultancy B.V. (RSTCC),
# owned by Ronald Stolk. All rights reserved. Any unauthorized use, copying, modification,
# reproduction, distribution, or commercial exploitation of Easy2Edit, including its source code,
# is strictly prohibited without prior written permission from Ronald Stolk or RSTCC.
# website https://rstcc.net


"""SEO (plugin). Zoekmachines, bots en AI-agents: robots.txt, sitemap, llms.txt, paginatitels, omschrijvingen en structured data.

Dit was een vast onderdeel van het systeem (apps/seo); nu een plugin. De code staat in seo_lib/, de routes zijn nog steeds /api/seo/... (System.mount) en de tabellen van het systeem uit de
tijd dat dit nog het systeem was (seo_*) worden bij het starten hernoemd naar plg_seo_*; er gaat geen gegeven verloren.
Staat de plugin uit, dan krijgt de website de gewone titels van de websitenaam, een standaard robots.txt en geen sitemap, llms.txt of structured data."""
import importlib
import inspect
import sys

PKG = "seo_lib"


def register(system):
    from django.db import connection, models

    for k in [k for k in sys.modules if k == PKG or k.startswith(PKG + ".")]:  # what an earlier load left behind (the models are made again)
        del sys.modules[k]

    models_mod = importlib.import_module(f"{PKG}.models")
    classes = [c for _n, c in inspect.getmembers(models_mod, inspect.isclass) if issubclass(c, models.Model) and c.__module__ == models_mod.__name__]

    # the tables of the system from before (seo_<model>) are renamed once: the data goes with them
    existing = set(connection.introspection.table_names())
    with connection.cursor() as cur:
        for m in classes:
            old, new = "seo_" + m.__name__.lower(), m._meta.db_table
            if old in existing and new not in existing:
                cur.execute(f'ALTER TABLE "{old}" RENAME TO "{new}"')
                existing.discard(old)
                existing.add(new)
    system.sync_models(*classes)

    parts = {name: importlib.import_module(f"{PKG}.{name}") for name in ("defaults", "service", "output", "views")}
    importlib.import_module(f"{PKG}.backup")  # (registers the SEO settings in the settings backup)
    urls = importlib.import_module(f"{PKG}.urls")
    system.mount(urls.urlpatterns)

    class Seo:
        models = models_mod
        defaults, service, output = parts["defaults"], parts["service"], parts["output"]

    system.provide("seo", Seo)
