// Copyright & Ownership Notice
// easy2Edit is the exclusive legal property of RST Coaching & Consultancy B.V. (RSTCC),
// owned by Ronald Stolk. All rights reserved. Any unauthorized use, copying, modification,
// reproduction, distribution, or commercial exploitation of Easy2Edit, including its source code,
// is strictly prohibited without prior written permission from Ronald Stolk or RSTCC.
// website https://rstcc.net

"use strict";
/* Coach video: the screens of the coach: overview of the analyses, the new-analysis dialog, the library of instruction videos, the athletes and the AI credit.
   Texts that are only used through a variable (for the translation tool):
   t("Concept") t("Gedeeld") t("Bekeken") t("Afgerond") t("Gearchiveerd") t("Wacht op AI") t("Verwerken…") t("Wachten") t("Uploaden…") t("Klaar") t("Video") t("Afbeelding")
   t("Alle statussen") t("opmerking") t("opmerkingen") t("instructievideo") t("instructievideo's") t("analyse") t("analyses") t("Alleen ik") t("Alle coaches van deze site") */
(function () {
  var t = CV.t, h = CV.h, icon = CV.icon;
  var STATUSES = ["concept", "gedeeld", "bekeken", "afgerond", "gearchiveerd"];
  var VIDEO_EXT = /\.(mp4|mov|m4v|webm)$/i, IMAGE_EXT = /\.(jpe?g|png|webp|heic|heif)$/i;

  /* ---------- shared helpers ---------- */
  function debounce(fn, ms) { var id; return function () { var a = arguments, self = this; clearTimeout(id); id = setTimeout(function () { fn.apply(self, a); }, ms); }; }
  function resize() { try { system.resize && system.resize(document.documentElement.scrollHeight); } catch (e) {} }
  function loading() { return h("div", { class: "cv-loading", role: "status" }, h("span", { class: "cv-spin", "aria-hidden": "true" }), t("Laden…")); }
  function errorBox(e, retry) { return h("div", { class: "alert", role: "alert" }, h("span", {}, (e && e.message) || String(e)), retry ? h("button", { type: "button", class: "btn", onclick: retry }, t("Opnieuw proberen")) : null); }
  function empty(ic, title, text, action) { return h("div", { class: "empty cv-empty" }, h("div", { class: "cv-empty__icon" }, icon(ic, 28)), h("h3", {}, title), text ? h("p", { class: "muted" }, text) : null, action || null); }
  function field(label, control, hint, id) {
    var lab = h("label", { class: "cv-field" }, h("span", { class: "cv-field__label" }, label), control, hint ? h("small", { class: "muted" }, hint) : null);
    return lab;
  }
  function pageHead(eyebrow, title, sub, actions) {
    return h("div", { class: "cv-head" }, h("div", { class: "cv-head__text" }, h("div", { class: "cv-eyebrow" }, eyebrow), h("h1", {}, title), sub ? h("p", { class: "muted cv-head__sub" }, sub) : null), actions ? h("div", { class: "row cv-head__actions" }, actions) : null);
  }
  function plural(n, one, many) { return n + " " + (n === 1 ? t(one) : t(many)); }
  function mssToSec(v) {
    v = String(v == null ? "" : v).trim(); if (!v) return "";
    if (/^\d+$/.test(v)) return parseInt(v, 10);
    var m = v.match(/^(?:(\d+):)?(\d{1,2}):(\d{1,2})$/); if (!m) return NaN;
    return (parseInt(m[1] || 0, 10) * 3600) + parseInt(m[2], 10) * 60 + parseInt(m[3], 10);
  }
  function secToMss(s) { if (s == null || s === "" || !Number(s)) return ""; s = Number(s); var hr = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), r = s % 60; return (hr ? hr + ":" + (m < 10 ? "0" : "") : "") + m + ":" + (r < 10 ? "0" : "") + r; }
  function home() { return CV.S.home || {}; }

  /* ---------- the navigation of the coach (CV.coachNav(active)) ---------- */
  function coachNav(active) {
    var items = [["analyses", t("Analyses"), "video"], ["sporters", t("Sporters"), "users"], ["bibliotheek", t("Instructievideo's"), "youtube"], ["tegoed", t("AI-tegoed"), "sparkle"]], waiting = Number(home().verzoeken) || 0;
    return h("nav", { class: "cv-nav", "aria-label": t("Coach video") }, items.map(function (it) {
      var b = it[0] === "sporters" && waiting > 0 ? h("span", { class: "badge info cv-nav__badge", "aria-label": t("{0} verzoeken om te beantwoorden", waiting) }, String(waiting)) : null;
      return h("button", { type: "button", class: "cv-nav__item" + (it[0] === active ? " on" : ""), "data-nav": it[0], "aria-current": it[0] === active ? "page" : null, onclick: function () { if (it[0] !== active) CV.go(it[0], {}, true); } }, icon(it[2], 16), h("span", {}, it[1]), b);
    }));
  }
  /* after an answer the number of waiting requests changes: reload the home data and redraw the badge in the navigation */
  function refreshNav() {
    return CV.refreshHome().then(function () {
      var btn = document.querySelector(".cv-nav__item[data-nav=sporters]"); if (!btn) return;
      var old = btn.querySelector(".cv-nav__badge"); if (old) old.remove();
      var n = Number(home().verzoeken) || 0; if (n > 0) btn.appendChild(h("span", { class: "badge info cv-nav__badge", "aria-label": t("{0} verzoeken om te beantwoorden", n) }, String(n)));
    }).catch(function () {});
  }
  /* the slim notice at the top of the first view when somebody waits for an answer (CV.S.notice is set by CV.start) */
  function noticeBar(root) {
    var n = Number(home().verzoeken) || 0; if (!CV.S.notice || n < 1) return;
    CV.S.notice = false;
    var bar = h("div", { class: "cv-notice", role: "status" }, icon("bell", 16), h("span", { class: "grow" }, n === 1 ? t("Je hebt 1 verzoek om te beantwoorden.") : t("Je hebt {0} verzoeken om te beantwoorden.", n)),
      h("button", { type: "button", class: "btn", onclick: function () { if (home().me && home().me.coach) CV.go("sporters", { tab: "verzoeken" }); else CV.go("mijn", { tab: "coaches" }); } }, t("Bekijken")));
    root.appendChild(bar);
  }
  /* one request as a card: r = item of verzoeken_in / verzoeken_uit; opts {inText, reload(koppelingen)} ; in = Accepteren / Weigeren, out = Opnieuw versturen (only an invitation of the coach) / Intrekken */
  function requestRow(r, opts) {
    var done = opts.done;
    function run(path, method, body, msg) { return CV.call(path, method, body).then(function (k) { if (msg) CV.toast(msg); refreshNav(); done(k); }).catch(CV.fail); }
    var name = r.naam || r.email, sub, actions;
    if (r.inkomend) {
      sub = opts.inText ? opts.inText(r) : "";
      actions = [h("button", { type: "button", class: "btn primary", "aria-label": t("Accepteren") + ": " + name, onclick: function () { run("verzoeken/" + r.id + "/antwoord", "POST", { akkoord: true }, t("Gekoppeld.")); } }, icon("check", 14), t("Accepteren")),
        h("button", { type: "button", class: "btn", "aria-label": t("Weigeren") + ": " + name, onclick: function () { run("verzoeken/" + r.id + "/antwoord", "POST", { akkoord: false }, t("Verzoek geweigerd.")); } }, icon("x", 14), t("Weigeren"))];
    } else {
      sub = opts.outText || "";
      actions = [r.richting === "uitnodiging" ? h("button", { type: "button", class: "btn", "aria-label": t("Opnieuw versturen") + ": " + name, onclick: function () { run("verzoeken/" + r.id + "/opnieuw", "POST", {}, t("Opnieuw verstuurd.")); } }, icon("send", 14), t("Opnieuw versturen")) : null,
        h("button", { type: "button", class: "btn", "aria-label": t("Intrekken") + ": " + name, onclick: function () { run("verzoeken/" + r.id, "DELETE", null, t("Verzoek ingetrokken.")); } }, icon("x", 14), t("Intrekken"))];
    }
    var badges = !r.inkomend && r.richting === "uitnodiging" ? h("span", { class: "badge" + (r.nieuw_account ? " info" : "") }, r.nieuw_account ? t("Nieuw account") : t("Bestaand account")) : null;
    return h("div", { class: "cv-rowcard cv-req", role: "listitem" }, CV.avatar(r.persoon || { name: name, initials: String(name || "?").slice(0, 2).toUpperCase() }, "e2e-avatar--lg"),
      h("div", { class: "grow cv-rowcard__text" }, h("strong", {}, name), !r.inkomend && r.email && r.email !== name ? h("small", { class: "muted" }, r.email) : null, sub ? h("small", { class: "muted" }, sub) : null,
        h("div", { class: "row cv-chips" }, badges, r.aangemaakt_op ? h("small", { class: "muted" }, CV.when(r.aangemaakt_op)) : null)),
      h("div", { class: "row cv-req__actions" }, actions));
  }

  /* ---------- inviting a person by e-mail (coach) ---------- */
  function inviteDialog(onDone) {
    var email = h("input", { type: "email", autocomplete: "off", maxlength: 254, "aria-required": "true", placeholder: "naam@voorbeeld.nl" });
    var first = h("input", { type: "text", maxlength: 150, autocomplete: "off" }), last = h("input", { type: "text", maxlength: 150, autocomplete: "off" });
    var err = h("div", { class: "alert", role: "alert", hidden: true }), names = h("div", { class: "cv-two cv-names" }, field(t("Voornaam"), first), field(t("Achternaam"), last)), dlg, busy = false;
    function showErr(m) { err.hidden = !m; err.textContent = m || ""; }
    var send = h("button", { type: "button", class: "btn primary", onclick: function () {
      if (busy) return; showErr(""); names.classList.remove("cv-names--need");
      var mail = email.value.trim();
      if (!mail) { showErr(t("Vul een e-mailadres in.")); email.focus(); return; }
      busy = true; send.disabled = true;
      CV.call("sporters/uitnodigen", "POST", { email: mail, first_name: first.value.trim(), last_name: last.value.trim() }).then(function (k) {
        var out = (k && k.verzoeken_uit) || [], mine = out.filter(function (r) { return String(r.email || "").toLowerCase() === mail.toLowerCase(); })[0] || out[0];
        CV.toast(mine && mine.nieuw_account ? t("Uitnodiging verstuurd.") : t("Verzoek verstuurd. De sporter moet eerst akkoord geven."));
        CV.refreshHome(); dlg.close(); if (onDone) onDone(k);
      }).catch(function (e) {
        busy = false; send.disabled = false; showErr((e && e.message) || String(e));
        if (!first.value.trim() || !last.value.trim()) { names.classList.add("cv-names--need"); (first.value.trim() ? last : first).focus(); }
      });
    } }, icon("send", 14), t("Uitnodiging versturen"));
    dlg = CV.dialog({ eyebrow: t("COACH VIDEO"), title: t("Sporter uitnodigen"), buttons: [h("button", { type: "button", class: "btn", onclick: function () { dlg.close(); } }, t("Annuleren")), send], tabs: [{ key: "g", label: t("Uitnodigen"), render: function (b) {
      b.appendChild(err);
      b.appendChild(field(t("E-mailadres"), email));
      b.appendChild(names); b.appendChild(h("small", { class: "muted" }, t("De naam is alleen nodig als dit e-mailadres nog geen account heeft.")));
      b.appendChild(h("div", { class: "cv-explain" }, icon("lock", 16), h("div", {},
        h("p", {}, h("strong", {}, t("Nog geen account:")), " ", t("de persoon krijgt een uitnodiging per e-mail, maakt een account aan (wachtwoord, voorwaarden en e-mailcode) en komt direct in Coach video, gekoppeld aan jou.")),
        h("p", {}, h("strong", {}, t("Al een account:")), " ", t("de persoon krijgt een verzoek en moet eerst akkoord geven. Zonder akkoord is koppelen niet mogelijk.")),
        h("p", { class: "muted" }, t("Je kunt alleen iemand toevoegen met het e-mailadres. Andere coaches zien jouw sporters nooit.")))));
    } }] });
    return dlg;
  }

  /* =====================================================================
     1. the overview of the analyses
     ===================================================================== */
  function kpiCard(label, value, extra, dark) {
    return h("div", { class: "cv-kpi" + (dark ? " dark" : "") }, h("div", { class: "cv-kpi__label" }, label), h("div", { class: "cv-kpi__value" }, value), extra || null);
  }
  function statusBadge(a) {
    if (a.verwerking === "fout") return h("span", { class: "badge cv-badge-bad" }, t("Fout bij verwerken"));
    if (a.verwerking === "bezig") return h("span", { class: "badge" }, t("Verwerken…"));
    if (a.ai_bezig) return h("span", { class: "badge info" }, t("Wacht op AI"));
    return CV.badge(a.status);
  }
  function analysisCard(a, reload) {
    var title = h("button", { type: "button", class: "cv-card__open", onclick: function () { CV.go("editor", { id: a.id }); } }, a.titel || t("Zonder titel"));
    var poster = h("div", { class: "cv-poster" }, a.poster ? h("img", { src: a.poster, alt: "", loading: "lazy" }) : h("span", { class: "cv-poster__ph" }, icon(a.soort === "afbeelding" ? "image" : "video", 34)),
      a.soort ? h("span", { class: "badge cv-poster__kind" }, icon(a.soort === "video" ? "video" : "image", 12), a.soort === "video" ? t("Video") : t("Afbeelding")) : null,
      a.soort === "video" && a.duur_ms ? h("span", { class: "cv-poster__dur" }, CV.ms(a.duur_ms)) : null);
    var names = h("div", { class: "cv-card__people" }, (a.sporters || []).slice(0, 3).map(function (p) { return h("span", { class: "cv-who" }, CV.avatar(p, "e2e-avatar--sm"), h("span", {}, p.name)); }),
      (a.sporters || []).length > 3 ? h("small", { class: "muted" }, "+" + (a.sporters.length - 3)) : null, !(a.sporters || []).length ? h("small", { class: "muted" }, t("Nog geen sporter")) : null);
    var menuBtn = h("button", { type: "button", class: "btn ghost icon-only cv-card__menubtn", "aria-label": t("Meer acties voor {0}", a.titel), "aria-haspopup": "menu", "aria-expanded": "false" }, "⋯");
    var menu = h("div", { class: "cv-menu", role: "menu", hidden: true },
      h("button", { type: "button", role: "menuitem", onclick: function () { close(); CV.call("analyses/" + a.id + "/archiveren", "POST").then(function () { CV.toast(a.status === "gearchiveerd" ? t("Teruggezet.") : t("Gearchiveerd.")); reload(); }).catch(CV.fail); } }, icon("archive", 15), a.status === "gearchiveerd" ? t("Terugzetten") : t("Archiveren")),
      h("button", { type: "button", role: "menuitem", class: "danger", onclick: function () {
        close(); CV.confirmBox(t("Weet je zeker dat je deze analyse en alle bestanden wilt verwijderen? Dit kan niet ongedaan worden gemaakt."), { danger: true, confirm: t("Verwijderen") }).then(function (ok) {
          if (ok) CV.call("analyses/" + a.id, "DELETE").then(function () { CV.toast(t("Analyse verwijderd.")); CV.refreshHome(); reload(); }).catch(CV.fail);
        });
      } }, icon("trash", 15), t("Verwijderen")));
    function onDoc(e) { if (!menu.isConnected) { close(); return; } if (!menu.contains(e.target) && e.target !== menuBtn) close(); }
    function onKey(e) { if (!menu.isConnected) { close(); return; } if (e.key === "Escape") { close(); menuBtn.focus(); } }
    function close() { menu.hidden = true; menuBtn.setAttribute("aria-expanded", "false"); document.removeEventListener("click", onDoc); document.removeEventListener("keydown", onKey); }
    menuBtn.addEventListener("click", function () {
      if (!menu.hidden) { close(); return; }
      menu.hidden = false; menuBtn.setAttribute("aria-expanded", "true"); setTimeout(function () { document.addEventListener("click", onDoc); }, 0); document.addEventListener("keydown", onKey);
      var f = menu.querySelector("button"); if (f) f.focus();
    });
    return h("article", { class: "cv-card" }, poster,
      h("div", { class: "cv-card__body" },
        h("div", { class: "cv-card__top" }, h("h3", { class: "cv-card__title" }, title), h("div", { class: "cv-card__menu" }, menuBtn, menu)),
        h("div", {}, statusBadge(a)),
        names,
        h("div", { class: "cv-card__meta muted" }, plural(a.opmerkingen || 0, "opmerking", "opmerkingen") + " · " + plural(a.instructievideos || 0, "instructievideo", "instructievideo's")),
        a.nieuwe_berichten ? h("div", { class: "cv-card__new" }, icon("message", 14), a.nieuwe_berichten === 1 ? t("1 nieuw bericht") : t("{0} nieuwe berichten", a.nieuwe_berichten)) : null));
  }

  CV.views.analyses = function (root) {
    var H = home(), kpi = H.kpi || {}, ai = H.ai || {};
    var f = { q: "", sporter: "", status: "", soort: "", page: 1 };
    var grid = h("div", { class: "cv-results" }), pager = h("div", { class: "cv-pager" }), seq = 0, sporterSel = h("select", { "aria-label": t("Alle sporters") }, h("option", { value: "" }, t("Alle sporters")));
    var statusSel = h("select", { "aria-label": t("Alle statussen") }, h("option", { value: "" }, t("Alle statussen")), STATUSES.map(function (s) { return h("option", { value: s }, t(({ concept: "Concept", gedeeld: "Gedeeld", bekeken: "Bekeken", afgerond: "Afgerond", gearchiveerd: "Gearchiveerd" })[s])); }));
    var search = h("input", { type: "search", placeholder: t("Zoek op titel of sporter"), "aria-label": t("Zoek op titel of sporter") });
    var pills = h("div", { class: "cv-pills", role: "group", "aria-label": t("Soort") }, [["", t("Alles")], ["video", t("Video")], ["afbeelding", t("Afbeelding")]].map(function (p) {
      return h("button", { type: "button", class: "e2e-chip" + (p[0] === "" ? " e2e-chip--active" : ""), "aria-pressed": p[0] === "" ? "true" : "false", "data-v": p[0], onclick: function () {
        f.soort = p[0]; f.page = 1; Array.prototype.forEach.call(pills.children, function (b) { var on = b.getAttribute("data-v") === f.soort; b.classList.toggle("e2e-chip--active", on); b.setAttribute("aria-pressed", on ? "true" : "false"); }); load();
      } }, p[1]);
    }));
    function load() {
      var my = ++seq; CV.clear(grid); CV.clear(pager); grid.appendChild(loading());
      var qs = Object.keys(f).filter(function (k) { return f[k] !== "" && f[k] != null && !(k === "page" && f.page === 1); }).map(function (k) { return k + "=" + encodeURIComponent(f[k]); }).join("&");
      CV.call("analyses" + (qs ? "?" + qs : "")).then(function (r) {
        if (my !== seq) return; CV.clear(grid);
        if (!r.analyses.length) {
          var filtered = f.q || f.sporter || f.status || f.soort;
          grid.appendChild(filtered ? empty("search", t("Geen analyses gevonden"), t("Pas je filters aan om meer te zien.")) : empty("video", t("Nog geen analyses"), t("Maak je eerste analyse: upload een video of foto van een sporter en teken er je lijnen en opmerkingen op."), h("button", { type: "button", class: "btn primary", onclick: newAnalysisDialog }, icon("plus", 16), t("Nieuwe analyse"))));
        } else grid.appendChild(h("div", { class: "cv-grid" }, r.analyses.map(function (a) { return analysisCard(a, load); })));
        if (r.pages > 1) {
          pager.appendChild(h("button", { type: "button", class: "btn", disabled: r.page <= 1, onclick: function () { f.page = r.page - 1; load(); } }, icon("back", 14), t("Vorige")));
          pager.appendChild(h("span", { class: "muted", "aria-live": "polite" }, t("Pagina {0} van {1}", r.page, r.pages)));
          pager.appendChild(h("button", { type: "button", class: "btn", disabled: r.page >= r.pages, onclick: function () { f.page = r.page + 1; load(); } }, t("Volgende"), h("span", { class: "cv-flip" }, icon("back", 14))));
        }
        resize();
      }).catch(function (e) { if (my === seq) { CV.clear(grid); grid.appendChild(errorBox(e, load)); } });
    }
    search.addEventListener("input", debounce(function () { f.q = search.value.trim(); f.page = 1; load(); }, 300));
    sporterSel.addEventListener("change", function () { f.sporter = sporterSel.value; f.page = 1; load(); });
    statusSel.addEventListener("change", function () { f.status = statusSel.value; f.page = 1; load(); });
    CV.call("sporters").then(function (r) { r.sporters.forEach(function (s) { sporterSel.appendChild(h("option", { value: s.id }, s.name)); }); }).catch(function () {});

    noticeBar(root);
    root.appendChild(coachNav("analyses"));
    root.appendChild(pageHead(t("COACH VIDEO"), t("Analyses"), t("Video's en foto's van je sporters, met jouw lijnen, opmerkingen en instructie."), [
      h("button", { type: "button", class: "btn", onclick: function () { CV.go("bibliotheek"); } }, icon("youtube", 16), t("Instructievideo's")),
      h("button", { type: "button", class: "btn primary", onclick: newAnalysisDialog }, icon("plus", 16), t("Nieuwe analyse"))]));
    root.appendChild(h("div", { class: "cv-kpis" },
      kpiCard(t("Open analyses"), String(kpi.open || 0)),
      kpiCard(t("Gedeeld, nog niet bekeken"), String(kpi.niet_bekeken || 0)),
      kpiCard(t("Ongelezen berichten"), String(kpi.ongelezen || 0), kpi.ongelezen > 0 ? h("span", { class: "badge info cv-kpi__badge" }, t("nieuw")) : null),
      kpiCard(t("AI-tegoed"), ai.available === false ? "–" : CV.money(ai.balance, ai.symbol), h("button", { type: "button", class: "cv-kpi__link", onclick: function () { system.aiCredit().then(function () { CV.refreshHome(); }).catch(CV.fail); } }, t("Opwaarderen")), true)));
    root.appendChild(h("div", { class: "cv-filters" }, h("div", { class: "cv-search grow" }, icon("search", 16), search), sporterSel, statusSel, pills));
    root.appendChild(grid); root.appendChild(pager);
    load();
  };

  /* =====================================================================
     2. the new analysis dialog
     ===================================================================== */
  function newAnalysisDialog() {
    var H = home(), lim = H.limits || {}, items = [], sel = {}, created = null, busy = false, dlg;
    var titel = h("input", { type: "text", maxlength: 160, placeholder: t("Bijvoorbeeld Squat – zijaanzicht"), "aria-required": "true" });
    var err = h("div", { class: "alert", role: "alert", hidden: true });
    var delen = "concept", melden = true;
    var fileInput = h("input", { type: "file", multiple: true, accept: "video/*,image/*,.heic,.heif", class: "cv-hidden", tabindex: "-1", "aria-hidden": "true", onchange: function () { addFiles(fileInput.files); fileInput.value = ""; } });
    var listEl = h("div", { class: "cv-uploads", "aria-live": "polite" });
    var athletes = null, athleteBox = h("div", { class: "cv-pick" });

    function showErr(m) { err.hidden = !m; err.textContent = m || ""; }
    function rowFor(it) {
      var bar = h("span", { class: "e2e-upload-row__fill" }), state = h("span", { class: "e2e-upload-row__state" }), meta = h("span", { class: "e2e-upload-row__meta" });
      var rm = h("button", { type: "button", class: "btn ghost icon-only", "aria-label": t("Verwijder {0}", it.name), onclick: function () { if (busy) return; items.splice(items.indexOf(it), 1); it.el.remove(); } }, icon("x", 14));
      it.el = h("div", { class: "e2e-upload-row" }, h("span", { class: "e2e-upload-row__icon" }, icon(it.kind === "video" ? "video" : "image", 18)),
        h("span", { class: "e2e-upload-row__main" }, h("span", { class: "e2e-upload-row__name" }, it.name), meta, h("span", { class: "e2e-upload-row__bar", role: "progressbar", "aria-label": it.name }, bar)), state, rm);
      it.set = function (st, text, pct) {
        it.state = st; state.textContent = text || ""; it.el.classList.toggle("e2e-upload-row--done", st === "klaar"); it.el.classList.toggle("e2e-upload-row--error", st === "fout");
        bar.style.width = (pct != null ? pct : st === "klaar" ? 100 : 0) + "%"; bar.classList.toggle("cv-indeterminate", st === "uploaden" || st === "verwerken"); rm.hidden = st === "uploaden" || st === "verwerken";
      };
      it.meta = function (ms, bytes) { meta.textContent = (ms ? CV.ms(ms) + " · " : "") + (bytes ? CV.size(bytes) : ""); };
      it.meta(null, it.size); it.set("wacht", t("Wachten"));
      return it.el;
    }
    function add(it) { items.push(it); listEl.appendChild(rowFor(it)); }
    function addFiles(files) {
      Array.prototype.forEach.call(files, function (f) {
        var kind = VIDEO_EXT.test(f.name) || /^video\//.test(f.type) ? "video" : IMAGE_EXT.test(f.name) || /^image\//.test(f.type) ? "image" : "";
        var it = { file: f, name: f.name, size: f.size, kind: kind || "image" };
        add(it);
        var max = (kind === "video" ? (lim.max_video_mb || 500) : (lim.max_foto_mb || 30)) * 1048576;
        if (!kind) it.set("fout", t("Dit soort bestand wordt niet ondersteund."));
        else if (f.size > max) it.set("fout", t("Te groot (maximaal {0} MB).", Math.round(max / 1048576)));
      });
    }
    function pickLibrary() {
      system.pickMedia().then(function (m) {
        if (!m) return; var nm = decodeURIComponent(String(m.url || "").split("?")[0].split("/").pop() || "bestand");
        add({ source: m.id, name: nm, size: 0, kind: VIDEO_EXT.test(nm) ? "video" : "image" });
      }).catch(CV.fail);
    }
    function pollMedia(id, it) {
      return new Promise(function (resolve) {
        (function tick() {
          CV.call("media/" + id).then(function (m) {
            it.meta(m.duur_ms, m.grootte || it.size);
            if (m.verwerking === "klaar") { it.set("klaar", t("Klaar")); resolve(true); }
            else if (m.verwerking === "fout") { it.set("fout", m.fout || t("Verwerken is niet gelukt.")); resolve(false); }
            else setTimeout(tick, 1500);
          }).catch(function () { setTimeout(tick, 3000); });
        })();
      });
    }
    function sendOne(it) {
      it.set("uploaden", t("Uploaden…"));
      var p = it.file ? CV.upload("analyses/" + created + "/media", it.file, {}) : CV.call("analyses/" + created + "/media", "POST", { source_media_id: it.source });
      return p.then(function (m) { it.set("verwerken", t("Verwerken…")); it.meta(m.duur_ms, m.grootte || it.size); return pollMedia(m.id, it); }).catch(function (e) { it.set("fout", (e && e.message) || t("Uploaden is niet gelukt.")); return false; });
    }
    function submit(btn) {
      if (busy) return; showErr("");
      var name = titel.value.trim(), ids = Object.keys(sel);
      if (!name) { dlg.tab("bestand"); showErr(t("Geef de analyse een titel.")); titel.focus(); return; }
      if (delen === "delen" && !ids.length) { dlg.tab("sporter"); showErr(t("Kies minstens één sporter om te kunnen delen.")); return; }
      busy = true; btn.disabled = true; btn.textContent = t("Bezig…");
      var first = created ? Promise.resolve() : CV.call("analyses", "POST", { titel: name, sporter_ids: ids.map(Number), delen: delen === "delen", melden: melden }).then(function (a) { created = a.id; });
      first.then(function () {
        var todo = items.filter(function (it) { return it.state === "wacht" || it.retry; });
        return todo.reduce(function (p, it) { it.retry = false; return p.then(function () { return sendOne(it); }).then(function (ok) { it.retry = !ok; }); }, Promise.resolve());
      }).then(function () {
        var failed = items.filter(function (it) { return it.retry; });
        if (failed.length) { busy = false; btn.disabled = false; btn.textContent = t("Opnieuw proberen"); dlg.tab("bestand"); showErr(t("De analyse is aangemaakt, maar niet alle bestanden zijn gelukt. Verwijder de mislukte bestanden en ga door, of probeer opnieuw.")); var go = h("button", { type: "button", class: "btn", onclick: function () { dlg.close(); CV.go("editor", { id: created }); } }, t("Toch openen")); err.appendChild(go); return; }
        CV.refreshHome(); dlg.close(); CV.go("editor", { id: created });
      }).catch(function (e) { busy = false; btn.disabled = false; btn.textContent = t("Analyse aanmaken"); showErr((e && e.message) || String(e)); });
    }

    function renderAthletes() {
      CV.clear(athleteBox);
      if (!athletes) { athleteBox.appendChild(loading()); return; }
      if (!athletes.length) {
        athleteBox.appendChild(empty("users", t("Nog geen sporters"), t("Je hebt nog geen sporters. Nodig iemand uit met zijn of haar e-mailadres."),
          h("button", { type: "button", class: "btn primary", onclick: function () { inviteDialog(function () { athletes = null; renderAthletes(); loadAthletes(); }); } }, icon("plus", 16), t("Sporter uitnodigen"))));
        return;
      }
      athleteBox.appendChild(h("div", { class: "cv-cards", role: "group", "aria-label": t("Sporters") }, athletes.map(function (s) {
        var cb = h("input", { type: "checkbox", checked: !!sel[s.id], onchange: function () { if (cb.checked) sel[s.id] = true; else delete sel[s.id]; card.classList.toggle("on", cb.checked); } });
        var card = h("label", { class: "cv-pickcard" + (sel[s.id] ? " on" : "") }, cb, CV.avatar(s), h("span", { class: "cv-pickcard__t" }, h("strong", {}, s.name), s.niveau ? h("small", { class: "muted" }, s.niveau) : null));
        return card;
      })));
    }
    function loadAthletes() { CV.call("sporters").then(function (r) { athletes = r.sporters; renderAthletes(); }).catch(function (e) { CV.clear(athleteBox); athleteBox.appendChild(errorBox(e, loadAthletes)); }); }

    var tabs = [
      { key: "bestand", label: t("Bestand"), render: function (body) {
        body.appendChild(err);
        body.appendChild(field(t("Titel"), titel));
        var hint = t("MP4, MOV, JPG, PNG of HEIC.") + " " + t("Video tot {0} minuten, maximaal {1} MB.", Math.max(1, Math.round((lim.max_video_sec || 180) / 60)), lim.max_video_mb || 500);
        var drop = h("div", { class: "e2e-drop", role: "group", "aria-label": t("Bestanden toevoegen"), ondragover: function (e) { e.preventDefault(); drop.classList.add("e2e-drop--over"); }, ondragleave: function () { drop.classList.remove("e2e-drop--over"); }, ondrop: function (e) { e.preventDefault(); drop.classList.remove("e2e-drop--over"); if (!busy && e.dataTransfer) addFiles(e.dataTransfer.files); } },
          h("span", { class: "cv-drop__icon" }, icon("upload", 28)), h("strong", {}, t("Sleep video's of foto's hierheen")), h("small", { class: "muted" }, hint),
          h("div", { class: "row cv-drop__btns" }, h("button", { type: "button", class: "btn primary", onclick: function () { fileInput.click(); } }, t("Bestand kiezen")), h("button", { type: "button", class: "btn", onclick: pickLibrary }, t("Uit mediabibliotheek"))), fileInput);
        body.appendChild(drop); body.appendChild(listEl);
        if (lim.video_verkleinen && H.ffmpeg) body.appendChild(h("label", { class: "cv-check cv-check--info" }, h("input", { type: "checkbox", checked: true, disabled: true }), h("span", {}, t("Video verkleinen voor snel afspelen (origineel blijft bewaard)"))));
      } },
      { key: "sporter", label: t("Sporter"), render: function (body) {
        body.appendChild(err); body.appendChild(h("p", { class: "muted" }, t("Kies voor wie deze analyse is. Alleen sporters die akkoord hebben gegeven staan hier. Om te delen is minstens één sporter nodig; een concept heeft er geen nodig.")));
        body.appendChild(athleteBox); renderAthletes();
      } },
      { key: "delen", label: t("Delen"), render: function (body) {
        body.appendChild(err);
        var mel = h("input", { type: "checkbox", checked: melden, onchange: function () { melden = mel.checked; } });
        function radio(v, label, sub) { return h("label", { class: "cv-radio" }, h("input", { type: "radio", name: "cv-delen", value: v, checked: delen === v, onchange: function () { delen = v; melRow.hidden = v !== "delen"; } }), h("span", {}, h("strong", {}, label), h("small", { class: "muted" }, sub))); }
        var melRow = h("label", { class: "cv-check", hidden: delen !== "delen" }, mel, h("span", {}, t("Sporter een melding sturen")));
        body.appendChild(h("div", { class: "cv-radios", role: "radiogroup", "aria-label": t("Delen") }, radio("concept", t("Als concept bewaren"), t("Alleen jij ziet de analyse tot je hem deelt.")), radio("delen", t("Direct delen met de sporter"), t("De sporter ziet de analyse meteen."))));
        body.appendChild(melRow);
      } }
    ];
    var cancel = h("button", { type: "button", class: "btn", onclick: function () { if (!busy) dlg.close(); } }, t("Annuleren"));
    var go = h("button", { type: "button", class: "btn primary", onclick: function () { submit(go); } }, t("Analyse aanmaken"));
    var used = H.opslag_gebruikt != null ? t("Opslag: {0} van {1} gebruikt", CV.size(H.opslag_gebruikt), CV.size(H.opslag_max)) : "";
    dlg = CV.dialog({ eyebrow: t("COACH VIDEO"), title: t("Nieuwe analyse"), tabs: tabs, footerLeft: used, buttons: [cancel, go], wide: true });
    loadAthletes();
    return dlg;
  }

  /* =====================================================================
     3. the library of instruction videos
     ===================================================================== */
  function videoCard(v, open) {
    var title = h("button", { type: "button", class: "cv-card__open", onclick: function () { open(v); } }, v.titel);
    return h("article", { class: "cv-card cv-card--video" },
      h("div", { class: "cv-poster cv-poster--tile" }, h("span", { class: "badge cv-poster__kind" }, icon("youtube", 12), "YouTube"), h("span", { class: "cv-play" }, icon("play", 22)), v.duur_s ? h("span", { class: "cv-poster__dur" }, CV.sec(v.duur_s)) : null),
      h("div", { class: "cv-card__body" }, h("h3", { class: "cv-card__title" }, title),
        h("div", { class: "row cv-chips" }, v.categorie ? h("span", { class: "e2e-chip e2e-chip--muted" }, v.categorie) : null, v.start_s ? h("span", { class: "e2e-chip e2e-chip--muted" }, t("start {0}", CV.sec(v.start_s))) : null, !v.van_mij ? h("span", { class: "e2e-chip e2e-chip--muted" }, t("van een andere coach")) : null),
        h("div", { class: "cv-card__meta muted" }, t("Gebruikt in {0}", plural(v.gebruikt || 0, "analyse", "analyses")))));
  }

  CV.views.bibliotheek = function (root) {
    var f = { q: "", categorie: "" }, grid = h("div", { class: "cv-results" }), pills = h("div", { class: "cv-pills", role: "group", "aria-label": t("Categorie") }), seq = 0, cats = [];
    var search = h("input", { type: "search", placeholder: t("Zoek op titel of tag"), "aria-label": t("Zoek op titel of tag") });
    function drawPills() {
      CV.clear(pills);
      var all = [["", t("Alles")]].concat(cats.map(function (c) { return [c, c]; }));
      all.forEach(function (p) { pills.appendChild(h("button", { type: "button", class: "e2e-chip" + (f.categorie === p[0] ? " e2e-chip--active" : ""), "aria-pressed": f.categorie === p[0] ? "true" : "false", onclick: function () { f.categorie = p[0]; drawPills(); load(); } }, p[1])); });
      pills.hidden = cats.length === 0;
    }
    function load() {
      var my = ++seq; CV.clear(grid); grid.appendChild(loading());
      var qs = Object.keys(f).filter(function (k) { return f[k]; }).map(function (k) { return k + "=" + encodeURIComponent(f[k]); }).join("&");
      CV.call("bibliotheek" + (qs ? "?" + qs : "")).then(function (r) {
        if (my !== seq) return; CV.clear(grid);
        if (!f.categorie && !f.q) { cats = r.categorieen || []; drawPills(); }
        if (!r.videos.length) grid.appendChild(f.q || f.categorie ? empty("search", t("Niets gevonden"), t("Probeer een andere zoekterm of categorie.")) : empty("youtube", t("Nog geen instructievideo's"), t("Bewaar YouTube-links die je vaak gebruikt en koppel ze aan een analyse of aan één opmerking."), h("button", { type: "button", class: "btn primary", onclick: function () { panel(null, r.categorieen || [], load); } }, icon("plus", 16), t("Link toevoegen"))));
        else grid.appendChild(h("div", { class: "cv-grid" }, r.videos.map(function (v) { return videoCard(v, function (x) { panel(x, cats, load); }); })));
        resize();
      }).catch(function (e) { if (my === seq) { CV.clear(grid); grid.appendChild(errorBox(e, load)); } });
    }
    search.addEventListener("input", debounce(function () { f.q = search.value.trim(); load(); }, 300));
    root.appendChild(coachNav("bibliotheek"));
    root.appendChild(pageHead(t("COACH VIDEO"), t("Instructievideo's"), t("Jouw bibliotheek met YouTube-links. Koppel ze aan een analyse of aan één opmerking."), [h("button", { type: "button", class: "btn primary", onclick: function () { panel(null, cats, load); } }, icon("plus", 16), t("Link toevoegen"))]));
    root.appendChild(h("div", { class: "cv-filters" }, h("div", { class: "cv-search grow" }, icon("search", 16), search)));
    root.appendChild(pills); root.appendChild(grid);
    drawPills(); load();
  };

  /* the right-side panel (drawer) to add or edit a link; v = null for a new one */
  function panel(v, categories, done) {
    var isNew = !v, own = isNew || v.van_mij, prev = document.activeElement, cur = v || {}, cur_tab = "link", tabBtns = {};
    var url = h("input", { type: "url", placeholder: "https://www.youtube.com/watch?v=…", "aria-label": t("YouTube-link"), disabled: !isNew });
    var titel = h("input", { type: "text", maxlength: 200, value: cur.titel || "", disabled: !own }), kanaal = h("input", { type: "text", maxlength: 120, value: cur.kanaal || "", disabled: !own });
    var start = h("input", { type: "text", inputmode: "numeric", placeholder: "0:00", value: secToMss(cur.start_s), disabled: !own, "aria-label": t("Start") }), eind = h("input", { type: "text", inputmode: "numeric", placeholder: "m:ss", value: secToMss(cur.eind_s), disabled: !own, "aria-label": t("Einde") });
    var cat = h("input", { type: "text", maxlength: 60, value: cur.categorie || "", list: "cv-cats", disabled: !own }), dl = h("datalist", { id: "cv-cats" }, (categories || []).map(function (c) { return h("option", { value: c }); }));
    var ed = CV.editor({ value: cur.uitleg || "", placeholder: t("Wat moet de sporter hiervan leren?"), label: t("Uitleg voor de sporter") });
    var vis = cur.zichtbaarheid || "eigen";
    var err = h("div", { class: "alert", role: "alert", hidden: true }), ytId = cur.youtube_id || "", prevBox = h("div", { class: "cv-preview" }), fetchBtn = h("button", { type: "button", class: "btn", onclick: fetchInfo }, t("Ophalen"));
    function showErr(m) { err.hidden = !m; err.textContent = m || ""; }
    function embed() {
      var s = mssToSec(start.value), e = mssToSec(eind.value), q = "?rel=0&autoplay=1" + (s ? "&start=" + s : "") + (e ? "&end=" + e : "");
      CV.clear(prevBox); prevBox.appendChild(h("iframe", { src: "https://www.youtube-nocookie.com/embed/" + encodeURIComponent(ytId) + q, title: titel.value || t("Voorbeeld"), allow: "accelerometer; encrypted-media; picture-in-picture; fullscreen", allowfullscreen: true, referrerpolicy: "strict-origin-when-cross-origin" }));
    }
    function drawPreview() {
      CV.clear(prevBox);
      if (!ytId) { prevBox.appendChild(h("div", { class: "cv-preview__ph muted" }, icon("youtube", 28), h("small", {}, t("Plak een YouTube-link en kies Ophalen.")))); return; }
      prevBox.appendChild(h("div", { class: "cv-preview__ph" }, h("button", { type: "button", class: "btn primary", onclick: embed }, icon("play", 14), t("Voorbeeld tonen")), h("small", { class: "muted" }, t("De video van YouTube wordt pas geladen als je dit kiest."))));
    }
    function fetchInfo() {
      showErr(""); if (!url.value.trim()) { showErr(t("Plak eerst een YouTube-link.")); url.focus(); return; }
      fetchBtn.disabled = true;
      CV.call("bibliotheek/ophalen", "POST", { url: url.value.trim() }).then(function (r) {
        ytId = r.youtube_id; if (r.titel && !titel.value) titel.value = r.titel; if (r.kanaal && !kanaal.value) kanaal.value = r.kanaal; if (r.start_s) start.value = secToMss(r.start_s);
        if (!r.gevonden) CV.toast(t("De titel kon niet worden opgehaald. Vul hem zelf in."), false); drawPreview();
      }).catch(function (e) { showErr(e.message || String(e)); }).then(function () { fetchBtn.disabled = false; });
    }
    function save(btn) {
      showErr("");
      var s = mssToSec(start.value), e = mssToSec(eind.value);
      if (Number.isNaN(s) || Number.isNaN(e)) { showErr(t("Vul start en einde in als m:ss, bijvoorbeeld 1:20.")); show("link"); return; }
      if (isNew && !url.value.trim()) { showErr(t("Plak eerst een YouTube-link.")); show("link"); url.focus(); return; }
      if (!titel.value.trim()) { showErr(t("Geef de instructievideo een titel.")); show("link"); titel.focus(); return; }
      var body = { titel: titel.value.trim(), kanaal: kanaal.value.trim(), start_s: s === "" ? 0 : s, eind_s: e, categorie: cat.value.trim(), uitleg: ed.get(), zichtbaarheid: vis };
      if (isNew) body.url = url.value.trim();
      btn.disabled = true;
      CV.call(isNew ? "bibliotheek" : "bibliotheek/" + cur.id, isNew ? "POST" : "PUT", body).then(function () { CV.toast(t("Opgeslagen.")); close(); done(); }).catch(function (x) { btn.disabled = false; showErr(x.message || String(x)); });
    }
    function remove() {
      CV.confirmBox(t("Deze link verwijderen? Hij verdwijnt ook uit de analyses waaraan hij gekoppeld is."), { danger: true, confirm: t("Verwijderen") }).then(function (ok) { if (ok) CV.call("bibliotheek/" + cur.id, "DELETE").then(function () { CV.toast(t("Verwijderd.")); close(); done(); }).catch(CV.fail); });
    }
    function onKey(e) { if (!ov.isConnected) { document.removeEventListener("keydown", onKey); return; } if (e.key === "Escape") close(); }
    function close() { ov.remove(); document.removeEventListener("keydown", onKey); if (prev && prev.focus) try { prev.focus(); } catch (e) {} }
    var panes = { link: h("div", { class: "cv-drawer__pane" }), uitleg: h("div", { class: "cv-drawer__pane" }) };
    if (isNew) panes.link.appendChild(h("div", { class: "cv-field" }, h("span", { class: "cv-field__label" }, t("YouTube-link")), h("div", { class: "row nowrap" }, h("div", { class: "grow" }, url), fetchBtn)));
    panes.link.appendChild(prevBox);
    panes.link.appendChild(field(t("Titel"), titel)); panes.link.appendChild(field(t("Kanaal"), kanaal));
    panes.link.appendChild(h("div", { class: "cv-two" }, field(t("Start"), start, t("m:ss")), field(t("Einde"), eind, t("m:ss, leeg = tot het einde"))));
    panes.uitleg.appendChild(field(t("Categorie"), cat)); panes.uitleg.appendChild(dl);
    panes.uitleg.appendChild(h("div", { class: "cv-field" }, h("span", { class: "cv-field__label" }, t("Uitleg voor de sporter")), ed.el));
    panes.uitleg.appendChild(h("fieldset", { class: "cv-radios", disabled: !own }, h("legend", { class: "cv-field__label" }, t("Wie mag deze link gebruiken")),
      [["eigen", t("Alleen ik")], ["alle_coaches", t("Alle coaches van deze site")]].map(function (o) { return h("label", { class: "cv-radio" }, h("input", { type: "radio", name: "cv-vis", value: o[0], checked: vis === o[0], onchange: function () { vis = o[0]; } }), h("span", {}, h("strong", {}, o[1]))); })));
    if (!own) panes.link.insertBefore(h("p", { class: "muted" }, t("Deze link is van een andere coach en kan alleen bekeken worden.")), panes.link.firstChild);
    function show(k) { cur_tab = k; Object.keys(panes).forEach(function (x) { panes[x].hidden = x !== k; tabBtns[x].classList.toggle("on", x === k); tabBtns[x].setAttribute("aria-selected", x === k ? "true" : "false"); }); }
    var tabsEl = h("div", { class: "tabs", role: "tablist" }, [["link", t("Link")], ["uitleg", t("Uitleg en delen")]].map(function (x) { return (tabBtns[x[0]] = h("button", { type: "button", role: "tab", onclick: function () { show(x[0]); } }, x[1])); }));
    var saveBtn = h("button", { type: "button", class: "btn primary", onclick: function () { save(saveBtn); } }, t("Opslaan"));
    var drawer = h("aside", { class: "cv-drawer", role: "dialog", "aria-modal": "true", "aria-label": isNew ? t("Link toevoegen") : t("Link bewerken") },
      h("div", { class: "cv-dialog__head" }, h("div", {}, h("div", { class: "cv-eyebrow" }, t("INSTRUCTIEVIDEO")), h("h2", {}, isNew ? t("Link toevoegen") : t("Link bewerken"))), CV.iconBtn("x", t("Sluiten"), close)),
      tabsEl, h("div", { class: "cv-dialog__body" }, err, panes.link, panes.uitleg),
      h("div", { class: "cv-dialog__foot" }, !isNew && own ? h("button", { type: "button", class: "btn danger", onclick: remove }, icon("trash", 14), t("Verwijderen")) : h("span", {}), h("div", { class: "row" }, h("button", { type: "button", class: "btn", onclick: close }, own ? t("Annuleren") : t("Sluiten")), own ? saveBtn : null)));
    var ov = h("div", { class: "cv-overlay cv-overlay--side", onmousedown: function (e) { if (e.target === ov) close(); } }, drawer);
    CV.root().appendChild(ov); document.addEventListener("keydown", onKey);
    show("link"); drawPreview(); (isNew ? url : titel).focus();
  }

  /* =====================================================================
     4. the athletes
     ===================================================================== */
  function editSporter(s, done) {
    var niveau = h("input", { type: "text", maxlength: 80, value: s.niveau || "" }), doel = h("input", { type: "text", maxlength: 200, value: s.doel || "" }), err = h("div", { class: "alert", role: "alert", hidden: true }), dlg;
    var ok = h("button", { type: "button", class: "btn primary", onclick: function () {
      ok.disabled = true;
      CV.call("sporters/" + (s.sporter_id || s.id), "PUT", { niveau: niveau.value.trim(), doel: doel.value.trim() }).then(function () { dlg.close(); CV.toast(t("Opgeslagen.")); done(); }).catch(function (e) { ok.disabled = false; err.hidden = false; err.textContent = e.message || String(e); });
    } }, t("Opslaan"));
    dlg = CV.dialog({ eyebrow: t("SPORTER"), title: s.name, tabs: [{ key: "g", label: t("Gegevens"), render: function (b) { b.appendChild(err); b.appendChild(field(t("Niveau"), niveau)); b.appendChild(field(t("Doel"), doel)); } }], buttons: [h("button", { type: "button", class: "btn", onclick: function () { dlg.close(); } }, t("Annuleren")), ok] });
  }
  CV.views.sporters = function (root, params) {
    params = params || {};
    var data = null, tab = params.tab || "sporters", body = h("div", { class: "cv-results" }), tabsEl, btns = {};
    function mineIn(k) { return (k.verzoeken_in || []).filter(function (r) { return r.richting === "aanvraag"; }); }
    function mineOut(k) { return (k.verzoeken_uit || []).filter(function (r) { return r.richting === "uitnodiging"; }); }
    function otherIn(k) { return (k.verzoeken_in || []).filter(function (r) { return r.richting === "uitnodiging"; }); }
    function setBadge(key, n) {
      var b = btns[key]; if (!b) return; var o = b.querySelector(".badge"); if (o) o.remove();
      if (n > 0) b.appendChild(h("span", { class: "badge info", "aria-label": t("{0} open", n) }, String(n)));
    }
    function show(k) { tab = k; Object.keys(btns).forEach(function (x) { btns[x].classList.toggle("on", x === k); btns[x].setAttribute("aria-selected", x === k ? "true" : "false"); }); draw(); }
    function sync(k) { data = k; setBadge("verzoeken", mineIn(k).length + mineOut(k).length); setBadge("coaches", otherIn(k).length); }
    function got(k) { sync(k); draw(); }
    function load() {
      CV.clear(body); body.appendChild(loading());
      CV.call("koppelingen").then(function (k) {
        data = k; invite.hidden = !k.uitnodigen; if (tab === "verzoeken" && !mineIn(k).length && otherIn(k).length) tab = "coaches";
        setBadge("verzoeken", mineIn(k).length + mineOut(k).length); setBadge("coaches", otherIn(k).length);
        Object.keys(btns).forEach(function (x) { btns[x].classList.toggle("on", x === tab); btns[x].setAttribute("aria-selected", x === tab ? "true" : "false"); }); draw();
      }).catch(function (e) { CV.clear(body); body.appendChild(errorBox(e, load)); });
    }
    function draw() {
      CV.clear(body); if (!data) return;
      if (tab === "sporters") drawSporters(); else if (tab === "verzoeken") drawRequests(); else CV.coachesPanel(body, { data: data, onData: sync });
      resize();
    }
    function drawSporters() {
      if (!data.sporters.length) { body.appendChild(empty("users", t("Nog geen sporters"), t("Je hebt nog geen sporters. Nodig iemand uit met zijn of haar e-mailadres."), data.uitnodigen ? h("button", { type: "button", class: "btn primary", onclick: function () { inviteDialog(got); } }, icon("plus", 16), t("Sporter uitnodigen")) : null)); return; }
      body.appendChild(h("div", { class: "cv-rows", role: "list" }, data.sporters.map(function (s) {
        return h("div", { class: "cv-rowcard", role: "listitem" }, CV.avatar(s, "e2e-avatar--lg"),
          h("div", { class: "grow cv-rowcard__text" }, h("strong", {}, s.name), h("small", { class: "muted" }, [s.niveau, s.doel].filter(Boolean).join(" · ") || t("Geen niveau of doel ingevuld"))),
          h("span", { class: "badge" }, plural(s.analyses || 0, "analyse", "analyses")),
          CV.iconBtn("edit", t("Gegevens van {0} wijzigen", s.name), function () { editSporter(s, load); }),
          h("button", { type: "button", class: "btn danger", "aria-label": t("Koppeling beëindigen") + ": " + s.name, onclick: function () {
            CV.confirmBox(t("De koppeling met {0} beëindigen? De analyses die je al deelde blijven voor deze sporter leesbaar, maar je kunt niets nieuws meer delen.", s.name), { danger: true, confirm: t("Koppeling beëindigen") }).then(function (ok) {
              if (ok) CV.call("koppelingen/" + s.sporter_id, "DELETE").then(function (k) { CV.toast(t("Koppeling beëindigd.")); CV.refreshHome(); got(k); }).catch(CV.fail);
            });
          } }, t("Koppeling beëindigen")));
      })));
    }
    function drawRequests() {
      var inc = mineIn(data), out = mineOut(data);
      if (!inc.length && !out.length) { body.appendChild(empty("send", t("Geen open verzoeken"), t("Verzoeken om een sporter te worden en de uitnodigingen die je verstuurde staan hier tot ze beantwoord zijn."))); return; }
      if (inc.length) {
        body.appendChild(h("h2", { class: "cv-sec" }, t("Wachten op jouw antwoord")));
        body.appendChild(h("div", { class: "cv-rows", role: "list" }, inc.map(function (r) { return requestRow(r, { done: got, inText: function (x) { return t("{0} wil jou als coach. Daarmee kun je analyses maken en met deze sporter chatten.", x.naam); } }); })));
      }
      if (out.length) {
        body.appendChild(h("h2", { class: "cv-sec" }, t("Verstuurd")));
        body.appendChild(h("div", { class: "cv-rows", role: "list" }, out.map(function (r) { return requestRow(r, { done: got, outText: t("Wacht op akkoord van de sporter") }); })));
      }
    }
    var invite = h("button", { type: "button", class: "btn primary", hidden: true, onclick: function () { inviteDialog(function (k) { got(k); show("verzoeken"); }); } }, t("+ Sporter uitnodigen"));
    tabsEl = h("div", { class: "tabs cv-tabs", role: "tablist" }, [["sporters", t("Sporters")], ["verzoeken", t("Verzoeken")], ["coaches", t("Mijn coaches")]].map(function (x) {
      return (btns[x[0]] = h("button", { type: "button", role: "tab", "data-key": x[0], class: x[0] === tab ? "on" : "", "aria-selected": x[0] === tab ? "true" : "false", onclick: function () { show(x[0]); } }, x[1]));
    }));
    root.appendChild(coachNav("sporters"));
    root.appendChild(pageHead(t("COACH VIDEO"), t("Sporters"), t("Alleen met het akkoord van de sporter kun je iemand koppelen. Je voegt iemand toe met het e-mailadres."), [invite]));
    root.appendChild(tabsEl); root.appendChild(body); load();
  };

  /* =====================================================================
     5. the AI credit
     ===================================================================== */
  CV.views.tegoed = function (root) {
    var box = h("div", { class: "stack" });
    function draw() {
      var H = home(), ai = H.ai || {}, used = H.opslag_gebruikt || 0, max = H.opslag_max || 0, pct = max ? Math.min(100, Math.round(used * 100 / max)) : 0;
      CV.clear(box);
      if (ai.available === false) box.appendChild(h("div", { class: "alert", role: "status" }, t("De AI is op deze site niet gekoppeld. Je kunt de analyses wel gewoon maken; alleen de AI-instructie is niet beschikbaar.")));
      box.appendChild(h("section", { class: "cv-kpi dark cv-credit" }, h("div", { class: "cv-kpi__label" }, t("AI-tegoed")), h("div", { class: "cv-kpi__value cv-credit__amount" }, ai.available === false ? "–" : CV.money(ai.balance, ai.symbol)),
        h("p", { class: "cv-credit__note" }, ai.credit_required ? t("Voor het gebruik van de AI is tegoed nodig.") : t("Voor het gebruik van de AI is op deze site geen tegoed nodig.")),
        ai.available === false ? null : h("div", {}, h("button", { type: "button", class: "btn primary", onclick: function () { system.aiCredit().then(function () { return CV.refreshHome(); }).then(draw).catch(CV.fail); } }, icon("sparkle", 16), t("Opwaarderen")))));
      box.appendChild(h("section", { class: "card stack" }, h("h2", {}, t("Hoe werkt het?")), h("p", {}, t("De coach betaalt het AI-gebruik uit zijn eigen tegoed; de kosten van een opdracht staan bij de analyse."))));
      box.appendChild(h("section", { class: "card stack" }, h("h2", {}, t("Opslag")), h("div", { class: "cv-meter", role: "progressbar", "aria-valuemin": 0, "aria-valuemax": 100, "aria-valuenow": pct, "aria-label": t("Opslag") }, h("span", { style: "width:" + pct + "%" })),
        h("p", {}, t("Opslag: {0} van {1} gebruikt", CV.size(used), CV.size(max))), h("small", { class: "muted" }, t("Verwijder oude analyses of archiveer ze om ruimte vrij te maken."))));
      resize();
    }
    root.appendChild(coachNav("tegoed"));
    root.appendChild(pageHead(t("COACH VIDEO"), t("AI-tegoed"), t("Je tegoed voor de AI-instructie en je opslagruimte.")));
    root.appendChild(box); draw();
    CV.refreshHome().then(draw).catch(function () {});
  };

  CV.coachNav = coachNav; CV.pageHead = pageHead; CV.newAnalysisDialog = newAnalysisDialog; CV.inviteDialog = inviteDialog; CV.noticeBar = noticeBar; CV.requestRow = requestRow; CV.refreshNav = refreshNav; CV.ui = { loading: loading, errorBox: errorBox, empty: empty, field: field, resize: resize }; CV.mssToSec = mssToSec; CV.secToMss = secToMss;
})();
