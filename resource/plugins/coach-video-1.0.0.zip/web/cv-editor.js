// Copyright & Ownership Notice
// easy2Edit is the exclusive legal property of RST Coaching & Consultancy B.V. (RSTCC),
// owned by Ronald Stolk. All rights reserved. Any unauthorized use, copying, modification,
// reproduction, distribution, or commercial exploitation of Easy2Edit, including its source code,
// is strictly prohibited without prior written permission from Ronald Stolk or RSTCC.
// website https://rstcc.net

"use strict";
/* Coach video: the analysis editor (view "editor": video/photo with drawing tools, timeline, remarks, instruction, AI, chat) and the AI dialog (CV.aiDialog).
   Texts that are only used through a variable (so the translation tool finds them):
   t("Lijn") t("Pijl") t("Hoek") t("Cirkel") t("Vrije hand") t("Tekst") t("Kort") t("Gemiddeld") t("Lang") t("Motiverend") t("Zakelijk") t("Vriendelijk") t("Streng")
   t("Klaar") t("Bezig") t("Mislukt") t("Instructie schrijven") t("Oefeningen voorstellen") t("Fouten benoemen") t("Samenvatting voor sporter") t("Vrije opdracht")
   t("Klik en sleep van begin naar einde.") t("Klik op het middelpunt en sleep naar de rand.") t("Teken met de muis of je vinger.") t("Klik op het beeld en typ het label.") t("Klik drie punten: begin, hoekpunt en einde.")
   t("Klik op een tekening om hem te kiezen, sleep om te verplaatsen.") */
CV.editorLogic = (function () {
  /* the pure logic (no DOM): coordinates, angle, hit tests, undo stack, timeline maths. Exercised by a node test. */
  var L = {};
  L.clamp = function (v, a, b) { return Math.min(b, Math.max(a, v)); };
  /* pointer position -> 0..1 in the picture */
  L.toNorm = function (rect, cx, cy) { return [L.clamp((cx - rect.left) / (rect.width || 1), 0, 1), L.clamp((cy - rect.top) / (rect.height || 1), 0, 1)]; };
  /* the angle (degrees, one decimal) at b between a and c; ratio = height / width of the picture, so it is a real angle */
  L.angle = function (a, b, c, ratio) {
    var v1 = [a[0] - b[0], (a[1] - b[1]) * ratio], v2 = [c[0] - b[0], (c[1] - b[1]) * ratio];
    var m = Math.hypot(v1[0], v1[1]) * Math.hypot(v2[0], v2[1]);
    return m ? Math.round(Math.acos(L.clamp((v1[0] * v2[0] + v1[1] * v2[1]) / m, -1, 1)) * 1800 / Math.PI) / 10 : 0;
  };
  /* distance of point p to the segment a-b (x-units: the width of the picture is 1) */
  L.segDist = function (p, a, b, r) {
    var px = p[0], py = p[1] * r, ax = a[0], ay = a[1] * r, dx = b[0] - ax, dy = b[1] * r - ay, l2 = dx * dx + dy * dy;
    var k = l2 ? L.clamp(((px - ax) * dx + (py - ay) * dy) / l2, 0, 1) : 0;
    return Math.hypot(px - (ax + k * dx), py - (ay + k * dy));
  };
  L.hit = function (it, p, tol, r) {
    var P = it.punten || [], i;
    if (it.soort === "tekst") { if (!P.length) return false; var hw = ((it.label || "").length * 8.5 + 16) / 1000, hh = 24 / 1000; return Math.abs(p[0] - P[0][0]) <= hw + tol / 2 && Math.abs((p[1] - P[0][1]) * r) <= hh + tol / 2; }
    if (it.soort === "cirkel") { if (P.length < 2) return false; var rad = Math.hypot(P[1][0] - P[0][0], (P[1][1] - P[0][1]) * r), d = Math.hypot(p[0] - P[0][0], (p[1] - P[0][1]) * r); return Math.abs(d - rad) <= tol; }
    for (i = 0; i < P.length - 1; i++) if (L.segDist(p, P[i], P[i + 1], r) <= tol) return true;
    return false;
  };
  L.handles = function (it) { return it.soort === "vrij" || it.soort === "tekst" ? [] : (it.punten || []); };
  L.handleAt = function (it, p, rad, r) {
    var H = L.handles(it), best = -1, bd = rad, i, d;
    for (i = 0; i < H.length; i++) { d = Math.hypot(p[0] - H[i][0], (p[1] - H[i][1]) * r); if (d <= bd) { bd = d; best = i; } }
    return best;
  };
  /* move all points by (dx, dy) but keep them inside the picture */
  L.moveBy = function (P, dx, dy) {
    var minx = 1, maxx = 0, miny = 1, maxy = 0;
    P.forEach(function (q) { minx = Math.min(minx, q[0]); maxx = Math.max(maxx, q[0]); miny = Math.min(miny, q[1]); maxy = Math.max(maxy, q[1]); });
    dx = L.clamp(dx, -minx, 1 - maxx); dy = L.clamp(dy, -miny, 1 - maxy);
    return P.map(function (q) { return [q[0] + dx, q[1] + dy]; });
  };
  L.decimate = function (pts, max) {
    if (pts.length <= max) return pts.slice();
    var out = [], step = (pts.length - 1) / (max - 1), i;
    for (i = 0; i < max; i++) out.push(pts[Math.round(i * step)]);
    return out;
  };
  /* undo/redo of states (strings) */
  L.History = function (limit) { this.s = []; this.i = -1; this.limit = limit || 100; };
  L.History.prototype.reset = function (state) { this.s = [state]; this.i = 0; };
  L.History.prototype.push = function (state) {
    if (this.i >= 0 && this.s[this.i] === state) return false;
    this.s = this.s.slice(0, this.i + 1); this.s.push(state);
    if (this.s.length > this.limit) this.s.shift();
    this.i = this.s.length - 1; return true;
  };
  L.History.prototype.canUndo = function () { return this.i > 0; };
  L.History.prototype.canRedo = function () { return this.i >= 0 && this.i < this.s.length - 1; };
  L.History.prototype.undo = function () { return this.canUndo() ? this.s[--this.i] : null; };
  L.History.prototype.redo = function () { return this.canRedo() ? this.s[++this.i] : null; };
  /* timeline */
  L.frac = function (ms, dur) { return dur > 0 ? L.clamp(ms / dur, 0, 1) : 0; };
  L.defaultRange = function (cur, dur) { var van = dur > 0 ? Math.min(cur, Math.max(0, dur - 500)) : cur; return { van: Math.round(van), tot: Math.round(dur > 0 ? Math.min(dur, van + 3000) : van + 3000) }; };
  L.moveRange = function (van, tot, mode, d, dur, min) {
    min = min || 300;
    if (mode === "l") van = L.clamp(van + d, 0, tot - min);
    else if (mode === "r") tot = L.clamp(tot + d, van + min, Math.max(dur, van + min));
    else { var len = tot - van; van = L.clamp(van + d, 0, Math.max(0, dur - len)); tot = van + len; }
    return { van: Math.round(van), tot: Math.round(tot) };
  };
  L.tickStep = function (dur, maxTicks) { var S = [100, 200, 500, 1000, 2000, 5000, 10000, 15000, 30000, 60000, 120000, 300000, 600000], i; for (i = 0; i < S.length; i++) if (dur / S[i] <= maxTicks) return S[i]; return S[S.length - 1]; };
  /* "1:20" or "80" -> seconds (null when it is not a time) */
  L.parseTime = function (s) {
    s = String(s == null ? "" : s).trim(); if (!s) return null;
    if (/^\d+$/.test(s)) return parseInt(s, 10);
    var m = /^(?:(\d+):)?(\d{1,2}):(\d{1,2})$/.exec(s); if (!m) return null;
    return (m[1] ? parseInt(m[1], 10) * 3600 : 0) + parseInt(m[2], 10) * 60 + parseInt(m[3], 10);
  };
  return L;
})();

(function () {
  var L = CV.editorLogic, t = CV.t, h = CV.h, icon = CV.icon, clear = CV.clear, NS = "http://www.w3.org/2000/svg";
  var KINDS = { lijn: "Lijn", pijl: "Pijl", hoek: "Hoek", cirkel: "Cirkel", vrij: "Vrije hand", tekst: "Tekst" };
  var KIND_ICON = { lijn: "line", pijl: "arrow", hoek: "angle", cirkel: "circle", vrij: "free", tekst: "text" };
  var DIKTES = [2, 4, 6];

  function svgEl(name, attrs) { var e = document.createElementNS(NS, name); Object.keys(attrs || {}).forEach(function (k) { e.setAttribute(k, attrs[k]); }); return e; }
  function isSrv(id) { return /^[0-9a-fA-F-]{32,36}$/.test(String(id || "")); }
  function errText(e) { return e && e.message ? e.message : String(e); }
  /* the plugin bridge only passes the text of an error: a 402 is recognised by its message as well */
  function isNoCredit(e) { return !!e && (e.code === "no_credit" || e.status === 402 || /tegoed|credit/i.test(errText(e))); }
  function debounce(fn, wait) { var tm, d = function () { var a = arguments; clearTimeout(tm); tm = setTimeout(function () { fn.apply(null, a); }, wait); }; d.cancel = function () { clearTimeout(tm); }; return d; }
  function pressed(btn, on) { btn.setAttribute("aria-pressed", on ? "true" : "false"); btn.classList.toggle("on", !!on); }
  function copy(o) { return JSON.parse(JSON.stringify(o)); }
  function processing(m) { return m.verwerking === "wacht" || m.verwerking === "bezig"; }
  function when(iso) { return CV.when(iso); }

  /* ──────────────────────────── the editor view ──────────────────────────── */
  CV.views.editor = function (root, params) {
    var id = params.id, A = null, M = null, mi = 0;
    var layers = {}, hists = {}, idmap = {}, freshIds = {}, tmpN = 0;
    var sel = null, tool = "select", color = "primair", dikte = 4, draft = null, angPts = null, gesture = null, textBox = null;
    var vid = null, pic = null, svg = null, box = null, ratio = 0.5625, dims = { w: 1600, h: 900 }, ms = 0, lastT = 0, rafId = 0, loop = { on: false, a: null, b: null };
    var activeRemark = null, pendingSeek = null, alive = true, visSig = "", pollTimer = 0, guardTimer = 0, formLink = null, aiInfo = null, chatBuilt = false, curTab = "opm", dragRange = null;
    var dirty = {}, ver = {}, busy = {}, again = {}, timers = {}, pend = 0, failed = false, ro = null;
    var el = {};  // the dom parts

    /* ---------- small helpers ---------- */
    function nid() { return "tmp" + (++tmpN); }
    function layer() { return M ? (layers[M.id] = layers[M.id] || []) : []; }
    function byId(i) { return i ? layer().filter(function (x) { return x.id === i; })[0] || null : null; }
    function isVideo() { return !!M && M.soort === "video"; }
    function dur() { return vid && isFinite(vid.duration) && vid.duration > 0 ? vid.duration * 1000 : (M && M.duur_ms) || 0; }
    function curMs() { return isVideo() && vid ? Math.round(vid.currentTime * 1000) : 0; }
    function fps() { return M && M.fps > 0 ? M.fps : 25; }
    function histOf(mid) { if (!hists[mid]) { hists[mid] = new L.History(100); hists[mid].reset(JSON.stringify(layers[mid] || [])); } return hists[mid]; }
    function visibleAt(it, m) { return !isVideo() || CV.draw.visible(it, m); }
    function mediaById(i) { return A.media.filter(function (x) { return x.id === i; })[0] || null; }

    /* ---------- saving (debounced, sequential per key, with an indicator) ---------- */
    function setSave(state) {
      if (!el.save) return;
      el.save.className = "cv-ed-save " + state; clear(el.save);
      if (state === "saving") el.save.appendChild(document.createTextNode(t("Opslaan…")));
      else if (state === "fail") { el.save.appendChild(document.createTextNode(t("Niet opgeslagen") + " ")); el.save.appendChild(h("button", { type: "button", class: "btn ghost", onclick: retry }, t("Opnieuw proberen"))); }
      else { el.save.appendChild(icon("check", 14)); el.save.appendChild(document.createTextNode(" " + t("Automatisch opgeslagen"))); }
    }
    function markDirty(key, delay) {
      dirty[key] = true; ver[key] = (ver[key] || 0) + 1;
      if (A && A.gedeeld_op && !A.ongepubliceerd) { A.ongepubliceerd = true; updateShare(); }
      setSave("saving"); clearTimeout(timers[key]); timers[key] = setTimeout(function () { runSave(key); }, delay == null ? 600 : delay);
    }
    function runSave(key) {
      clearTimeout(timers[key]);
      if (busy[key]) { again[key] = true; return busy[key]; }
      var v = ver[key];
      pend++;
      busy[key] = doSave(key).then(function () { if (ver[key] === v) delete dirty[key]; if (!Object.keys(dirty).length) failed = false; }, function (e) { failed = true; throw e; }).then(function () { return null; }, function () { return null; }).then(function () {
        pend--; busy[key] = null;
        if (again[key]) { again[key] = false; runSave(key); return; }
        if (!pend) setSave(failed || Object.keys(dirty).length ? "fail" : "ok");
      });
      return busy[key];
    }
    function doSave(key) {
      if (key === "titel") return CV.call("analyses/" + id, "PUT", { titel: A.titel });
      if (key === "instr") return CV.call("analyses/" + id, "PUT", { instructie: el.instr ? el.instr.get() : A.instructie }).then(function () { A.instructie = el.instr ? el.instr.get() : A.instructie; });
      var mid = key.slice(2), list = (layers[mid] || []).map(function (it) { return serial(it); }), sent = (layers[mid] || []).map(function (it) { return { id: it.id, o: serial(it) }; });
      return CV.call("analyses/" + id + "/tekeningen", "PUT", { media_id: mid, tekeningen: list }).then(function (res) {
        var srv = (res && res.tekeningen) || [], known = {};
        Object.keys(idmap).forEach(function (k) { known[idmap[k]] = 1; });
        (layers[mid] || []).forEach(function (it) { if (isSrv(it.id)) known[it.id] = 1; });
        var fresh = srv.filter(function (s) { return !known[s.id]; });
        function sig(o) { return o.soort + "|" + JSON.stringify((o.punten || []).map(function (q) { return [Math.round(q[0] * 1e6), Math.round(q[1] * 1e6)]; })) + "|" + (o.van_ms == null ? "" : o.van_ms); }
        sent.forEach(function (s) {
          if (isSrv(s.id) || idmap[s.id]) return;
          var k = -1; fresh.forEach(function (f, i) { if (k < 0 && sig(f) === sig(s.o)) k = i; });
          if (k >= 0) { idmap[s.id] = fresh[k].id; fresh.splice(k, 1); }
        });
      });
    }
    function serial(it) {
      return { id: idmap[it.id] || it.id, soort: it.soort, punten: it.punten.map(function (q) { return [Math.round(q[0] * 1e5) / 1e5, Math.round(q[1] * 1e5) / 1e5]; }), stijl: { kleur: (it.stijl || {}).kleur || "primair", dikte: (it.stijl || {}).dikte || 4 },
               label: it.label || "", waarde: it.waarde == null ? null : it.waarde, van_ms: it.van_ms == null ? null : it.van_ms, tot_ms: it.tot_ms == null ? null : it.tot_ms, opmerking_id: it.opmerking_id || null };
    }
    function flushAll() {
      Object.keys(dirty).forEach(function (k) { clearTimeout(timers[k]); });
      return Promise.all(Object.keys(dirty).map(function (k) { return runSave(k); })).then(function () { return Promise.all(Object.keys(busy).map(function (k) { return busy[k]; })); });
    }
    function retry() { failed = false; Object.keys(dirty).forEach(function (k) { runSave(k); }); if (!Object.keys(dirty).length) setSave("ok"); }
    function track(p) { pend++; setSave("saving"); return p.then(function (r) { pend--; if (!pend) setSave(failed || Object.keys(dirty).length ? "fail" : "ok"); return r; }, function (e) { pend--; if (!pend) setSave(failed || Object.keys(dirty).length ? "fail" : "ok"); throw e; }); }

    /* ---------- loading ---------- */
    root.appendChild(h("p", { class: "muted" }, t("Laden…")));
    CV.call("analyses/" + id).then(function (d) {
      A = d; A.opmerkingen = A.opmerkingen || []; A.tekeningen = A.tekeningen || []; A.instructievideos = A.instructievideos || []; A.momentopnames = A.momentopnames || []; A.sporters = A.sporters || [];
      A.tekeningen.forEach(function (x) { (layers[x.media_id] = layers[x.media_id] || []).push(x); });
      build();
    }).catch(function (e) {
      clear(root); root.appendChild(h("div", { class: "alert" }, errText(e)));
      root.appendChild(h("p", {}, h("button", { type: "button", class: "btn", onclick: function () { CV.back("analyses"); } }, icon("back", 16), " ", t("Terug"))));
    });

    /* ---------- layout ---------- */
    function build() {
      clear(root);
      el.root = h("div", { class: "cv-ed" });
      buildTop(); buildMedia(); buildMain();
      root.appendChild(el.root);
      mi = Math.max(0, A.media.findIndex(function (m) { return m.verwerking === "klaar"; }));
      document.addEventListener("keydown", onKey);
      window.addEventListener("pagehide", flushAll);
      guardTimer = setInterval(function () { if (!root.isConnected) cleanup(); }, 1000);
      if (window.ResizeObserver) { ro = new ResizeObserver(debounce(function () { buildRuler(); renderSvg(); }, 120)); ro.observe(el.root); }
      loadMedia(); updateShare(); renderRemarks(); renderInstr(); loadAi(); updateTabs(); pollMedia();
    }
    function cleanup() {
      if (!alive) return; alive = false;
      document.removeEventListener("keydown", onKey); window.removeEventListener("pagehide", flushAll);
      clearInterval(guardTimer); clearInterval(pollTimer); cancelAnimationFrame(rafId); if (ro) ro.disconnect();
      if (Object.keys(dirty).length) flushAll();
    }

    function buildTop() {
      el.title = h("h1", { class: "cv-ed-title" });
      el.sub = h("div", { class: "cv-ed-sub muted" });
      el.status = h("span", { class: "cv-ed-status" });
      el.save = h("span", { class: "cv-ed-save ok", role: "status", "aria-live": "polite" });
      el.shareBtn = h("button", { type: "button", class: "btn primary", onclick: doShare });
      el.hint = h("div", { class: "cv-ed-hint muted", hidden: true });
      el.menu = h("div", { class: "cv-ed-pop cv-ed-menu", role: "menu", hidden: true });
      var menuBtn = h("button", { type: "button", class: "btn icon-only", "aria-haspopup": "menu", "aria-label": t("Meer acties"), title: t("Meer acties"), onclick: function (e) { e.stopPropagation(); toggleMenu(menuBtn); } }, icon("settings"));
      el.fileIn = h("input", { type: "file", accept: "video/*,image/*,.heic,.heif", hidden: true, "aria-hidden": "true", onchange: function () { if (el.fileIn.files[0]) addMedia(el.fileIn.files[0]); el.fileIn.value = ""; } });
      el.root.appendChild(h("header", { class: "cv-ed-top" },
        CV.iconBtn("back", t("Terug"), function () { flushAll().then(function () { CV.back("analyses"); }); }),
        h("div", { class: "cv-ed-titlebox grow" }, el.title, el.sub),
        el.status, el.save,
        h("div", { class: "row cv-ed-actions" },
          h("button", { type: "button", class: "btn", onclick: function () { flushAll().then(function () { CV.go("bekijk", { id: id }); }); } }, icon("eye", 16), " ", t("Bekijk als sporter")),
          el.shareBtn, h("span", { class: "cv-ed-menuwrap" }, menuBtn, el.menu), el.fileIn)));
      el.root.appendChild(el.hint);
      drawTop();
      document.addEventListener("click", function off() { if (!alive) { document.removeEventListener("click", off); return; } el.menu.hidden = true; if (el.snapPop) el.snapPop.hidden = true; });
    }
    function drawTop() {
      clear(el.title);
      el.title.appendChild(h("button", { type: "button", class: "cv-ed-titlebtn", title: t("Titel wijzigen"), "aria-label": t("Titel wijzigen") + ": " + A.titel, onclick: editTitle }, h("span", {}, A.titel), icon("edit", 15)));
      var names = A.sporters.map(function (s) { return s.name; }).filter(Boolean).join(", ") || t("Nog geen sporter");
      var v = A.media.filter(function (m) { return m.soort === "video" && m.duur_ms; })[0];
      el.sub.textContent = names + " · " + t("geüpload") + " " + when(A.aangemaakt_op) + (v ? " · " + CV.ms(v.duur_ms) : "");
      clear(el.status);
      var first = null; A.sporters.forEach(function (s) { if (s.eerst_bekeken_op && (!first || s.eerst_bekeken_op < first)) first = s.eerst_bekeken_op; });
      if (A.status === "gedeeld" || A.status === "bekeken") el.status.appendChild(CV.badge(A.status, t("Gedeeld") + (first ? " · " + t("bekeken") + " " + when(first) : "")));
      else el.status.appendChild(CV.badge(A.status));
      if (A.gedeeld_op && A.ongepubliceerd) el.status.appendChild(h("span", { class: "badge info" }, t("Wijzigingen niet gedeeld")));
    }
    function editTitle() {
      var inp = h("input", { type: "text", class: "cv-ed-titlein", value: A.titel, maxlength: "160", "aria-label": t("Titel") }), done = false;
      function fin(save) {
        if (done) return; done = true; var v = inp.value.trim();
        if (save && v && v !== A.titel) { A.titel = v; markDirty("titel", 0); }
        drawTop();
      }
      inp.addEventListener("keydown", function (e) { if (e.key === "Enter") fin(true); else if (e.key === "Escape") fin(false); e.stopPropagation(); });
      inp.addEventListener("blur", function () { fin(true); });
      clear(el.title); el.title.appendChild(inp); inp.focus(); inp.select();
    }
    function toggleMenu(anchor) {
      if (!el.menu.hidden) { el.menu.hidden = true; return; }
      clear(el.menu);
      function item(label, ic, fn, danger) { return h("button", { type: "button", role: "menuitem", class: "cv-ed-menuitem" + (danger ? " danger" : ""), onclick: function () { el.menu.hidden = true; fn(); } }, icon(ic, 16), " ", label); }
      el.menu.appendChild(item(t("Beeld toevoegen"), "plus", function () { el.fileIn.click(); }));
      el.menu.appendChild(item(t("Afronden"), "check", function () { act("afronden", t("Analyse afgerond.")); }));
      el.menu.appendChild(item(A.status === "gearchiveerd" ? t("Terugzetten") : t("Archiveren"), "archive", function () { act("archiveren", A.status === "gearchiveerd" ? t("Analyse teruggezet.") : t("Analyse gearchiveerd.")); }));
      el.menu.appendChild(item(t("Verwijderen"), "trash", delAnalysis, true));
      el.menu.hidden = false; var b = el.menu.querySelector("button"); if (b) b.focus();
    }
    function act(path, msg) {
      flushAll().then(function () { return CV.call("analyses/" + id + "/" + path, "POST", {}); }).then(function (r) { A.status = r.status; A.afgerond_op = r.afgerond_op; A.gedeeld_op = r.gedeeld_op; drawTop(); updateShare(); CV.toast(msg); }).catch(CV.fail);
    }
    function delAnalysis() {
      CV.confirmBox(t("Deze analyse met al zijn beelden, tekeningen en opmerkingen verwijderen? Dit kan niet ongedaan worden."), { title: t("Analyse verwijderen"), okLabel: t("Verwijderen"), danger: true }).then(function (ok) {
        if (!ok) return;
        Object.keys(dirty).forEach(function (k) { clearTimeout(timers[k]); delete dirty[k]; });
        CV.call("analyses/" + id, "DELETE").then(function () { cleanup(); CV.go("analyses", {}, true); }).catch(CV.fail);
      });
    }
    function updateShare() {
      if (!el.shareBtn) return;
      var noSp = !A.sporters.length, busyM = A.media.some(processing), first = !A.gedeeld_op, hint = noSp ? t("Kies eerst een sporter om mee te delen.") : busyM ? t("De beelden worden nog verwerkt. Delen kan zo meteen.") : "";
      clear(el.shareBtn); el.shareBtn.appendChild(icon("share", 16)); el.shareBtn.appendChild(document.createTextNode(" " + (first ? t("Delen") : t("Wijzigingen delen"))));
      el.shareBtn.className = "btn " + (first || A.ongepubliceerd ? "primary" : ""); el.shareBtn.disabled = !!hint; el.shareBtn.title = hint || (A.gedeeld_op && !A.ongepubliceerd ? t("Alles is al gedeeld.") : "");
      el.hint.hidden = !hint; el.hint.textContent = hint;
    }
    function doShare() {
      el.shareBtn.disabled = true;
      flushAll().then(function () { return CV.call("analyses/" + id + "/delen", "POST", { melden: true }); }).then(function (r) {
        A.status = r.status; A.gedeeld_op = r.gedeeld_op; A.ongepubliceerd = !!r.ongepubliceerd; A.sporters = r.sporters || A.sporters; drawTop(); updateShare(); CV.toast(t("Gedeeld met de sporter."));
      }).catch(function (e) { updateShare(); CV.fail(e); });
    }

    /* ---------- media switcher, add, poll ---------- */
    function buildMedia() { el.media = h("div", { class: "cv-ed-media", role: "tablist", "aria-label": t("Beelden van deze analyse"), hidden: true }); el.root.appendChild(el.media); }
    function renderSwitcher() {
      clear(el.media); el.media.hidden = A.media.length < 2; if (A.media.length < 2) return;
      A.media.forEach(function (m, i) {
        var thumb = m.poster ? h("img", { src: m.poster, alt: "" }) : h("span", { class: "cv-ed-thumbph" }, icon(m.soort === "video" ? "video" : "image", 20));
        el.media.appendChild(h("span", { class: "cv-ed-mthumb" + (i === mi ? " on" : "") },
          h("button", { type: "button", role: "tab", "aria-selected": i === mi ? "true" : "false", title: m.naam || "", onclick: function () { selectMedia(i); } }, thumb,
            h("span", { class: "cv-ed-mname" }, processing(m) ? t("Verwerken…") : (m.soort === "video" && m.duur_ms ? CV.ms(m.duur_ms) : (m.naam || t("Foto"))))),
          CV.iconBtn("x", t("Beeld verwijderen"), function () { delMedia(m); }, "cv-ed-mdel")));
      });
    }
    function selectMedia(i) { if (i === mi && M) return; mi = i; loadMedia(); }
    function delMedia(m) {
      CV.confirmBox(t("Dit beeld met zijn tekeningen en opmerkingen verwijderen?"), { title: t("Beeld verwijderen"), okLabel: t("Verwijderen"), danger: true }).then(function (ok) {
        if (!ok) return;
        CV.call("media/" + m.id, "DELETE").then(function () {
          A.media = A.media.filter(function (x) { return x.id !== m.id; }); A.opmerkingen = A.opmerkingen.filter(function (r) { return r.media_id !== m.id; }); delete layers[m.id]; delete hists[m.id];
          mi = Math.min(mi, Math.max(0, A.media.length - 1)); M = null; loadMedia(); renderRemarks(); updateTabs(); updateShare(); drawTop();
        }).catch(CV.fail);
      });
    }
    function addMedia(file) {
      el.stageBusy = true; showOverlay(t("Uploaden…"));
      CV.upload("analyses/" + id + "/media", file, {}).then(function (m) { A.media.push(m); mi = A.media.length - 1; el.stageBusy = false; loadMedia(); updateShare(); pollMedia(); }).catch(function (e) { el.stageBusy = false; loadMedia(); CV.fail(e); });
    }
    function pollMedia() {
      clearInterval(pollTimer);
      if (!A.media.some(processing)) return;
      pollTimer = setInterval(function () {
        if (!alive) return;
        var todo = A.media.filter(processing);
        if (!todo.length) { clearInterval(pollTimer); return; }
        todo.forEach(function (m) {
          CV.call("media/" + m.id).then(function (d) {
            var was = m.verwerking; Object.assign(m, d);
            if (was !== d.verwerking) { renderSwitcher(); updateShare(); drawTop(); if (A.media[mi] && A.media[mi].id === m.id) { M = null; loadMedia(); } }
          }).catch(function () {});
        });
      }, 3000);
    }

    /* ---------- main grid: toolbar, stage, timeline, panel ---------- */
    function buildMain() {
      el.toolbar = buildToolbar();
      el.stage = h("div", { class: "e2e-annot cv-ed-stage", tabindex: "0", "aria-label": t("Beeld met tekenlaag") });
      el.selbar = buildSelbar();
      el.tl = buildTimeline();
      el.work = h("div", { class: "cv-ed-work" }, el.toolbar, h("div", { class: "cv-ed-stagecol" }, el.stage, el.selbar, el.tl));
      el.panel = buildPanel();
      el.root.appendChild(h("div", { class: "cv-ed-main" }, el.work, el.panel));
    }

    /* ----- toolbar ----- */
    function buildToolbar() {
      var tb = h("div", { class: "e2e-toolbar cv-ed-toolbar", role: "toolbar", "aria-label": t("Tekengereedschap"), "aria-orientation": "vertical" });
      el.toolBtns = {};
      [["select", "cursor", t("Selecteren")], ["lijn", "line", t("Lijn")], ["pijl", "arrow", t("Pijl")], ["hoek", "angle", t("Hoek")], ["cirkel", "circle", t("Cirkel")], ["vrij", "free", t("Vrije hand")], ["tekst", "text", t("Tekst")]].forEach(function (d) {
        var b = h("button", { type: "button", class: "e2e-toolbar__btn", "aria-pressed": "false", "aria-label": d[2], title: d[2], onclick: function () { setTool(d[0]); } }, icon(d[1], 20));
        el.toolBtns[d[0]] = b; tb.appendChild(b);
      });
      tb.appendChild(h("span", { class: "e2e-toolbar__sep", role: "separator" }));
      el.swatches = {};
      [["primair", "primary", t("Kleur: hoofdkleur")], ["licht", "light", t("Kleur: licht")], ["accent", "accent", t("Kleur: accent")]].forEach(function (d) {
        var b = h("button", { type: "button", class: "e2e-swatch e2e-swatch--" + d[1], "aria-pressed": "false", "aria-label": d[2], title: d[2], onclick: function () { setColor(d[0]); } });
        el.swatches[d[0]] = b; tb.appendChild(b);
      });
      el.dikBtns = {};
      DIKTES.forEach(function (n, i) {
        var lab = [t("Dun"), t("Gemiddeld"), t("Dik")][i];
        var b = h("button", { type: "button", class: "e2e-toolbar__btn cv-ed-dikbtn", "aria-pressed": "false", "aria-label": t("Lijndikte") + ": " + lab, title: t("Lijndikte") + ": " + lab, onclick: function () { setDikte(n); } }, h("span", { class: "cv-ed-dik", style: "height:" + (i * 2 + 2) + "px" }));
        el.dikBtns[n] = b; tb.appendChild(b);
      });
      tb.appendChild(h("span", { class: "e2e-toolbar__sep", role: "separator" }));
      el.undoBtn = h("button", { type: "button", class: "e2e-toolbar__btn", "aria-label": t("Ongedaan maken"), title: t("Ongedaan maken") + " (Ctrl+Z)", onclick: undo }, icon("undo", 20));
      el.redoBtn = h("button", { type: "button", class: "e2e-toolbar__btn", "aria-label": t("Opnieuw"), title: t("Opnieuw") + " (Ctrl+Shift+Z)", onclick: redo }, icon("redo", 20));
      el.clearBtn = h("button", { type: "button", class: "e2e-toolbar__btn", "aria-label": t("Laag wissen"), title: t("Laag wissen"), onclick: clearLayer }, icon("trash", 20));
      tb.appendChild(el.undoBtn); tb.appendChild(el.redoBtn); tb.appendChild(el.clearBtn);
      refreshToolbar(); return tb;
    }
    function refreshToolbar() {
      Object.keys(el.toolBtns).forEach(function (k) { pressed(el.toolBtns[k], k === tool); });
      Object.keys(el.swatches).forEach(function (k) { pressed(el.swatches[k], k === color); });
      Object.keys(el.dikBtns).forEach(function (k) { pressed(el.dikBtns[k], Number(k) === dikte); });
      var hs = M ? histOf(M.id) : null; el.undoBtn.disabled = !hs || !hs.canUndo(); el.redoBtn.disabled = !hs || !hs.canRedo(); el.clearBtn.disabled = !layer().length;
      if (svg) { svg.style.cursor = tool === "select" ? "default" : "crosshair"; svg.style.touchAction = tool === "select" && !sel ? "pan-y" : "none"; }
      var hints = { select: "Klik op een tekening om hem te kiezen, sleep om te verplaatsen.", lijn: "Klik en sleep van begin naar einde.", pijl: "Klik en sleep van begin naar einde.", hoek: "Klik drie punten: begin, hoekpunt en einde.", cirkel: "Klik op het middelpunt en sleep naar de rand.", vrij: "Teken met de muis of je vinger.", tekst: "Klik op het beeld en typ het label." };
      if (el.toolHint) el.toolHint.textContent = t(hints[tool]);
    }
    function setTool(k) { cancelDraft(); tool = k; if (k !== "select") sel = null; refreshToolbar(); renderSvg(); updateSelbar(); }
    function setColor(k) { color = k; var it = byId(sel); if (it) { it.stijl = Object.assign({}, it.stijl, { kleur: k }); commit(); renderSvg(); } refreshToolbar(); }
    function setDikte(n) { dikte = n; var it = byId(sel); if (it) { it.stijl = Object.assign({}, it.stijl, { dikte: n }); commit(); renderSvg(); } refreshToolbar(); }

    /* ----- selection bar ----- */
    function buildSelbar() {
      el.toolHint = h("div", { class: "cv-ed-toolhint muted", "aria-live": "polite" });
      el.selInfo = h("span", { class: "cv-ed-selinfo" });
      el.labelIn = h("input", { type: "text", class: "cv-ed-labelin", maxlength: "80", placeholder: t("Label (optioneel)"), "aria-label": t("Label van de tekening"),
        oninput: function () { var it = byId(sel); if (!it) return; it.label = el.labelIn.value.slice(0, 80); renderSvg(); markDirty("l:" + M.id); }, onchange: function () { commit(true); } });
      el.selDel = h("button", { type: "button", class: "btn", onclick: removeSelected }, icon("trash", 15), " ", t("Verwijderen"));
      el.selWrap = h("div", { class: "cv-ed-selwrap", hidden: true }, el.selInfo, el.labelIn, el.selDel);
      return h("div", { class: "cv-ed-selbar" }, el.toolHint, el.selWrap);
    }
    function updateSelbar() {
      var it = byId(sel); el.selWrap.hidden = !it; refreshToolbar();
      if (!it) return;
      clear(el.selInfo); el.selInfo.appendChild(icon(KIND_ICON[it.soort], 16));
      var txt = t(KINDS[it.soort]) + (it.soort === "hoek" ? " " + String(it.waarde == null ? "" : it.waarde).replace(".", ",") + "°" : "");
      el.selInfo.appendChild(document.createTextNode(" " + txt));
      if (document.activeElement !== el.labelIn) el.labelIn.value = it.label || "";
      el.labelIn.placeholder = it.soort === "tekst" ? t("Tekst") : t("Label (optioneel)");
    }

    /* ---------- the stage ---------- */
    function showOverlay(text, retryFn, spin) {
      if (!box) { box = h("div", { class: "cv-ed-box" }); clear(el.stage); el.stage.appendChild(box); }
      var old = box.querySelector(".cv-ed-over"); if (old) old.remove();
      box.appendChild(h("div", { class: "cv-ed-over", role: "status" }, spin === false ? null : h("span", { class: "cv-ed-spin", "aria-hidden": "true" }), h("div", {}, text), retryFn ? h("button", { type: "button", class: "btn primary", onclick: retryFn }, t("Opnieuw proberen")) : null));
    }
    function setBox(w, hh) {
      dims = { w: w || dims.w, h: hh || dims.h }; ratio = dims.h / dims.w;
      box.style.aspectRatio = dims.w + " / " + dims.h; box.style.setProperty("--ar", dims.w / dims.h); box.style.width = "min(100%, " + Math.round(540 * dims.w / dims.h) + "px)";
      if (svg) CV.draw.setup(svg, dims.w, dims.h);
    }
    function loadMedia() {
      cancelAnimationFrame(rafId); cancelDraft(); closeText();
      if (vid) { try { vid.pause(); } catch (e) {} }
      vid = null; pic = null; svg = null; box = null; ms = 0; lastT = 0; loop = { on: false, a: null, b: null };
      M = A.media[mi] || null; clear(el.stage); renderSwitcher();
      el.stage.classList.toggle("is-photo", !!M && M.soort !== "video");
      if (!M) {
        el.stage.appendChild(h("div", { class: "cv-ed-empty" }, icon("upload", 32), h("p", {}, t("Er zijn nog geen beelden bij deze analyse.")), h("button", { type: "button", class: "btn primary", onclick: function () { el.fileIn.click(); } }, icon("plus", 16), " ", t("Beeld toevoegen"))));
        el.tl.hidden = true; refreshToolbar(); updateSelbar(); return;
      }
      box = h("div", { class: "cv-ed-box" }); el.stage.appendChild(box);
      svg = svgEl("svg", { class: "e2e-annot__svg cv-ed-svg", "aria-label": t("Tekenlaag over het beeld") });
      box.appendChild(h("div", { class: "e2e-annot__media cv-ed-mediawrap" }));
      setBox(M.breedte, M.hoogte);
      var mw = box.firstChild;
      if (M.verwerking !== "klaar") {
        el.tl.hidden = true; box.appendChild(svg);
        if (processing(M)) showOverlay(t("Verwerken…")); else showOverlay(t("Verwerken is mislukt.") + (M.fout ? " " + M.fout : ""), function () { retryMedia(M); });
        refreshToolbar(); updateSelbar(); return;
      }
      if (M.soort === "video") {
        vid = h("video", { class: "cv-ed-pic", crossorigin: "anonymous", src: M.url, poster: M.poster || null, playsinline: true, preload: "metadata", "aria-label": M.naam || t("Video"), tabindex: "-1" });
        vid.disablePictureInPicture = true;
        ["timeupdate", "seeked", "seeking", "loadedmetadata", "durationchange"].forEach(function (n) { vid.addEventListener(n, function () { if (n === "seeked" || n === "seeking") lastT = vid.currentTime * 1000; onTime(); if (n === "loadedmetadata") metaReady(); }); });
        vid.addEventListener("play", function () { syncPlay(); cancelAnimationFrame(rafId); rafId = requestAnimationFrame(frameLoop); });
        vid.addEventListener("pause", syncPlay); vid.addEventListener("ended", syncPlay);
        vid.addEventListener("error", function () { showOverlay(t("Deze video kan niet worden afgespeeld."), null, false); });
        mw.appendChild(vid);
      } else {
        pic = h("img", { class: "cv-ed-pic", src: M.url, alt: M.naam || t("Foto"), draggable: "false" });
        pic.addEventListener("load", function () { if (pic.naturalWidth) { setBox(pic.naturalWidth, pic.naturalHeight); renderSvg(); } });
        pic.addEventListener("error", function () { showOverlay(t("Deze foto kan niet worden geladen."), null, false); });
        mw.appendChild(pic);
      }
      box.appendChild(svg);
      svg.addEventListener("pointerdown", onDown); svg.addEventListener("pointermove", onMove); svg.addEventListener("pointerup", onUp); svg.addEventListener("pointercancel", onCancel);
      svg.addEventListener("dblclick", function () { if (byId(sel)) el.labelIn.focus(); });
      svg.addEventListener("contextmenu", function (e) { if (tool !== "select") e.preventDefault(); });
      box.addEventListener("pointerdown", function () { el.stage.focus({ preventScroll: true }); });
      if (isVideo()) el.stage.appendChild(buildControls());
      el.tl.hidden = !isVideo();
      histOf(M.id); refreshToolbar(); updateSelbar(); renderSvg(); refreshTl(); buildRuler(); highlightRemark(activeRemark);
      if (pendingSeek != null && isVideo()) { var ps = pendingSeek; pendingSeek = null; vid.addEventListener("loadedmetadata", function () { seek(ps); }, { once: true }); }
      CV.draw.setup(svg, dims.w, dims.h);
      renderSvg(); resizeFrame();
    }
    function metaReady() {
      if (vid.videoWidth && vid.videoHeight && (Math.abs(vid.videoWidth / vid.videoHeight - dims.w / dims.h) > 0.01)) setBox(vid.videoWidth, vid.videoHeight);
      buildRuler(); refreshTl(); onTime(); renderSvg();
    }
    function resizeFrame() { try { system.resize && system.resize(document.documentElement.scrollHeight); } catch (e) {} }
    function retryMedia(m) { CV.call("media/" + m.id + "/opnieuw", "POST", {}).then(function (d) { Object.assign(m, d); loadMedia(); pollMedia(); }).catch(CV.fail); }

    /* ----- the controls bar ----- */
    function buildControls() {
      el.playBtn = h("button", { type: "button", class: "btn primary cv-ed-play", "aria-label": t("Afspelen"), title: t("Afspelen") + " (Space)", onclick: togglePlay }, icon("play", 22));
      el.timeLbl = h("span", { class: "e2e-annot__time cv-ed-time", "aria-live": "off" }, "0:00.0 / 0:00.0");
      el.speed = h("select", { class: "cv-ed-speed", "aria-label": t("Afspeelsnelheid"), onchange: function () { vid.playbackRate = parseFloat(el.speed.value); } },
        [["0.25", "0,25×"], ["0.5", "0,5×"], ["1", "1×"]].map(function (o) { return h("option", { value: o[0], selected: o[0] === "1" }, o[1]); }));
      el.loopBtn = h("button", { type: "button", class: "btn ghost icon-only", "aria-pressed": "false", "aria-label": t("Herhalen"), title: t("Herhalen"), onclick: toggleLoop }, icon("repeat"));
      el.loopA = h("button", { type: "button", class: "btn ghost cv-ed-loopmark", hidden: true, title: t("Begin van de herhaling hier"), onclick: function () { loop.a = curMs(); if (loop.b != null && loop.b <= loop.a) loop.b = null; applyLoop(); } }, "[");
      el.loopB = h("button", { type: "button", class: "btn ghost cv-ed-loopmark", hidden: true, title: t("Einde van de herhaling hier"), onclick: function () { loop.b = curMs(); if (loop.a != null && loop.a >= loop.b) loop.a = null; applyLoop(); } }, "]");
      el.snapBtn = h("button", { type: "button", class: "btn ghost icon-only", "aria-haspopup": "menu", "aria-label": t("Momentopname maken"), title: t("Momentopname maken"), onclick: function (e) { e.stopPropagation(); toggleSnapMenu(); } }, icon("camera"));
      el.snapPop = h("div", { class: "cv-ed-pop cv-ed-snapmenu", role: "menu", hidden: true },
        h("button", { type: "button", role: "menuitem", class: "cv-ed-menuitem", onclick: function () { el.snapPop.hidden = true; doSnap(true); } }, t("Met tekening")),
        h("button", { type: "button", role: "menuitem", class: "cv-ed-menuitem", onclick: function () { el.snapPop.hidden = true; doSnap(false); } }, t("Zonder tekening")));
      var cmp = h("button", { type: "button", class: "btn ghost icon-only", disabled: true, title: t("Binnenkort"), "aria-label": t("Naast elkaar vergelijken") + " (" + t("Binnenkort") + ")" }, icon("columns"));
      var fs = h("button", { type: "button", class: "btn ghost icon-only", "aria-label": t("Volledig scherm"), title: t("Volledig scherm"), onclick: fullscreen }, icon("fullscreen"));
      return h("div", { class: "e2e-annot__controls cv-ed-controls" },
        h("button", { type: "button", class: "btn ghost icon-only", "aria-label": t("Een beeld terug"), title: t("Een beeld terug") + " (←)", onclick: function () { step(-1); } }, icon("stepBack")), el.playBtn,
        h("button", { type: "button", class: "btn ghost icon-only", "aria-label": t("Een beeld vooruit"), title: t("Een beeld vooruit") + " (→)", onclick: function () { step(1); } }, icon("stepFwd")),
        el.timeLbl, h("span", { class: "grow" }), el.speed, el.loopA, el.loopB, el.loopBtn, h("span", { class: "cv-ed-snapwrap" }, el.snapBtn, el.snapPop), cmp, fs);
    }
    function syncPlay() {
      if (!el.playBtn || !vid) return; var pl = !vid.paused && !vid.ended;
      clear(el.playBtn); el.playBtn.appendChild(icon(pl ? "pause" : "play", 22)); el.playBtn.setAttribute("aria-label", pl ? t("Pauzeren") : t("Afspelen")); el.playBtn.title = (pl ? t("Pauzeren") : t("Afspelen")) + " (Space)";
    }
    function togglePlay() { if (!vid) return; if (vid.paused || vid.ended) { if (vid.ended) vid.currentTime = 0; lastT = vid.currentTime * 1000; var p = vid.play(); if (p && p.catch) p.catch(function () {}); } else vid.pause(); }
    function step(dir) { if (!vid) return; vid.pause(); seek(Math.round(vid.currentTime * 1000 + dir * 1000 / fps() + (dir > 0 ? 0.5 : -0.5))); }
    function seek(msv) { if (!vid) return; var d = dur(); msv = L.clamp(msv, 0, d || msv); vid.currentTime = msv / 1000; lastT = msv; ms = msv; onTime(true); }
    function toggleLoop() { loop.on = !loop.on; if (!loop.on) { loop.a = loop.b = null; } applyLoop(); }
    function applyLoop() { if (!vid) return; pressed(el.loopBtn, loop.on); el.loopA.hidden = el.loopB.hidden = !loop.on; vid.loop = loop.on && loop.a == null && loop.b == null; refreshTl(); }
    function fullscreen() { try { var f = document.fullscreenElement ? document.exitFullscreen() : el.stage.requestFullscreen(); if (f && f.catch) f.catch(function () { CV.toast(t("Volledig scherm is hier niet beschikbaar."), false); }); } catch (e) { CV.toast(t("Volledig scherm is hier niet beschikbaar."), false); } }
    function toggleSnapMenu() { el.snapPop.hidden = !el.snapPop.hidden; if (!el.snapPop.hidden) el.snapPop.firstChild.focus(); }
    function doSnap(withDrawing) { takeSnapshot(withDrawing).then(function () { CV.toast(t("Momentopname opgeslagen.")); }).catch(CV.fail); }

    /* the frame loop while playing: remarks that pause, loops, the playhead */
    function frameLoop() { if (!alive || !vid || vid.paused || vid.ended) return; onTime(); rafId = requestAnimationFrame(frameLoop); }
    function onTime(force) {
      if (!vid) return;
      var cur = vid.currentTime * 1000, playing = !vid.paused && !vid.ended;
      if (playing) {
        if (cur < lastT - 300) lastT = cur;  // wrapped (loop) or jumped back
        var hit = null;
        A.opmerkingen.forEach(function (r) { if (r.pauzeren && r.media_id === M.id && r.tijd_ms != null && r.tijd_ms > lastT && r.tijd_ms <= cur && (!hit || r.tijd_ms < hit.tijd_ms)) hit = r; });
        if (hit) { vid.pause(); vid.currentTime = hit.tijd_ms / 1000; cur = hit.tijd_ms; lastT = cur; ms = cur; showRemark(hit, true); }
        else if (loop.on && (loop.a != null || loop.b != null)) {
          var b = loop.b != null ? loop.b : dur(), a = loop.a || 0;
          if (cur >= b - 20 || cur < a - 300) { vid.currentTime = a / 1000; cur = a; lastT = a - 1; }
        }
        if (!hit) lastT = cur;
      }
      ms = cur; updateHead(cur); var sig = visSigNow(); if (sig !== visSig || force) { renderSvg(); }
    }
    function visSigNow() { return layer().filter(function (x) { return visibleAt(x, ms); }).map(function (x) { return x.id; }).join(",") + "|" + sel + "|" + (draft ? 1 : 0); }
    function updateHead(cur) {
      var d = dur(), f = L.frac(cur, d);
      if (el.timeLbl) el.timeLbl.textContent = CV.ms(cur, true) + " / " + CV.ms(d, true);
      if (el.head) { el.head.style.left = "calc(var(--lw) + (100% - var(--lw)) * " + f + ")"; el.fill.style.width = (f * 100) + "%"; el.track.setAttribute("aria-valuenow", String(Math.round(cur))); el.track.setAttribute("aria-valuetext", CV.ms(cur, true)); el.track.setAttribute("aria-valuemax", String(Math.round(d))); }
      if (el.addLbl) { var s = isVideo() ? t("Opmerking op {0}", CV.ms(cur, true)) : t("Opmerking bij dit beeld"); if (el.addLbl.textContent !== s) el.addLbl.textContent = s; }
    }

    /* ---------- drawing on the svg ---------- */
    function renderSvg() {
      if (!svg || !M) return;
      var list = layer().slice(); if (draft) list.push(draft);
      CV.draw.render(svg, list, isVideo() ? ms : null, { onlyFor: M.id, selectedId: sel });
      visSig = visSigNow();
      var g = svgEl("g", { class: "cv-ed-handles", "pointer-events": "none" }), it = byId(sel), rect = svg.getBoundingClientRect(), u = 1000 / (rect.width || 1000), V = CV.draw.size();
      if (it && !draft && visibleAt(it, ms)) {
        var P = it.punten.map(CV.draw.px), x0 = 1e9, y0 = 1e9, x1 = -1e9, y1 = -1e9, pad = 22 * Math.max(1, u * 0.6);
        P.forEach(function (q) { x0 = Math.min(x0, q[0]); y0 = Math.min(y0, q[1]); x1 = Math.max(x1, q[0]); y1 = Math.max(y1, q[1]); });
        if (it.soort === "cirkel" && P.length > 1) { var rr = Math.hypot(P[1][0] - P[0][0], P[1][1] - P[0][1]); x0 = P[0][0] - rr; x1 = P[0][0] + rr; y0 = P[0][1] - rr; y1 = P[0][1] + rr; }
        if (it.soort === "tekst") { var hw = ((it.label || "").length * 8.5 + 16), hy = 24; x0 -= hw; x1 += hw; y0 -= hy; y1 += hy; }
        g.appendChild(svgEl("rect", { x: x0 - pad, y: y0 - pad, width: x1 - x0 + pad * 2, height: y1 - y0 + pad * 2, rx: 12, fill: "none", stroke: "var(--e2e-primary, var(--blue, #f0833a))", "stroke-width": 3 * Math.max(1, u * 0.5), "stroke-dasharray": "14 10", opacity: ".85" }));
        var hr = Math.max(14, 9 * u);
        L.handles(it).forEach(function (q) { var c = CV.draw.px(q); g.appendChild(svgEl("circle", { cx: c[0], cy: c[1], r: hr, fill: "var(--e2e-card, #fff)", stroke: "var(--e2e-primary, var(--blue, #f0833a))", "stroke-width": hr / 3 })); });
      }
      if (angPts && angPts.length && !draft) angPts.forEach(function (q) { var c = CV.draw.px(q); g.appendChild(svgEl("circle", { cx: c[0], cy: c[1], r: Math.max(10, 7 * u), fill: "var(--e2e-primary, var(--blue, #f0833a))" })); });
      svg.appendChild(g); void V;
    }
    function ptOf(e) { return L.toNorm(svg.getBoundingClientRect(), e.clientX, e.clientY); }
    function tolOf(e) { var w = svg.getBoundingClientRect().width || 800; return (e.pointerType === "touch" ? 18 : 9) / w; }
    function hrOf(e) { var w = svg.getBoundingClientRect().width || 800; return (e.pointerType === "touch" ? 24 : 13) / w; }
    function style() { return { kleur: color, dikte: dikte }; }
    function mkDraft(kind, pts) { return { id: "draft", media_id: M.id, soort: kind, punten: pts, stijl: style(), label: "", waarde: null, van_ms: null, tot_ms: null }; }
    function cancelDraft() { draft = null; angPts = null; gesture = null; if (svg) renderSvg(); }

    function onDown(e) {
      if (!M || (e.pointerType === "mouse" && e.button !== 0)) return;
      var p = ptOf(e);
      if (textBox) { finishText(true); }
      if (tool === "select") return selectDown(e, p);
      e.preventDefault();
      if (tool === "tekst") { startText(p); return; }
      try { svg.setPointerCapture(e.pointerId); } catch (x) {}
      if (tool === "hoek") {
        angPts = angPts || []; angPts.push(p); gesture = { kind: "hoekpt", pid: e.pointerId }; hoekDraft(null); return;
      }
      gesture = { kind: tool, pid: e.pointerId, p0: p, pts: [p] };
      draft = mkDraft(tool, tool === "vrij" ? [p, p] : [p, p]); renderSvg();
    }
    function hoekDraft(cursor) {
      var P = angPts.slice(); if (cursor && P.length < 3) P.push(cursor);
      if (P.length === 2) draft = mkDraft("lijn", P); else if (P.length === 3) draft = mkDraft("hoek", P); else draft = null;
      renderSvg();
    }
    function onMove(e) {
      if (!M) return;
      var p = ptOf(e);
      if (gesture && gesture.pid === e.pointerId) {
        if (gesture.kind === "hoekpt") { angPts[angPts.length - 1] = p; hoekDraft(null); return; }
        if (gesture.kind === "lijn" || gesture.kind === "pijl" || gesture.kind === "cirkel") { draft.punten = [gesture.p0, p]; renderSvg(); return; }
        if (gesture.kind === "vrij") { var last = gesture.pts[gesture.pts.length - 1]; if (Math.hypot(p[0] - last[0], (p[1] - last[1]) * ratio) > 0.004) { gesture.pts.push(p); draft.punten = gesture.pts.length > 1 ? gesture.pts.slice() : [p, p]; renderSvg(); } return; }
        if (gesture.kind === "move" || gesture.kind === "handle") return dragMove(p);
        return;
      }
      if (tool === "hoek" && angPts && angPts.length && angPts.length < 3 && e.pointerType === "mouse") { hoekDraft(p); return; }
      if (tool === "select" && e.pointerType === "mouse") { var over = layer().some(function (it) { return visibleAt(it, ms) && L.hit(it, p, tolOf(e), ratio); }); svg.style.cursor = over ? "move" : "default"; }
    }
    function onUp(e) {
      if (!gesture || gesture.pid !== e.pointerId) return;
      var g = gesture; gesture = null; try { svg.releasePointerCapture(e.pointerId); } catch (x) {}
      if (g.kind === "hoekpt") { if (angPts.length === 3) { var P = angPts.slice(); angPts = null; draft = null; var it = { soort: "hoek", punten: P, waarde: L.angle(P[0], P[1], P[2], ratio), label: "" }; addItem(it); } else hoekDraft(null); return; }
      if (g.kind === "lijn" || g.kind === "pijl" || g.kind === "cirkel") {
        var q = draft.punten; draft = null;
        if (Math.hypot(q[1][0] - q[0][0], (q[1][1] - q[0][1]) * ratio) < 0.012) { renderSvg(); return; }
        addItem({ soort: g.kind, punten: q, label: "" }); return;
      }
      if (g.kind === "vrij") {
        var pts = L.decimate(g.pts, 400); draft = null;
        if (pts.length < 2) { renderSvg(); return; }
        addItem({ soort: "vrij", punten: pts, label: "" }); return;
      }
      if (g.kind === "move" || g.kind === "handle") { if (g.moved) commit(); renderSvg(); updateSelbar(); }
    }
    function onCancel(e) { if (gesture && gesture.pid === e.pointerId) { var g = gesture; if ((g.kind === "move" || g.kind === "handle") && g.orig) { var it = byId(sel); if (it) it.punten = g.orig; } cancelDraft(); renderSvg(); } }

    function addItem(it) {
      it.id = nid(); it.media_id = M.id; it.stijl = style();
      if (isVideo()) { var r = L.defaultRange(curMs(), dur()); it.van_ms = r.van; it.tot_ms = r.tot; } else { it.van_ms = null; it.tot_ms = null; }
      layer().push(it); freshIds[it.id] = 1; sel = it.id; tool = "select"; commit(); renderSvg(); updateSelbar();
    }
    /* select tool: handles of the selected drawing first, then the drawing under the pointer (the top one) */
    function selectDown(e, p) {
      var it = byId(sel), r = ratio;
      if (it && visibleAt(it, ms)) {
        var hi = L.handleAt(it, p, hrOf(e), r);
        if (hi >= 0) { e.preventDefault(); startDrag(e, "handle", hi, p, it); return; }
        if (L.hit(it, p, tolOf(e), r)) { e.preventDefault(); startDrag(e, "move", -1, p, it); return; }
      }
      var list = layer(), found = null, i;
      for (i = list.length - 1; i >= 0; i--) if (visibleAt(list[i], ms) && L.hit(list[i], p, tolOf(e), r)) { found = list[i]; break; }
      if (found) { sel = found.id; e.preventDefault(); startDrag(e, "move", -1, p, found); }
      else sel = null;
      renderSvg(); updateSelbar(); refreshTl();
    }
    function startDrag(e, kind, idx, p, it) {
      try { svg.setPointerCapture(e.pointerId); } catch (x) {}
      gesture = { kind: kind, idx: idx, p0: p, pid: e.pointerId, orig: copy(it.punten), moved: false };
      renderSvg(); updateSelbar(); refreshTl();
    }
    function dragMove(p) {
      var it = byId(sel); if (!it || !gesture) return;
      var dx = p[0] - gesture.p0[0], dy = p[1] - gesture.p0[1];
      if (!gesture.moved && Math.hypot(dx, dy * ratio) < 0.004) return;
      gesture.moved = true;
      if (gesture.kind === "move") it.punten = L.moveBy(gesture.orig, dx, dy);
      else if (it.soort === "cirkel" && gesture.idx === 0) it.punten = L.moveBy(gesture.orig, dx, dy);
      else { it.punten = copy(gesture.orig); it.punten[gesture.idx] = p; }
      if (it.soort === "hoek") it.waarde = L.angle(it.punten[0], it.punten[1], it.punten[2], ratio);
      renderSvg(); updateSelbar();
    }
    function removeSelected() { var it = byId(sel); if (!it) return; layers[M.id] = layer().filter(function (x) { return x !== it; }); sel = null; commit(); renderSvg(); updateSelbar(); }
    /* text tool: a small inline input at the clicked place */
    function startText(p) {
      var inp = h("input", { type: "text", class: "cv-ed-textin", maxlength: "80", "aria-label": t("Tekst voor op het beeld"), placeholder: t("Typ een label"), style: "left:" + (p[0] * 100) + "%;top:" + (p[1] * 100) + "%" });
      textBox = { inp: inp, p: p, done: false };
      inp.addEventListener("keydown", function (e) { e.stopPropagation(); if (e.key === "Enter") finishText(true); else if (e.key === "Escape") finishText(false); });
      inp.addEventListener("blur", function () { finishText(true); });
      inp.addEventListener("pointerdown", function (e) { e.stopPropagation(); });
      box.appendChild(inp); setTimeout(function () { inp.focus(); }, 0);
    }
    function finishText(save) {
      if (!textBox || textBox.done) return; var b = textBox; b.done = true; textBox = null;
      var v = b.inp.value.trim(); b.inp.remove();
      if (save && v) addItem({ soort: "tekst", punten: [b.p], label: v.slice(0, 80) });
    }
    function closeText() { if (textBox) { textBox.done = true; try { textBox.inp.remove(); } catch (e) {} textBox = null; } }

    /* history */
    function commit(labelOnly) {
      if (!M) return; var hs = histOf(M.id); hs.push(JSON.stringify(layer()));
      markDirty("l:" + M.id); refreshToolbar(); refreshTl(); if (!labelOnly) renderSvg();
    }
    function restore(state) {
      if (state == null) return; layers[M.id] = JSON.parse(state); if (!byId(sel)) sel = null;
      markDirty("l:" + M.id); renderSvg(); updateSelbar(); refreshTl();
    }
    function undo() { if (!M) return; cancelDraft(); restore(histOf(M.id).undo()); }
    function redo() { if (!M) return; cancelDraft(); restore(histOf(M.id).redo()); }
    function clearLayer() {
      if (!layer().length) return;
      CV.confirmBox(t("Alle tekeningen op dit beeld wissen?"), { title: t("Laag wissen"), okLabel: t("Wissen"), danger: true }).then(function (ok) { if (!ok) return; layers[M.id] = []; sel = null; commit(); updateSelbar(); });
    }

    /* keyboard */
    function onKey(e) {
      if (!alive) return;
      if (!root.isConnected) { cleanup(); return; }
      var tg = e.target, tag = tg && tg.tagName, typing = tag === "INPUT" || tag === "TEXTAREA" || tag === "SELECT" || (tg && tg.isContentEditable);
      if (document.querySelector(".cv-overlay")) return;
      var mod = e.ctrlKey || e.metaKey;
      if (e.key === "Escape") { if (draft || angPts || gesture || textBox) { cancelDraft(); closeText(); } else if (tool !== "select") setTool("select"); else if (sel) { sel = null; renderSvg(); updateSelbar(); } return; }
      if (typing) return;
      if (mod && (e.key === "z" || e.key === "Z")) { e.preventDefault(); if (e.shiftKey) redo(); else undo(); return; }
      if (mod && (e.key === "y" || e.key === "Y")) { e.preventDefault(); redo(); return; }
      if (e.key === "Delete" || e.key === "Backspace") { if (sel) { e.preventDefault(); removeSelected(); } return; }
      if (!vid || mod || e.altKey) return;
      if (e.key === " " && tag !== "BUTTON" && tag !== "A") { e.preventDefault(); togglePlay(); }
      else if (e.key === "ArrowLeft" && !(tg && tg.getAttribute && tg.getAttribute("role") === "slider")) { e.preventDefault(); step(-1); }
      else if (e.key === "ArrowRight" && !(tg && tg.getAttribute && tg.getAttribute("role") === "slider")) { e.preventDefault(); step(1); }
    }

    /* ---------- snapshot ---------- */
    function resolveVars(str) {
      var cs = getComputedStyle(document.documentElement), n = 0;
      while (/var\(/.test(str) && n++ < 8) str = str.replace(/var\((--[\w-]+)\s*(?:,\s*([^()]*))?\)/g, function (m, name, fb) { var v = cs.getPropertyValue(name).trim(); return v || (fb || "").trim() || "#888"; });
      return str;
    }
    function takeSnapshot(withDrawing) {
      if (!M) return Promise.reject(new Error(t("Er is geen beeld.")));
      var src = isVideo() ? vid : pic, w0 = isVideo() ? (vid && vid.videoWidth) : (pic && pic.naturalWidth), h0 = isVideo() ? vid.videoHeight : (pic && pic.naturalHeight);
      if (!src || !w0) return Promise.reject(new Error(t("Het beeld is nog niet geladen.")));
      var k = Math.min(1, 1568 / Math.max(w0, h0)), W = Math.round(w0 * k), H = Math.round(h0 * k), cv = document.createElement("canvas"), c;
      cv.width = W; cv.height = H; c = cv.getContext("2d");
      var tMs = curMs(), mid = M.id, items = copy(layer()), mdims = { w: dims.w, h: dims.h };
      function paint(s) { c.drawImage(s, 0, 0, W, H); c.getImageData(0, 0, 1, 1); }
      /* the picture can be "tainted" in the sandboxed frame; then a second, CORS-enabled element is tried */
      function cors() {
        return new Promise(function (res, rej) {
          var bad = function () { rej(new Error(t("Dit beeld kan niet worden vastgelegd door de beveiliging van de browser."))); };
          if (isVideo()) {
            var v2 = document.createElement("video"); v2.crossOrigin = "anonymous"; v2.muted = true; v2.preload = "auto"; v2.onerror = bad;
            v2.addEventListener("loadeddata", function () { v2.addEventListener("seeked", function () { try { paint(v2); res(); } catch (e) { bad(); } }, { once: true }); v2.currentTime = tMs / 1000; });
            v2.src = M.url;
          } else { var i2 = new Image(); i2.crossOrigin = "anonymous"; i2.onerror = bad; i2.onload = function () { try { paint(i2); res(); } catch (e) { bad(); } }; i2.src = M.url; }
        });
      }
      var base = new Promise(function (res) { try { paint(src); res(); } catch (e) { res(cors()); } });
      return base.then(function () {
        if (!withDrawing || !items.length) return;
        return new Promise(function (res, rej) {
          var s = svgEl("svg", { xmlns: NS, width: W, height: H }); CV.draw.setup(s, mdims.w, mdims.h); CV.draw.render(s, items, isVideo() ? tMs : null, { onlyFor: mid });
          var img = new Image(); img.onload = function () { c.drawImage(img, 0, 0, W, H); res(); }; img.onerror = function () { rej(new Error(t("De tekening kon niet worden toegevoegd."))); };
          img.src = "data:image/svg+xml;charset=utf-8," + encodeURIComponent(resolveVars(new XMLSerializer().serializeToString(s)));
          CV.draw.setup(svg, dims.w, dims.h);
        });
      }).then(function () {
        return new Promise(function (res, rej) { try { cv.toBlob(function (b) { b ? res(b) : rej(new Error(t("Dit beeld kan niet worden vastgelegd door de beveiliging van de browser."))); }, "image/jpeg", 0.85); } catch (e) { rej(new Error(t("Dit beeld kan niet worden vastgelegd door de beveiliging van de browser."))); } });
      }).then(function (blob) {
        var f = new File([blob], "momentopname.jpg", { type: "image/jpeg" }), fields = { media_id: mid, met_tekening: withDrawing ? "1" : "0" }; if (isVideo()) fields.tijd_ms = tMs;
        return CV.upload("analyses/" + id + "/momentopnames", f, fields);
      }).then(function (snap) { A.momentopnames.push(snap); return snap; });
    }

    /* ---------- timeline ---------- */
    function buildTimeline() {
      el.ruler = h("div", { class: "e2e-annot-timeline__ruler cv-tl-ruler", "aria-hidden": "true" });
      el.fill = h("div", { class: "cv-tl-fill" });
      el.track = h("div", { class: "e2e-annot-timeline__track cv-tl-track", tabindex: "0", role: "slider", "aria-label": t("Tijdlijn van de video"), "aria-valuemin": "0", "aria-valuemax": "0", "aria-valuenow": "0" }, el.fill);
      el.lane1 = h("div", { class: "e2e-annot-timeline__lane cv-tl-lane cv-tl-lane--remarks" });
      el.lane2 = h("div", { class: "e2e-annot-timeline__lane cv-tl-lane cv-tl-lane--draw" });
      el.head = h("div", { class: "e2e-annot-timeline__playhead cv-tl-head", "aria-hidden": "true" });
      el.loopRange = h("div", { class: "e2e-annot-timeline__range e2e-annot-timeline__range--accent e2e-annot__mark cv-tl-loop", hidden: true, "aria-hidden": "true" });
      var seekFrom = function (e) { var r = el.track.getBoundingClientRect(); seek(L.frac(e.clientX - r.left, r.width) * dur()); };
      [el.ruler, el.track].forEach(function (n) {
        n.addEventListener("pointerdown", function (e) { if (!vid) return; e.preventDefault(); el.track.focus({ preventScroll: true }); n.setPointerCapture(e.pointerId); n._seek = true; seekFrom(e); });
        n.addEventListener("pointermove", function (e) { if (n._seek) seekFrom(e); });
        n.addEventListener("pointerup", function () { n._seek = false; });
        n.addEventListener("pointercancel", function () { n._seek = false; });
      });
      el.track.addEventListener("keydown", function (e) {
        if (!vid) return; var d = e.key === "ArrowLeft" ? -1 : e.key === "ArrowRight" ? 1 : 0;
        if (d) { e.preventDefault(); e.stopPropagation(); seek(curMs() + d * (e.shiftKey ? 1000 : 1000 / fps())); }
        else if (e.key === "Home") { e.preventDefault(); e.stopPropagation(); seek(0); } else if (e.key === "End") { e.preventDefault(); e.stopPropagation(); seek(dur()); }
      });
      function row(label, node) { return h("div", { class: "cv-tl-row" }, h("div", { class: "e2e-annot-timeline__lane-label cv-tl-label" }, label || ""), node); }
      return h("section", { class: "e2e-annot-timeline cv-ed-tl card", "aria-label": t("Tijdlijn"), hidden: true },
        h("div", { class: "cv-tl-body" }, row("", el.ruler), row("", el.track), row(t("Opmerkingen"), el.lane1), row(t("Tekeningen"), el.lane2), el.head),
        h("p", { class: "muted cv-tl-hint" }, t("Een tekening hoort bij een tijdstip. Sleep de randen om te bepalen hoe lang hij zichtbaar is; bij afspelen pauzeert de video op elke opmerking.")));
    }
    function buildRuler() {
      if (!el.ruler || !M || !isVideo()) return; clear(el.ruler);
      var d = dur(); if (!d) return; var w = el.ruler.clientWidth || 600, step = L.tickStep(d, Math.max(3, Math.floor(w / 64))), x;
      for (x = 0; x <= d; x += step) el.ruler.appendChild(h("span", { class: "cv-tl-tick", style: "left:" + (x / d * 100) + "%" }, CV.ms(x, step < 1000)));
      updateHead(curMs());
    }
    function refreshTl() {
      if (!el.lane1 || !M || !isVideo()) return;
      var d = dur(); clear(el.lane1); clear(el.lane2);
      A.opmerkingen.filter(function (r) { return r.media_id === M.id && r.tijd_ms != null; }).forEach(function (r) {
        el.lane1.appendChild(h("button", { type: "button", class: "e2e-annot-timeline__marker cv-tl-marker" + (activeRemark === r.id ? " e2e-annot-timeline__marker--active is-active" : ""), style: "left:" + (L.frac(r.tijd_ms, d) * 100) + "%", "aria-label": t("Opmerking {0} op {1}", r.nummer, CV.ms(r.tijd_ms, true)), title: CV.plain(r.tekst).slice(0, 80), onclick: function () { jumpTo(r); } }, String(r.nummer)));
      });
      var items = layer().slice().sort(function (a, b) { return (a.van_ms || 0) - (b.van_ms || 0); });
      if (!items.length) el.lane2.appendChild(h("div", { class: "cv-tl-none muted" }, t("Nog geen tekeningen")));
      items.forEach(function (it) {
        var van = it.van_ms == null ? 0 : it.van_ms, tot = it.tot_ms == null ? d : it.tot_ms, on = it.id === sel;
        var bar = h("div", { class: "e2e-annot-timeline__range cv-tl-range" + (on ? " e2e-annot-timeline__range--accent is-selected" : ""), tabindex: "0", role: "button", "aria-pressed": on ? "true" : "false",
          "aria-label": t(KINDS[it.soort]) + ": " + t("zichtbaar van {0} tot {1}", CV.ms(van, true), CV.ms(tot, true)), style: "left:" + (L.frac(van, d) * 100) + "%;width:" + Math.max(0.8, (L.frac(tot, d) - L.frac(van, d)) * 100) + "%" },
          h("span", { class: "cv-tl-edge l", "data-m": "l" }), h("span", { class: "cv-tl-bartxt" }, icon(KIND_ICON[it.soort], 12), " ", t(KINDS[it.soort])), h("span", { class: "cv-tl-edge r", "data-m": "r" }));
        bar.addEventListener("keydown", function (e) { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); e.stopPropagation(); pickDrawing(it.id); } });
        bar.addEventListener("pointerdown", function (e) { rangeDown(e, it, bar); });
        bar.addEventListener("pointermove", rangeMove); bar.addEventListener("pointerup", function (e) { rangeUp(e, it); }); bar.addEventListener("pointercancel", function () { dragRange = null; });
        el.lane2.appendChild(h("div", { class: "cv-tl-lanerow" }, bar));
      });
      if (loop.on && (loop.a != null || loop.b != null)) { var a = loop.a || 0, b = loop.b != null ? loop.b : d; el.loopRange.hidden = false; el.loopRange.style.left = (L.frac(a, d) * 100) + "%"; el.loopRange.style.width = ((L.frac(b, d) - L.frac(a, d)) * 100) + "%"; el.track.appendChild(el.loopRange); } else el.loopRange.hidden = true;
      updateHead(curMs());
    }
    function pickDrawing(did) {
      var it = byId(did); if (!it) return; tool = "select"; sel = did;
      if (isVideo() && !visibleAt(it, ms) && it.van_ms != null) seek(it.van_ms);
      renderSvg(); updateSelbar(); refreshTl();
    }
    function rangeDown(e, it, bar) {
      if (e.button > 0) return; e.preventDefault(); e.stopPropagation(); bar.setPointerCapture(e.pointerId);
      var d = dur(), tr = el.track.getBoundingClientRect(), m = e.target.getAttribute && e.target.getAttribute("data-m") || "m";
      dragRange = { id: it.id, mode: m, x0: e.clientX, w: tr.width, dur: d, van: it.van_ms == null ? 0 : it.van_ms, tot: it.tot_ms == null ? d : it.tot_ms, moved: false, bar: bar };
    }
    function rangeMove(e) {
      var r = dragRange; if (!r) return; var it = byId(r.id); if (!it) return;
      var dx = e.clientX - r.x0; if (!r.moved && Math.abs(dx) < 3) return; r.moved = true;
      var v = L.moveRange(r.van, r.tot, r.mode, dx / (r.w || 1) * r.dur, r.dur, 300);
      it.van_ms = v.van; it.tot_ms = v.tot; r.bar.style.left = (L.frac(v.van, r.dur) * 100) + "%"; r.bar.style.width = Math.max(0.8, (L.frac(v.tot, r.dur) - L.frac(v.van, r.dur)) * 100) + "%";
      renderSvg();
    }
    function rangeUp(e, it) {
      var r = dragRange; dragRange = null; if (!r) return;
      try { r.bar.releasePointerCapture(e.pointerId); } catch (x) {}
      if (r.moved) { sel = it.id; commit(); updateSelbar(); } else pickDrawing(it.id);
    }

    /* ---------- the right panel ---------- */
    function buildPanel() {
      var tabs = [["opm", "Opmerkingen"], ["instr", "Instructie"], ["ai", "AI"], ["chat", "Chat"]];
      el.tabBtns = {}; el.panes = {};
      var tl = h("div", { class: "tabs cv-ed-tabs", role: "tablist" });
      tabs.forEach(function (d) {
        var b = h("button", { type: "button", role: "tab", id: "cv-tab-" + d[0], "aria-controls": "cv-pane-" + d[0], onclick: function () { showTab(d[0]); }, onkeydown: function (e) { tabKey(e, d[0]); } });
        el.tabBtns[d[0]] = b; tl.appendChild(b);
        el.panes[d[0]] = h("div", { class: "cv-ed-pane", role: "tabpanel", id: "cv-pane-" + d[0], "aria-labelledby": "cv-tab-" + d[0], hidden: d[0] !== "opm" });
      });
      el.paneOpm = el.panes.opm; el.paneInstr = el.panes.instr; el.paneAi = el.panes.ai; el.paneChat = el.panes.chat;
      buildOpmPane();
      return h("aside", { class: "cv-ed-panel card", "aria-label": t("Opmerkingen, instructie, AI en chat") }, tl, el.panes.opm, el.panes.instr, el.panes.ai, el.panes.chat);
    }
    function tabKey(e, k) {
      var order = visibleTabs(), i = order.indexOf(k), n = e.key === "ArrowRight" ? order[(i + 1) % order.length] : e.key === "ArrowLeft" ? order[(i + order.length - 1) % order.length] : null;
      if (n) { e.preventDefault(); showTab(n); el.tabBtns[n].focus(); }
    }
    function visibleTabs() { return ["opm", "instr", "ai", "chat"].filter(function (k) { return !el.tabBtns[k].hidden; }); }
    function updateTabs() {
      var lab = { opm: t("Opmerkingen") + " (" + A.opmerkingen.length + ")", instr: t("Instructie") + (A.instructievideos.length ? " (" + A.instructievideos.length + ")" : ""), ai: t("AI"), chat: t("Chat") };
      Object.keys(lab).forEach(function (k) { clear(el.tabBtns[k]); el.tabBtns[k].appendChild(document.createTextNode(lab[k])); });
      if (A.nieuwe_berichten) el.tabBtns.chat.appendChild(h("span", { class: "badge info cv-ed-unread", title: t("Nieuwe berichten") }, String(A.nieuwe_berichten)));
      el.tabBtns.chat.hidden = !A.chat_aan;
      showTab(curTab, true);
    }
    function showTab(k, quiet) {
      if (k === "chat" && !A.chat_aan) k = "opm";
      curTab = k;
      Object.keys(el.panes).forEach(function (x) { el.panes[x].hidden = x !== k; el.tabBtns[x].classList.toggle("on", x === k); el.tabBtns[x].setAttribute("aria-selected", x === k ? "true" : "false"); el.tabBtns[x].tabIndex = x === k ? 0 : -1; });
      if (k === "chat" && !chatBuilt) {
        chatBuilt = true;
        if (CV.chat) CV.chat(el.paneChat, id, { onSeek: function (m) { seek(m); }, getSnapshot: function (w) { return takeSnapshot(!!w); }, getTime: curMs, onRead: function () { A.nieuwe_berichten = 0; updateTabs(); } });
        else el.paneChat.appendChild(h("p", { class: "muted" }, t("De chat is niet beschikbaar.")));
      }
      if (k === "ai" && !quiet) loadAi();
    }

    /* ----- tab: remarks ----- */
    function buildOpmPane() {
      el.remList = h("div", { class: "cv-ed-remlist", role: "list" });
      el.addLbl = h("label", { class: "cv-ed-addlbl" }, t("Opmerking"));
      el.remEd = CV.editor({ placeholder: t("Wat zie je op dit moment?"), minHeight: 80, label: t("Nieuwe opmerking") });
      el.pauseChk = h("input", { type: "checkbox", id: "cv-pause-new", checked: true });
      el.formLinkBox = h("div", { class: "cv-ed-formlink" });
      el.addBtn = h("button", { type: "button", class: "btn primary", onclick: addRemark }, icon("plus", 16), " ", t("Toevoegen"));
      el.paneOpm.appendChild(el.remList);
      el.paneOpm.appendChild(h("div", { class: "cv-ed-add" }, el.addLbl, el.remEd.el,
        h("label", { class: "cv-ed-check", for: "cv-pause-new" }, el.pauseChk, " ", t("Video pauzeren bij deze opmerking")), el.formLinkBox,
        h("div", { class: "row between" }, h("button", { type: "button", class: "btn", onclick: function () { pickVideo(function (v, s) { formLink = { v: v, s: s }; drawFormLink(); return Promise.resolve(); }); } }, icon("youtube", 16), " ", t("Instructievideo koppelen")), el.addBtn)));
    }
    function drawFormLink() {
      clear(el.formLinkBox);
      if (formLink) el.formLinkBox.appendChild(h("span", { class: "e2e-chip cv-ed-chip" }, icon("youtube", 14), " ", formLink.v.titel + (formLink.s ? " · " + t("vanaf") + " " + CV.sec(formLink.s) : ""), CV.iconBtn("x", t("Koppeling weghalen"), function () { formLink = null; drawFormLink(); }, "cv-ed-chipx")));
    }
    function linksOf(r) { return A.instructievideos.filter(function (v) { return v.opmerking_id === r.id; }); }
    function linkChip(v, small) {
      var s = v.start_s != null ? v.start_s : null;
      return h("span", { class: "e2e-chip cv-ed-chip" }, icon("youtube", 14), " ", v.titel + (s ? " · " + t("vanaf") + " " + CV.sec(s) : ""), small ? null : null);
    }
    function renderRemarks() {
      if (!el.remList) return; clear(el.remList);
      var list = A.opmerkingen.slice().sort(function (a, b) { return a.nummer - b.nummer; });
      if (!list.length) el.remList.appendChild(h("p", { class: "muted cv-ed-noremarks" }, t("Nog geen opmerkingen. Zet de video op een moment en schrijf wat je ziet.")));
      list.forEach(function (r) { el.remList.appendChild(remarkCard(r)); });
      var n = A.opmerkingen.length; if (el.tabBtns) updateTabs.call(null); void n;
    }
    function remarkCard(r) {
      var other = r.media_id && M && r.media_id !== M.id ? mediaById(r.media_id) : null;
      var chip = r.tijd_ms != null ? h("button", { type: "button", class: "e2e-chip cv-ed-timechip", title: t("Ga naar dit moment"), onclick: function (e) { e.stopPropagation(); jumpTo(r); } }, icon("clock", 13), " ", CV.ms(r.tijd_ms, true)) : null;
      var card = h("article", { class: "cv-ed-remark" + (activeRemark === r.id ? " is-active" : ""), role: "listitem", "data-id": r.id, tabindex: "0", "aria-label": t("Opmerking {0}", r.nummer), onclick: function () { jumpTo(r, true); }, onkeydown: function (e) { if (e.target === card && (e.key === "Enter")) jumpTo(r); } },
        h("span", { class: "cv-ed-num", "aria-hidden": "true" }, String(r.nummer)),
        h("div", { class: "cv-ed-rembody" },
          h("div", { class: "row cv-ed-remmeta" }, chip, other ? h("span", { class: "e2e-chip" }, icon(other.soort === "video" ? "video" : "image", 13), " ", other.naam || t("Ander beeld")) : null, r.pauzeren && r.tijd_ms != null ? h("span", { class: "muted cv-ed-pauseico", title: t("De video pauzeert hier") }, icon("pause", 13)) : null),
          CV.rich(r.tekst), linksOf(r).length ? h("div", { class: "row cv-ed-links" }, linksOf(r).map(function (v) { return linkChip(v); })) : null),
        h("div", { class: "cv-ed-remact" }, CV.iconBtn("edit", t("Opmerking wijzigen"), function (e) { e.stopPropagation(); editRemark(r, card); }), CV.iconBtn("trash", t("Opmerking verwijderen"), function (e) { e.stopPropagation(); delRemark(r); })));
      return card;
    }
    function editRemark(r, card) {
      var ed = CV.editor({ value: r.tekst, minHeight: 70, label: t("Opmerking wijzigen") }), chk = h("input", { type: "checkbox", checked: !!r.pauzeren }), tm = { v: r.tijd_ms };
      var timeBtn = isVideo() && r.tijd_ms != null ? h("button", { type: "button", class: "btn", onclick: function () { tm.v = curMs(); timeBtn.textContent = t("Tijd: {0}", CV.ms(tm.v, true)); } }, t("Naar huidig moment") + " (" + CV.ms(r.tijd_ms, true) + ")") : null;
      var form = h("div", { class: "cv-ed-remedit", onclick: function (e) { e.stopPropagation(); }, onkeydown: function (e) { e.stopPropagation(); } }, ed.el, h("label", { class: "cv-ed-check" }, chk, " ", t("Video pauzeren bij deze opmerking")), timeBtn,
        h("div", { class: "row" }, h("button", { type: "button", class: "btn primary", onclick: function () {
          var html = ed.get(); if (!html) { CV.toast(t("Schrijf eerst een opmerking."), false); return; }
          var body = { tekst: html, pauzeren: chk.checked }; if (tm.v != null && tm.v !== r.tijd_ms) body.tijd_ms = tm.v;
          track(CV.call("opmerkingen/" + r.id, "PUT", body)).then(function (n) { Object.assign(r, n); renderRemarks(); refreshTl(); }).catch(CV.fail);
        } }, t("Opslaan")), h("button", { type: "button", class: "btn ghost", onclick: renderRemarks }, t("Annuleren"))));
      card.onclick = null; clear(card); card.appendChild(form); card.classList.add("is-editing");
    }
    function delRemark(r) {
      CV.confirmBox(t("Deze opmerking verwijderen?"), { title: t("Opmerking verwijderen"), okLabel: t("Verwijderen"), danger: true }).then(function (ok) {
        if (!ok) return;
        track(CV.call("opmerkingen/" + r.id, "DELETE")).then(function () {
          A.opmerkingen = A.opmerkingen.filter(function (x) { return x.id !== r.id; });
          A.instructievideos.forEach(function (v) { if (v.opmerking_id === r.id) v.opmerking_id = null; });
          Object.keys(layers).forEach(function (k) { layers[k].forEach(function (d) { if (d.opmerking_id === r.id) d.opmerking_id = null; }); });
          if (activeRemark === r.id) activeRemark = null; renderRemarks(); refreshTl(); renderInstr();
        }).catch(CV.fail);
      });
    }
    function addRemark() {
      var html = el.remEd.get(); if (!html) { CV.toast(t("Schrijf eerst een opmerking."), false); return; }
      if (!M) { CV.toast(t("Voeg eerst een beeld toe."), false); return; }
      var body = { media_id: M.id, tekst: html, pauzeren: el.pauseChk.checked }; if (isVideo()) body.tijd_ms = curMs();
      var link = formLink; el.addBtn.disabled = true;
      track(CV.call("analyses/" + id + "/opmerkingen", "POST", body)).then(function (r) {
        A.opmerkingen.push(r); activeRemark = r.id;
        var attached = false; layer().forEach(function (d) { if (freshIds[d.id] && !d.opmerking_id) { d.opmerking_id = r.id; attached = true; } }); freshIds = {};
        if (attached) markDirty("l:" + M.id);
        el.remEd.set(""); formLink = null; drawFormLink(); renderRemarks(); refreshTl(); highlightRemark(r.id);
        if (link) return linkVideo(link.v, r.id, link.s);
      }).catch(CV.fail).then(function () { el.addBtn.disabled = false; });
    }
    function jumpTo(r, fromCard) {
      activeRemark = r.id;
      if (r.media_id && M && r.media_id !== M.id) { var i = A.media.findIndex(function (m) { return m.id === r.media_id; }); if (i >= 0) { pendingSeek = r.tijd_ms; selectMedia(i); } }
      else if (vid && r.tijd_ms != null) { vid.pause(); seek(r.tijd_ms); }
      showRemark(r, !fromCard);
    }
    function showRemark(r, scroll) { activeRemark = r.id; showTab("opm"); renderRemarks(); highlightRemark(r.id, scroll); refreshTl(); }
    function highlightRemark(rid, scroll) {
      if (!el.remList) return;
      Array.prototype.forEach.call(el.remList.children, function (c) { var on = c.getAttribute("data-id") === rid; c.classList.toggle("is-active", on); if (on && scroll && c.scrollIntoView) { try { c.scrollIntoView({ block: "nearest", behavior: "smooth" }); } catch (e) {} } });
    }

    /* ----- instruction videos from the library ----- */
    function linkVideo(v, remarkId, startS) {
      return track(CV.call("analyses/" + id + "/instructievideos", "POST", { instructievideo_id: v.id, opmerking_id: remarkId || null, start_s: startS == null ? "" : startS })).then(function (row) {
        A.instructievideos.push(row); renderRemarks(); renderInstr(); refreshTl();
      });
    }
    function pickVideo(onPick) { CV.pickInstructionVideo({ onPick: onPick }); }

    /* ----- tab: instruction ----- */
    function renderInstr() {
      if (!el.paneInstr) return;
      var keep = el.instr ? el.instr.get() : null; clear(el.paneInstr);
      var list = h("div", { class: "cv-ed-ivlist" });
      if (!A.instructievideos.length) list.appendChild(h("p", { class: "muted" }, t("Nog geen instructievideo's gekoppeld.")));
      A.instructievideos.forEach(function (v) {
        var r = v.opmerking_id ? A.opmerkingen.filter(function (x) { return x.id === v.opmerking_id; })[0] : null;
        list.appendChild(h("div", { class: "cv-ed-iv" }, icon("youtube", 20), h("div", { class: "grow" }, h("strong", {}, v.titel), h("div", { class: "muted" }, (v.start_s ? t("vanaf") + " " + CV.sec(v.start_s) : t("vanaf het begin")) + (r ? " · " + t("bij opmerking {0}", r.nummer) : ""))),
          CV.iconBtn("x", t("Koppeling verwijderen"), function () {
            track(CV.call("analyse-instructievideos/" + v.koppeling_id, "DELETE")).then(function () { A.instructievideos = A.instructievideos.filter(function (x) { return x !== v; }); renderInstr(); renderRemarks(); }).catch(CV.fail);
          })));
      });
      el.instr = CV.editor({ value: keep != null ? keep : A.instructie, placeholder: t("Schrijf hier de instructie voor de sporter."), minHeight: 160, label: t("Instructie"), onChange: function () { markDirty("instr", 800); } });
      el.paneInstr.appendChild(h("h3", {}, t("Gekoppelde instructievideo's"))); el.paneInstr.appendChild(list);
      el.paneInstr.appendChild(h("button", { type: "button", class: "btn", onclick: function () { pickVideo(function (v, s) { return linkVideo(v, null, s); }); } }, icon("library", 16), " ", t("Uit bibliotheek kiezen")));
      el.paneInstr.appendChild(h("h3", { class: "cv-ed-h3" }, t("Instructie voor de sporter")));
      el.paneInstr.appendChild(el.instr.el);
      el.paneInstr.appendChild(h("div", { class: "row" }, h("button", { type: "button", class: "btn primary", onclick: openAi }, icon("sparkle", 16), " ", t("Schrijf met AI"))));
      updateTabs.call(null);
    }
    function openAi() {
      CV.aiDialog(A, { snapshot: takeSnapshot, onTake: function (html) { A.instructie = html; if (el.instr) el.instr.set(html); showTab("instr"); }, onChange: loadAi });
    }

    /* ----- tab: AI ----- */
    function loadAi() {
      CV.call("ai/" + id).then(function (d) { aiInfo = d; renderAi(); }).catch(function (e) { aiInfo = null; clear(el.paneAi); el.paneAi.appendChild(h("p", { class: "muted" }, errText(e))); });
    }
    function aiKindLabel(k) { return { instructie: t("Instructie schrijven"), oefeningen: t("Oefeningen voorstellen"), fouten: t("Fouten benoemen"), samenvatting: t("Samenvatting voor sporter"), vrij: t("Vrije opdracht") }[k] || k; }
    function renderAi() {
      if (!el.paneAi || !aiInfo) return; clear(el.paneAi);
      var ai = aiInfo.ai || {};
      el.paneAi.appendChild(h("div", { class: "cv-ed-aicredit" }, icon("sparkle", 18), h("div", { class: "grow" }, h("strong", {}, ai.credit_required ? t("Jouw tegoed: {0}", CV.money(ai.balance, ai.symbol)) : t("AI is beschikbaar")), h("div", { class: "muted" }, t("Betaald door jou als coach"))),
        h("button", { type: "button", class: "btn primary", disabled: !ai.available, title: ai.available ? "" : t("De AI is niet gekoppeld."), onclick: openAi }, icon("plus", 16), " ", t("Nieuwe opdracht"))));
      var list = h("div", { class: "cv-ed-ailist" });
      if (!(aiInfo.opdrachten || []).length) list.appendChild(h("p", { class: "muted" }, t("Nog geen AI-opdrachten voor deze analyse.")));
      (aiInfo.opdrachten || []).forEach(function (o) {
        var st = { klaar: t("Klaar"), bezig: t("Bezig"), fout: t("Mislukt") }[o.status] || o.status;
        list.appendChild(h("button", { type: "button", class: "cv-ed-aiitem", onclick: function () { CV.aiDialog(A, { snapshot: takeSnapshot, onTake: function (html) { A.instructie = html; if (el.instr) el.instr.set(html); showTab("instr"); }, onChange: loadAi, open: o }); } },
          h("div", { class: "grow" }, h("strong", {}, aiKindLabel(o.soort)), h("div", { class: "muted" }, when(o.aangemaakt_op) + (o.beelden ? " · " + t("{0} beelden", o.beelden) : ""))),
          h("div", { class: "cv-ed-aiside" }, h("span", { class: "badge " + (o.status === "klaar" ? "ok" : o.status === "fout" ? "" : "info") }, st), o.status !== "bezig" ? h("small", { class: "muted" }, CV.money(o.kosten, ai.symbol)) : null)));
      });
      el.paneAi.appendChild(list);
    }

    /* the lang of document-level things is not needed: everything is bound to this view */
  };

  /* ──────────────────────────── the library picker ──────────────────────────── */
  /* CV.pickInstructionVideo({onPick: function (video, startSeconds) -> Promise}) : lists GET bibliotheek with search */
  CV.pickInstructionVideo = function (o) {
    var q = "", list = [], chosen = null, dlg, listEl, startIn, startRow, okBtn, seq = 0;
    function paint() {
      clear(listEl);
      if (!list.length) listEl.appendChild(h("p", { class: "muted" }, t("Geen instructievideo's gevonden.")));
      list.forEach(function (v) {
        var on = chosen && chosen.id === v.id;
        listEl.appendChild(h("button", { type: "button", class: "cv-ed-libitem" + (on ? " on" : ""), "aria-pressed": on ? "true" : "false", onclick: function () { chosen = v; startIn.value = v.start_s ? CV.sec(v.start_s) : ""; paint(); startRow.hidden = false; okBtn.disabled = false; } },
          icon("youtube", 20), h("span", { class: "grow" }, h("strong", {}, v.titel), h("small", { class: "muted" }, [v.kanaal, v.duur_s ? CV.sec(v.duur_s) : "", v.categorie].filter(Boolean).join(" · ")))));
      });
    }
    var load = debounce(function () { var n = ++seq; CV.call("bibliotheek" + (q ? "?q=" + encodeURIComponent(q) : "")).then(function (d) { if (n !== seq) return; list = d.videos || []; paint(); }).catch(CV.fail); }, 250);
    okBtn = h("button", { type: "button", class: "btn primary", disabled: true, onclick: function () {
      var raw = startIn.value.trim(), s = raw ? L.parseTime(raw) : null; if (raw && s == null) { CV.toast(t("Vul de starttijd in als m:ss, bijvoorbeeld 1:20."), false); return; }
      okBtn.disabled = true;
      Promise.resolve(o.onPick(chosen, s)).then(function () { dlg.close(); }).catch(function (e) { okBtn.disabled = false; CV.fail(e); });
    } }, t("Koppelen"));
    dlg = CV.dialog({ eyebrow: t("BIBLIOTHEEK"), title: t("Instructievideo koppelen"), tabs: [{ key: "lib", label: t("Bibliotheek"), render: function (body) {
      listEl = h("div", { class: "cv-ed-liblist" });
      startIn = h("input", { type: "text", placeholder: "0:00", "aria-label": t("Starttijd (m:ss)"), class: "cv-ed-startin" });
      startRow = h("label", { class: "cv-ed-startrow", hidden: !chosen }, t("Starttijd (m:ss)"), " ", startIn);
      body.appendChild(h("input", { type: "search", class: "cv-ed-libsearch", placeholder: t("Zoek op titel, categorie of tag"), "aria-label": t("Zoeken"), value: q, oninput: function (e) { q = e.target.value.trim(); load(); } }));
      body.appendChild(listEl); body.appendChild(startRow); paint();
    } }], buttons: [h("button", { type: "button", class: "btn", onclick: function () { dlg.close(); } }, t("Annuleren")), okBtn] });
    load();
    return dlg;
  };

  /* ──────────────────────────── the AI dialog ──────────────────────────── */
  /* CV.aiDialog(analyse, {snapshot: function (withDrawing) -> Promise(snapshot), onTake: function (instructionHtml), onChange: function (), open: opdracht}) */
  CV.aiDialog = function (analyse, opts) {
    opts = opts || {};
    var id = analyse.id, S = { soort: "instructie", taal: "Nederlands", lengte: "gemiddeld", toon: "motiverend", opdracht: "", meesturen: { opmerkingen: true, instructievideos: true, niveau: false }, chosen: {}, snaps: [], max: 5, info: null, est: null, run: null, result: null, picked: {} };
    var dlg, poll = 0, alive = true, est = null, sending = false;
    var LANGS = ["Nederlands", "English", "Deutsch", "Français", "Español", "Italiano", "Português", "Polski", "Türkçe", "Русский", "Українська", "العربية", "हिन्दी", "Bahasa Indonesia", "日本語", "中文"];
    var KINDS_AI = [["instructie", t("Instructie schrijven")], ["oefeningen", t("Oefeningen voorstellen")], ["fouten", t("Fouten benoemen")], ["samenvatting", t("Samenvatting voor sporter")], ["vrij", t("Vrije opdracht")]];
    var LENG = [["kort", t("Kort")], ["gemiddeld", t("Gemiddeld")], ["lang", t("Lang")]], TOON = [["motiverend", t("Motiverend")], ["zakelijk", t("Zakelijk")], ["vriendelijk", t("Vriendelijk")], ["streng", t("Streng")]];
    var costLine = h("div", { class: "cv-ai-cost" }, t("Geschatte kosten: …")), creditLine = h("div", { class: "muted cv-ai-credit" }), buyBtn = h("button", { type: "button", class: "btn ghost", hidden: true, onclick: buy }, t("Tegoed bijkopen"));
    var sendBtn = h("button", { type: "button", class: "btn primary", onclick: send }, icon("send", 16), " ", t("Versturen naar AI"));
    var cancelBtn = h("button", { type: "button", class: "btn", onclick: function () { dlg.close(); } }, t("Annuleren"));
    function ids() { return Object.keys(S.chosen).filter(function (k) { return S.chosen[k]; }); }
    function payload() { return { soort: S.soort, opdracht: S.opdracht, opties: { taal: S.taal, lengte: S.lengte, toon: S.toon, meesturen: S.meesturen }, momentopname_ids: ids() }; }
    function sym() { return (S.est && S.est.symbol) || (S.info && S.info.ai && S.info.ai.symbol) || "€ "; }
    function paintFoot() {
      var e = S.est, ai = S.info && S.info.ai;
      costLine.textContent = e ? t("Geschatte kosten: {0} – {1}", CV.money(e.laag, e.symbol), CV.money(e.hoog, e.symbol)) : t("Geschatte kosten: …");
      var bal = e ? e.tegoed : ai ? ai.balance : null;
      creditLine.textContent = bal == null ? "" : t("Jouw tegoed: {0} · betaald door jou als coach", CV.money(bal, sym()));
      var short = !!e && e.genoeg === false; buyBtn.hidden = !short;
      if (short) creditLine.textContent += " · " + t("onvoldoende tegoed");
      var running = S.run && S.run.status === "bezig";
      sendBtn.disabled = short || running || sending || (ai && ai.available === false) || (S.soort === "vrij" && !S.opdracht.trim());
      sendBtn.title = ai && ai.available === false ? t("De AI is niet gekoppeld.") : short ? t("Je tegoed is niet genoeg.") : "";
    }
    var estimate = debounce(function () {
      CV.call("ai/" + id + "/schat", "POST", payload()).then(function (r) { if (alive) { S.est = r; paintFoot(); } }).catch(function () {});
    }, 500);
    function changed() { paintFoot(); estimate(); }
    function buy() { Promise.resolve(system.aiCredit()).then(function () { return CV.call("ai/" + id); }).then(function (d) { S.info = d; estimate(); }).catch(function () {}); }
    function send() {
      sending = true; paintFoot();
      CV.call("ai/" + id, "POST", payload()).then(function (o) { S.run = o; S.result = null; S.picked = {}; sending = false; paintFoot(); dlg.tab("voorstel"); startPoll(); if (opts.onChange) opts.onChange(); }).catch(function (e) {
        sending = false; paintFoot();
        if (isNoCredit(e)) { Promise.resolve(system.aiCredit()).then(function () { return CV.call("ai/" + id); }).then(function (d) { S.info = d; estimate(); }).catch(function () {}); } else CV.fail(e);
      });
    }
    function startPoll() {
      clearInterval(poll);
      poll = setInterval(function () {
        if (!alive || !S.run) return;
        CV.call("ai/opdracht/" + S.run.id).then(function (o) {
          if (!alive) return; S.run = o;
          if (o.status !== "bezig") { clearInterval(poll); if (o.status === "klaar") { S.result = o.resultaat || []; S.picked = {}; S.result.forEach(function (b, i) { S.picked[i] = true; }); } paintFoot(); if (opts.onChange) opts.onChange(); }
          if (dlg.current() === "voorstel") dlg.tab("voorstel");
        }).catch(function () {});
      }, 2000);
    }
    function pill(group, items, key) {
      return h("div", { class: "cv-ai-pills", role: "radiogroup", "aria-label": group }, items.map(function (d) {
        var on = S[key] === d[0];
        return h("button", { type: "button", role: "radio", "aria-checked": on ? "true" : "false", class: "cv-ai-pill" + (on ? " on" : ""), onclick: function () { S[key] = d[0]; dlg.tab("opdracht"); changed(); } }, d[1]);
      }));
    }
    function select(label, items, key) {
      return h("label", { class: "cv-ai-field" }, h("span", {}, label), h("select", { onchange: function (e) { S[key] = e.target.value; changed(); } }, items.map(function (d) { var v = Array.isArray(d) ? d[0] : d, l = Array.isArray(d) ? d[1] : d; return h("option", { value: v, selected: v === S[key] }, l); })));
    }
    function check(label, key) { return h("label", { class: "cv-ed-check" }, h("input", { type: "checkbox", checked: !!S.meesturen[key], onchange: function (e) { S.meesturen[key] = e.target.checked; changed(); } }), " ", label); }
    function tabOpdracht(body) {
      var n = (S.info && S.info.opmerkingen != null) ? S.info.opmerkingen : (analyse.opmerkingen || []).length, v = S.info ? S.info.instructievideos : (analyse.instructievideos || []).length;
      body.appendChild(h("div", {}, h("div", { class: "cv-ai-label" }, t("Soort opdracht")), pill(t("Soort opdracht"), KINDS_AI, "soort")));
      body.appendChild(h("div", { class: "cv-ai-grid" }, select(t("Taal"), LANGS, "taal"), select(t("Lengte"), LENG, "lengte"), select(t("Toon"), TOON, "toon")));
      body.appendChild(h("label", { class: "cv-ai-field" }, h("span", {}, t("Jouw opdracht (optioneel)")), h("textarea", { rows: "3", maxlength: "1500", placeholder: S.soort === "vrij" ? t("Schrijf wat de AI moet doen.") : "", oninput: function (e) { S.opdracht = e.target.value; changed(); } }, S.opdracht)));
      body.appendChild(h("fieldset", { class: "cv-ai-send" }, h("legend", {}, t("Meesturen met de opdracht")),
        check(t("Mijn {0} opmerkingen met tijden", n), "opmerkingen"), check(t("Titels van de {0} gekoppelde instructievideo's", v), "instructievideos"), check(t("Niveau en doel van de sporter (geen naam of contactgegevens)"), "niveau"),
        h("div", { class: "cv-ed-check" }, icon("image", 15), " ", t("{0} beelden", ids().length), " (", h("button", { type: "button", class: "cv-ai-link", onclick: function () { dlg.tab("beelden"); } }, t("zie tab Beelden")), ")")));
    }
    function snapMaker(withDrawing, label) {
      return h("button", { type: "button", class: "btn", disabled: !opts.snapshot, onclick: function (e) {
        var b = e.currentTarget; b.disabled = true;
        opts.snapshot(withDrawing).then(function (s) { S.snaps.push(s); if (ids().length < S.max) S.chosen[s.id] = true; dlg.tab("beelden"); changed(); }).catch(CV.fail).then(function () { b.disabled = false; });
      } }, icon("camera", 16), " ", label);
    }
    function tabBeelden(body) {
      var n = ids().length;
      body.appendChild(h("div", { class: "row between" }, h("p", { class: "muted grow" }, t("Kies welke momentopnames de AI mag zien.")), h("strong", { class: "cv-ai-count", "aria-live": "polite" }, t("{0} van {1}", n, S.max))));
      var grid = h("div", { class: "cv-ai-snaps" });
      if (!S.snaps.length) grid.appendChild(h("p", { class: "muted" }, t("Er zijn nog geen momentopnames. Maak er een met de camera-knop bij de video.")));
      S.snaps.forEach(function (s) {
        var on = !!S.chosen[s.id];
        grid.appendChild(h("button", { type: "button", class: "cv-ai-snap" + (on ? " on" : ""), "aria-pressed": on ? "true" : "false", "aria-label": t("Momentopname") + (s.tijd_ms != null ? " " + CV.ms(s.tijd_ms, true) : ""), onclick: function () {
          if (!on && n >= S.max) { CV.toast(t("Je kunt maximaal {0} beelden meesturen.", S.max), false); return; }
          S.chosen[s.id] = !on; dlg.tab("beelden"); changed();
        } }, h("img", { src: s.url, alt: "" }), h("span", { class: "cv-ai-snapmeta" }, (s.tijd_ms != null ? CV.ms(s.tijd_ms, true) : t("Foto")) + (s.met_tekening ? " · " + t("met tekening") : "")), on ? h("span", { class: "cv-ai-tick" }, icon("check", 14)) : null));
      });
      body.appendChild(grid);
      body.appendChild(h("div", { class: "row" }, snapMaker(true, t("Nieuw beeld, met tekening")), snapMaker(false, t("Nieuw beeld, zonder tekening"))));
      if (!opts.snapshot) body.appendChild(h("p", { class: "muted" }, t("Open de editor om een nieuw beeld van de video te maken.")));
    }
    function tabVoorstel(body) {
      var r = S.run;
      if (!r) { body.appendChild(h("div", { class: "empty" }, icon("sparkle", 30), h("p", {}, t("Hier verschijnt het voorstel van de AI nadat je de opdracht hebt verstuurd. Je beslist zelf wat er in de instructie komt.")))); return; }
      if (r.status === "bezig") { body.appendChild(h("div", { class: "cv-ai-wait", role: "status", "aria-live": "polite" }, h("span", { class: "cv-ed-spin", "aria-hidden": "true" }), h("strong", {}, t("AI is aan het schrijven…")), h("p", { class: "muted" }, t("Dit duurt meestal een halve minuut. Je kunt dit venster open laten.")))); return; }
      if (r.status === "fout") { body.appendChild(h("div", { class: "alert" }, r.fout || t("De opdracht is niet gelukt."))); body.appendChild(h("div", { class: "row" }, h("button", { type: "button", class: "btn", onclick: function () { dlg.tab("opdracht"); } }, t("Opnieuw")))); return; }
      var blocks = S.result || r.resultaat || [];
      body.appendChild(h("div", { class: "row between" }, h("strong", {}, t("Voorstel van de AI")), h("small", { class: "muted" }, t("Kosten: {0}", CV.money(r.kosten, sym())))));
      blocks.forEach(function (b, i) {
        body.appendChild(h("label", { class: "cv-ai-block" }, h("input", { type: "checkbox", checked: !!S.picked[i], onchange: function (e) { S.picked[i] = e.target.checked; } }), h("div", { class: "grow" }, h("strong", {}, b.titel), CV.rich(b.tekst))));
      });
      body.appendChild(h("div", { class: "row cv-ai-stick" },
        h("button", { type: "button", class: "btn primary", onclick: function (e) {
          var sel = blocks.map(function (b, i) { return i; }).filter(function (i) { return S.picked[i]; }); if (!sel.length) { CV.toast(t("Kies minstens één blok."), false); return; }
          e.currentTarget.disabled = true;
          CV.call("ai/opdracht/" + r.id + "/overnemen", "POST", { blokken: sel }).then(function (d) { if (opts.onTake) opts.onTake(d.instructie); CV.toast(t("Overgenomen in de instructie.")); if (opts.onChange) opts.onChange(); dlg.close(); }).catch(function (er) { e.currentTarget.disabled = false; CV.fail(er); });
        } }, icon("check", 16), " ", t("Overnemen in instructie")),
        h("button", { type: "button", class: "btn", onclick: function () { S.run = null; S.result = null; dlg.tab("opdracht"); paintFoot(); } }, icon("repeat", 16), " ", t("Opnieuw"))));
    }
    dlg = CV.dialog({ eyebrow: t("AI-INSTRUCTIE") + " · " + String(analyse.titel || "").toUpperCase(), title: t("Laat AI de instructie schrijven"), wide: true,
      tabs: [{ key: "opdracht", label: t("Opdracht"), render: tabOpdracht }, { key: "beelden", label: t("Beelden"), render: tabBeelden }, { key: "voorstel", label: t("Voorstel"), render: tabVoorstel }],
      footerLeft: h("div", {}, costLine, creditLine, buyBtn), buttons: [cancelBtn, sendBtn], onClose: function () { alive = false; clearInterval(poll); estimate.cancel(); } });
    CV.call("ai/" + id).then(function (d) {
      if (!alive) return; S.info = d; S.max = d.max_beelden || 5; S.snaps = d.momentopnames || [];
      S.snaps.slice(-S.max).forEach(function (s) { S.chosen[s.id] = true; });
      if (opts.open) { S.run = opts.open; if (opts.open.status === "klaar") { S.result = opts.open.resultaat || []; S.result.forEach(function (b, i) { S.picked[i] = true; }); } if (opts.open.status === "bezig") startPoll(); dlg.tab("voorstel"); } else dlg.tab(dlg.current());
      paintFoot(); estimate();
    }).catch(CV.fail);
    paintFoot();
    return dlg;
  };
})();
