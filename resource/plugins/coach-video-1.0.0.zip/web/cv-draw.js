// Copyright & Ownership Notice
// easy2Edit is the exclusive legal property of RST Coaching & Consultancy B.V. (RSTCC),
// owned by Ronald Stolk. All rights reserved. Any unauthorized use, copying, modification,
// reproduction, distribution, or commercial exploitation of Easy2Edit, including its source code,
// is strictly prohibited without prior written permission from Ronald Stolk or RSTCC.
// website https://rstcc.net

"use strict";
/* Coach video: drawing the layer of lines, arrows, angles, circles, freehand lines and texts over a picture. Used by the editor and by the view of the athlete, so both show exactly the same.
   A drawing: {id, soort: lijn|pijl|hoek|cirkel|vrij|tekst, punten: [[x, y], ...] (0..1, relative to the picture), stijl: {kleur: primair|licht|accent, dikte 1..8}, label, waarde, van_ms, tot_ms, opmerking_id}.
   The svg has viewBox 0 0 1000 1000 * the aspect of the picture: CV.draw.setup(svg, width, height) once, then CV.draw.render(svg, items, timeMs, {onlyFor, selectedId}). */
CV.draw = (function () {
  var NS = "http://www.w3.org/2000/svg";
  var COLOR = { primair: "var(--e2e-primary, var(--blue, #f0833a))", licht: "#ffffff", accent: "var(--e2e-accent-light, #f4c430)" };
  var V = { w: 1000, h: 1000 };
  function el(name, attrs) { var e = document.createElementNS(NS, name); Object.keys(attrs || {}).forEach(function (k) { e.setAttribute(k, attrs[k]); }); return e; }
  function setup(svg, width, height) {
    var ratio = (height && width) ? height / width : 0.5625;
    V = { w: 1000, h: Math.round(1000 * ratio) };
    svg.setAttribute("viewBox", "0 0 " + V.w + " " + V.h); svg.setAttribute("preserveAspectRatio", "none"); svg.setAttribute("role", "img");
    return V;
  }
  function px(p) { return [p[0] * V.w, p[1] * V.h]; }
  function norm(x, y) { return [Math.min(1, Math.max(0, x / V.w)), Math.min(1, Math.max(0, y / V.h))]; }
  /* the angle in degrees at the middle point of three points (in pixels of the picture, so it is a real angle) */
  function angle(a, b, c) {
    var A = px(a), B = px(b), C = px(c), v1 = [A[0] - B[0], A[1] - B[1]], v2 = [C[0] - B[0], C[1] - B[1]];
    var dot = v1[0] * v2[0] + v1[1] * v2[1], m = Math.hypot(v1[0], v1[1]) * Math.hypot(v2[0], v2[1]);
    return m ? Math.round(Math.acos(Math.max(-1, Math.min(1, dot / m))) * 1800 / Math.PI) / 10 : 0;
  }
  function visible(it, ms) { if (ms == null || it.van_ms == null || it.tot_ms == null) return true; return ms >= it.van_ms && ms <= it.tot_ms; }
  function labelBox(g, x, y, text, color) {
    var t = el("text", { x: x, y: y, "font-size": 30, "font-weight": 700, fill: "#fff", "text-anchor": "middle", "dominant-baseline": "central", "pointer-events": "none" }); t.textContent = text;
    g.appendChild(el("rect", { x: x - (text.length * 8.5 + 16), y: y - 24, width: text.length * 17 + 32, height: 48, rx: 14, fill: color === "licht" ? "rgba(0,0,0,.72)" : COLOR[color] || COLOR.primair, "pointer-events": "none" })); g.appendChild(t);
  }
  function shape(it, selected) {
    var g = el("g", { "data-id": it.id || "", "class": "cv-shape" + (selected ? " is-selected" : "") }), c = COLOR[(it.stijl || {}).kleur] || COLOR.primair, w = (it.stijl || {}).dikte || 3, P = (it.punten || []).map(px);
    var line = { stroke: c, "stroke-width": w * 2.2, "stroke-linecap": "round", "stroke-linejoin": "round", fill: "none" };
    if (it.soort === "lijn" && P.length === 2) g.appendChild(el("line", Object.assign({ x1: P[0][0], y1: P[0][1], x2: P[1][0], y2: P[1][1] }, line)));
    else if (it.soort === "pijl" && P.length === 2) {
      var a = Math.atan2(P[1][1] - P[0][1], P[1][0] - P[0][0]), L = 26 + w * 5;
      g.appendChild(el("line", Object.assign({ x1: P[0][0], y1: P[0][1], x2: P[1][0], y2: P[1][1] }, line)));
      g.appendChild(el("path", Object.assign({ d: "M" + (P[1][0] - L * Math.cos(a - 0.45)) + " " + (P[1][1] - L * Math.sin(a - 0.45)) + " L" + P[1][0] + " " + P[1][1] + " L" + (P[1][0] - L * Math.cos(a + 0.45)) + " " + (P[1][1] - L * Math.sin(a + 0.45)) }, line)));
    } else if (it.soort === "hoek" && P.length === 3) {
      g.appendChild(el("polyline", Object.assign({ points: P.map(function (p) { return p.join(","); }).join(" ") }, line)));
      var val = it.waarde != null ? it.waarde : angle(it.punten[0], it.punten[1], it.punten[2]);
      var m1 = Math.atan2(P[0][1] - P[1][1], P[0][0] - P[1][0]), m2 = Math.atan2(P[2][1] - P[1][1], P[2][0] - P[1][0]), mid = (m1 + m2) / 2;
      if (Math.abs(m1 - m2) > Math.PI) mid += Math.PI;
      labelBox(g, P[1][0] + 90 * Math.cos(mid), P[1][1] + 90 * Math.sin(mid), Math.round(val) + "°", (it.stijl || {}).kleur);
    } else if (it.soort === "cirkel" && P.length === 2) g.appendChild(el("circle", Object.assign({ cx: P[0][0], cy: P[0][1], r: Math.hypot(P[1][0] - P[0][0], P[1][1] - P[0][1]) }, line)));
    else if (it.soort === "vrij" && P.length > 1) g.appendChild(el("polyline", Object.assign({ points: P.map(function (p) { return p.join(","); }).join(" ") }, line)));
    else if (it.soort === "tekst" && P.length === 1) { labelBox(g, P[0][0], P[0][1], it.label || "", (it.stijl || {}).kleur); return g; }
    if (it.label && it.soort !== "tekst" && P.length) { var last = P[P.length - 1]; labelBox(g, last[0], last[1] - 44, it.label, (it.stijl || {}).kleur); }
    return g;
  }
  function render(svg, items, ms, opts) {
    opts = opts || {};
    while (svg.firstChild) svg.removeChild(svg.firstChild);
    (items || []).forEach(function (it) { if ((!opts.onlyFor || it.media_id === opts.onlyFor) && visible(it, ms)) svg.appendChild(shape(it, opts.selectedId && it.id === opts.selectedId)); });
  }
  return { setup: setup, render: render, px: px, norm: norm, angle: angle, visible: visible, size: function () { return V; }, COLOR: COLOR };
})();
