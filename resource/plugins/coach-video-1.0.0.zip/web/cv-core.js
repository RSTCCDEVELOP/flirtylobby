// Copyright & Ownership Notice
// easy2Edit is the exclusive legal property of RST Coaching & Consultancy B.V. (RSTCC),
// owned by Ronald Stolk. All rights reserved. Any unauthorized use, copying, modification,
// reproduction, distribution, or commercial exploitation of Easy2Edit, including its source code,
// is strictly prohibited without prior written permission from Ronald Stolk or RSTCC.
// website https://rstcc.net

"use strict";
/* Coach video: the shared part of the pages (helpers, icons, the view router, the dialog with tabs). Every other script of the plugin uses the global CV.
   Texts go through t("…") so every language gets them. */
var CV = (function () {
  var ROUTE = "/plugins/run/coach-video/";
  var t = function () { return system.t.apply(system, arguments); };
  var S = { home: null, ready: null, view: null, params: {}, stack: [] };

  /* a tiny DOM builder: h("div", {class: "x", onclick: fn}, child, [children], "text") */
  function h(tag, props) {
    var el = document.createElement(tag), kids = Array.prototype.slice.call(arguments, 2);
    Object.keys(props || {}).forEach(function (k) {
      var v = props[k];
      if (k === "class") el.className = v;
      else if (k.indexOf("on") === 0 && typeof v === "function") el.addEventListener(k.slice(2), v);
      else if (k === "style") el.style.cssText = v;
      else if (k === "value") el.value = v;
      else if (k === "html") el.innerHTML = v;
      else if (v === true) el.setAttribute(k, "");
      else if (v !== false && v != null) el.setAttribute(k, v);
    });
    (function add(list) { list.forEach(function (c) { if (Array.isArray(c)) add(c); else if (c != null && c !== false) el.appendChild(typeof c === "object" ? c : document.createTextNode(String(c))); }); })(kids);
    return el;
  }
  function clear(el) { while (el.firstChild) el.removeChild(el.firstChild); return el; }
  function call(path, method, body) { return system.api(ROUTE + path, { method: method || "GET", body: body }); }
  function upload(path, file, fields) { return system.upload("/plugins/run/coach-video/" + path, file, fields || {}); }
  function esc(s) { return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); }
  function lang() { return document.documentElement.lang || "nl"; }
  /* where dialogs, drawers and toasts go: the layer on top of the whole page when the page runs inside the dashboard (system.portal), else the body of the frame */
  function root() { return (window.system && system.portal) ? system.portal() : document.body; }

  /* monochrome icons (stroke, currentColor): CV.icon("video") gives an <svg> */
  var PATHS = {
    video: '<rect x="3" y="6" width="13" height="12" rx="2"/><path d="M16 10l5-3v10l-5-3"/>', image: '<rect x="3" y="4" width="18" height="16" rx="2"/><circle cx="9" cy="10" r="1.6"/><path d="M21 16l-5-5-8 8"/>',
    upload: '<path d="M12 16V4M7 9l5-5 5 5"/><path d="M4 16v3a1 1 0 001 1h14a1 1 0 001-1v-3"/>', user: '<circle cx="12" cy="8" r="3.6"/><path d="M4.5 20a7.5 7.5 0 0115 0"/>', users: '<circle cx="9" cy="8" r="3.2"/><path d="M2.5 19a6.5 6.5 0 0113 0M16 5.2a3.2 3.2 0 010 5.6M18 14.2a6.5 6.5 0 013.5 4.8"/>',
    book: '<path d="M4 5a2 2 0 012-2h13v16H6a2 2 0 00-2 2zM4 19V5"/><path d="M9 7h6"/>', library: '<rect x="3" y="4" width="4" height="16" rx="1"/><rect x="9" y="4" width="4" height="16" rx="1"/><path d="M15.5 6l4 1-3 13-4-1"/>',
    sparkle: '<path d="M12 3l1.9 5.1L19 10l-5.1 1.9L12 17l-1.9-5.1L5 10l5.1-1.9z"/><path d="M18.5 16.5l.7 1.8 1.8.7-1.8.7-.7 1.8-.7-1.8-1.8-.7 1.8-.7z"/>', settings: '<circle cx="12" cy="12" r="3"/><path d="M12 3v2.5M12 18.5V21M3 12h2.5M18.5 12H21M5.6 5.6l1.8 1.8M16.6 16.6l1.8 1.8M18.4 5.6l-1.8 1.8M7.4 16.6l-1.8 1.8"/>',
    plus: '<path d="M12 5v14M5 12h14"/>', search: '<circle cx="11" cy="11" r="6.5"/><path d="M20 20l-4.2-4.2"/>', x: '<path d="M6 6l12 12M18 6L6 18"/>', play: '<path d="M7 5l12 7-12 7z"/>', pause: '<path d="M8 5v14M16 5v14"/>',
    stepBack: '<path d="M6 5v14M18 5l-9 7 9 7z"/>', stepFwd: '<path d="M18 5v14M6 5l9 7-9 7z"/>', repeat: '<path d="M4 11V9a3 3 0 013-3h11l-3-3M20 13v2a3 3 0 01-3 3H6l3 3"/>', camera: '<path d="M4 8h3l1.6-2.4h6.8L17 8h3a1 1 0 011 1v10a1 1 0 01-1 1H4a1 1 0 01-1-1V9a1 1 0 011-1z"/><circle cx="12" cy="13.5" r="3.5"/>',
    columns: '<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M12 4v16"/>', fullscreen: '<path d="M4 9V4h5M20 9V4h-5M4 15v5h5M20 15v5h-5"/>', back: '<path d="M15 5l-7 7 7 7"/>', chevron: '<path d="M7 10l5 5 5-5"/>', share: '<circle cx="6" cy="12" r="2.4"/><circle cx="17" cy="6" r="2.4"/><circle cx="17" cy="18" r="2.4"/><path d="M8.2 10.9l6.6-3.7M8.2 13.1l6.6 3.7"/>',
    trash: '<path d="M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13M10 11v6M14 11v6"/>', edit: '<path d="M4 20h4L19 9l-4-4L4 16z"/>', check: '<path d="M5 12.5l4.5 4.5L19 7"/>', send: '<path d="M21 3L10 14M21 3l-7 18-4-7-7-4z"/>', clip: '<path d="M20 11.5l-8 8a5 5 0 01-7-7l8.5-8.5a3.3 3.3 0 014.7 4.7L9.5 17.2a1.7 1.7 0 01-2.4-2.4L15 7"/>',
    clock: '<circle cx="12" cy="12" r="8.5"/><path d="M12 7.5V12l3 2"/>', undo: '<path d="M9 7L4 12l5 5M4 12h10a6 6 0 010 12"/>', redo: '<path d="M15 7l5 5-5 5M20 12H10a6 6 0 000 12"/>', cursor: '<path d="M6 3l12 8-5.5 1.5L10 18z"/>', line: '<path d="M5 19L19 5"/>',
    arrow: '<path d="M5 19L19 5M9 5h10v10"/>', angle: '<path d="M5 19L19 19M5 19L15 6"/><path d="M11 19a6 6 0 00-2-4.5"/>', circle: '<circle cx="12" cy="12" r="8"/>', free: '<path d="M4 15c3-8 5 2 8-3s4 3 8-3"/>', text: '<path d="M5 6V4h14v2M12 4v16M9 20h6"/>',
    youtube: '<rect x="3" y="6" width="18" height="12" rx="3.5"/><path d="M10.5 9.5l4 2.5-4 2.5z"/>', bell: '<path d="M6 16V11a6 6 0 0112 0v5l1.5 2h-15zM10 20a2 2 0 004 0"/>', archive: '<rect x="3" y="4" width="18" height="4" rx="1"/><path d="M5 8v11h14V8M10 12h4"/>', link: '<path d="M10 14a4 4 0 005.7 0l3-3a4 4 0 00-5.7-5.7l-1 1M14 10a4 4 0 00-5.7 0l-3 3a4 4 0 005.7 5.7l1-1"/>',
    eye: '<path d="M2.5 12S6 5.5 12 5.5 21.5 12 21.5 12 18 18.5 12 18.5 2.5 12 2.5 12z"/><circle cx="12" cy="12" r="3"/>', lock: '<rect x="5" y="11" width="14" height="9" rx="2"/><path d="M8 11V8a4 4 0 018 0v3"/>', message: '<path d="M4 5h16v11H9l-5 4z"/>', tick: '<path d="M3 12.5l4 4L15 8M10 14.5l1.5 1.5L21 7"/>'
  };
  function icon(name, size) {
    var s = document.createElementNS("http://www.w3.org/2000/svg", "svg");
    s.setAttribute("viewBox", "0 0 24 24"); s.setAttribute("width", size || 18); s.setAttribute("height", size || 18); s.setAttribute("fill", "none"); s.setAttribute("stroke", "currentColor");
    s.setAttribute("stroke-width", "2"); s.setAttribute("stroke-linecap", "round"); s.setAttribute("stroke-linejoin", "round"); s.setAttribute("aria-hidden", "true"); s.setAttribute("focusable", "false");
    s.innerHTML = PATHS[name] || ""; return s;
  }
  function iconBtn(name, label, onclick, cls) { return h("button", { type: "button", class: "btn ghost icon-only " + (cls || ""), "aria-label": label, title: label, onclick: onclick }, icon(name)); }

  /* formatting */
  function ms(v, tenths) { if (v == null) return ""; var s = Math.max(0, v) / 1000, m = Math.floor(s / 60), r = s - m * 60; return m + ":" + (tenths ? (r < 10 ? "0" : "") + r.toFixed(1) : (r < 10 ? "0" : "") + Math.floor(r)); }
  function sec(v) { return ms((v || 0) * 1000); }
  function size(n) { n = Number(n) || 0; return n < 1048576 ? Math.max(1, Math.round(n / 1024)) + " KB" : n < 1073741824 ? (n / 1048576).toFixed(n < 10485760 ? 1 : 0) + " MB" : (n / 1073741824).toFixed(1) + " GB"; }
  function when(iso, withTime) { if (!iso) return ""; var d = new Date(iso); return d.toLocaleDateString(lang(), { day: "numeric", month: "short" }) + (withTime ? " " + d.toLocaleTimeString(lang(), { hour: "2-digit", minute: "2-digit" }) : ""); }
  function clock(iso) { return new Date(iso).toLocaleTimeString(lang(), { hour: "2-digit", minute: "2-digit" }); }
  function money(v, symbol) { return (symbol || "€ ") + Number(v || 0).toLocaleString(lang(), { minimumFractionDigits: 2, maximumFractionDigits: 2 }); }
  /* rich text that comes from the server: "html:<clean html>" or plain text. Our own pass on top of the server's cleaning (a whitelist, no attributes except a safe href). */
  var OK_TAGS = { B: 1, STRONG: 1, I: 1, EM: 1, U: 1, S: 1, P: 1, BR: 1, UL: 1, OL: 1, LI: 1, A: 1, BLOCKQUOTE: 1, H3: 1, SPAN: 1 };
  function safeHtml(value) {
    var v = String(value || ""); if (v.indexOf("html:") !== 0) { var p = document.createElement("p"); p.textContent = v; return p.outerHTML; }
    var box = document.createElement("div"); box.innerHTML = v.slice(5);
    (function walk(node) {
      Array.prototype.slice.call(node.childNodes).forEach(function (c) {
        if (c.nodeType === 8) { node.removeChild(c); return; }
        if (c.nodeType !== 1) return;
        if (!OK_TAGS[c.tagName]) { while (c.firstChild) node.insertBefore(c.firstChild, c); node.removeChild(c); return; }
        Array.prototype.slice.call(c.attributes).forEach(function (a) { if (!(c.tagName === "A" && a.name === "href" && /^(https?:|mailto:)/i.test(a.value))) c.removeAttribute(a.name); });
        if (c.tagName === "A") { c.setAttribute("target", "_blank"); c.setAttribute("rel", "noopener noreferrer"); }
        walk(c);
      });
    })(box);
    return box.innerHTML;
  }
  function plain(value) { var d = document.createElement("div"); d.innerHTML = safeHtml(value); return (d.textContent || "").trim(); }
  function rich(value, cls) { return h("div", { class: "rich " + (cls || ""), html: safeHtml(value) }); }

  /* the small rich text editor (bold, italic, underline, list, link): CV.editor({value, placeholder, minHeight}) -> {el, get(), set(v)}; get() returns "html:<html>" or "" */
  function editor(o) {
    o = o || {};
    var area = h("div", { class: "cv-editor__area", contenteditable: "true", role: "textbox", "aria-multiline": "true", "aria-label": o.label || t("Tekst"), "data-placeholder": o.placeholder || "", style: "min-height:" + (o.minHeight || 90) + "px" });
    area.innerHTML = o.value ? safeHtml(o.value) : "";
    function cmd(c, arg) { return function (e) { e.preventDefault(); area.focus(); document.execCommand(c, false, arg || null); if (o.onChange) o.onChange(); }; }
    function btn(label, c, content, arg) { return h("button", { type: "button", class: "btn ghost icon-only", "aria-label": label, title: label, onmousedown: cmd(c, arg) }, content); }
    var saved = null, linkRow = null;
    function keepRange() { var sel = window.getSelection(); saved = sel && sel.rangeCount && area.contains(sel.anchorNode) ? sel.getRangeAt(0).cloneRange() : null; }
    var urlInput = h("input", { type: "url", placeholder: "https://", "aria-label": t("Webadres van de link"), class: "cv-editor__url" });
    function applyLink(e) {
      if (e) e.preventDefault();
      var u = String(urlInput.value || "").trim();
      if (/^(https?:\/\/|mailto:)/i.test(u)) { area.focus(); if (saved) { var sel = window.getSelection(); sel.removeAllRanges(); sel.addRange(saved); } document.execCommand("createLink", false, u); if (o.onChange) o.onChange(); }
      linkRow.hidden = true; urlInput.value = "";
    }
    linkRow = h("div", { class: "cv-editor__link", hidden: true }, urlInput, h("button", { type: "button", class: "btn primary", onclick: applyLink }, t("Toepassen")), h("button", { type: "button", class: "btn ghost", onclick: function () { linkRow.hidden = true; } }, t("Annuleren")));
    var bar = h("div", { class: "cv-editor__bar", role: "toolbar" }, btn(t("Vet"), "bold", h("b", {}, "B")), btn(t("Cursief"), "italic", h("i", {}, "I")), btn(t("Onderstreept"), "underline", h("u", {}, "U")), btn(t("Lijst"), "insertUnorderedList", "•"),
      h("button", { type: "button", class: "btn ghost icon-only", "aria-label": t("Link"), title: t("Link"), onmousedown: function (e) { e.preventDefault(); keepRange(); linkRow.hidden = false; urlInput.focus(); } }, icon("link", 16)));
    area.addEventListener("input", function () { if (o.onChange) o.onChange(); });
    area.addEventListener("paste", function (e) { e.preventDefault(); var txt = (e.clipboardData || window.clipboardData).getData("text/plain"); document.execCommand("insertText", false, txt); });
    return {
      el: h("div", { class: "cv-editor" }, bar, linkRow, area),
      get: function () { var txt = (area.textContent || "").trim(); return txt ? "html:" + safeHtml("html:" + area.innerHTML) : ""; },
      set: function (v) { area.innerHTML = v ? safeHtml(v) : ""; }
    };
  }

  /* the dialog with tabs and fixed buttons at the bottom: CV.dialog({eyebrow, title, tabs:[{key,label,render(body)}], footerLeft: node, buttons:[node...], wide, onClose}) -> {close, body, tab(key), root} */
  function dialog(o) {
    var cur = o.tabs && o.tabs[0] ? o.tabs[0].key : "", body = h("div", { class: "cv-dialog__body" }), tabsEl = null;
    var prev = document.activeElement;
    function close() { ov.remove(); document.removeEventListener("keydown", onKey); if (prev && prev.focus) try { prev.focus(); } catch (e) {} if (o.onClose) o.onClose(); }
    function onKey(e) { if (!ov.isConnected) { document.removeEventListener("keydown", onKey); return; } if (e.key === "Escape") close(); }
    function show(key) {
      cur = key; clear(body);
      var tab = (o.tabs || []).filter(function (x) { return x.key === key; })[0];
      if (tab) tab.render(body);
      if (tabsEl) Array.prototype.forEach.call(tabsEl.children, function (b) { b.classList.toggle("on", b.getAttribute("data-key") === key); b.setAttribute("aria-selected", b.getAttribute("data-key") === key ? "true" : "false"); });
    }
    if (o.tabs && o.tabs.length > 1) tabsEl = h("div", { class: "tabs", role: "tablist" }, o.tabs.map(function (x) { return h("button", { type: "button", role: "tab", "data-key": x.key, onclick: function () { show(x.key); } }, x.label); }));
    var panel = h("div", { class: "cv-dialog" + (o.wide ? " wide" : ""), role: "dialog", "aria-modal": "true", "aria-label": o.title || "" },
      h("div", { class: "cv-dialog__head" }, h("div", {}, o.eyebrow ? h("div", { class: "cv-eyebrow" }, o.eyebrow) : null, h("h2", {}, o.title || "")), iconBtn("x", t("Sluiten"), close)),
      tabsEl, body, h("div", { class: "cv-dialog__foot" }, h("div", { class: "cv-dialog__hint" }, o.footerLeft || null), h("div", { class: "row" }, o.buttons || [])));
    var ov = h("div", { class: "cv-overlay", onmousedown: function (e) { if (e.target === ov) close(); } }, panel);
    root().appendChild(ov); document.addEventListener("keydown", onKey);
    show(cur);
    var first = panel.querySelector("input, textarea, select, button.primary"); if (first) first.focus();
    return { close: close, body: body, tab: show, root: panel, current: function () { return cur; } };
  }
  function confirmBox(message, opts) { return system.confirm(message, opts || {}); }

  /* the avatar (initials) and a status badge */
  function avatar(p, cls) { return h("span", { class: "e2e-avatar " + (cls || ""), title: p && p.name || "" }, (p && p.initials) || "?"); }
  var STATUS = { concept: ["Concept", ""], gedeeld: ["Gedeeld", "info"], bekeken: ["Bekeken", "ok"], afgerond: ["Afgerond", "ok"], gearchiveerd: ["Gearchiveerd", ""] };
  function badge(status, text) { var s = STATUS[status] || [status, ""]; return h("span", { class: "badge " + s[1] }, text || t(s[0])); }
  /* t() for the status names that are only used through a variable: t("Concept") t("Gedeeld") t("Bekeken") t("Afgerond") t("Gearchiveerd") */

  /* messages */
  function toast(text, ok) { var el = h("div", { class: "cv-toast " + (ok === false ? "bad" : "ok"), role: "status" }, text); root().appendChild(el); setTimeout(function () { el.remove(); }, 3500); }
  function fail(e) { toast(e && e.message ? e.message : String(e), false); }
  function noCredit(e) { /* a 402 from the AI routes: the system's offer to buy credit */ return system.aiCredit(); }

  /* the views: each script registers CV.views.<name> = function (root, params) and a page moves with CV.go(name, params) (CV.back() returns) */
  var views = {};
  function go(name, params, replace) {
    if (!replace && S.view) S.stack.push({ view: S.view, params: S.params });
    S.view = name; S.params = params || {}; draw();
  }
  function back(fallback) { var p = S.stack.pop(); if (p) { S.view = p.view; S.params = p.params; draw(); } else go(fallback || "analyses", {}, true); }
  function draw() {
    var root = document.getElementById("app"); clear(root);
    var fn = views[S.view];
    if (!fn) { root.appendChild(h("p", { class: "muted" }, t("Deze pagina bestaat niet."))); return; }
    try { fn(root, S.params); } catch (e) { root.appendChild(h("div", { class: "alert" }, (e && e.message) || String(e))); console.error(e); }
    try { system.resize && system.resize(document.documentElement.scrollHeight); } catch (e2) {}
  }
  function start(initial) {
    system.ready.then(function (ctx) {
      S.ready = ctx;
      return call("home").then(function (home) {
        S.home = home;
        var q = (ctx.route && ctx.route.query) || {};
        var coach = !!(home.me && home.me.coach), params = q.analyse ? { id: q.analyse } : {}, first = initial || (q.analyse ? (coach ? "editor" : "bekijk") : coach ? "analyses" : "mijn");
        if (!initial && !q.analyse && q.koppelingen) { /* links in notifications and e-mails: ?koppelingen=1 */ first = coach ? "sporters" : "mijn"; params = { tab: coach ? "verzoeken" : "coaches" }; }
        else if (!initial && !q.analyse && Number(home.verzoeken) > 0 && !Object.keys(q).length) S.notice = true; /* somebody waits for an answer: a slim notice at the top of the first view */
        go(first, params, true);
      });
    }).catch(function (e) { var root = document.getElementById("app"); clear(root); root.appendChild(h("div", { class: "alert" }, (e && e.message) || String(e))); });
  }
  function refreshHome() { return call("home").then(function (home) { S.home = home; return home; }); }

  return { ROUTE: ROUTE, root: root, S: S, t: t, h: h, clear: clear, call: call, upload: upload, esc: esc, lang: lang, icon: icon, iconBtn: iconBtn, ms: ms, sec: sec, size: size, when: when, clock: clock, money: money, safeHtml: safeHtml, plain: plain, rich: rich,
           editor: editor, dialog: dialog, confirmBox: confirmBox, avatar: avatar, badge: badge, toast: toast, fail: fail, noCredit: noCredit, views: views, go: go, back: back, draw: draw, start: start, refreshHome: refreshHome };
})();
