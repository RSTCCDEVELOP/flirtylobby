// Copyright & Ownership Notice
// easy2Edit is the exclusive legal property of RST Coaching & Consultancy B.V. (RSTCC),
// owned by Ronald Stolk. All rights reserved. Any unauthorized use, copying, modification,
// reproduction, distribution, or commercial exploitation of Easy2Edit, including its source code,
// is strictly prohibited without prior written permission from Ronald Stolk or RSTCC.
// website https://rstcc.net

"use strict";
/* Coach video: the admin page (overview and explanation). Texts only used through a variable: t("Lokaal") t("S3") */
(function () {
  var t = CV.t, h = CV.h;

  function stat(label, value, sub) { return h("div", { class: "cva-stat" }, h("div", { class: "cva-stat__label" }, label), h("div", { class: "cva-stat__value" }, String(value)), sub ? h("small", { class: "muted" }, sub) : null); }
  function num(n) { return Number(n || 0).toLocaleString(CV.lang()); }

  function overview(body) {
    CV.clear(body); body.appendChild(h("div", { class: "cva-loading", role: "status" }, t("Laden…")));
    CV.call("admin/overview").then(function (d) {
      CV.clear(body);
      body.appendChild(h("div", { class: "cva-stats" },
        stat(t("Analyses"), num(d.analyses)), stat(t("Bestanden"), num(d.media), CV.size(d.grootte)), stat(t("Berichten"), num(d.berichten)),
        stat(t("Instructievideo's"), num(d.bibliotheek)), stat(t("AI-opdrachten"), num(d.ai_opdrachten)),
        stat(t("Video verkleinen (ffmpeg)"), d.ffmpeg ? t("Aanwezig") : t("Niet aanwezig"), d.ffmpeg ? null : t("Video's blijven dan zoals ze zijn geüpload.")),
        stat(t("Opslag"), d.opslag === "s3" ? t("S3") : t("Lokaal"))));
      var rows = d.per_coach || [];
      body.appendChild(h("h2", { class: "cva-h" }, t("Opslag per coach")));
      if (!rows.length) { body.appendChild(h("p", { class: "muted" }, t("Er zijn nog geen bestanden opgeslagen."))); return; }
      var max = Math.max.apply(null, rows.map(function (r) { return r.bytes; })) || 1;
      body.appendChild(h("div", { class: "cva-table-wrap" }, h("table", { class: "cva-table" },
        h("caption", { class: "cva-sr" }, t("Opslag per coach")),
        h("thead", {}, h("tr", {}, h("th", { scope: "col" }, t("Coach")), h("th", { scope: "col", class: "num" }, t("Bestanden")), h("th", { scope: "col", class: "num" }, t("Grootte")), h("th", { scope: "col", class: "cva-bar-col" }, ""))),
        h("tbody", {}, rows.map(function (r) {
          return h("tr", {}, h("td", {}, h("span", { class: "row cva-who" }, CV.avatar(r.coach || {}, "e2e-avatar--sm"), h("span", {}, (r.coach && r.coach.name) || t("Verwijderde gebruiker")))),
            h("td", { class: "num" }, num(r.bestanden)), h("td", { class: "num" }, CV.size(r.bytes)),
            h("td", { class: "cva-bar-col" }, h("span", { class: "cva-meter", "aria-hidden": "true" }, h("span", { style: "width:" + Math.max(2, Math.round(r.bytes * 100 / max)) + "%" }))));
        })))));
    }).catch(function (e) { CV.clear(body); body.appendChild(h("div", { class: "alert", role: "alert" }, h("span", {}, (e && e.message) || String(e)), h("button", { type: "button", class: "btn", onclick: function () { overview(body); } }, t("Opnieuw proberen")))); });
  }

  function explain(body) {
    CV.clear(body);
    function block(title, items) { return h("section", { class: "card cva-explain" }, h("h2", {}, title), h("ol", {}, items.map(function (i) { return h("li", {}, i); }))); }
    body.appendChild(block(t("Coaches aanmaken"), [
      t("Maak in Gebruikers een gebruikersgroep aan, bijvoorbeeld Coaches."),
      t("Zet bij de instellingen van deze plugin de naam van die groep bij Gebruikersgroepen van de coaches (meer namen mag, gescheiden door een komma)."),
      t("Voeg de gebruikers die coach moeten worden toe aan die groep. Beheerders zijn altijd coach."),
      t("Bij Wie mag een coach als sporter koppelen stel je in welke leden een coach als sporter kan kiezen: alle leden, een groep of de leden van zijn eigen bedrijf of club.")]));
    body.appendChild(block(t("AI-tegoed"), [
      t("De coach betaalt het AI-gebruik uit zijn eigen tegoed; de kosten van een opdracht staan bij de analyse."),
      t("De coach kan zelf opwaarderen op het scherm AI-tegoed of in de analyse als het tegoed te laag is."),
      t("Is de AI op deze site niet gekoppeld, dan werkt alles behalve de AI-instructie.")]));
    body.appendChild(block(t("Instellingen en rechten"), [
      t("Maximale grootte en duur van video's, het verkleinen van video, de opslag (plugin-map of S3), de bewaartermijn van gearchiveerde analyses en de chat staan bij de instellingen van deze plugin."),
      t("Wie een analyse mag zien, wordt beheerd met het rechtensysteem: een sporter ziet alleen wat de coach met hem of haar gedeeld heeft."),
      t("Het tabblad Overzicht laat zien hoeveel ruimte elke coach gebruikt.")]));
  }

  CV.views.admin = function (root) {
    var q = (CV.S.ready && CV.S.ready.route && CV.S.ready.route.query) || {}, cur = q.tab === "uitleg" ? "uitleg" : "overview";
    var body = h("div", { class: "cva-body", role: "tabpanel" }), btns = {};
    function show(k) {
      cur = k; Object.keys(btns).forEach(function (x) { btns[x].classList.toggle("on", x === k); btns[x].setAttribute("aria-selected", x === k ? "true" : "false"); btns[x].tabIndex = x === k ? 0 : -1; });
      (k === "overview" ? overview : explain)(body);
      try { system.resize && system.resize(document.documentElement.scrollHeight); } catch (e) {}
    }
    var tabs = h("div", { class: "tabs", role: "tablist", "aria-label": t("Coach video") }, [["overview", t("Overzicht")], ["uitleg", t("Uitleg")]].map(function (x, i, all) {
      return (btns[x[0]] = h("button", { type: "button", role: "tab", onclick: function () { show(x[0]); }, onkeydown: function (e) {
        if (e.key === "ArrowRight" || e.key === "ArrowLeft") { var n = all[(i + (e.key === "ArrowRight" ? 1 : all.length - 1)) % all.length][0]; show(n); btns[n].focus(); }
      } }, x[1]));
    }));
    root.appendChild(h("div", { class: "cva-head" }, h("div", { class: "cv-eyebrow" }, t("COACH VIDEO")), h("h1", {}, t("Beheer"))));
    root.appendChild(tabs); root.appendChild(body); show(cur);
  };
})();
