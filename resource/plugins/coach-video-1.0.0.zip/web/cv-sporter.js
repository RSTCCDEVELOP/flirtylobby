// Copyright & Ownership Notice
// easy2Edit is the exclusive legal property of RST Coaching & Consultancy B.V. (RSTCC),
// owned by Ronald Stolk. All rights reserved. Any unauthorized use, copying, modification,
// reproduction, distribution, or commercial exploitation of Easy2Edit, including its source code,
// is strictly prohibited without prior written permission from Ronald Stolk or RSTCC.
// website https://rstcc.net

"use strict";
/* Coach video: the screens of the athlete and the chat.
   Exports: CV.player(container, media[], tekeningen[], opmerkingen[], opts) -> {el, seek(ms), seekRemark(r), time(), mediaId(), snapshot(), setMedia(i), destroy()}
            CV.chat(container, analyseId, {rol, onSeek(ms), getSnapshot(), getTime(), getMediaId(), onUnread(n), compact}) -> {destroy(), refresh(), markRead(), toBottom()}
            CV.sporterLogic = pure helpers (dayKey, dayDiff, mergeMessages, msgSig, ymd) ; CV.views.mijn (athlete, tabs Analyses / Coaches) ; CV.coachesPanel(container, {data, onData(koppelingen)}) = my coaches, requests for me, add a coach by e-mail ; CV.views.bekijk (coach: "Bekijk als sporter")
   Texts that are only used through a variable (for the translation tool): t("Vandaag") t("Gisteren") t("Afspelen") t("Pauzeren") t("Gelezen") t("Verzonden") t("foto") t("video") t("afgerond") */
(function () {
  var h = CV.h, t = CV.t;
  var FULL = ["Vandaag", "Gisteren"]; void FULL;

  /* ───── pure logic (also tested outside the browser) ───── */
  function p2(n) { return (n < 10 ? "0" : "") + n; }
  function ymd(d) { return d.getFullYear() + "-" + p2(d.getMonth() + 1) + "-" + p2(d.getDate()); }
  function dayKey(iso) { return ymd(new Date(iso)); }
  function dayDiff(iso, now) { var a = new Date(iso), b = now ? new Date(now) : new Date(); return Math.round((Date.UTC(b.getFullYear(), b.getMonth(), b.getDate()) - Date.UTC(a.getFullYear(), a.getMonth(), a.getDate())) / 864e5); }
  function stamp(m) { return Date.parse(m.aangemaakt_op) || 0; }
  function mergeMessages(list, incoming) {
    var by = {}; (list || []).forEach(function (m) { by[m.id] = m; }); (incoming || []).forEach(function (m) { by[m.id] = m; });
    return Object.keys(by).map(function (k) { return by[k]; }).sort(function (a, b) { return stamp(a) - stamp(b) || (a.id < b.id ? -1 : 1); });
  }
  function msgSig(list) { return (list || []).map(function (m) { return m.id + (m.verwijderd ? "x" : "") + (m.gelezen ? "g" : "") + (m.bewerkt_op || ""); }).join("|"); }
  CV.sporterLogic = { ymd: ymd, dayKey: dayKey, dayDiff: dayDiff, mergeMessages: mergeMessages, msgSig: msgSig };

  function dayText(iso) {
    var d = dayDiff(iso);
    if (d === 0) return t("Vandaag"); if (d === 1) return t("Gisteren");
    var x = new Date(iso), o = { weekday: "long", day: "numeric", month: "long" }; if (x.getFullYear() !== new Date().getFullYear()) o.year = "numeric";
    return x.toLocaleDateString(CV.lang(), o);
  }
  function isStatus(e, n) { return e && (e.status === n || new RegExp("\\b" + n + "\\b").test(String(e.message || ""))); }
  function noop() {}

  /* ───── the player: a read-only stage with the drawing of the coach, controls and markers ───── */
  CV.player = function (container, media, tekeningen, opmerkingen, opts) {
    opts = opts || {};
    var list = (media || []).filter(Boolean), cur = 0, show = true, fired = {}, lastMs = 0, raf = 0, dead = false, el = null, svg = null, m = null, vid = false, dur = 0, pendingSeek = null, active = null;
    var box = h("div", { class: "e2e-annot cv-player", tabindex: "-1" });
    var stage = h("div", { class: "e2e-annot__media cv-player__stage" });
    var playBtn = h("button", { type: "button", class: "btn ghost icon-only cv-player__play", onclick: toggle }), timeEl = h("span", { class: "e2e-annot__time", "aria-live": "off" }, "0:00 / 0:00");
    var seekIn = h("input", { type: "range", class: "e2e-annot__range", min: 0, max: 1000, step: 10, value: 0, "aria-label": t("Zoek in de video"), oninput: function () { doSeek(Number(seekIn.value), true); } });
    var marks = h("div", { class: "cv-player__marks" });
    var seekWrap = h("div", { class: "e2e-annot__seek" }, seekIn, marks);
    var linesChk = h("input", { type: "checkbox", checked: true, onchange: function () { show = linesChk.checked; draw(); } });
    var linesLbl = h("label", { class: "cv-player__lines" }, linesChk, h("span", {}, t("Lijnen tonen")));
    var fsBtn = CV.iconBtn("fullscreen", t("Volledig scherm"), fullscreen);
    var controls = h("div", { class: "e2e-annot__controls" }, playBtn, timeEl, seekWrap, linesLbl, fsBtn);
    var note = h("div", { class: "cv-player__note", hidden: true, role: "status" });
    var sw = list.length > 1 ? h("div", { class: "cv-player__sw", role: "group", "aria-label": t("Kies een beeld") }, list.map(function (x, i) { return h("button", { type: "button", class: "btn ghost", "aria-pressed": "false", onclick: function () { load(i); } }, CV.icon(x.soort === "video" ? "video" : "image", 15), " " + (x.naam || (t("Beeld") + " " + (i + 1)))); })) : null;
    box.appendChild(stage); box.appendChild(controls); box.appendChild(note); if (sw) box.appendChild(sw);
    if (!(box.requestFullscreen || box.webkitRequestFullscreen)) fsBtn.hidden = true;
    container.appendChild(box);

    function setPlayIcon() { var paused = !el || !vid || el.paused; CV.clear(playBtn); playBtn.appendChild(CV.icon(paused ? "play" : "pause")); playBtn.setAttribute("aria-label", paused ? t("Afspelen") : t("Pauzeren")); playBtn.title = playBtn.getAttribute("aria-label"); }
    function fullscreen() { try { if (document.fullscreenElement || document.webkitFullscreenElement) (document.exitFullscreen || document.webkitExitFullscreen).call(document); else (box.requestFullscreen || box.webkitRequestFullscreen).call(box); } catch (e) { /* not allowed in this frame */ } }
    function toggle() { if (!vid) return; if (el.paused) { if (el.ended) el.currentTime = 0; var p = el.play(); if (p && p.catch) p.catch(noop); } else el.pause(); }
    function msNow() { return vid && el ? el.currentTime * 1000 : null; }
    function draw() {
      if (!svg || !m) return; CV.draw.setup(svg, m.breedte || (el && el.videoWidth) || 16, m.hoogte || (el && el.videoHeight) || 9);
      CV.draw.render(svg, tekeningen || [], vid ? msNow() : null, { onlyFor: m.id }); svg.style.display = show ? "" : "none";
    }
    function mineRemarks() { return (opmerkingen || []).filter(function (r) { return m && (!r.media_id || r.media_id === m.id) && r.tijd_ms != null; }); }
    function setActive(r) {
      active = r;
      if (r) { CV.clear(note); note.hidden = false; note.appendChild(h("span", { class: "cv-s-num" }, String(r.nummer || ""))); note.appendChild(CV.rich(r.tekst, "cv-player__notetext")); } else { note.hidden = true; CV.clear(note); }
      if (opts.onRemark) opts.onRemark(r);
    }
    function buildMarks() {
      CV.clear(marks); if (!vid || !dur) return;
      mineRemarks().forEach(function (r) {
        marks.appendChild(h("button", { type: "button", class: "e2e-annot__mark", style: "left:" + Math.min(100, Math.max(0, r.tijd_ms / dur * 100)) + "%", "aria-label": t("Opmerking") + " " + (r.nummer || "") + " · " + CV.ms(r.tijd_ms), title: t("Opmerking") + " " + (r.nummer || "") + " · " + CV.ms(r.tijd_ms), onclick: function () { doSeek(r.tijd_ms, true); setActive(r); } }));
      });
    }
    function tick() {
      if (!vid || !el) return; var ms = el.currentTime * 1000; if (!dur && isFinite(el.duration)) { dur = el.duration * 1000; seekIn.max = Math.round(dur); buildMarks(); }
      seekIn.value = Math.round(ms); timeEl.textContent = CV.ms(ms) + " / " + CV.ms(dur); seekIn.setAttribute("aria-valuetext", timeEl.textContent); draw();
      if (!el.paused) mineRemarks().forEach(function (r) { if (r.pauzeren && !fired[r.id] && r.tijd_ms > lastMs && r.tijd_ms <= ms && ms - lastMs < 1200) { fired[r.id] = 1; el.pause(); el.currentTime = r.tijd_ms / 1000; setActive(r); } });
      lastMs = ms;
    }
    function loop() { raf = 0; if (dead || !box.isConnected) { dead = true; return; } tick(); if (el && !el.paused) raf = requestAnimationFrame(loop); }
    function doSeek(ms, user) {
      if (!vid || !el) return; el.currentTime = Math.max(0, ms) / 1000; lastMs = ms; mineRemarks().forEach(function (r) { if (r.tijd_ms > ms) delete fired[r.id]; });
      if (user && active && Math.abs((active.tijd_ms || 0) - ms) > 300) setActive(null); tick();
    }
    function load(i) {
      cur = i; m = list[i]; fired = {}; lastMs = 0; dur = m && m.duur_ms || 0; active = null; note.hidden = true; if (el && vid) try { el.pause(); } catch (e) { /* gone */ }
      CV.clear(stage); if (!m) { stage.appendChild(h("p", { class: "empty" }, t("Er is geen beeld."))); return; }
      vid = m.soort === "video"; var ratio = (m.breedte && m.hoogte) ? m.breedte / m.hoogte : 16 / 9;
      stage.style.cssText = "aspect-ratio:" + ratio + ";width:min(100%," + Math.round(640 * ratio) + "px)";
      el = vid ? h("video", { class: "cv-player__el", src: m.url, poster: m.poster || false, playsinline: true, preload: "metadata", "aria-label": m.naam || t("Video van je coach"), onclick: toggle })
               : h("img", { class: "cv-player__el", src: m.url, alt: m.naam || t("Foto van de analyse"), onload: draw });
      svg = document.createElementNS("http://www.w3.org/2000/svg", "svg"); svg.setAttribute("class", "e2e-annot__svg"); svg.setAttribute("aria-label", t("Tekeningen van je coach"));
      stage.appendChild(el); stage.appendChild(svg);
      seekWrap.hidden = timeEl.hidden = playBtn.hidden = !vid; linesLbl.hidden = !(tekeningen || []).some(function (x) { return x.media_id === m.id; });
      seekIn.max = dur || 1000; seekIn.value = 0; timeEl.textContent = "0:00 / " + CV.ms(dur); setPlayIcon(); buildMarks();
      if (vid) {
        el.addEventListener("loadedmetadata", function () { dur = el.duration * 1000; seekIn.max = Math.round(dur); if (!m.breedte && el.videoWidth) stage.style.aspectRatio = el.videoWidth + "/" + el.videoHeight; buildMarks(); if (pendingSeek != null) { doSeek(pendingSeek); pendingSeek = null; } tick(); });
        el.addEventListener("play", function () { setPlayIcon(); if (active) setActive(null); if (!raf) raf = requestAnimationFrame(loop); });
        ["pause", "ended"].forEach(function (n) { el.addEventListener(n, function () { setPlayIcon(); tick(); }); });
        ["timeupdate", "seeked"].forEach(function (n) { el.addEventListener(n, tick); });
        el.addEventListener("error", function () { stage.appendChild(h("p", { class: "alert cv-player__err" }, t("Deze video kan niet worden afgespeeld."))); });
      }
      if (sw) Array.prototype.forEach.call(sw.children, function (b, k) { b.setAttribute("aria-pressed", k === i ? "true" : "false"); b.classList.toggle("on", k === i); });
      draw();
    }
    box.addEventListener("keydown", function (e) { if ((e.key === " " || e.key === "k") && e.target && (e.target === box || e.target === el)) { e.preventDefault(); toggle(); } });
    document.addEventListener("fullscreenchange", fsChange); function fsChange() { if (!box.isConnected) { document.removeEventListener("fullscreenchange", fsChange); return; } box.classList.toggle("is-full", document.fullscreenElement === box); }
    load(0);

    var api = {
      el: box, mediaId: function () { return m ? m.id : null; }, time: function () { var x = msNow(); return x == null ? null : Math.round(x); },
      seek: function (ms) { if (!vid) return; doSeek(ms, true); try { box.scrollIntoView({ behavior: "smooth", block: "nearest" }); } catch (e) { /* old browser */ } },
      seekRemark: function (r) {
        var i = list.findIndex(function (x) { return x.id === r.media_id; });
        if (i >= 0 && i !== cur) { pendingSeek = r.tijd_ms; load(i); } else if (r.tijd_ms != null) doSeek(r.tijd_ms, true);
        setActive(r); try { box.scrollIntoView({ behavior: "smooth", block: "nearest" }); } catch (e) { /* old browser */ }
      },
      setMedia: function (i) { if (list[i]) load(i); },
      /* a still of the current frame (with the drawing when "Lijnen tonen" is on) for the chat: resolves {blob, tijd_ms, media_id, met_tekening}; rejects when the browser does not allow reading the frame */
      snapshot: function () {
        return new Promise(function (resolve, reject) {
          if (!m || !el) return reject(new Error("geen beeld"));
          var w = vid ? el.videoWidth : el.naturalWidth, hh = vid ? el.videoHeight : el.naturalHeight; if (!w || !hh) return reject(new Error("geen beeld"));
          var k = Math.min(1, 1568 / Math.max(w, hh)), c = document.createElement("canvas"); c.width = Math.round(w * k); c.height = Math.round(hh * k);
          var g = c.getContext("2d"), withDraw = show && svg && svg.childNodes.length > 0;
          function done() { try { c.toBlob(function (b) { b ? resolve({ blob: b, tijd_ms: api.time(), media_id: m.id, met_tekening: !!withDraw }) : reject(new Error("leeg")); }, "image/jpeg", 0.85); } catch (e) { reject(e); } }
          try {
            g.drawImage(el, 0, 0, c.width, c.height);
            if (!withDraw) return done();
            var s = svg.cloneNode(true); s.setAttribute("xmlns", "http://www.w3.org/2000/svg"); s.setAttribute("width", c.width); s.setAttribute("height", c.height);
            var im = new Image(); im.onload = function () { try { g.drawImage(im, 0, 0, c.width, c.height); } catch (e) { /* the frame alone */ } done(); }; im.onerror = done;
            im.src = "data:image/svg+xml;charset=utf-8," + encodeURIComponent(new XMLSerializer().serializeToString(s));
          } catch (e) { reject(e); }
        });
      },
      destroy: function () { dead = true; if (raf) cancelAnimationFrame(raf); document.removeEventListener("fullscreenchange", fsChange); try { if (el && vid) el.pause(); } catch (e) { /* gone */ } box.remove(); }
    };
    return api;
  };

  /* ───── the chat ───── */
  CV.chat = function (container, id, opts) {
    opts = opts || {};
    var S = { msgs: [], nu: null, people: [], dead: false, timer: 0, tick: 0, fails: 0, unread: 0, pending: null, useTime: false, timeRef: null, sending: false, off: false, first: true, forceFile: false, below: false, sig: "" };
    var root = h("section", { class: "e2e-chat cv-chat" + (opts.compact ? " is-compact" : ""), "aria-label": t("Chat over deze analyse") });
    var headName = h("div", { class: "cv-chat__who" }), head = h("div", { class: "cv-chat__head" }, h("span", { class: "e2e-avatar" }, CV.icon("message", 16)), h("div", { class: "grow" }, headName, h("small", { class: "muted" }, t("Chat over deze analyse"))));
    var list = h("div", { class: "e2e-chat__list cv-chat__list", role: "log", "aria-live": "polite", "aria-label": t("Berichten"), tabindex: "0" });
    var newBtn = h("button", { type: "button", class: "btn cv-chat__new", hidden: true, onclick: function () { toBottom(); } }, CV.icon("chevron", 15), " " + t("Nieuwe berichten"));
    var input = h("textarea", { class: "e2e-chat__input", rows: 1, maxlength: 4000, placeholder: t("Schrijf een bericht…"), "aria-label": t("Bericht"), oninput: grow, onkeydown: function (e) { if (e.key === "Enter" && !e.shiftKey && !e.isComposing) { e.preventDefault(); send(); } } });
    var file = h("input", { type: "file", accept: "image/*", hidden: true, onchange: function () { var f = file.files && file.files[0]; file.value = ""; if (f) attachBlob({ blob: f }); } });
    var attachBtn = CV.iconBtn("clip", t("Beeld toevoegen"), attach, "cv-chat__attach");
    var sendBtn = h("button", { type: "button", class: "e2e-chat__send", "aria-label": t("Verstuur"), title: t("Verstuur"), onclick: send }, CV.icon("send", 18));
    var pendEl = h("div", { class: "cv-chat__pend", hidden: true });
    var timeChip = h("button", { type: "button", class: "e2e-chip cv-chat__time", hidden: true, "aria-pressed": "false", onclick: toggleTime });
    var off = h("p", { class: "cv-chat__off muted", hidden: true, role: "status" });
    var composer = h("div", { class: "e2e-chat__composer cv-chat__composer" }, pendEl, h("div", { class: "cv-chat__chips" }, timeChip), h("div", { class: "cv-chat__row" }, attachBtn, input, sendBtn), file);
    root.appendChild(head); root.appendChild(list); root.appendChild(newBtn); root.appendChild(off); root.appendChild(composer); container.appendChild(root);

    function grow() { input.style.height = "auto"; input.style.height = Math.min(input.scrollHeight, 130) + "px"; }
    function myRol() { var mine = S.msgs.filter(function (x) { return x.mine; })[0]; return mine ? mine.rol : (opts.rol || null); }
    function renderHead() {
      var rol = myRol(), others = S.people.filter(function (p) { return rol === "coach" ? p.rol !== "coach" : p.rol === "coach"; });
      CV.clear(headName); headName.appendChild(document.createTextNode(others.length ? others.map(function (p) { return p.name; }).join(", ") : (rol === "coach" ? t("Sporter") : t("Coach"))));
      var p = others[0]; if (p) { var av = head.firstChild; av.replaceWith(CV.avatar(p)); }
    }
    function visible() { return !S.dead && !document.hidden && container.isConnected && root.offsetParent !== null; }
    function atBottom() { return list.scrollHeight - list.scrollTop - list.clientHeight < 56; }
    function toBottom() { list.scrollTop = list.scrollHeight; S.below = false; newBtn.hidden = true; }

    function bubble(m) {
      var left = m.rol === "coach", name = m.mine ? t("Jij") : ((m.afzender && m.afzender.name) || "");
      var bub = h("div", { class: "e2e-chat__bubble" + (m.verwijderd ? " is-deleted" : "") });
      if (m.verwijderd) bub.appendChild(h("em", {}, t("Dit bericht is verwijderd.")));
      else {
        if (m.tekst) bub.appendChild(h("p", { class: "cv-chat__text" }, m.tekst));
        if (m.tijd_ref_ms != null) {
          var lbl = [CV.icon("clock", 13), " " + CV.ms(m.tijd_ref_ms)];
          bub.appendChild(opts.onSeek ? h("button", { type: "button", class: "e2e-chat__ref", title: t("Ga naar dit moment in de video"), "aria-label": t("Ga naar") + " " + CV.ms(m.tijd_ref_ms), onclick: function () { opts.onSeek(m.tijd_ref_ms); } }, lbl) : h("span", { class: "e2e-chat__ref" }, lbl));
        }
        if (m.momentopname && m.momentopname.url) bub.appendChild(h("button", { type: "button", class: "cv-chat__imgbtn", "aria-label": t("Beeld groter bekijken"), onclick: function () { zoom(m.momentopname.url); } }, h("img", { class: "e2e-chat__img", src: m.momentopname.url, alt: t("Beeld uit de video"), loading: "lazy" })));
      }
      var meta = h("div", { class: "e2e-chat__meta" }, h("span", {}, CV.clock(m.aangemaakt_op)));
      if (m.mine && !m.verwijderd) { var ok = !!m.gelezen; meta.appendChild(h("span", { class: "cv-chat__tick" + (ok ? " is-read" : ""), role: "img", "aria-label": ok ? t("Gelezen") : t("Verzonden"), title: ok ? t("Gelezen") : t("Verzonden") }, CV.icon(ok ? "tick" : "check", 14))); }
      if (!m.verwijderd && (m.mine || myRol() === "coach")) meta.appendChild(h("button", { type: "button", class: "cv-chat__del", "aria-label": t("Bericht verwijderen"), title: t("Bericht verwijderen"), onclick: function () { del(m); } }, CV.icon("trash", 14)));
      return h("div", { class: "e2e-chat__msg e2e-chat__msg--" + (left ? "left" : "right") + (m.mine ? " is-mine" : ""), "data-id": m.id },
        h("div", { class: "e2e-chat__name" }, name, left ? h("span", { class: "cv-chat__role" }, t("Coach")) : null), bub, meta);
    }
    function render(forceBottom) {
      var stick = S.first || forceBottom || atBottom(), top = list.scrollTop; CV.clear(list); renderHead();
      if (!S.msgs.length) list.appendChild(h("p", { class: "e2e-chat__empty muted" }, S.off ? "" : t("Nog geen berichten. Stel gerust een vraag.")));
      var day = null;
      S.msgs.forEach(function (m) { var k = dayKey(m.aangemaakt_op); if (k !== day) { day = k; list.appendChild(h("div", { class: "e2e-chat__day" }, dayText(m.aangemaakt_op))); } list.appendChild(bubble(m)); });
      if (stick) { list.scrollTop = list.scrollHeight; S.below = false; } else list.scrollTop = top;
      newBtn.hidden = !S.below; if (visible()) S.first = false;
    }
    function zoom(url) {
      var d = CV.dialog({ title: t("Beeld uit de video"), wide: true, tabs: [{ key: "b", label: t("Beeld"), render: function (b) { b.appendChild(h("img", { class: "cv-chat__zoom", src: url, alt: t("Beeld uit de video") })); } }], buttons: [h("button", { type: "button", class: "btn primary", onclick: function () { d.close(); } }, t("Sluiten"))] });
    }
    function del(m) {
      CV.confirmBox(t("Dit bericht verwijderen?"), { title: t("Bericht verwijderen"), okLabel: t("Verwijderen"), danger: true }).then(function (yes) {
        if (!yes) return; return CV.call("chat/bericht/" + m.id, "DELETE").then(function () { m.verwijderd = true; m.tekst = ""; m.tijd_ref_ms = null; m.momentopname = null; render(); });
      }).catch(CV.fail);
    }

    function apply(res, partial) {
      var known = {}; S.msgs.forEach(function (x) { known[x.id] = 1; });
      var fresh = (res.berichten || []).filter(function (x) { return !known[x.id] && !x.mine; });
      var low = atBottom(); S.msgs = partial ? mergeMessages(S.msgs, res.berichten) : mergeMessages([], res.berichten); if (res.nu) S.nu = res.nu; if (res.deelnemers) S.people = res.deelnemers;
      var sig = msgSig(S.msgs) + "|" + S.people.length, changed = sig !== S.sig; S.sig = sig;
      if (fresh.length && !low && !S.first) S.below = true;
      if (changed) render();
      if (fresh.length || (!partial && (res.ongelezen || 0) > 0)) { if (visible()) markRead(); else { S.unread += fresh.length || res.ongelezen || 0; if (opts.onUnread) opts.onUnread(S.unread); } }
    }
    function unavailable(e) {
      S.off = true; off.hidden = false; off.textContent = (e && e.message) || t("De chat is niet beschikbaar."); composer.querySelectorAll("textarea, button").forEach(function (b) { b.disabled = true; }); render();
    }
    function markRead() {
      S.unread = 0; if (opts.onUnread) opts.onUnread(0); if (S.off || S.dead) return;
      CV.call("chat/" + id + "/gelezen", "POST", {}).catch(noop);
    }
    function load() { return CV.call("chat/" + id).then(function (res) { S.fails = 0; apply(res, false); }); }
    function poll() {
      S.timer = 0; if (S.dead) return; if (!container.isConnected) { destroy(); return; }
      S.tick++; var full = S.tick % 6 === 0 || !S.nu;  /* every half minute a full reload: the read ticks of my messages change without the message changing */
      CV.call("chat/" + id + (full ? "" : "?after=" + encodeURIComponent(S.nu))).then(function (res) { S.fails = 0; apply(res, !full); }).catch(function (e) { S.fails++; if (isStatus(e, 404) && S.fails > 2) unavailable(e); }).then(schedule);
    }
    function schedule() { if (S.dead || S.off) return; var wait = (document.hidden ? 20000 : 5000) * (S.fails ? Math.min(6, 1 + S.fails) : 1); S.timer = setTimeout(poll, wait); }
    function onVis() { if (S.dead) return; if (!document.hidden) { clearTimeout(S.timer); S.timer = 0; if (!S.off) { poll(); if (visible() && S.unread) markRead(); } } }
    document.addEventListener("visibilitychange", onVis); list.addEventListener("scroll", function () { if (atBottom()) { S.below = false; newBtn.hidden = true; } });

    /* composer */
    function syncTime() {
      if (S.dead) return; var cur = opts.getTime ? opts.getTime() : null;
      if (S.useTime) { timeChip.hidden = false; timeChip.textContent = ""; timeChip.appendChild(CV.icon("clock", 13)); timeChip.appendChild(document.createTextNode(" " + t("Verwijst naar") + " " + CV.ms(S.timeRef))); timeChip.setAttribute("aria-pressed", "true"); timeChip.classList.add("on"); }
      else if (cur != null) { timeChip.hidden = false; timeChip.textContent = ""; timeChip.appendChild(CV.icon("clock", 13)); timeChip.appendChild(document.createTextNode(" " + t("Verwijs naar") + " " + CV.ms(cur))); timeChip.setAttribute("aria-pressed", "false"); timeChip.classList.remove("on"); }
      else timeChip.hidden = true;
    }
    function toggleTime() { if (S.useTime) { S.useTime = false; S.timeRef = null; } else { var cur = opts.getTime ? opts.getTime() : null; if (cur == null) return; S.useTime = true; S.timeRef = cur; } syncTime(); }
    var clockTimer = setInterval(function () { if (!container.isConnected) { destroy(); return; } if (!S.useTime) syncTime(); }, 700);
    function setPending(p) {
      if (S.pending && S.pending.local) try { URL.revokeObjectURL(S.pending.local); } catch (e) { /* ok */ }
      S.pending = p; CV.clear(pendEl); pendEl.hidden = !p; if (!p) return;
      pendEl.appendChild(h("img", { class: "cv-chat__thumb", src: p.local, alt: t("Beeld dat je meestuurt") })); pendEl.appendChild(h("span", { class: "grow" }, t("Beeld toegevoegd")));
      pendEl.appendChild(CV.iconBtn("x", t("Beeld weghalen"), function () { setPending(null); }));
    }
    function attachBlob(s) {
      var blob = s.blob || s.file || s; if (!blob || !/^image\//.test(blob.type || "image/jpeg")) { CV.toast(t("Kies een afbeelding."), false); return Promise.resolve(); }
      attachBtn.disabled = true;
      var f = { media_id: s.media_id || (opts.getMediaId ? opts.getMediaId() : "") || "", met_tekening: s.met_tekening ? 1 : 0 }; if (s.tijd_ms != null) f.tijd_ms = Math.round(s.tijd_ms); if (!f.media_id) delete f.media_id;
      return CV.upload("analyses/" + id + "/momentopnames", blob, f).then(function (r) { setPending({ id: r.id, local: URL.createObjectURL(blob) }); input.focus(); }).catch(CV.fail).then(function () { attachBtn.disabled = S.off; });
    }
    function attach() {
      if (!opts.getSnapshot || S.forceFile) { S.forceFile = false; file.click(); return; }
      attachBtn.disabled = true;
      Promise.resolve().then(opts.getSnapshot).then(function (s) { if (!s) throw new Error("leeg"); return attachBlob(s); })
        .catch(function () { S.forceFile = true; CV.toast(t("Het beeld kon niet worden vastgelegd. Druk nog eens op de knop om een afbeelding te kiezen."), false); }).then(function () { attachBtn.disabled = S.off; });
    }
    function send() {
      var txt = input.value.trim(); if (S.sending || S.off || (!txt && !S.pending)) return;
      S.sending = true; sendBtn.disabled = true; var body = { tekst: txt }; if (S.pending) body.momentopname_id = S.pending.id; if (S.useTime && S.timeRef != null) body.tijd_ref_ms = Math.round(S.timeRef);
      CV.call("chat/" + id, "POST", body).then(function (m) {
        S.msgs = mergeMessages(S.msgs, [m]); S.sig = msgSig(S.msgs) + "|" + S.people.length; input.value = ""; grow(); setPending(null); S.useTime = false; S.timeRef = null; syncTime(); render(true); markRead();
      }).catch(function (e) { if (isStatus(e, 404)) unavailable(e); else CV.fail(e); }).then(function () { S.sending = false; sendBtn.disabled = S.off; input.focus(); });
    }
    function destroy() { S.dead = true; clearTimeout(S.timer); clearInterval(clockTimer); document.removeEventListener("visibilitychange", onVis); if (S.pending && S.pending.local) try { URL.revokeObjectURL(S.pending.local); } catch (e) { /* ok */ } root.remove(); }

    renderHead(); syncTime();
    load().then(function () { schedule(); if (visible()) { toBottom(); } }).catch(function (e) { unavailable(e); });
    return { destroy: destroy, refresh: function () { clearTimeout(S.timer); poll(); }, markRead: function () { if (visible()) { S.first = false; markRead(); toBottom(); } }, toBottom: toBottom };
  };

  /* ───── instruction videos: only after a click, only embedded through youtube-nocookie in a dialog ───── */
  function playVideo(v) {
    var yt = /^[A-Za-z0-9_-]{6,20}$/.test(String(v.youtube_id || "")) ? v.youtube_id : "";
    var q = "?rel=0" + (v.start_s ? "&start=" + (parseInt(v.start_s, 10) || 0) : "") + (v.eind_s ? "&end=" + (parseInt(v.eind_s, 10) || 0) : "");
    var d = CV.dialog({ eyebrow: v.kanaal || "", title: v.titel || t("Instructievideo"), wide: true, buttons: [h("button", { type: "button", class: "btn primary", onclick: function () { d.close(); } }, t("Sluiten"))],
      tabs: [{ key: "v", label: t("Video"), render: function (body) {
        function embed() {
          CV.clear(body); if (!yt) { body.appendChild(h("p", { class: "alert" }, t("Deze video kan niet worden getoond."))); return; }
          body.appendChild(h("div", { class: "cv-s-embed" }, h("iframe", { src: "https://www.youtube-nocookie.com/embed/" + yt + q, title: v.titel || "YouTube", allow: "fullscreen; picture-in-picture; encrypted-media", allowfullscreen: true, referrerpolicy: "strict-origin-when-cross-origin", sandbox: "allow-scripts allow-same-origin allow-presentation allow-popups" })));
        }
        var asked = false;
        function ask() { asked = true; CV.clear(body); body.appendChild(h("div", { class: "cv-s-consent" }, h("p", {}, t("Door te kijken laad je een video van YouTube.")), h("button", { type: "button", class: "btn primary", onclick: embed }, CV.icon("play", 15), " " + t("Video laden")))); }
        var c = null; try { c = system.consent ? system.consent() : null; } catch (e) { c = null; }
        Promise.resolve(c).then(function (r) { if (r && r.choices) embed(); else ask(); }).catch(function () { if (!asked) ask(); });
      } }] });
  }

  /* ───── the detail of one analysis (the athlete, and the coach in "Bekijk als sporter") ───── */
  function detail(host, data, o) {
    o = o || {}; var rol = (data.me && data.me.rol) || "sporter", chat = null, players = null, items = {};
    var wrap = h("div", { class: "cv-s-detail" + (data.chat_aan ? " has-chat" : ""), "data-pane": "info" });
    var who = data.coach && data.coach.name ? data.coach.name : "";
    var chip = h("span", { class: "e2e-chip cv-s-chip" }, CV.icon("user", 14), " " + (rol === "coach" ? t("Gedeeld door jou") : t("Van je coach")) + (who && rol !== "coach" ? " · " + who : ""));
    var head = h("div", { class: "cv-s-head" }, chip, h("h1", {}, data.titel || t("Analyse")));
    var stageHost = h("div", { class: "cv-s-stage" });
    if (!(data.media || []).length) stageHost.appendChild(h("p", { class: "empty card" }, t("Er is nog geen beeld bij deze analyse.")));
    var videos = data.instructievideos || [];
    function highlight(r) { Object.keys(items).forEach(function (k) { items[k].classList.toggle("is-active", !!r && k === r.id); }); }
    if ((data.media || []).length) players = CV.player(stageHost, data.media, data.tekeningen, data.opmerkingen, { onRemark: highlight });

    /* remarks */
    var rems = (data.opmerkingen || []).slice().sort(function (a, b) { return (a.nummer || 0) - (b.nummer || 0); });
    var remList = h("ol", { class: "cv-s-rems" });
    rems.forEach(function (r) {
      var linked = videos.filter(function (v) { return v.opmerking_id && v.opmerking_id === r.id; });
      var li = h("li", { class: "cv-s-rem", "data-id": r.id },
        h("button", { type: "button", class: "cv-s-num", "aria-label": t("Opmerking") + " " + (r.nummer || ""), onclick: function () { if (players && r.tijd_ms != null) players.seekRemark(r); } }, String(r.nummer || "")),
        h("div", { class: "grow" }, r.tijd_ms != null ? h("button", { type: "button", class: "e2e-chip cv-s-time", title: t("Ga naar dit moment in de video"), onclick: function () { if (players) players.seekRemark(r); } }, CV.icon("clock", 13), " " + CV.ms(r.tijd_ms)) : null, CV.rich(r.tekst),
          linked.map(function (v) { return h("button", { type: "button", class: "btn ghost cv-s-link", onclick: function () { playVideo(v); } }, CV.icon("youtube", 15), " " + (v.titel || t("Instructievideo"))); })));
      items[r.id] = li; remList.appendChild(li);
    });
    var remCard = h("section", { class: "card cv-s-card" }, h("h3", {}, t("Opmerkingen van je coach")), rems.length ? remList : h("p", { class: "muted" }, t("Geen opmerkingen.")));

    /* instruction + videos */
    var hasText = CV.plain(data.instructie || "") !== "";
    var insCard = h("section", { class: "card cv-s-card" }, h("h3", {}, t("Instructie")), hasText ? CV.rich(data.instructie) : (videos.length ? null : h("p", { class: "muted" }, t("Geen instructie."))),
      videos.length ? h("div", { class: "cv-s-vids" }, videos.map(function (v) {
        return h("button", { type: "button", class: "cv-vid", onclick: function () { playVideo(v); } }, h("span", { class: "cv-vid__tile", "aria-hidden": "true" }, CV.icon("play", 22)),
          h("span", { class: "cv-vid__txt" }, h("strong", {}, v.titel || t("Instructievideo")), h("small", { class: "muted" }, v.start_s ? t("Bekijk vanaf") + " " + CV.sec(v.start_s) : t("Bekijk de video"))));
      })) : null);
    var info = h("div", { class: "cv-s-info" }, h("div", { class: "cv-s-cards" }, remCard, insCard));

    wrap.appendChild(head); wrap.appendChild(stageHost);
    if (data.chat_aan) {
      var badge = h("span", { class: "cv-s-dot", hidden: true }), tabInfo, tabChat;
      var setPane = function (p) { wrap.setAttribute("data-pane", p); tabInfo.classList.toggle("on", p === "info"); tabChat.classList.toggle("on", p === "chat"); tabInfo.setAttribute("aria-selected", p === "info"); tabChat.setAttribute("aria-selected", p === "chat"); if (p === "chat" && chat) { chat.markRead(); badge.hidden = true; } };
      tabInfo = h("button", { type: "button", role: "tab", class: "on", "aria-selected": "true", onclick: function () { setPane("info"); } }, t("Opmerkingen en instructie"));
      tabChat = h("button", { type: "button", role: "tab", "aria-selected": "false", onclick: function () { setPane("chat"); } }, CV.icon("message", 15), " " + t("Chat"), badge);
      wrap.appendChild(h("div", { class: "tabs cv-s-tabs", role: "tablist" }, tabInfo, tabChat));
      wrap.appendChild(info);
      var chatHost = h("aside", { class: "cv-s-chat", "aria-label": t("Chat") }); wrap.appendChild(chatHost);
      host.appendChild(wrap);
      chat = CV.chat(chatHost, data.id, { rol: rol, onSeek: function (ms) { if (players) players.seek(ms); }, getSnapshot: players ? function () { return players.snapshot(); } : null, getTime: players ? function () { return players.time(); } : null, getMediaId: players ? function () { return players.mediaId(); } : null,
        onUnread: function (n) { badge.hidden = !(n > 0) || wrap.getAttribute("data-pane") === "chat"; badge.textContent = n > 0 ? String(n) : ""; if (o.onUnread) o.onUnread(n); } });
    } else { wrap.appendChild(info); host.appendChild(wrap); }
    return { destroy: function () { if (chat) chat.destroy(); if (players) players.destroy(); wrap.remove(); } };
  }

  function notFound(host, onBack) {
    CV.clear(host); host.appendChild(h("div", { class: "card empty cv-s-gone" }, CV.icon("lock", 22), h("p", {}, t("Deze analyse bestaat niet of is niet (meer) voor jou beschikbaar.")), onBack ? h("button", { type: "button", class: "btn", onclick: onBack }, t("Terug")) : null));
  }

  /* ───── view: the athlete (list + detail) ───── */
  function analysesTab(root, params, ctx) {
    params = params || {}; var st = { rows: [], sel: null, cur: null, seq: 0 }, wide = function () { return window.matchMedia && window.matchMedia("(min-width: 860px)").matches; };
    var listEl = h("div", { class: "cv-s-list", role: "list" }), pane = h("div", { class: "cv-s-pane", "aria-live": "polite" });
    var wrap = h("div", { class: "cv-s-mine", "data-page": "list" }, h("aside", { class: "cv-s-side" }, h("div", { class: "cv-eyebrow" }, t("Mijn analyses")), listEl), pane);
    root.appendChild(wrap);
    function sub(r) {
      var bits = [r.gedeeld_op ? CV.when(r.gedeeld_op) : ""], n = r.nieuwe_berichten || 0;
      bits.push(n > 0 ? n + " " + (n === 1 ? t("nieuw bericht") : t("nieuwe berichten")) : r.status === "afgerond" ? t("afgerond") : r.soort === "afbeelding" ? t("foto") : t("video"));
      return bits.filter(Boolean).join(" · ");
    }
    function renderList() {
      CV.clear(listEl);
      if (!st.rows.length) { listEl.appendChild(h("p", { class: "empty" }, t("Je coach heeft nog niets met je gedeeld."))); return; }
      st.rows.forEach(function (r) {
        var cls = "cv-s-row" + (r.id === st.sel ? " is-sel" : "") + (r.gezien === false ? " is-new" : "");
        listEl.appendChild(h("button", { type: "button", role: "listitem", class: cls, "aria-current": r.id === st.sel ? "true" : "false", onclick: function () { select(r.id); } },
          h("span", { class: "cv-s-thumb" }, r.poster ? h("img", { src: r.poster, alt: "", loading: "lazy" }) : CV.icon(r.soort === "afbeelding" ? "image" : "video", 20)),
          h("span", { class: "cv-s-rowtxt" }, h("strong", {}, r.titel), h("small", { class: "muted" }, sub(r)), r.coach && r.coach.name ? h("small", { class: "muted" }, r.coach.name) : null),
          r.gezien === false ? h("span", { class: "cv-s-dot", role: "img", "aria-label": t("Nieuw") }, "") : null));
      });
    }
    function toList() { st.seq++; st.sel = null; if (st.cur) { st.cur.destroy(); st.cur = null; } CV.clear(pane); wrap.setAttribute("data-page", "list"); renderList(); }
    function select(id) {
      var seq = ++st.seq; st.sel = id; if (st.cur) { st.cur.destroy(); st.cur = null; } CV.clear(pane); wrap.setAttribute("data-page", "detail");
      var back = h("button", { type: "button", class: "btn ghost cv-s-back", onclick: toList }, CV.icon("back", 16), " " + t("Mijn analyses")); pane.appendChild(back);
      var body = h("div", { class: "cv-s-body" }, h("p", { class: "muted" }, t("Laden…"))); pane.appendChild(body); renderList();
      CV.call("mijn/" + id).then(function (d) {
        if (seq !== st.seq) return; CV.clear(body); st.cur = detail(body, d, {});
        st.rows.forEach(function (r) { if (r.id === id) { r.gezien = true; r.nieuwe_berichten = d.nieuwe_berichten || 0; } }); renderList(); try { window.scrollTo(0, 0); } catch (e) { /* frame */ }
      }).catch(function (e) { if (seq !== st.seq) return; if (isStatus(e, 404)) notFound(body, toList); else { CV.clear(body); body.appendChild(h("div", { class: "alert" }, (e && e.message) || String(e))); } });
    }
    CV.call("mijn").then(function (res) {
      st.rows = res.analyses || [];
      if (!st.rows.length && ctx && ctx.noCoach) {
        CV.clear(root); root.appendChild(CV.ui.empty("users", t("Je hebt nog geen coach"), t("Een coach deelt analyses van je video's en foto's met je. Voeg je coach toe met zijn of haar e-mailadres; de coach moet dat eerst accepteren."),
          h("button", { type: "button", class: "btn primary", onclick: ctx.toCoaches }, CV.icon("plus", 16), t("Coach toevoegen")))); return;
      }
      renderList();
      if (params.id) select(params.id); else if (st.rows.length && wide()) select(st.rows[0].id);
    }).catch(function (e) { CV.clear(listEl); listEl.appendChild(h("div", { class: "alert" }, (e && e.message) || String(e))); });
    return { destroy: function () { st.seq++; if (st.cur) { st.cur.destroy(); st.cur = null; } } };
  }

  /* ───── the coaches of a member (athlete view tab and the third tab of a coach): CV.coachesPanel(container, {data, onData(koppelingen)}) ───── */
  CV.coachesPanel = function (container, opts) {
    opts = opts || {}; var data = opts.data || null, note = "", mail = h("input", { type: "email", maxlength: 254, autocomplete: "off", placeholder: "coach@voorbeeld.nl" }), box = h("div", { class: "stack cv-coaches" }), busy = false;
    container.appendChild(box);
    function got(k, msg) { data = k; if (msg !== undefined) note = msg; if (opts.onData) opts.onData(k); CV.refreshHome().then(function () { if (CV.refreshNav) CV.refreshNav(); }).catch(function () {}); render(); }
    function load() { CV.clear(box); box.appendChild(CV.ui.loading()); CV.call("koppelingen").then(function (k) { data = k; if (opts.onData) opts.onData(k); render(); }).catch(function (e) { CV.clear(box); box.appendChild(CV.ui.errorBox(e, load)); }); }
    function ask() {
      if (busy) return; var v = mail.value.trim(); if (!v) { mail.focus(); CV.toast(t("Vul het e-mailadres van je coach in."), false); return; }
      busy = true;
      CV.call("coaches/vragen", "POST", { email: v }).then(function (k) { busy = false; mail.value = ""; got(k, k.boodschap || ""); }).catch(function (e) { busy = false; CV.fail(e); });
    }
    function render() {
      CV.clear(box); if (!data) return;
      var inc = (data.verzoeken_in || []).filter(function (r) { return r.richting === "uitnodiging"; }), out = (data.verzoeken_uit || []).filter(function (r) { return r.richting === "aanvraag"; }), coaches = data.coaches || [];
      if (inc.length) box.appendChild(h("section", { class: "stack" }, h("h2", { class: "cv-sec" }, t("Verzoeken voor jou")),
        h("div", { class: "cv-rows", role: "list" }, inc.map(function (r) { return CV.requestRow(r, { done: function (k) { got(k, ""); }, inText: function (x) { return t("{0} wil je als sporter toevoegen. Daarmee kan die coach jouw analyses maken en met je chatten.", x.naam); } }); }))));
      box.appendChild(h("section", { class: "stack" }, h("h2", { class: "cv-sec" }, t("Mijn coaches")),
        coaches.length ? h("div", { class: "cv-rows", role: "list" }, coaches.map(function (c) {
          return h("div", { class: "cv-rowcard", role: "listitem" }, CV.avatar(c, "e2e-avatar--lg"), h("div", { class: "grow cv-rowcard__text" }, h("strong", {}, c.name), h("small", { class: "muted" }, t("Coach"))),
            h("span", { class: "badge" }, c.analyses === 1 ? t("1 analyse") : t("{0} analyses", c.analyses || 0)),
            h("button", { type: "button", class: "btn danger", "aria-label": t("Koppeling beëindigen") + ": " + c.name, onclick: function () {
              CV.confirmBox(t("De koppeling met {0} beëindigen? Je verlaat daarmee ook de analyses van deze coach en kunt ze niet meer zien.", c.name), { danger: true, confirm: t("Koppeling beëindigen") }).then(function (ok) {
                if (ok) CV.call("koppelingen/" + c.sporter_id, "DELETE").then(function (k) { CV.toast(t("Koppeling beëindigd.")); got(k, ""); }).catch(CV.fail);
              });
            } }, t("Koppeling beëindigen")));
        })) : h("p", { class: "muted" }, t("Je hebt nog geen coach gekoppeld."))));
      var noteEl = h("div", { class: "cv-notice", role: "status", hidden: !note }, CV.icon("check", 16), h("span", { class: "grow" }, note));
      box.appendChild(h("section", { class: "card stack" }, h("h2", { class: "cv-sec" }, t("Coach toevoegen")),
        h("p", { class: "muted" }, t("Typ het e-mailadres van je coach. De coach moet het verzoek eerst accepteren; pas daarna kan de coach analyses met je delen.")),
        h("div", { class: "row nowrap cv-addcoach" }, h("div", { class: "grow" }, CV.ui.field(t("E-mailadres van je coach"), mail)), h("button", { type: "button", class: "btn primary", onclick: ask }, CV.icon("send", 14), t("Verzoek sturen"))), noteEl));
      mail.onkeydown = function (e) { if (e.key === "Enter") { e.preventDefault(); ask(); } };
      if (out.length) box.appendChild(h("section", { class: "stack" }, h("h2", { class: "cv-sec" }, t("Verstuurde verzoeken")),
        h("div", { class: "cv-rows", role: "list" }, out.map(function (r) { return CV.requestRow(r, { done: function (k) { got(k, ""); }, outText: t("Wacht op akkoord van de coach") }); }))));
      CV.ui.resize();
    }
    if (data) render(); else load();
  };

  /* ───── view: the athlete (tabs Analyses and Coaches) ───── */
  CV.views.mijn = function (root, params) {
    params = params || {}; var tab = params.tab === "coaches" ? "coaches" : "analyses", host = h("div", { class: "cv-mine-host" }), cur = null, k = null, btns = {}, first = true;
    function openOpen(n) { var b = btns.coaches; if (!b) return; var o = b.querySelector(".badge"); if (o) o.remove(); if (n > 0) b.appendChild(h("span", { class: "badge info", "aria-label": t("{0} open", n) }, String(n))); }
    function open(key) {
      tab = key; var fp = first; first = false; if (cur) { cur.destroy(); cur = null; } CV.clear(host);
      Object.keys(btns).forEach(function (x) { btns[x].classList.toggle("on", x === key); btns[x].setAttribute("aria-selected", x === key ? "true" : "false"); });
      if (key === "coaches") CV.coachesPanel(host, { data: k, onData: function (d) { k = d; openOpen((d.verzoeken_in || []).length); } });
      else cur = analysesTab(host, fp ? params : {}, { noCoach: !!k && !(k.coaches || []).length && !(k.verzoeken_in || []).length && !(k.verzoeken_uit || []).length, toCoaches: function () { open("coaches"); } });
    }
    var tabsEl = h("div", { class: "tabs cv-tabs", role: "tablist" }, [["analyses", t("Analyses")], ["coaches", t("Coaches")]].map(function (x) {
      return (btns[x[0]] = h("button", { type: "button", role: "tab", "data-key": x[0], "aria-selected": "false", onclick: function () { open(x[0]); } }, x[1]));
    }));
    if (CV.noticeBar) CV.noticeBar(root);
    root.appendChild(tabsEl); root.appendChild(host);
    CV.call("koppelingen").then(function (d) { k = d; }, function () { k = null; }).then(function () { openOpen(k ? (k.verzoeken_in || []).length : 0); open(tab); });
  };

  /* ───── view: the coach looks as the athlete ───── */
  CV.views.bekijk = function (root, params) {
    var host = h("div", { class: "cv-s-body" }, h("p", { class: "muted" }, t("Laden…"))), cur = null;
    root.appendChild(h("div", { class: "cv-s-view" },
      h("div", { class: "row cv-s-bar" }, h("button", { type: "button", class: "btn", onclick: function () { if (cur) cur.destroy(); CV.back("editor"); } }, CV.icon("back", 16), " " + t("Terug")),
        h("div", { class: "cv-s-banner grow", role: "note" }, CV.icon("eye", 16), h("span", {}, t("Zo ziet je sporter deze analyse")))), host));
    CV.call("mijn/" + (params && params.id)).then(function (d) { CV.clear(host); cur = detail(host, d, {}); })
      .catch(function (e) { if (isStatus(e, 404)) notFound(host, function () { CV.back("editor"); }); else { CV.clear(host); host.appendChild(h("div", { class: "alert" }, (e && e.message) || String(e))); } });
  };
})();
