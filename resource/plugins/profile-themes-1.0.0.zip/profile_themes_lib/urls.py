from django.urls import path

from . import views as v

urlpatterns = [
    path("profile-themes/", v.themes_list),
    path("profile-themes/new/", v.theme_create),
    path("profile-themes/ai/", v.theme_ai),
    path("profile-themes/library/", v.library),
    path("profile-themes/<slug:key>/", v.theme_detail),
    path("profile-themes/<slug:key>/install/", v.theme_install),
]
