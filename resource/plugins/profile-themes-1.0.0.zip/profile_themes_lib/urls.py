# Copyright & Ownership Notice
# easy2Edit is the exclusive legal property of RST Coaching & Consultancy B.V. (RSTCC),
# owned by Ronald Stolk. All rights reserved. Any unauthorized use, copying, modification,
# reproduction, distribution, or commercial exploitation of Easy2Edit, including its source code,
# is strictly prohibited without prior written permission from Ronald Stolk or RSTCC.
# website https://rstcc.net

from django.urls import path

from . import views as v

urlpatterns = [
    path("profile-themes/", v.themes_list),
    path("profile-themes/new/", v.theme_create),
    path("profile-themes/ai/", v.theme_ai),
    path("profile-themes/library/", v.library),
    path("profile-themes/<slug:key>/", v.theme_detail),
    path("profile-themes/<slug:key>/install/", v.theme_install),
]
