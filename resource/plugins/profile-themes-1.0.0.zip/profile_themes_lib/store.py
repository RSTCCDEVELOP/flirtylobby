# Copyright & Ownership Notice
# easy2Edit is the exclusive legal property of RST Coaching & Consultancy B.V. (RSTCC),
# owned by Ronald Stolk. All rights reserved. Any unauthorized use, copying, modification,
# reproduction, distribution, or commercial exploitation of Easy2Edit, including its source code,
# is strictly prohibited without prior written permission from Ronald Stolk or RSTCC.
# website https://rstcc.net

"""The theme packages: the ones that come with the plugin (packs/*.json), the installed ones and the ones made here.

A package: {key, label, desc, version, builtin: {headline: bool ...}, fields: [field ...], search: {title, filters, swipe}}.
Installed packages live in SystemSettings.data["profile_themes"] = {"installed": {key: package}}; the first time the four bundled themes are installed (as before the plugin existed)."""
import json
import re
from pathlib import Path

PACKS = Path(__file__).parent / "packs"
KEY_RE = re.compile(r"^[a-z0-9][a-z0-9-]{1,29}$")
FIELD_RE = re.compile(r"^[a-z][a-z0-9_]{1,29}$")
TYPES = ["text", "textarea", "number", "select", "multiselect", "checkbox", "date", "url"]
VISIBILITY = ["public", "members", "friends", "hidden"]
BUILTIN_KEYS = ["headline", "bio", "gender", "birth_date", "city", "interests", "aim"]
FILTERS = ["q", "gender", "age", "city", "country", "interest", "distance", "aim", "sort", "online", "photo"]
LAYOUTS = ["default", "cover", "tiles", "single", "split"]  # how a profile page looks: default = the own design of the theme
BASIC = "normal"


class Invalid(Exception):
    pass


def bundled():
    out = {}
    for p in sorted(PACKS.glob("*.json")):
        try:
            d = json.loads(p.read_text(encoding="utf-8"))
            out[d["key"]] = d
        except (ValueError, KeyError, OSError):
            continue
    return out


def _settings():
    from apps.core.models import SystemSettings

    row, _ = SystemSettings.objects.get_or_create(pk=1)
    return row


def _state():
    row = _settings()
    data = row.data or {}
    st = data.get("profile_themes")
    if not isinstance(st, dict) or not isinstance(st.get("installed"), dict):
        st = {"installed": {k: dict(v) for k, v in bundled().items()}}
        row.data = {**data, "profile_themes": st}
        row.save()
    elif BASIC not in st["installed"] and BASIC in bundled():  # (the basic theme can be edited too: from now on it is kept here as well)
        st["installed"][BASIC] = dict(bundled()[BASIC])
        row.data = {**data, "profile_themes": st}
        row.save()
    return st


def _save(st):
    row = _settings()
    row.data = {**(row.data or {}), "profile_themes": st}
    row.save()


def installed():
    return _state()["installed"]


def layout(key):
    return (installed().get(key) or {}).get("layout") or "default"


def search(key):
    s = (installed().get(key) or {}).get("search")
    return s if isinstance(s, dict) and s.get("filters") else None


def clean(pkg):
    """Check a package (from the editor or an import) and give the normalised one."""
    if not isinstance(pkg, dict):
        raise Invalid("Ongeldig themapakket.")
    key = str(pkg.get("key") or "").strip().lower()
    if not KEY_RE.match(key):
        raise Invalid("De sleutel van een thema bestaat uit 2-30 kleine letters, cijfers of streepjes.")
    label = str(pkg.get("label") or "").strip()[:60]
    if not label:
        raise Invalid("Geef het thema een naam.")
    seen, fields = set(), []
    for x in (pkg.get("fields") or [])[:60]:
        if not isinstance(x, dict):
            continue
        fk = str(x.get("key") or "").strip().lower()
        if not FIELD_RE.match(fk) or fk in BUILTIN_KEYS or fk in seen:
            raise Invalid(f"Veld '{fk}': de sleutel is ongeldig of komt dubbel voor.")
        seen.add(fk)
        typ = x.get("type") if x.get("type") in TYPES else "text"
        opts = [str(o).strip()[:60] for o in (x.get("options") or []) if str(o).strip()][:40] if typ in ("select", "multiselect") else []
        if typ in ("select", "multiselect") and not opts:
            raise Invalid(f"Veld '{fk}': geef minstens één keuze.")
        fields.append({"key": fk, "label": str(x.get("label") or fk).strip()[:80], "type": typ, "options": opts, "unit": str(x.get("unit") or "")[:12] if typ == "number" else "",
                       "required": bool(x.get("required")), "visibility": x.get("visibility") if x.get("visibility") in VISIBILITY else "members",
                       "card": bool(x.get("card")), "filter": bool(x.get("filter")), "group": str(x.get("group") or "")[:40]})
    b = pkg.get("builtin") if isinstance(pkg.get("builtin"), dict) else {}
    s = pkg.get("search") if isinstance(pkg.get("search"), dict) else {}
    flt = [f for f in (s.get("filters") or []) if f in FILTERS] or ["q", "gender", "age", "city", "country", "interest", "distance", "sort", "online", "photo"]
    return {"key": key, "label": label, "desc": str(pkg.get("desc") or "")[:300], "version": str(pkg.get("version") or "1.0.0")[:20],
            "builtin": {k: bool(b.get(k, k not in ("aim",))) for k in BUILTIN_KEYS}, "fields": fields,
            "search": {"title": str(s.get("title") or label)[:80], "filters": flt, "swipe": bool(s.get("swipe"))},
            "layout": pkg.get("layout") if pkg.get("layout") in LAYOUTS else "default"}


def install(key):
    pack = bundled().get(key)
    if not pack:
        raise Invalid("Dit thema zit niet in de plugin.")
    st = _state()
    st["installed"][key] = clean(pack)
    _save(st)


def save(pkg, old_key=None):
    """Make or change a theme here (an installed one); a changed key renames it."""
    p = clean(pkg)
    st = _state()
    if old_key and old_key != p["key"]:
        if old_key in st["installed"] and not pkg.get("rename_ok", True):
            raise Invalid("De sleutel kan niet worden gewijzigd.")
        st["installed"].pop(old_key, None)
    elif not old_key and p["key"] in st["installed"]:
        raise Invalid("Er is al een thema met deze sleutel.")
    st["installed"][p["key"]] = p
    _save(st)
    return p


def remove(key, in_use):
    if key == BASIC:
        raise Invalid("Het basisthema kan niet worden verwijderd.")
    st = _state()
    if key not in st["installed"]:
        raise Invalid("Dit thema is niet geïnstalleerd.")
    if key in in_use:
        raise Invalid("Dit thema is in gebruik en kan niet worden verwijderd.")
    del st["installed"][key]
    _save(st)
    row = _settings()  # also not allowed any more
    data = dict(row.data or {})
    data["community_themes"] = [k for k in (data.get("community_themes") or []) if k != key]
    row.data = data
    row.save()


def library_dir():
    """resource/profielthemas: the themes that can be installed from the library (one JSON file per theme)."""
    from apps.core import resources

    d = resources.root() / "profielthemas"
    d.mkdir(exist_ok=True)
    return d


def export_all():
    """Write every installed theme to the library (resource/profielthemas/<key>.json). Returns the keys."""
    d, done = library_dir(), []
    for k, p in installed().items():
        (d / f"{k}.json").write_text(json.dumps(p, ensure_ascii=False, indent=1) + "\n", encoding="utf-8")
        done.append(k)
    return done


def library():
    """The themes in the library: [{key, label, desc, fields, installed, newer}]."""
    inst, out = installed(), []
    for f in sorted(library_dir().glob("*.json")):
        try:
            p = clean(json.loads(f.read_text(encoding="utf-8")))
        except (ValueError, OSError, Invalid):
            continue
        out.append({"key": p["key"], "label": p["label"], "desc": p["desc"], "fields": len(p["fields"]), "installed": p["key"] in inst, "changed": p["key"] in inst and inst[p["key"]] != p})
    return out


def install_from_library(key):
    f = library_dir() / f"{key}.json"
    if not f.is_file():
        raise Invalid("Dit thema staat niet in de bibliotheek.")
    try:
        p = clean(json.loads(f.read_text(encoding="utf-8")))
    except ValueError:
        raise Invalid("Het themabestand in de bibliotheek is ongeldig.")
    st = _state()
    st["installed"][p["key"]] = p
    _save(st)
    return p


def listing():
    """All themes this plugin knows: the installed ones and the bundled ones that are not installed (yet)."""
    inst, pack = installed(), bundled()
    out = []
    for k, p in inst.items():
        out.append({"key": k, "label": p["label"], "desc": p.get("desc", ""), "fields": len(p.get("fields") or []), "installed": True, "bundled": k in pack, "version": p.get("version", "")})
    for k, p in pack.items():
        if k not in inst:
            out.append({"key": k, "label": p["label"], "desc": p.get("desc", ""), "fields": len(p.get("fields") or []), "installed": False, "bundled": True, "version": p.get("version", "")})
    return out
