# Copyright & Ownership Notice
# easy2Edit is the exclusive legal property of RST Coaching & Consultancy B.V. (RSTCC),
# owned by Ronald Stolk. All rights reserved. Any unauthorized use, copying, modification,
# reproduction, distribution, or commercial exploitation of Easy2Edit, including its source code,
# is strictly prohibited without prior written permission from Ronald Stolk or RSTCC.
# website https://rstcc.net

import logging

from rest_framework import status
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response

from apps.plugins import facade

from . import store

logger = logging.getLogger(__name__)
AUTH = [IsAuthenticated]


def bad(msg, code=status.HTTP_400_BAD_REQUEST):
    return Response({"detail": msg}, status=code)


def _guard(request):
    return None if request.user.is_staff else bad("Alleen een superadmin mag dit.", status.HTTP_403_FORBIDDEN)


def _themes():
    return facade.mod("community", "themes")


def _in_use():
    svc = facade.mod("community", "service")
    try:
        return {svc.get()["profiles"]["theme"]} if svc else set()
    except Exception:  # noqa: BLE001
        return set()


def _overview():
    th = _themes()
    on = th.enabled() if th else set()
    use = _in_use()
    rows = []
    for r in sorted(store.listing(), key=lambda x: x["key"] != store.BASIC):  # (the basic theme first)
        rows.append({**r, "basic": r["key"] == store.BASIC})
    return [{**r, "enabled": r["key"] in on and r["installed"], "active": r["key"] in use, "locked": r["basic"] or r["key"] in use} for r in rows]


@api_view(["GET", "PUT"])
@permission_classes(AUTH)
def themes_list(request):
    """Superadmin: the themes (installed or in the plugin) and which ones may be used."""
    if (g := _guard(request)):
        return g
    th = _themes()
    if request.method == "PUT":
        keys = request.data.get("enabled")
        if not isinstance(keys, list) or not th:
            return bad("Ongeldige keuze.")
        th.set_enabled([k for k in keys if k in th.THEMES])
    return Response({"themes": _overview(), "ai": _ai_on()})


def _ai_on():
    try:
        from apps.integrations import ai

        return bool(ai.available())
    except Exception:  # noqa: BLE001
        return False


AI_SYSTEM = ("You design a profile theme for a community website (member profiles). Answer with ONE JSON object only, no text around it, in the language of the request: "
             '{"key": "slug-with-dashes", "label": "Name", "desc": "one sentence", "builtin": {"headline": bool, "bio": bool, "gender": bool, "birth_date": bool, "city": bool, "interests": bool, "aim": bool}, '
             '"fields": [{"key": "snake_case", "label": "...", "type": "text|textarea|number|select|multiselect|checkbox|date|url", "options": ["..."], "unit": "", "required": false, '
             '"visibility": "public|members|friends|hidden", "card": false, "filter": false, "group": "..."}], '
             '"search": {"title": "...", "filters": ["q","gender","age","city","country","interest","distance","aim","sort","online","photo"], "swipe": false}, '
             '"layout": "default|cover|tiles|single|split"}. Use 8 to 20 useful fields grouped in 3 to 5 groups; select and multiselect need options; put the 2-4 most important fields on the card (card: true) '
             "and the ones worth searching on as filters (filter: true). Choose the layout that fits: cover (banner and avatar, business), tiles (key facts as tiles), single (one column), split (photo beside the content).")


@api_view(["POST"])
@permission_classes(AUTH)
def theme_ai(request):
    """Superadmin, when Claude is linked: describe the theme; the AI makes the package (not saved: it opens in the editor)."""
    if (g := _guard(request)):
        return g
    text = str(request.data.get("prompt") or "").strip()[:2000]
    if len(text) < 8:
        return bad("Beschrijf het thema wat uitgebreider.")
    try:
        import json

        from apps.integrations import ai

        raw = ai.claude(AI_SYSTEM, text, 4000, 120)
        start, end = raw.find("{"), raw.rfind("}")
        pkg = json.loads(raw[start:end + 1])
        if pkg.get("key") in store.installed() or pkg.get("key") in (None, "", store.BASIC):
            pkg["key"] = (str(pkg.get("label") or "thema").lower().replace(" ", "-") + "-ai")[:29]
        return Response({"theme": store.clean(pkg)})
    except store.Invalid as e:
        return bad(f"De AI maakte geen geldig thema: {e}")
    except ValueError as e:
        return bad(str(e))
    except Exception as e:  # noqa: BLE001
        logger.warning("Profile theme AI failed: %s", e)
        return bad("De AI gaf geen bruikbaar antwoord. Probeer het opnieuw of beschrijf het anders.")


@api_view(["POST", "DELETE"])
@permission_classes(AUTH)
def theme_install(request, key):
    if (g := _guard(request)):
        return g
    try:
        if request.method == "POST":
            store.install(key)
        else:
            store.remove(key, _in_use())
    except store.Invalid as e:
        return bad(str(e))
    return Response({"themes": _overview()})


@api_view(["GET", "PUT"])
@permission_classes(AUTH)
def theme_detail(request, key):
    """One installed theme: read it for the editor, or save it."""
    if (g := _guard(request)):
        return g
    if request.method == "GET":
        p = store.installed().get(key)
        return Response({"theme": p}) if p else bad("Onbekend thema.", status.HTTP_404_NOT_FOUND)
    try:
        p = store.save(request.data, old_key=key)
    except store.Invalid as e:
        return bad(str(e))
    return Response({"theme": p, "themes": _overview()})


@api_view(["POST"])
@permission_classes(AUTH)
def theme_create(request):
    """A new theme (from the editor or an imported package)."""
    if (g := _guard(request)):
        return g
    try:
        p = store.save(request.data)
    except store.Invalid as e:
        return bad(str(e))
    logger.info("Profile theme %s made by %s", p["key"], request.user.email)
    return Response({"theme": p, "themes": _overview()}, status=status.HTTP_201_CREATED)


@api_view(["GET", "POST"])
@permission_classes(AUTH)
def library(request):
    """The library (resource/profielthemas): GET = what is in it; POST {export: true} = write all installed themes to it; POST {install: key} = install one from it."""
    if (g := _guard(request)):
        return g
    try:
        if request.method == "POST":
            if request.data.get("export"):
                store.export_all()
            elif request.data.get("install"):
                store.install_from_library(str(request.data["install"]))
    except store.Invalid as e:
        return bad(str(e))
    return Response({"library": store.library(), "themes": _overview()})
