"""Profielthema's (plugin). Thema's voor de profielen van de Community als pakketten.

Het thema "Normaal" blijft in de Community zelf (dat is het basisthema en staat altijd aan). De andere thema's (Sporters, Dating, Business, Webshop) komen
als pakket mee in packs/*.json en staan na de eerste keer geïnstalleerd; je kunt ze verwijderen, opnieuw installeren, aanpassen en er eigen bij maken.
Welke geïnstalleerde thema's de gebruikers mogen kiezen bepaalt de superadmin (dezelfde lijst als altijd: SystemSettings.data["community_themes"]).
De Community vraagt de thema's hier op via `system.provide("profilethemes", ...)`; staat deze plugin uit, dan heeft de Community alleen het basisthema."""
import importlib
import sys

PKG = "profile_themes_lib"


def register(system):
    for k in [k for k in sys.modules if k == PKG or k.startswith(PKG + ".")]:
        del sys.modules[k]
    store = importlib.import_module(f"{PKG}.store")
    urls = importlib.import_module(f"{PKG}.urls")
    system.mount(urls.urlpatterns)

    class ProfileThemes:
        packages = staticmethod(store.installed)  # {key: package} of the installed themes
        search = staticmethod(store.search)
        layout = staticmethod(store.layout)
        listing = staticmethod(store.listing)

    system.provide("profilethemes", ProfileThemes)
