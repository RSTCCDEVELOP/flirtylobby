# Copyright & Ownership Notice
# easy2Edit is the exclusive legal property of RST Coaching & Consultancy B.V. (RSTCC),
# owned by Ronald Stolk. All rights reserved. Any unauthorized use, copying, modification,
# reproduction, distribution, or commercial exploitation of Easy2Edit, including its source code,
# is strictly prohibited without prior written permission from Ronald Stolk or RSTCC.
# website https://rstcc.net


"""Site importeren (plugin). Een andere website (adres, map of ZIP) inlezen: thema, pagina's, startpagina, iconen en plaatjes. Te verwijderen met alles wat erbij hoort.

Dit was een vast onderdeel van het systeem (apps/siteimport); nu een plugin. De code staat in siteimport_lib/, de routes zijn nog steeds /api/siteimport/... (System.mount) en de tabel van
het systeem uit de tijd dat dit nog het systeem was (siteimport_siteimport) wordt bij het starten hernoemd naar plg_siteimport_siteimport; er gaat geen gegeven verloren.
Wat een import maakte (pagina's, mediabibliotheek, thema) blijft gewone inhoud van de website, ook als de plugin uit gaat. De hulp om een website uit te lezen die ook
"Thema uit een webadres" gebruikt, staat in het systeem (apps/core/webtoolkit.py)."""
import importlib
import inspect
import sys

PKG = "siteimport_lib"


def register(system):
    from django.contrib.auth import get_user_model
    from django.db import connection, models
    from django.db.models.signals import pre_delete

    for k in [k for k in sys.modules if k == PKG or k.startswith(PKG + ".")]:  # what an earlier load left behind (the models are made again)
        del sys.modules[k]

    models_mod = importlib.import_module(f"{PKG}.models")
    classes = [c for _n, c in inspect.getmembers(models_mod, inspect.isclass) if issubclass(c, models.Model) and c.__module__ == models_mod.__name__]

    # the table of the system from before (siteimport_siteimport) is renamed once: the data goes with it
    existing = set(connection.introspection.table_names())
    with connection.cursor() as cur:
        for m in classes:
            old, new = "siteimport_" + m.__name__.lower(), m._meta.db_table
            if old in existing and new not in existing:
                cur.execute(f'ALTER TABLE "{old}" RENAME TO "{new}"')
                existing.discard(old)
                existing.add(new)
    system.sync_models(*classes)

    importer_mod = importlib.import_module(f"{PKG}.importer")
    importlib.import_module(f"{PKG}.views")
    urls = importlib.import_module(f"{PKG}.urls")
    system.mount(urls.urlpatterns)

    User = get_user_model()

    def forget_user(sender, instance, **kwargs):  # (the database does not do SET_NULL for the tables of a plugin)
        models_mod.SiteImport.objects.filter(created_by_id=instance.pk).update(created_by=None)

    pre_delete.connect(forget_user, sender=User, dispatch_uid="siteimport_forget_user", weak=False)

    class SiteImport:
        models = models_mod
        importer = importer_mod

    system.provide("siteimport", SiteImport)
