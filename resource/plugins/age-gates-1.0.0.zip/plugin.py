# Copyright & Ownership Notice
# easy2Edit is the exclusive legal property of RST Coaching & Consultancy B.V. (RSTCC),
# owned by Ronald Stolk. All rights reserved. Any unauthorized use, copying, modification,
# reproduction, distribution, or commercial exploitation of Easy2Edit, including its source code,
# is strictly prohibited without prior written permission from Ronald Stolk or RSTCC.
# website https://rstcc.net

"""Leeftijd, land & gokken (plugin). De leeftijdscontrole (18+), de landcontrole en de gokken-popup.

Dit was een vast onderdeel van het systeem (apps/security: geo.py en de leeftijdscontrole in service.py); nu een plugin. De instellingen blijven bij Beveiliging staan (SecuritySettings,
de secties geo, age en gambling): er verhuist geen gegeven. Het systeem vraagt om hulp via `system.provide("age-gates", ...)`; staat de plugin uit, dan wordt niemand geblokkeerd of
naar zijn leeftijd gevraagd (zie apps/plugins/facade.py: `gates`)."""
import importlib
import sys

PKG = "age_gates_lib"


def register(system):
    for k in [k for k in sys.modules if k == PKG or k.startswith(PKG + ".")]:  # what an earlier load left behind
        del sys.modules[k]
    geo = importlib.import_module(f"{PKG}.geo")
    logic = importlib.import_module(f"{PKG}.logic")

    class Gates:
        check_visitor = staticmethod(geo.check)
        underage_message = staticmethod(logic.underage_message)
        min_age = staticmethod(logic.min_age)

    system.provide("age-gates", Gates)
