# Copyright & Ownership Notice
# easy2Edit is the exclusive legal property of RST Coaching & Consultancy B.V. (RSTCC),
# owned by Ronald Stolk. All rights reserved. Any unauthorized use, copying, modification,
# reproduction, distribution, or commercial exploitation of Easy2Edit, including its source code,
# is strictly prohibited without prior written permission from Ronald Stolk or RSTCC.
# website https://rstcc.net

"""The decision about the age of a visitor or member (the settings are those of Beveiliging)."""
from datetime import date


def _cfg():
    from apps.security import service

    return service.get()["age"]


def underage_message(birth_date):
    """Text when the birth date is below the site's age limit (18+ gate), else None."""
    cfg = _cfg()
    if not birth_date or not cfg.get("enabled"):
        return None
    t = date.today()
    age = t.year - birth_date.year - ((t.month, t.day) < (birth_date.month, birth_date.day))
    if age < cfg["min_age"]:
        return f"Deze website is alleen voor bezoekers van {cfg['min_age']} jaar en ouder. Met deze geboortedatum kun je geen gegevens opslaan."
    return None


def min_age():
    """The age limit of the site while the gate is on, else None."""
    cfg = _cfg()
    return cfg["min_age"] if cfg.get("enabled") else None
