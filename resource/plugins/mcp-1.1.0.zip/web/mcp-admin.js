// Copyright & Ownership Notice
// easy2Edit is the exclusive legal property of RST Coaching & Consultancy B.V. (RSTCC),
// owned by Ronald Stolk. All rights reserved. Any unauthorized use, copying, modification,
// reproduction, distribution, or commercial exploitation of Easy2Edit, including its source code,
// is strictly prohibited without prior written permission from Ronald Stolk or RSTCC.
// website https://rstcc.net

/* MCP-koppeling: beheerscherm (draait in het dashboard zelf, niet in een frame). */
(function () {
  var t = function () { return system.t.apply(system, arguments); };
  var S = { top: "clients", data: { clients: [], scopes: {}, endpoint: "", token_endpoint: "" }, shown: null, verify: null, msg: null };
  var ICON = { plus: '<path d="M12 5v14M5 12h14"/>', key: '<circle cx="8" cy="15" r="4"/><path d="M11 12l9-9M17 6l3 3M14 9l2 2"/>', trash: '<path d="M4 7h16M10 11v6M14 11v6M6 7l1 12h10l1-12M9 7V4h6v3"/>', refresh: '<path d="M20 11a8 8 0 0 0-14-4L4 9M4 4v5h5M4 13a8 8 0 0 0 14 4l2-2M20 20v-5h-5"/>', ban: '<circle cx="12" cy="12" r="9"/><path d="M5.600 5.600l12.800 12.800"/>', x: '<path d="M6 6l12 12M18 6L6 18"/>', check: '<path d="M5 12l5 5 9-10"/>', copy: '<rect x="9" y="9" width="11" height="11" rx="2"/><path d="M5 15V6a2 2 0 0 1 2-2h9"/>', download: '<path d="M12 4v11M7 11l5 5 5-5M5 20h14"/>', upload: '<path d="M12 16V5M7 9l5-5 5 5M5 20h14"/>', shield: '<path d="M12 3l8 3v6c0 5-3.500 8-8 9-4.500-1-8-4-8-9V6z"/><path d="M9 12l2 2 4-4"/>', edit: '<path d="M4 20h4L19 9l-4-4L4 16v4zM13 7l4 4"/>', globe: '<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a14 14 0 0 1 0 18M12 3a14 14 0 0 0 0 18"/>' };

  /* the texts of Item help (the "?" at the top right): an element with hk: "<key>" tells what it does */
  var HM = null;
  function HELP(k) {
    if (!HM) HM = {
      tab_clients: t("De koppelingen met MCP-servers en AI-assistenten: maak ze, stel hun rechten in, trek ze in of verwijder ze."),
      tab_verify: t("Controleer of een geheime sleutel geldig is, zonder hem te gebruiken."),
      tab_connect: t("Het adres en de gegevens die je in je MCP-client invult om te verbinden."),
      tab_general: t("De naam en de vervaldatum van de koppeling."),
      tab_access: t("Vanaf welke IP-adressen de koppeling mag verbinden."),
      tab_website: t("Rechten op de websitegegevens, de pagina's en de mediabibliotheek."),
      tab_people: t("Rechten op de gebruikers, het bedrijf en de tags."),
      tab_system: t("Rechten om modules en plugins te bekijken en aan of uit te zetten."),
      tab_plugins: t("Per actieve plugin bepalen of deze koppeling hem mag opvragen."),
      tab_sum: t("Wat deze koppeling nu mag, met alle gereedschappen op een rij."),
      name: t("De naam waaronder je deze koppeling herkent."),
      expires: t("Vanaf deze dag werkt de sleutel niet meer. Leeg = nooit."),
      ips: t("Alleen deze IP-adressen mogen verbinden. Leeg = vanaf elk adres."),
      ip_get: t("Zet een hostnaam om in IP-adressen. Laat je het veld leeg, dan wordt je eigen IP-adres ingevuld."),
      copy: t("Kopieert dit naar het klembord."),
      new_conn: t("Maakt een nieuwe koppeling met een eigen client-id en geheime sleutel. De sleutel zie je één keer."),
      open_file: t("Leest een eerder opgeslagen koppelingsbestand en toont het adres, het client-id en de sleutel. Er wordt niets opgeslagen in easy2edit."),
      rights: t("Bepaal per onderdeel van de website wat deze koppeling mag lezen en schrijven."),
      edit: t("Wijzig de naam, de vervaldatum en de toegestane IP-adressen van deze koppeling."),
      revoke: t("Trekt de koppeling in: de sleutel werkt dan niet meer, tot je hem weer aanzet."),
      unrevoke: t("Zet de ingetrokken koppeling weer aan."),
      renew: t("Maakt een nieuwe geheime sleutel. De oude sleutel en zijn toegangstokens werken dan niet meer."),
      delete: t("Verwijdert de koppeling voorgoed. Je krijgt eerst een bevestigingsvraag."),
      verify_input: t("Plak hier de geheime sleutel (die begint met mcp_)."),
      verify_go: t("Controleert of de sleutel bestaat, niet is ingetrokken of verlopen, en wat hij mag."),
      f_endpoint: t("Het adres waarmee je MCP-client verbindt."),
      f_client: t("De openbare naam van deze koppeling. Dit is niet geheim."),
      f_secret: t("De sleutel waarmee de client zich bekendmaakt. Hij is maar één keer te zien: bewaar hem veilig."),
      import_conn: t("Maakt van dit bestand een koppeling op deze website, met hetzelfde client-id en dezelfde sleutel. Alleen de hash van de sleutel wordt opgeslagen."),
      save_file: t("Bewaart het adres, het client-id en de geheime sleutel als bestand op je computer. Bewaar het veilig."),
      copy_config: t("Kopieert een kant-en-klare configuratie om in je MCP-client te plakken."),
      close_new: t("Sluit dit blok. De geheime sleutel is daarna niet meer te zien."),
      close_file: t("Sluit dit blok. Er is niets opgeslagen."),
      preset_none: t("Zet alle rechten uit."),
      preset_read: t("Zet alle leesrechten en de toegang tot alle actieve plugins aan, zonder schrijfrechten."),
      preset_all: t("Zet alle lees- en schrijfrechten aan. Let op: de koppeling kan dan gegevens van de website wijzigen."),
      all_on: t("Geeft deze koppeling toegang tot alle actieve plugins."),
      all_off: t("Haalt de toegang tot alle plugins weg."),
      res_row: t("Een onderdeel van de website. De groene schakelaar geeft leesrecht, de rode schrijfrecht."),
      sw_read: t("Laat deze koppeling dit onderdeel lezen."),
      sw_write: t("Laat deze koppeling dit onderdeel wijzigen. Lezen gaat dan ook aan."),
      plugin_row: t("Laat deze koppeling informatie over deze plugin opvragen (get_plugin)."),
    };
    return HM[k] || "";
  }
  function h(tag, attrs) {
    var el = document.createElement(tag), kids = Array.prototype.slice.call(arguments, 2);
    Object.keys(attrs || {}).forEach(function (k) { if (k === "tag") el.setAttribute("data-easy2edit-tag", attrs[k]); else if (k === "hk") { var ht = HELP(attrs[k]); if (ht) el.setAttribute("data-help", ht); } else if (k.slice(0, 2) === "on") el.addEventListener(k.slice(2), attrs[k]); else if (attrs[k] !== false && attrs[k] != null) el.setAttribute(k, attrs[k] === true ? "" : attrs[k]); });
    kids.forEach(function add(k) { if (k == null || k === false) return; if (Array.isArray(k)) k.forEach(add); else el.appendChild(typeof k === "object" ? k : document.createTextNode(k)); });
    return el;
  }
  function icon(n) { var s = document.createElementNS("http://www.w3.org/2000/svg", "svg"); s.setAttribute("class", "ic"); s.setAttribute("width", "16"); s.setAttribute("height", "16"); s.setAttribute("viewBox", "0 0 24 24"); s.setAttribute("fill", "none"); s.setAttribute("stroke", "currentColor"); s.setAttribute("stroke-width", "2"); s.setAttribute("stroke-linecap", "round"); s.setAttribute("stroke-linejoin", "round"); s.setAttribute("aria-hidden", "true"); s.innerHTML = ICON[n]; return s; }
  /* copy to the clipboard: the button shows a tick for a moment */
  function copy(text, label) {
    var b = h("button", { type: "button", hk: "copy", class: "btn icon", title: label || t("Kopiëren"), "aria-label": label || t("Kopiëren"), onclick: function () {
      var done = function () { b.replaceChildren(icon("check")); setTimeout(function () { b.replaceChildren(icon("copy")); }, 1500); };
      var legacy = function () { var a = h("textarea", { style: "position:fixed;opacity:0" }); a.value = text; document.body.appendChild(a); a.select(); try { document.execCommand("copy"); done(); } catch (e) { say(t("Kopiëren is niet gelukt.")); draw(); } a.remove(); };
      if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(text).then(done, legacy); else legacy();
    } }, icon("copy"));
    return b;
  }
  /* the connection as a file on the computer (name, address, client id and secret) and back: reading a file only shows it, nothing is stored in easy2edit */
  function connInfo(x) { return { scopes: Array.isArray(x.scopes) ? x.scopes : undefined, name: x.name || "", endpoint: x.endpoint || S.data.endpoint, token_endpoint: x.token_endpoint || S.data.token_endpoint, client_id: x.client_id, secret: x.secret }; }
  function mcpConfig(x) { var o = { mcpServers: {} }; o.mcpServers[(x.name || "easy2edit").toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "") || "easy2edit"] = { type: "http", url: x.endpoint, headers: { Authorization: "Bearer " + x.secret } }; return JSON.stringify(o, null, 2); }
  function saveFile(x) {
    var c = connInfo(x), data = { easy2edit_mcp: 1, name: c.name, scopes: c.scopes, endpoint: c.endpoint, token_endpoint: c.token_endpoint, client_id: c.client_id, secret: c.secret, mcp_config: JSON.parse(mcpConfig(c)) };
    var a = h("a", { href: URL.createObjectURL(new Blob([JSON.stringify(data, null, 2)], { type: "application/json" })), download: "mcp-" + (c.name.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "") || c.client_id) + ".json" });
    document.body.appendChild(a); a.click(); setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 500);
  }
  function openFile() {
    var f = h("input", { type: "file", accept: ".json,application/json", style: "display:none", onchange: function () {
      var file = f.files && f.files[0]; f.remove(); if (!file) return;
      var r = new FileReader();
      r.onload = function () {
        var d; try { d = JSON.parse(String(r.result)); } catch (e) { d = null; }
        if (!d || d.easy2edit_mcp !== 1 || !d.client_id || !d.secret) { say(t("Dit is geen bestand van een MCP-koppeling.")); draw(); return; }
        S.shown = Object.assign(connInfo(d), { fromFile: true, check: null }); say(""); S.top = "clients"; draw();
        api("admin/verify", { method: "POST", body: { secret: d.secret } }).then(function (v) { if (S.shown && S.shown.fromFile) { S.shown.check = v; draw(); } }).catch(function () {});
      };
      r.readAsText(file);
    } });
    document.body.appendChild(f); f.click();
  }
  function urlRow() { return h("div", { class: "row urlrow muted", hk: "f_endpoint" }, h("span", {}, t("MCP-adres") + ":"), h("code", { class: "grow" }, S.data.endpoint), copy(S.data.endpoint, t("MCP-adres kopiëren"))); }
  function codeRow(text) { return h("div", { class: "row" }, h("code", { class: "grow" }, text), copy(text)); }
  function layer() { return (window.system && system.portal) ? system.portal() : document.body; }
  function say(text, ok) { S.msg = text ? { text: text, ok: !!ok } : null; }
  function fail(e) { say(e && e.message || String(e)); draw(); }
  function api(path, opts) { return system.api("/plugins/run/mcp/" + path, opts); }
  function load() { return api("admin/clients").then(function (d) { S.data = d; }); }
  function fdate(v) { return v ? new Date(v).toLocaleString(document.documentElement.lang || "nl") : "—"; }
  function stateText(s) { return { ok: t("Actief"), revoked: t("Ingetrokken"), expired: t("Verlopen") }[s] || s; }

  function dialog(title, content, onOk, okLabel, size) {
    var ov = h("div", { class: "overlay", onclick: function (e) { if (e.target === ov) close(); } }), prev = document.activeElement;
    function close() { ov.remove(); if (prev && prev.focus) prev.focus(); }
    ov.appendChild(h("div", { tag: "ui-overlays", class: "modal" + (size ? " " + size : ""), role: "dialog", "aria-modal": "true", "aria-label": title }, h("div", { class: "row between" }, h("h2", {}, title), h("button", { type: "button", class: "btn ghost icon", "aria-label": t("Sluiten"), onclick: close }, icon("x"))), content,
      h("div", { class: "row end" }, h("button", { type: "button", class: "btn", onclick: close }, t("Annuleren")), h("button", { type: "button", class: "btn primary", onclick: function () { onOk(close); } }, okLabel))));
    ov.addEventListener("keydown", function (e) { if (e.key === "Escape") close(); });
    layer().appendChild(ov); var f = ov.querySelector("input[type=text]"); if (f) f.focus();
  }

  /* the dialog to make or change a connection: tabs General and Access (the rights have their own dialog) */
  function editDialog(c) {  // c = null: a new connection; else the connection that is changed
    var m = c ? { tab: "general", name: c.name, expires: c.expires ? String(c.expires).slice(0, 10) : "", ips: (c.allowed_ips || []).join(", ") } : { tab: "general", name: "", expires: "", ips: "" }, body = h("div", { class: "stack" }), err = h("div");
    function keep() {
      var n = body.querySelector("[data-f=name]"), e = body.querySelector("[data-f=expires]"), i = body.querySelector("[data-f=ips]");
      if (n) m.name = n.value; if (e) m.expires = e.value; if (i) m.ips = i.value;
    }
    function tabs() { return h("div", { class: "tabs", role: "tablist", tag: "ui-tabs" }, [["general", t("Algemeen")], ["access", t("Toegang")]].map(function (x) { return h("button", { type: "button", role: "tab", hk: "tab_" + x[0], class: m.tab === x[0] ? "on" : "", onclick: function () { keep(); m.tab = x[0]; fill(); } }, x[1]); })); }
    function fill() {
      body.innerHTML = ""; body.appendChild(tabs());
      if (m.tab === "general") {
        body.appendChild(h("label", { tag: "ui-form-fields", class: "fld", hk: "name" }, h("span", {}, t("Naam") + " *"), h("input", { type: "text", "data-f": "name", maxlength: "80", value: m.name })));
        body.appendChild(h("label", { tag: "ui-form-fields", class: "fld", hk: "expires" }, h("span", {}, t("Vervalt op (leeg = nooit)")), h("input", { type: "date", "data-f": "expires", value: m.expires })));
        if (!c) body.appendChild(h("small", { class: "muted" }, t("Een nieuwe koppeling mag alleen de websitegegevens en pagina's lezen. Wat hij verder mag, stel je daarna in met de knop Rechten.")));
      } else {
        var ipf = h("input", { type: "text", "data-f": "ips", value: m.ips, placeholder: t("bijvoorbeeld 203.0.113.5 of mcp.voorbeeld.nl") }), note = h("small", { class: "muted" }, t("Een hostnaam of leeg veld wordt met de knop omgezet naar IP-adressen. Leeg laten = overal toegestaan."));
        var get = h("button", { type: "button", hk: "ip_get", class: "btn", onclick: function () {
          var hosts = ipf.value.split(",").map(function (x) { return x.trim(); }).filter(Boolean);
          get.disabled = true;
          api("admin/resolve", { method: "POST", body: { hosts: hosts } }).then(function (r) {
            if (r.ips.length) { ipf.value = r.ips.join(", "); m.ips = ipf.value; }
            note.textContent = r.failed.length ? t("Niet gevonden: {0}", r.failed.join(", ")) : hosts.length ? t("De IP-adressen zijn ingevuld.") : t("Je eigen IP-adres is ingevuld.");
          }).catch(function (e) { note.textContent = e && e.message || String(e); }).then(function () { get.disabled = false; });
        } }, icon("globe"), " " + t("IP-adres ophalen"));
        body.appendChild(h("div", { tag: "ui-form-fields", class: "fld", hk: "ips" }, h("span", {}, t("Toegestane IP-adressen (komma-gescheiden, leeg = overal)")), h("div", { class: "row" }, h("span", { class: "grow" }, ipf), get), note));
      }
    }
    fill();
    dialog(c ? t("Koppeling bewerken") : t("Nieuwe koppeling"), h("div", {}, err, body), function (close) {
      keep();
      if (!m.name.trim()) { m.tab = "general"; fill(); err.innerHTML = ""; err.appendChild(h("div", { tag: "ui-alerts", class: "alert" }, t("Geef de koppeling een naam."))); return; }
      api(c ? "admin/clients/" + c.id : "admin/clients", { method: c ? "PATCH" : "POST", body: { name: m.name, expires: m.expires, allowed_ips: m.ips.split(",").map(function (x) { return x.trim(); }).filter(Boolean) } }).then(function (r) { if (!c) S.shown = r; else say(t("Opgeslagen."), true); close(); return load(); }).then(draw).catch(function (e) { err.innerHTML = ""; err.appendChild(h("div", { tag: "ui-alerts", class: "alert" }, e && e.message || String(e))); });
    }, c ? t("Opslaan") : t("Maken"));
  }

  /* the texts of the parts of the website that a connection can get rights on (the tools behind them come from the server) */
  function resText(k) {
    return { site: [t("Websitegegevens"), t("De naam van de website en welke modules aan staan.")],
      pages: [t("Pagina's"), t("De pagina's van de website lezen; schrijven = titel, aan/uit en menu wijzigen.")],
      media: [t("Mediabibliotheek"), t("De lijst met bestanden van de site (naam, soort, grootte). Geen privébestanden van leden.")],
      users: [t("Gebruikers"), t("De accounts (naam en of ze actief zijn), zonder e-mailadressen.")],
      entity: [t("Bedrijf"), t("Het bedrijf of de organisatie achter de website: naam, adres, contact en registratie.")],
      tags: [t("Tags"), t("De tags met een kleur lezen; schrijven = nieuwe tags maken.")],
      modules: [t("Modules"), t("Zien welke modules er zijn en of ze aan staan; schrijven = een module aan of uit zetten (niet de basismodules).")],
      plugins: [t("Plugins"), t("Zien welke plugins er zijn en of ze aan staan; schrijven = een plugin aan of uit zetten (niet deze plugin zelf).")] }[k] || [k, ""];
  }
  function sectionText(k) { return { website: t("Website"), people: t("Mensen en bedrijf"), system: t("Systeem") }[k] || k; }
  function summary(sel) {
    var r = S.data.resources, rd = 0, wr = 0;
    Object.keys(r).forEach(function (k) { if (sel.indexOf(k + ":read") >= 0) rd++; if (sel.indexOf(k + ":write") >= 0) wr++; });
    return { read: rd, write: wr };
  }

  /* the dialog with the rights of one connection: what may be read and what may be written, in tabs per section, with a summary */
  function rightsDialog(c) {
    var R = S.data.resources, sel = (c.scopes || []).slice(), tab = (S.data.sections || [])[0] || "website", body = h("div", { class: "stack" });
    function has(x) { return sel.indexOf(x) >= 0; }
    function set(x, on) { var i = sel.indexOf(x); if (on && i < 0) sel.push(x); if (!on && i >= 0) sel.splice(i, 1); }
    function all(kind) { return Object.keys(R).filter(function (k) { return R[k][kind].length; }).map(function (k) { return k + ":" + kind; }); }
    function allPlugins() { return (S.data.plugins || []).map(function (p) { return "plugin:" + p.name; }); }
    function preset(list) { sel = list.slice(); fill(); }
    function pluginRow(p) {
      var x = "plugin:" + p.name;
      return h("label", { class: "setrow", hk: "plugin_row" }, h("div", { class: "grow" }, h("span", { class: "setlbl" }, p.title), h("small", { class: "muted" }, p.description || p.name)), h("input", { type: "checkbox", class: "sw-read", checked: has(x), onchange: function (e) { set(x, e.target.checked); fill(); } }));
    }
    function row(k) {  // one part of the website: name and text on the left, a green switch for reading and a red one for writing in two equal columns
      var r = R[k], tx = resText(k);
      var cell = function (kind) {
        var x = k + ":" + kind;
        return h("div", { class: "rcell" }, r[kind].length ? h("input", { type: "checkbox", class: kind === "write" ? "sw-write" : "sw-read", hk: kind === "write" ? "sw_write" : "sw_read", checked: has(x), "aria-label": (kind === "write" ? t("Schrijven") : t("Lezen")) + ": " + tx[0], onchange: function (e) { set(x, e.target.checked); if (kind === "write" && e.target.checked) set(k + ":read", true); if (kind === "read" && !e.target.checked) set(k + ":write", false); fill(); } }) : h("span", { class: "muted", title: t("Nog niet beschikbaar") }, "—"));
      };
      var toolLine = [r.read.length ? t("Lezen") + ": " + r.read.join(", ") : "", r.write.length ? t("Schrijven") + ": " + r.write.join(", ") : ""].filter(Boolean).join(" · ");
      return h("div", { class: "setrow res", hk: "res_row" }, h("div", { class: "grow" }, h("span", { class: "setlbl" }, tx[0]), h("small", { class: "muted" }, tx[1]), h("small", { class: "muted tools" }, toolLine)), cell("read"), cell("write"));
    }
    function head() { return h("div", { class: "rhead" }, h("span", {}), h("span", { class: "rh read" }, t("Lezen")), h("span", { class: "rh write" }, t("Schrijven"))); }
    function fill() {
      body.innerHTML = "";
      var tabs = (S.data.sections || []).map(function (k) { return [k, sectionText(k)]; }).concat([["plugins", t("Plugins")], ["sum", t("Samenvatting")]]);
      body.appendChild(h("div", { class: "tabs", role: "tablist", tag: "ui-tabs" }, tabs.map(function (x) { return h("button", { type: "button", role: "tab", hk: "tab_" + x[0], class: tab === x[0] ? "on" : "", onclick: function () { tab = x[0]; fill(); } }, x[1]); })));
      if (tab === "plugins") {
        var pl = S.data.plugins || [];
        body.appendChild(h("div", { class: "hint" }, t("Alleen plugins die aan staan. Een plugin die je hier toestaat, kan deze koppeling opvragen met het gereedschap get_plugin.")));
        if (!pl.length) body.appendChild(h("div", { class: "empty" }, t("Er staan geen andere plugins aan.")));
        else { body.appendChild(h("div", { class: "row" }, h("button", { type: "button", hk: "all_on", class: "btn", onclick: function () { allPlugins().forEach(function (x) { set(x, true); }); fill(); } }, t("Alles aan")), h("button", { type: "button", hk: "all_off", class: "btn", onclick: function () { allPlugins().forEach(function (x) { set(x, false); }); fill(); } }, t("Alles uit")))); pl.forEach(function (p) { body.appendChild(pluginRow(p)); }); }
        return;
      }
      if (tab !== "sum") { body.appendChild(head()); Object.keys(R).filter(function (k) { return R[k].section === tab; }).forEach(function (k) { body.appendChild(row(k)); }); return; }
      var sm = summary(sel);
      var pn = sel.filter(function (x) { return x.indexOf("plugin:") === 0; }).length;
      body.appendChild(h("div", { class: "hint" }, t("Lezen: {0} onderdelen · Schrijven: {1} onderdelen", String(sm.read), String(sm.write)) + (pn ? " · " + t("Plugins: {0}", String(pn)) : "")));
      if (sm.write) body.appendChild(h("div", { tag: "ui-alerts", class: "alert" }, t("Let op: met schrijfrechten kan deze koppeling gegevens van de website wijzigen.")));
      var tools = [];
      Object.keys(R).forEach(function (k) { ["read", "write"].forEach(function (a) { if (has(k + ":" + a)) R[k][a].forEach(function (n) { tools.push([n, a, resText(k)[0]]); }); }); });
      if (pn) tools.push(["get_plugin", "read", t("Plugins") + " (" + pn + ")"]);
      body.appendChild(tools.length ? h("div", { class: "tw", tag: "ui-data-table" }, h("table", { class: "slim" }, h("thead", {}, h("tr", {}, [t("Onderdeel"), t("Recht"), t("Gereedschap")].map(function (x) { return h("th", {}, x); }))), h("tbody", {}, tools.map(function (x) { return h("tr", {}, h("td", {}, x[2]), h("td", {}, x[1] === "write" ? t("Schrijven") : t("Lezen")), h("td", {}, h("code", {}, x[0]))); })))) : h("div", { class: "empty" }, t("Deze koppeling mag niets.")));
    }
    fill();
    var content = h("div", { class: "stack" }, urlRow(), h("div", { class: "row" }, h("small", { class: "muted" }, t("Snel instellen") + ":"),
      h("button", { type: "button", hk: "preset_none", class: "btn", onclick: function () { preset([]); } }, t("Niets")), h("button", { type: "button", hk: "preset_read", class: "btn", onclick: function () { preset(all("read").concat(allPlugins())); } }, t("Alleen lezen")), h("button", { type: "button", hk: "preset_all", class: "btn", onclick: function () { preset(all("read").concat(all("write"), allPlugins())); } }, t("Lezen en schrijven"))), body);
    dialog(t("Rechten") + ": " + c.name, content, function (close) {
      api("admin/clients/" + c.id, { method: "PATCH", body: { scopes: sel } }).then(function () { say(t("Opgeslagen."), true); close(); return load(); }).then(draw).catch(fail);
    }, t("Opslaan"), "wide");
  }

  function act(kind, c) {
    var p;
    if (kind === "revoke") p = api("admin/clients/" + c.id, { method: "PATCH", body: { revoked: c.state !== "revoked" } });
    else if (kind === "renew") p = system.confirm(t("Een nieuwe sleutel maken? De oude sleutel en zijn toegangstokens werken dan niet meer.")).then(function (y) { return y ? api("admin/clients/" + c.id + "/renew", { method: "POST" }).then(function (r) { S.shown = r; }) : null; });
    else p = system.confirm(t("Deze koppeling verwijderen?"), { danger: true }).then(function (y) { return y ? api("admin/clients/" + c.id, { method: "DELETE" }) : null; });
    p.then(load).then(draw).catch(fail);
  }

  function rightsText(c) {
    var sm = summary(c.scopes || []);
    var pn = (c.scopes || []).filter(function (x) { return x.indexOf("plugin:") === 0; }).length;
    return !sm.read && !sm.write && !pn ? "—" : t("{0} lezen", String(sm.read)) + (sm.write ? " · " + t("{0} schrijven", String(sm.write)) : "") + (pn ? " · " + t("{0} plugins", String(pn)) : "");
  }
  function vClients() {
    var out = [];
    if (S.shown) {
      var x = connInfo(S.shown), ck = S.shown.check, file = !!S.shown.fromFile;
      var field = function (label, value, copyLabel, cls) { return h("div", { class: "cfield" + (cls ? " " + cls : ""), hk: cls === "wide" ? "f_endpoint" : cls === "secret" ? "f_secret" : "f_client" }, h("span", { class: "clabel" }, label), h("div", { class: "cbox" }, h("code", { class: "cval" }, value), copy(value, copyLabel))); };
      out.push(h("div", { class: "conn" + (file ? " file" : "") },
        h("div", { class: "conn-head" }, h("span", { class: "conn-ico" }, icon("key")), h("div", { class: "grow" }, h("strong", {}, x.name || x.client_id), h("small", { class: "muted" }, file ? t("Uit bestand gelezen: alleen getoond, niet opgeslagen in easy2edit.") : t("Bewaar de geheime sleutel nu: hij wordt maar één keer getoond."))),
          h("span", { tag: "ui-badges", class: "badge" + (file && ck && !ck.valid ? " bad" : "") }, file ? (ck ? (ck.valid ? t("Geldig") : ck.state === "unknown" ? t("Onbekend") : stateText(ck.state)) : t("Bezig…")) : t("Nieuw"))),
        h("div", { class: "conn-grid" }, field(t("MCP-adres"), x.endpoint, t("MCP-adres kopiëren"), "wide"), field(t("Client-id"), x.client_id, t("Client-id kopiëren")), field(t("Geheime sleutel"), x.secret, t("Geheime sleutel kopiëren"), "secret")),
        h("div", { class: "conn-actions" },
          file && ck && ck.state === "unknown" ? h("button", { type: "button", hk: "import_conn", class: "btn primary", onclick: function () {
            api("admin/clients/import", { method: "POST", body: { client_id: x.client_id, secret: x.secret, name: x.name, scopes: x.scopes } }).then(function () { S.shown = null; say(t("De koppeling is opgeslagen."), true); return load(); }).then(draw).catch(fail);
          } }, icon("plus"), " " + t("Koppeling opslaan")) : null,
          h("button", { type: "button", hk: "save_file", class: "btn primary", onclick: function () { saveFile(x); } }, icon("download"), " " + t("Opslaan als bestand")),
          h("button", { type: "button", hk: "copy_config", class: "btn", onclick: function () { var b = this; var txt = mcpConfig(x); (navigator.clipboard ? navigator.clipboard.writeText(txt) : Promise.reject()).then(function () { b.textContent = t("Gekopieerd"); }, function () { say(t("Kopiëren is niet gelukt.")); draw(); }); } }, icon("copy"), " " + t("MCP-configuratie kopiëren")),
          h("span", { class: "grow" }),
          h("button", { type: "button", hk: file ? "close_file" : "close_new", class: "btn ghost", onclick: function () { S.shown = null; draw(); } }, file ? t("Sluiten") : t("Ik heb hem bewaard"))),
        h("small", { class: "muted conn-note" }, t("Het bestand bevat de geheime sleutel: bewaar het veilig en deel het niet."))));
    }
    out.push(h("div", { class: "hint row between" }, h("span", { class: "grow" }, t("Elke MCP-server of AI-assistent die met deze website verbindt, krijgt een eigen client-id en sleutel.")), h("div", { class: "row" }, h("button", { type: "button", hk: "open_file", class: "btn", onclick: openFile }, icon("upload"), " " + t("Bestand openen")), h("button", { type: "button", hk: "new_conn", class: "btn primary", onclick: function () { editDialog(null); } }, icon("plus"), " " + t("Nieuwe koppeling")))));
    out.push(urlRow());
    if (!S.data.clients.length) { out.push(h("div", { class: "empty" }, t("Nog geen koppelingen."))); return out; }
    out.push(h("div", { class: "clist", tag: "ui-record-list" }, S.data.clients.map(function (c) {
      var btn = function (key, title, ic, fn) { return h("button", { type: "button", hk: key, class: "btn icon", title: title, "aria-label": title, onclick: fn }, icon(ic)); };
      return h("div", { class: "crow" },
        h("div", { class: "cmain" },
          h("div", { class: "cname" }, h("strong", {}, c.name), h("span", { tag: "ui-badges", class: "badge" + (c.state === "ok" ? "" : " bad") }, stateText(c.state))),
          h("div", { class: "cid" }, h("code", {}, c.client_id), copy(c.client_id, t("Client-id kopiëren"))),
          h("small", { class: "muted cmeta" }, rightsText(c) + " · " + t("{0}×", String(c.uses)) + " · " + t("Laatst") + ": " + fdate(c.last_used) + (c.last_ip ? " (" + c.last_ip + ")" : ""))),
        h("div", { class: "cacts" },
          h("button", { type: "button", hk: "rights", class: "btn", onclick: function () { rightsDialog(c); } }, icon("shield"), " " + t("Rechten")),
          btn("edit", t("Bewerken"), "edit", function () { editDialog(c); }),
          btn(c.state === "revoked" ? "unrevoke" : "revoke", c.state === "revoked" ? t("Weer aanzetten") : t("Intrekken"), "ban", function () { act("revoke", c); }),
          btn("renew", t("Nieuwe sleutel"), "refresh", function () { act("renew", c); }),
          btn("delete", t("Verwijderen"), "trash", function () { act("del", c); })));
    })));
    return out;
  }
  function vVerify() {
    var inp = h("input", { type: "text", hk: "verify_input", autocomplete: "off", placeholder: "mcp_…", "aria-label": t("Geheime sleutel") }), r = S.verify;
    return [h("div", { class: "card stack" }, h("label", { class: "fld" }, h("span", {}, t("Plak een geheime sleutel om te controleren")), inp),
      h("div", {}, h("button", { type: "button", hk: "verify_go", class: "btn primary", onclick: function () { api("admin/verify", { method: "POST", body: { secret: inp.value } }).then(function (x) { S.verify = x; draw(); }).catch(fail); } }, icon("key"), " " + t("Verifiëren"))),
      r ? h("div", { tag: "ui-alerts", class: "alert" + (r.valid ? " ok" : "") }, r.valid ? [t("Geldig") + ": ", h("strong", {}, r.name), " (" + r.client_id + ") · " + t("Rechten") + ": " + (r.scopes || []).join(", ")] : (r.state === "unknown" ? t("Onbekende sleutel.") : t("Niet geldig") + ": " + stateText(r.state))) : null)];
  }
  function vConnect() {
    return [h("div", { class: "card stack" }, h("div", {}, h("h3", {}, t("MCP-adres")), codeRow(S.data.endpoint)),
      h("div", {}, h("h3", {}, t("Toegangstoken ophalen (optioneel)")), h("p", { class: "muted" }, t("Stuur je geheime sleutel naar dit adres en je krijgt een toegangstoken dat een uur geldt. Je kunt de sleutel ook direct gebruiken.")), codeRow("POST " + S.data.token_endpoint)),
      h("div", {}, h("h3", {}, t("Verbinden")), h("p", { class: "muted" }, t("Stel in je MCP-client dit adres in (Streamable HTTP) met de header")), codeRow("Authorization: Bearer <" + t("geheime sleutel of toegangstoken") + ">")))];
  }

  function draw() {
    var app = document.getElementById("app");
    app.innerHTML = "";
    app.appendChild(h("div", { class: "tabs", role: "tablist", tag: "ui-tabs" }, [["clients", t("Koppelingen")], ["verify", t("Verifiëren")], ["connect", t("Verbinden")]].map(function (x) { return h("button", { type: "button", role: "tab", hk: "tab_" + x[0], class: S.top === x[0] ? "on" : "", onclick: function () { S.top = x[0]; say(""); draw(); } }, x[1]); })));
    if (S.msg) app.appendChild(h("div", { tag: "ui-alerts", class: "alert" + (S.msg.ok ? " ok" : "") }, S.msg.text));
    (S.top === "clients" ? vClients() : S.top === "verify" ? vVerify() : vConnect()).forEach(function (n) { app.appendChild(n); });
    try { system.resize(Math.ceil(document.documentElement.scrollHeight)); } catch (e) { /* inline: nothing to resize */ }
  }

  system.ready.then(load).then(draw).catch(fail).then(function () { try { system.loaded(); } catch (e) { /* an older system */ } });
})();
