// Copyright & Ownership Notice
// easy2Edit is the exclusive legal property of RST Coaching & Consultancy B.V. (RSTCC),
// owned by Ronald Stolk. All rights reserved. Any unauthorized use, copying, modification,
// reproduction, distribution, or commercial exploitation of Easy2Edit, including its source code,
// is strictly prohibited without prior written permission from Ronald Stolk or RSTCC.
// website https://rstcc.net

/* Hulpfuncties voor de pagina's van de webshop (zonder framework). Gebruikt window.system uit het systeem. */
var t = function () { return system.t.apply(system, arguments); };
var $ = function (s, r) { return (r || document).querySelector(s); };
function esc(s) { return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); }
var RUN = "/plugins/run/webshop/";
var LANG = "";  /* de taal van de bezoeker: producten en groepen komen in die taal terug (als ze zijn vertaald) */
function api(path, opts) { return system.api(RUN + path + (LANG ? (path.indexOf("?") >= 0 ? "&" : "?") + "lang=" + encodeURIComponent(LANG) : ""), opts); }
function money(v) { try { return new Intl.NumberFormat(document.documentElement.lang || "nl", { style: "currency", currency: "EUR" }).format(Number(v)); } catch (e) { return "€ " + Number(v).toFixed(2); } }
var origin = "";
function img(u) { return !u ? "" : (/^https?:/.test(u) ? u : origin + u); }
function height() {  /* a popup lies over the page: the frame must be as high as the popup, else it is cut off */
  var o = document.querySelector(".overlay"), m = o && o.firstElementChild, want = m ? Math.ceil(m.getBoundingClientRect().bottom + 24) + "px" : "";
  if (document.body.style.minHeight !== want) document.body.style.minHeight = want;
  system.resize(Math.ceil(Math.max(document.documentElement.scrollHeight, document.body.scrollHeight)));
}
new MutationObserver(function () { height(); }).observe(document.documentElement, { childList: true, subtree: true, attributes: true });
window.addEventListener("load", height);
document.addEventListener("click", function (e) {  /* a link with data-go opens an address of the website */
  var a = e.target.closest && e.target.closest("[data-go]");
  if (a) { e.preventDefault(); system.go(a.getAttribute("data-go")); }
});
/* de winkelwagen: [{id, qty, v}] in de opslag van de plugin (v = de gekozen variant; de kop van de website telt mee) */
var cart = {
  get: function () { return system.store.get("cart").then(function (v) { return Array.isArray(v) ? v : []; }); },
  set: function (v) { return system.store.set("cart", v); },
  add: function (id, qty, variant) { return cart.get().then(function (c) { var i = c.find(function (x) { return x.id === id && (x.v || "") === (variant || ""); }); if (i) i.qty = Math.min(99, i.qty + qty); else c.push({ id: id, qty: qty, v: variant || "" }); return cart.set(c); }); },
  body: function (items) { return items.map(function (i) { return { product: i.id, quantity: i.qty, variant: i.v || "" }; }); }
};
function boot(fn) { system.ready.then(function (ctx) { origin = ctx.apiBase || ""; LANG = ctx.lang || ""; return fn(ctx); }).catch(function (e) { document.body.innerHTML = '<div class="alert">' + esc(e.message || e) + "</div>"; }); }
