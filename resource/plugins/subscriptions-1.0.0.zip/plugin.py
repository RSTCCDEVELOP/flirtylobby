"""Abonnementen (plugin). Abonnementen, donaties en de acties die bepalen wat gratis is en wat betaald.

Dit was een vast onderdeel van het systeem (apps/subscriptions); nu een plugin. De code staat in subscriptions_lib/ (models, service, views, urls, backup), de routes zijn nog steeds
/api/subscriptions/... en /api/donations/... (System.mount) en de tabellen van het systeem uit de tijd dat dit nog het systeem was (subscriptions_*) worden bij het starten hernoemd naar
plg_subscriptions_*; er gaat geen gegeven verloren. Het systeem en andere plugins vragen om hulp via `system.provide("subscriptions", ...)` (zie apps/plugins/facade.py: zonder deze plugin is niets
afgeschermd). Heeft de plugin Orders nodig (zie "requires" in plugin.json)."""
import importlib
import inspect
import logging
import sys

logger = logging.getLogger(__name__)
PKG = "subscriptions_lib"


def register(system):
    from django.contrib.auth import get_user_model
    from django.db import connection, models
    from django.db.models.signals import pre_delete

    for k in [k for k in sys.modules if k == PKG or k.startswith(PKG + ".")]:  # what an earlier load left behind (the models are made again)
        del sys.modules[k]

    models_mod = importlib.import_module(f"{PKG}.models")
    classes = [c for _n, c in inspect.getmembers(models_mod, inspect.isclass) if issubclass(c, models.Model) and c.__module__ == models_mod.__name__]

    existing = set(connection.introspection.table_names())
    with connection.cursor() as cur:
        for m in classes:
            old, new = "subscriptions_" + m.__name__.lower(), m._meta.db_table
            if old in existing and new not in existing:
                cur.execute(f'ALTER TABLE "{old}" RENAME TO "{new}"')
                existing.discard(old)
                existing.add(new)
    system.sync_models(*classes)

    service = importlib.import_module(f"{PKG}.service")
    views = importlib.import_module(f"{PKG}.views")
    importlib.import_module(f"{PKG}.backup")  # (the plans and actions go with the settings backup)
    urls = importlib.import_module(f"{PKG}.urls")
    system.mount(urls.urlpatterns)

    from apps.sandbox import service as sandbox  # a payment that is settled (also by the simulation) comes back here
    sandbox.HOOKS[:] = [h for h in sandbox.HOOKS if not str(getattr(h, "__module__", "")).startswith(PKG)]
    sandbox.HOOKS.append(service.on_payment)

    User = get_user_model()

    class Subscriptions:
        models = models_mod
        service_ = service

        @staticmethod
        def purge_user(user_id):
            """The subscriptions and gifts of this member go with the member (the database does not do that for the tables of a plugin); a donation stays, without the person."""
            M = models_mod
            M.DonorAction.objects.filter(user_id=user_id).delete()
            M.Subscription.objects.filter(user_id=user_id).delete()
            M.Donation.objects.filter(user_id=user_id).update(user=None)
            M.DonationCampaign.objects.filter(recipient_user_id=user_id).update(recipient_user=None)

        @staticmethod
        def renew():
            return service.process_due()

    Subscriptions.service = service
    Subscriptions.views = views

    def purge(sender, instance, **kwargs):
        Subscriptions.purge_user(instance.pk)

    pre_delete.connect(purge, sender=User, dispatch_uid="subscriptions_purge_user", weak=False)
    system.provide("subscriptions", Subscriptions)
