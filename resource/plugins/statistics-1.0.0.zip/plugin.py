# Copyright & Ownership Notice
# easy2Edit is the exclusive legal property of RST Coaching & Consultancy B.V. (RSTCC),
# owned by Ronald Stolk. All rights reserved. Any unauthorized use, copying, modification,
# reproduction, distribution, or commercial exploitation of Easy2Edit, including its source code,
# is strictly prohibited without prior written permission from Ronald Stolk or RSTCC.
# website https://rstcc.net

"""Statistieken (plugin). Grafieken en cijfers over de hele website: bezoekers, SEO, bots en AI-aanroepen, en per module en plugin een eigen tabblad.

Dit was een vast onderdeel van het systeem (apps/stats); nu een plugin. De code staat in statistics_lib/, de routes zijn nog steeds /api/stats/... (System.mount) en de tabellen van
het systeem uit de tijd dat dit nog het systeem was (stats_*) worden bij het starten hernoemd naar plg_statistics_*; er gaat geen gegeven verloren.
Het systeem en andere plugins schrijven hun cijfers via `facade.stats.record(...)` (en `system.stats.record(...)` in een plugin); staat deze plugin uit, dan wordt niets geteld."""
import importlib
import inspect
import sys

PKG = "statistics_lib"


def register(system):
    from django.db import connection, models

    for k in [k for k in sys.modules if k == PKG or k.startswith(PKG + ".")]:  # what an earlier load left behind (the models are made again)
        del sys.modules[k]

    models_mod = importlib.import_module(f"{PKG}.models")
    classes = [c for _n, c in inspect.getmembers(models_mod, inspect.isclass) if issubclass(c, models.Model) and c.__module__ == models_mod.__name__]

    # the tables of the system from before (stats_<model>) are renamed once: the data goes with them
    existing = set(connection.introspection.table_names())
    with connection.cursor() as cur:
        for m in classes:
            old, new = "stats_" + m.__name__.lower(), m._meta.db_table
            if old in existing and new not in existing:
                cur.execute(f'ALTER TABLE "{old}" RENAME TO "{new}"')
                existing.discard(old)
                existing.add(new)
    system.sync_models(*classes)

    service = importlib.import_module(f"{PKG}.service")
    urls = importlib.import_module(f"{PKG}.urls")
    importlib.import_module(f"{PKG}.collectors")
    system.mount(urls.urlpatterns)

    class Statistics:
        models = models_mod
        record, record_file, record_hit, record_bot = service.record, service.record_file, service.record_hit, service.record_bot

    system.provide("statistics", Statistics)
