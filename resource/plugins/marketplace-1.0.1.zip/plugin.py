# Copyright & Ownership Notice
# easy2Edit is the exclusive legal property of RST Coaching & Consultancy B.V. (RSTCC),
# owned by Ronald Stolk. All rights reserved. Any unauthorized use, copying, modification,
# reproduction, distribution, or commercial exploitation of Easy2Edit, including its source code,
# is strictly prohibited without prior written permission from Ronald Stolk or RSTCC.
# website https://rstcc.net

"""Marktplaats (plugin). Een eigen programma naast het systeem: de gegevens staan in de database van het systeem (tabellen plg_marketplace_*),
de afbeeldingen in de datamap van de plugin. Gebruikers en blokkades komen van het systeem. Teksten staan in T("…") zodat het systeem ze in alle talen kan leveren.

Routes: /api/plugins/run/marketplace/<pad>  (zie onderaan `register`); de pagina staat in web/index.html."""
import base64
import binascii
import io
import re
import uuid
from datetime import datetime
from decimal import Decimal, InvalidOperation

from django.db import models
from django.db.models import Count, Q, Sum
from django.http import FileResponse, HttpResponse
from django.utils import timezone
from rest_framework.response import Response

THEMES = ["classic", "fresh", "sunny", "party", "elegant", "playful", "dark"]
KINDS = ("product", "service", "other")


def register(system):
    from apps.plugins.facade import community as social  # (the plugin Community; without it: no profiles, nobody hidden)

    T = system.t
    bad = lambda msg, code=400: Response({"detail": msg}, status=code)  # noqa: E731
    img_dir = system.data_dir / "images"
    img_dir.mkdir(exist_ok=True)
    U, label = system.User, system.app_label

    class Meta:  # the tables of the plugin live in the system's own database
        app_label = label

    def table(name):
        return type("Meta", (), {"app_label": label, "db_table": system.db_prefix + name})

    class Listing(models.Model):
        owner = models.ForeignKey(U, on_delete=models.CASCADE, related_name="+")
        title = models.CharField(max_length=120)
        description = models.TextField(blank=True)
        kind = models.CharField(max_length=10, default="product")
        theme = models.CharField(max_length=12, default="classic")
        mode = models.CharField(max_length=8, default="sale")
        price = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)
        allow_bids = models.BooleanField(default=False)
        min_bid = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)
        booking_type = models.CharField(max_length=12, blank=True)
        starts_at = models.DateTimeField(null=True, blank=True)
        capacity = models.PositiveIntegerField(null=True, blank=True)
        auto_confirm = models.BooleanField(default=False)
        location = models.CharField(max_length=120, blank=True)
        status = models.CharField(max_length=8, default="active")
        winner = models.ForeignKey(U, null=True, blank=True, on_delete=models.SET_NULL, related_name="+")
        created_at = models.DateTimeField(auto_now_add=True)
        Meta = table("listing")

    class Image(models.Model):
        listing = models.ForeignKey(Listing, on_delete=models.CASCADE, related_name="images")
        file = models.CharField(max_length=60)
        ord = models.PositiveIntegerField(default=0)
        Meta = table("image")

    class Bid(models.Model):
        listing = models.ForeignKey(Listing, on_delete=models.CASCADE, related_name="bids")
        bidder = models.ForeignKey(U, on_delete=models.CASCADE, related_name="+")
        kind = models.CharField(max_length=4, default="bid")
        amount = models.DecimalField(max_digits=10, decimal_places=2)
        message = models.CharField(max_length=300, blank=True)
        status = models.CharField(max_length=10, default="open")
        created_at = models.DateTimeField(auto_now_add=True)
        Meta = table("bid")

    class Booking(models.Model):
        listing = models.ForeignKey(Listing, on_delete=models.CASCADE, related_name="bookings")
        user = models.ForeignKey(U, on_delete=models.CASCADE, related_name="+")
        persons = models.PositiveIntegerField(default=1)
        message = models.CharField(max_length=300, blank=True)
        status = models.CharField(max_length=10, default="pending")
        created_at = models.DateTimeField(auto_now_add=True)
        Meta = table("booking")

    system.sync_models(Listing, Image, Bid, Booking)

    cfg = system.config
    num = lambda k, d: max(1, int(cfg.get(k) or d))  # noqa: E731
    f2 = lambda v: float(v) if v is not None else None  # noqa: E731
    names = {}

    def name(uid):
        if uid not in names:
            u = U.objects.filter(pk=uid).first()
            names[uid] = social.display_name(u) if u else "?"
        return names[uid]

    def money(v, what):
        if v in (None, ""):
            return None
        try:
            d = Decimal(str(v).replace(",", ".")).quantize(Decimal("0.01"))
        except (InvalidOperation, ValueError):
            raise ValueError(T("{0}: ongeldig bedrag.", what))
        if d < 0 or d > 99999999:
            raise ValueError(T("{0}: ongeldig bedrag.", what))
        return d

    def top_bid(l):
        return l.bids.filter(kind="bid", status__in=("open", "accepted")).order_by("-amount", "created_at").first()

    def taken(l):
        return l.bookings.filter(status__in=("pending", "confirmed")).aggregate(n=Sum("persons"))["n"] or 0

    def card(l, me):
        top, img = top_bid(l), l.images.order_by("ord", "id").first()
        return {"id": l.id, "title": l.title, "kind": l.kind, "mode": l.mode, "theme": l.theme, "status": l.status, "price": f2(l.price), "allow_bids": l.allow_bids, "min_bid": f2(l.min_bid),
                "top_bid": f2(top.amount) if top else None, "bid_count": l.bids.filter(kind="bid", status__in=("open", "accepted")).count(), "booking_type": l.booking_type,
                "starts_at": l.starts_at, "capacity": l.capacity, "spots_left": max(0, l.capacity - taken(l)) if l.capacity else None, "location": l.location,
                "image": img.file if img else None, "owner": {"id": l.owner_id, "name": name(l.owner_id)}, "mine": l.owner_id == me.id, "created_at": l.created_at}

    def visible(l, me):
        return l.owner_id == me.id or (l.owner_id not in social.hidden_ids(me) and l.status != "closed")

    def row(pk, me):
        l = Listing.objects.filter(pk=pk).first() if str(pk).isdigit() else None
        return l if l and visible(l, me) else None

    def detail(l, me):
        d, mine = card(l, me), l.owner_id == me.id
        bids = [{"id": b.id, "bidder": {"id": b.bidder_id, "name": name(b.bidder_id)}, "amount": f2(b.amount), "kind": b.kind, "message": b.message, "status": b.status,
                 "created_at": b.created_at, "mine": b.bidder_id == me.id} for b in l.bids.exclude(status="withdrawn").order_by("-amount", "created_at")]
        mine_booking = l.bookings.filter(user=me).exclude(status__in=("cancelled", "declined")).first()
        d.update({"description": l.description, "images": [{"id": i.id, "url": i.file} for i in l.images.order_by("ord", "id")], "bids": bids,
                  "my_bid": next((b for b in bids if b["mine"] and b["status"] == "open"), None), "auto_confirm": l.auto_confirm,
                  "bookings": [{"id": b.id, "user": {"id": b.user_id, "name": name(b.user_id)}, "persons": b.persons, "message": b.message, "status": b.status, "created_at": b.created_at}
                               for b in l.bookings.order_by("created_at")] if mine else [],
                  "my_booking": {"id": mine_booking.id, "persons": mine_booking.persons, "status": mine_booking.status} if mine_booking else None,
                  "taken": taken(l) if l.mode == "booking" else None, "winner": {"id": l.winner_id, "name": name(l.winner_id)} if l.winner_id else None,
                  "can_bid": not mine and l.status == "active" and l.mode == "sale" and l.allow_bids, "can_buy": not mine and l.status == "active" and l.mode == "sale" and l.price is not None,
                  "can_book": not mine and l.status == "active" and l.mode == "booking" and not mine_booking})
        return d

    def clean(data, old=None):
        g = lambda k, d=None: data[k] if k in data else (getattr(old, k) if old is not None else d)  # noqa: E731
        title = str(g("title", "") or "").strip()[:120]
        if not title:
            raise ValueError(T("Geef de advertentie een titel."))
        desc = str(g("description", "") or "").strip()[:4000]
        from apps.security.words import find_forbidden

        if find_forbidden(f"{title} {desc}"):
            raise ValueError(T("Deze tekst bevat woorden die niet zijn toegestaan."))
        kind, theme, mode = g("kind", "product"), g("theme", "classic"), g("mode", "sale")
        if kind not in KINDS:
            raise ValueError(T("Kies product, dienst of anders."))
        if theme not in THEMES:
            raise ValueError(T("Onbekend thema."))
        if mode not in ("sale", "booking"):
            raise ValueError(T("Kies verkopen of boeking."))
        price, min_bid = money(g("price"), T("Prijs")), money(g("min_bid"), T("Vanaf prijs"))
        out = {"title": title, "description": desc, "kind": kind, "theme": theme, "mode": mode, "price": price, "min_bid": None, "allow_bids": False, "booking_type": "", "starts_at": None,
               "capacity": None, "auto_confirm": False, "location": str(g("location", "") or "").strip()[:120]}
        if mode == "sale":
            bids = bool(g("allow_bids", False))
            if price is not None and not cfg.get("allow_fixed", True) and not bids:
                raise ValueError(T("Een vaste prijs is op deze website niet toegestaan."))
            if bids and not cfg.get("allow_bids", True):
                raise ValueError(T("Bieden is op deze website niet toegestaan."))
            if price is None and not bids:
                raise ValueError(T("Geef een vaste prijs op of sta bieden toe."))
            if bids and price is not None and min_bid is not None and min_bid > price:
                raise ValueError(T("De vanaf-prijs voor bieden kan niet hoger zijn dan de vaste prijs."))
            out["allow_bids"], out["min_bid"] = bids, (min_bid if bids else None)
        else:
            if not cfg.get("allow_booking", True):
                raise ValueError(T("Boeken is op deze website niet toegestaan."))
            bt = g("booking_type", "appointment")
            if bt not in ("appointment", "event"):
                raise ValueError(T("Kies afspraak of feest."))
            out["booking_type"] = bt
            raw = g("starts_at")
            if raw:
                try:
                    dt = raw if isinstance(raw, datetime) else datetime.fromisoformat(str(raw).replace("Z", "+00:00"))
                except ValueError:
                    raise ValueError(T("Ongeldige datum of tijd."))
                out["starts_at"] = timezone.make_aware(dt) if timezone.is_naive(dt) else dt
            if bt == "event" and not out["starts_at"]:
                raise ValueError(T("Geef de datum en tijd van het feest op."))
            cap = g("capacity")
            if cap not in (None, ""):
                try:
                    out["capacity"] = int(cap)
                    assert 1 <= out["capacity"] <= 100000
                except (TypeError, ValueError, AssertionError):
                    raise ValueError(T("Het aantal plaatsen is ongeldig."))
            out["auto_confirm"] = bool(g("auto_confirm", False))
        return out

    # ── routes ─────────────────────────────────────────────────────────────
    @system.route("GET", "config")
    def get_config(request):
        return {"themes": THEMES, "max_images": num("max_images", 6), "max_active": num("max_active", 10), "allow_fixed": bool(cfg.get("allow_fixed", True)),
                "allow_bids": bool(cfg.get("allow_bids", True)), "allow_booking": bool(cfg.get("allow_booking", True))}

    @system.route("GET", "listings")
    def listings(request):
        me, q = request.user, request.query_params
        scope, qs = q.get("scope", "all"), Listing.objects.all()
        if scope == "mine":
            qs = qs.filter(owner=me)
        elif scope == "involved":
            qs = qs.filter(Q(bids__bidder=me) | Q(bookings__user=me)).distinct()
        else:
            qs = qs.filter(status="active").exclude(owner_id__in=list(social.hidden_ids(me)))
        if (t := (q.get("q") or "").strip()):
            qs = qs.filter(Q(title__icontains=t) | Q(description__icontains=t))
        for key in ("kind", "mode"):
            if q.get(key) in (*KINDS, "sale", "booking"):
                qs = qs.filter(**{key: q[key]})
        qs = qs.order_by({"price": "price", "price_desc": "-price", "date": "starts_at"}.get(q.get("sort"), "-created_at"))
        out = []
        for l in qs[:120]:
            d = card(l, me)
            if l.owner_id == me.id:
                d["open_bids"], d["pending_bookings"] = l.bids.filter(status="open").count(), l.bookings.filter(status="pending").count()
            out.append(d)
        return out

    @system.route("POST", "listings")
    def create(request):
        me = request.user
        if Listing.objects.filter(owner=me, status="active").count() >= num("max_active", 10):
            return bad(T("Je kunt maximaal {0} actieve advertenties hebben.", num("max_active", 10)))
        try:
            f = clean(request.data)
        except ValueError as e:
            return bad(str(e))
        l = Listing.objects.create(owner=me, **f)
        d = detail(l, me)
        system.emit("listing_created", listing=d, user=me)
        return Response(d, status=201)

    @system.route("GET", "listing/<id>")
    def get_listing(request, id):
        l = row(id, request.user)
        return detail(l, request.user) if l else bad(T("Deze advertentie bestaat niet of is niet zichtbaar."), 404)

    @system.route("PATCH", "listing/<id>")
    def change(request, id):
        me, l = request.user, row(id, request.user)
        if not l:
            return bad(T("Deze advertentie bestaat niet of is niet zichtbaar."), 404)
        if l.owner_id != me.id:
            return bad(T("Dit is niet jouw advertentie."), 403)
        data = request.data
        if set(data) == {"status"}:
            if data["status"] not in ("active", "closed", "sold"):
                return bad(T("Ongeldige status."))
            l.status = data["status"]
        else:
            try:
                for k, v in clean(data, l).items():
                    setattr(l, k, v)
            except ValueError as e:
                return bad(str(e))
        l.save()
        return detail(l, me)

    @system.route("DELETE", "listing/<id>")
    def remove(request, id):
        l = Listing.objects.filter(pk=id, owner=request.user).first() if str(id).isdigit() else None
        if not l:
            return bad(T("Niet gevonden."), 404)
        for i in l.images.all():
            (img_dir / i.file).unlink(missing_ok=True)
        Image.objects.filter(listing=l).delete()  # (the cascade of the system does not know the models of a plugin)
        Bid.objects.filter(listing=l).delete()
        Booking.objects.filter(listing=l).delete()
        l.delete()
        return Response(status=204)

    @system.route("POST", "listing/<id>/images")
    def add_image(request, id):
        """Body: {"image": "data:image/jpeg;base64,…"} (the page shrinks the picture first)."""
        me = request.user
        l = Listing.objects.filter(pk=id, owner=me).first() if str(id).isdigit() else None
        if not l:
            return bad(T("Niet gevonden."), 404)
        if l.images.count() >= num("max_images", 6):
            return bad(T("Maximaal {0} afbeeldingen per advertentie.", num("max_images", 6)))
        try:
            raw = base64.b64decode(str(request.data.get("image", "")).split(",", 1)[-1])
            from PIL import Image as PILImage

            im = PILImage.open(io.BytesIO(raw))
            im.load()
            if im.format not in ("JPEG", "PNG", "WEBP"):
                raise ValueError
            im = im.convert("RGB")
            im.thumbnail((1600, 1600))
        except (binascii.Error, ValueError, OSError):
            return bad(T("Dit is geen geldige afbeelding (JPG, PNG of WebP)."))
        fname = f"{uuid.uuid4().hex}.jpg"
        im.save(img_dir / fname, "JPEG", quality=85)  # re-encoded: no metadata, no surprises
        Image.objects.create(listing=l, file=fname, ord=(l.images.aggregate(m=models.Max("ord"))["m"] or -1) + 1)
        return Response(detail(l, me), status=201)

    @system.route("DELETE", "listing/<id>/image/<image_id>")
    def del_image(request, id, image_id):
        me = request.user
        l = Listing.objects.filter(pk=id, owner=me).first() if str(id).isdigit() else None
        img = l.images.filter(pk=image_id).first() if l and str(image_id).isdigit() else None
        if not img:
            return bad(T("Niet gevonden."), 404)
        (img_dir / img.file).unlink(missing_ok=True)
        img.delete()
        return detail(l, me)

    @system.route("GET", "image/<file>", public=True)
    def image(request, file):
        f = img_dir / file
        if not re.fullmatch(r"[0-9a-f]{32}\.jpg", file) or not f.is_file():
            return HttpResponse(status=404)
        r = FileResponse(open(f, "rb"), content_type="image/jpeg")
        r["Cache-Control"] = "public, max-age=86400"
        return r

    @system.route("POST", "listing/<id>/bids")
    def bid(request, id):
        me, data, l = request.user, request.data, row(id, request.user)
        if not l:
            return bad(T("Deze advertentie bestaat niet of is niet zichtbaar."), 404)
        if l.owner_id == me.id:
            return bad(T("Je kunt niet op je eigen advertentie bieden."))
        if l.status != "active" or l.mode != "sale":
            return bad(T("Hier kan niet meer op geboden worden."))
        kind, msg = ("buy" if data.get("kind") == "buy" else "bid"), str(data.get("message") or "").strip()[:300]
        if kind == "buy":
            if l.price is None:
                return bad(T("Deze advertentie heeft geen vaste prijs."))
            amount = l.price
            if l.bids.filter(bidder=me, kind="buy", status="open").exists():
                return bad(T("Je hebt al een koopverzoek gedaan."))
        else:
            if not l.allow_bids:
                return bad(T("Bieden is bij deze advertentie niet toegestaan."))
            try:
                amount = money(data.get("amount"), T("Bod"))
            except ValueError as e:
                return bad(str(e))
            if not amount or amount <= 0:
                return bad(T("Vul een bedrag in."))
            if l.min_bid is not None and amount < l.min_bid:
                return bad(T("Je bod moet minimaal {0} zijn.", l.min_bid))
            top = top_bid(l)
            if top and amount <= top.amount:
                return bad(T("Je bod moet hoger zijn dan het hoogste bod ({0}).", top.amount))
            l.bids.filter(bidder=me, kind="bid", status="open").update(status="withdrawn")  # a new bid replaces your previous one
        b = Bid.objects.create(listing=l, bidder=me, kind=kind, amount=amount, message=msg)
        d = detail(l, me)
        system.emit("bid_placed", bid={"id": b.id, "amount": f2(amount), "kind": kind}, listing=d, user=me)
        return Response(d, status=201)

    @system.route("POST", "bid/<id>/respond")
    def respond_bid(request, id):
        me, action = request.user, request.data.get("action")
        b = Bid.objects.select_related("listing").filter(pk=id).first() if str(id).isdigit() else None
        if not b:
            return bad(T("Niet gevonden."), 404)
        l = b.listing
        if action == "withdraw" and b.bidder_id == me.id and b.status == "open":
            b.status = "withdrawn"
            b.save()
        elif l.owner_id == me.id and b.status == "open" and action in ("accept", "decline"):
            if action == "decline":
                b.status = "declined"
                b.save()
            else:
                b.status = "accepted"
                b.save()
                l.bids.filter(status="open").exclude(pk=b.pk).update(status="declined")
                l.status, l.winner_id = "sold", b.bidder_id
                l.save()
        else:
            return bad(T("Dit kan nu niet."), 403)
        return detail(l, me)

    @system.route("POST", "listing/<id>/bookings")
    def book(request, id):
        me, data, l = request.user, request.data, row(id, request.user)
        if not l:
            return bad(T("Deze advertentie bestaat niet of is niet zichtbaar."), 404)
        if l.owner_id == me.id or l.mode != "booking" or l.status != "active":
            return bad(T("Hier kun je niet voor boeken."))
        if l.bookings.filter(user=me).exclude(status__in=("cancelled", "declined")).exists():
            return bad(T("Je hebt je hier al voor aangemeld."))
        try:
            persons = max(1, min(20, int(data.get("persons") or 1)))
        except (TypeError, ValueError):
            return bad(T("Het aantal personen is ongeldig."))
        if l.booking_type != "event":
            persons = 1
        left = (l.capacity - taken(l)) if l.capacity else None
        if left is not None and persons > left:
            return bad(T("Er zijn niet genoeg plaatsen meer.") if left else T("Het is vol."))
        b = Booking.objects.create(listing=l, user=me, persons=persons, message=str(data.get("message") or "").strip()[:300], status="confirmed" if l.auto_confirm else "pending")
        d = detail(l, me)
        system.emit("booking_created", booking={"id": b.id, "persons": persons}, listing=d, user=me)
        return Response(d, status=201)

    @system.route("POST", "booking/<id>/respond")
    def respond_booking(request, id):
        me, action = request.user, request.data.get("action")
        b = Booking.objects.select_related("listing").filter(pk=id).first() if str(id).isdigit() else None
        if not b:
            return bad(T("Niet gevonden."), 404)
        l = b.listing
        if action == "cancel" and b.user_id == me.id and b.status in ("pending", "confirmed"):
            b.status = "cancelled"
        elif l.owner_id == me.id and b.status in ("pending", "confirmed") and action in ("confirm", "decline"):
            if action == "confirm" and l.capacity and b.status == "pending":
                others = l.bookings.filter(status__in=("pending", "confirmed")).exclude(pk=b.pk).aggregate(n=Sum("persons"))["n"] or 0
                if others + b.persons > l.capacity:
                    return bad(T("Er zijn niet genoeg plaatsen."))
            b.status = "confirmed" if action == "confirm" else "declined"
        else:
            return bad(T("Dit kan nu niet."), 403)
        b.save()
        return detail(l, me)

    # ── demo data (Super admin → Standaard installaties → Demo-gegevens): listings of the demo people, found by their e-mail address demo-…@example.com ──
    class MarketplaceDemo:
        ROWS = [  # owner (number of the demo person), title, text, kind, mode, price, min bid / booking type, place, theme, picture motif, days from now, capacity
            (0, "Wollen winterjas, maat M", "Warme jas, twee winters gedragen en nog als nieuw. Uit een rookvrij huis.", "product", "sale", 45, 25, "Utrecht", "classic", "tag", None, None),
            (1, "Festivaltent voor 4 personen", "Ruime tent met luifel, één keer gebruikt. Inclusief haringen en tas.", "product", "sale", 120, 80, "Amsterdam", "fresh", "box", None, None),
            (2, "Yogales in de studio", "Een uur ontspannen vinyasa voor beginners en gevorderden. Matten zijn aanwezig.", "service", "booking", 18, "appointment", "Rotterdam", "elegant", "people", 4, 8),
            (3, "Zeilcursus voor beginners", "Een zaterdag op het water met een ervaren instructeur. Inclusief zeilpak en lunch.", "service", "booking", 95, "event", "Den Haag", "sunny", "calendar", 9, 6),
            (4, "Vintage eettafel van eiken", "Massief eiken tafel uit 1965, 180 x 90 cm. Met een paar gebruikssporen, daarom aantrekkelijk geprijsd.", "product", "sale", 350, 250, "Eindhoven", "elegant", "box", None, None),
            (5, "Retro spelcomputer met vijf games", "Alles werkt prima. Twee controllers en alle kabels erbij.", "product", "sale", 85, None, "Groningen", "playful", "tag", None, None),
            (6, "Kookworkshop streetfood", "Samen koken en eten: dumplings, saté en een Marokkaanse tajine. Alle ingrediënten zijn inbegrepen.", "service", "booking", 45, "event", "Antwerpen", "party", "calendar", 12, 10),
            (7, "Akoestische gitaar met hoes", "Mooie klank, nieuwe snaren. Ideaal voor een beginner of als reserve.", "product", "sale", 180, 130, "Gent", "classic", "tag", None, None),
            (8, "Hondenmand en riem", "Maat L, weinig gebruikt. Wasbare hoes. Samen te koop.", "product", "sale", 20, None, "Haarlem", "fresh", "box", None, None),
            (9, "Bijles geschiedenis voor de bovenbouw", "Een uur bijles aan huis of online, gericht op je examen.", "service", "booking", 30, "appointment", "Leiden", "classic", "people", 3, None),
        ]

        def _people(self):
            return list(U.objects.filter(email__startswith="demo-", email__endswith="@example.com").order_by("id")[:12])

        def empty(self):  # the module has no content of its own yet (an import fills it with example content then)
            return not Listing.objects.exists()

        def counts(self):
            return {"listings": Listing.objects.filter(owner__email__startswith="demo-", owner__email__endswith="@example.com").count()}

        def create(self, objects=True, orders=True, use_media=False, sets=None):
            people = self._people()
            if len(people) < 4 or self.counts()["listings"]:
                return {}
            from datetime import timedelta

            from apps.core import demo_art

            spec = demo_art.ART["marktplaats"]
            made = 0
            for n, (who, title, text, kind, mode, price, extra, place, theme, motif, days, cap) in enumerate(self.ROWS):
                if who >= len(people):
                    continue
                l = Listing.objects.create(owner=people[who], title=title, description=text, kind=kind, theme=theme, mode=mode, price=price, location=place,
                                           allow_bids=mode == "sale" and isinstance(extra, int), min_bid=extra if mode == "sale" and isinstance(extra, int) else None,
                                           booking_type=extra if mode == "booking" else "", starts_at=timezone.now().replace(minute=0, second=0, microsecond=0) + timedelta(days=days) if days else None,
                                           capacity=cap, auto_confirm=mode == "booking" and cap is None)
                for i in range(2):  # two pictures per listing, drawn
                    fname = f"{uuid.uuid4().hex}.jpg"
                    (img_dir / fname).write_bytes(demo_art._picture(spec, [motif if i == 0 else ("tag" if motif != "tag" else "box")], 1200, 800, 70 + n * 3 + i))
                    Image.objects.create(listing=l, file=fname, ord=i)
                made += 1
            # bids on the listings that allow them, and bookings on the services
            top = {1: [(3, 90), (5, 95), (8, 100)], 4: [(2, 260), (6, 290)], 7: [(0, 140), (3, 155)], 0: [(1, 30), (4, 35)]}
            for owner_idx, bids in top.items():
                l = Listing.objects.filter(owner=people[owner_idx], allow_bids=True).first() if owner_idx < len(people) else None
                for who, amount in bids:
                    if l and who < len(people):
                        Bid.objects.create(listing=l, bidder=people[who], kind="bid", amount=amount, message="Is dit nog beschikbaar?" if amount % 2 else "")
            for who_owner, bookers in ((2, [(0, "confirmed"), (4, "pending"), (6, "confirmed")]), (3, [(1, "confirmed"), (5, "pending")]), (6, [(7, "confirmed"), (8, "confirmed"), (0, "pending")]), (9, [(10, "pending")])):
                l = Listing.objects.filter(owner=people[who_owner], mode="booking").first() if who_owner < len(people) else None
                for who, status in bookers:
                    if l and who < len(people):
                        Booking.objects.create(listing=l, user=people[who], persons=1, status=status, message="Ik kom graag!" if status == "pending" else "")
            return {"listings": made}

        def remove(self):
            qs = Listing.objects.filter(owner__email__startswith="demo-", owner__email__endswith="@example.com")
            n = qs.count()
            for img in Image.objects.filter(listing__in=qs):
                (img_dir / img.file).unlink(missing_ok=True)
            Image.objects.filter(listing__in=qs).delete()  # (plugin models are not linked in the app registry: nothing goes along with the listing)
            Bid.objects.filter(listing__in=qs).delete()
            Booking.objects.filter(listing__in=qs).delete()
            Bid.objects.filter(bidder__email__startswith="demo-", bidder__email__endswith="@example.com").delete()
            Booking.objects.filter(user__email__startswith="demo-", user__email__endswith="@example.com").delete()
            qs.delete()
            return {"listings": n}

    system.provide("demo", MarketplaceDemo())
