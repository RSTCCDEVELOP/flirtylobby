# Copyright & Ownership Notice
# easy2Edit is the exclusive legal property of RST Coaching & Consultancy B.V. (RSTCC),
# owned by Ronald Stolk. All rights reserved. Any unauthorized use, copying, modification,
# reproduction, distribution, or commercial exploitation of Easy2Edit, including its source code,
# is strictly prohibited without prior written permission from Ronald Stolk or RSTCC.
# website https://rstcc.net

"""A section that follows the easy2edit design vocabulary (a band with a container, headings, texts, lists, buttons, pictures, grids of cards) as rows of the page builder,
worked out from the REAL css values (cssfacts.py): colours, sizes, margins, paddings, columns and the look of the cards. No AI is needed for such a section, the result is exact and
fast. Returns None when something in the section is not part of the vocabulary (a table, a form, an accordion, an own svg ...): the AI builds that section."""
import html as htmllib
import re

from . import cssfacts as CF

NOPAD = {"t": 0, "r": 0, "b": 0, "l": 0}  # (an item of the page builder has 10 px space inside by default: a design copies its own css instead)
INLINE_OK = {"p": "p", "ul": "ul", "ol": "ol", "li": "li", "strong": "strong", "b": "strong", "em": "em", "i": "em", "br": "br"}
WRAP = ("div", "section", "article", "header", "figure", "span", "main", "aside")
UNSUPPORTED = ("table", "form", "svg", "iframe", "video", "audio", "canvas", "input", "select", "textarea", "details", "picture", "object", "embed", "dl")


def rem(v):
    m = re.fullmatch(r"\s*(-?[\d.]+)\s*(rem|em|px)?\s*", str(v or ""))
    if not m:
        return None
    x = float(m.group(1))
    return x / 16 if m.group(2) == "px" else x


def px(v):
    r = rem(v)
    return None if r is None else r * 16


def margins(f):
    """(top, bottom) in rem from margin-top/-bottom or the margin shorthand."""
    top, bot = rem(f.get("margin-top")), rem(f.get("margin-bottom"))
    if f.get("margin") and (top is None or bot is None):
        parts = str(f["margin"]).split()
        idx = {1: (0, 0), 2: (0, 0), 3: (0, 2), 4: (0, 2)}.get(len(parts))
        if idx:
            top = rem(parts[idx[0]]) if top is None else top
            bot = rem(parts[idx[1]]) if bot is None else bot
    return (max(0.0, top or 0.0), max(0.0, bot or 0.0))


def hexc(v, over=None):
    """A colour as #rrggbb; a transparent colour is mixed over `over` (#rrggbb) so it can be used as a plain colour."""
    c = CF.parse_color(v)
    if not c:
        return ""
    if c[3] < 0.999:
        o = CF.parse_color(over or "#ffffff") or (255, 255, 255, 1)
        c = tuple(c[i] * c[3] + o[i] * (1 - c[3]) for i in range(3)) + (1.0,)
    return CF.fmt_color(c)


def kids(n):
    return [k for k in n.kids if not isinstance(k, str)]


def text_of(n):
    return " ".join(n.text().split())


def inline_html(n):
    out = []
    for k in n.kids:
        if isinstance(k, str):
            out.append(htmllib.escape(k))
            continue
        t = INLINE_OK.get(k.tag)
        if k.tag == "a":
            out.append(f'<a href="{htmllib.escape(k.attrs.get("href", "#"), quote=True)}">{inline_html(k)}</a>')
        elif k.tag == "br":
            out.append("<br>")
        elif t:
            out.append(f"<{t}>{inline_html(k)}</{t}>")
        elif k.tag in ("script", "style"):
            continue
        else:
            out.append(inline_html(k))  # a span or anything else: its text stays, its look is not copied
    return "".join(out)


class Convert:
    def __init__(self, section, rules, imgs):
        self.section, self.rules, self.imgs = section, rules, imgs
        self.compiled = [(CF._compounds(r[0]), r) for r in rules]
        self.sec = self.f(section)
        self.bg = self.sec.get("bg") or "#ffffff"
        self.ok = True

    def f(self, n):
        return CF.facts_of(n, self.rules, self.compiled)

    def media(self, url):
        return self.imgs.get(str(url or "").replace("__MEDIA__/", ""))

    def is_box(self, f):
        return bool(f.get("border") and "none" not in f["border"] and "0" != f["border"].split()[0][:1]) or bool(f.get("box-shadow") and f["box-shadow"] != "none") or (f.get("bg") and f.get("bg") != self.bg and bool(f.get("border-radius") or f.get("padding")))

    def grid_cols(self, f):
        g = f.get("grid-template-columns")
        if f.get("display") != "grid" or not g:
            return 0
        m = re.search(r"repeat\(\s*(\d+)", g)
        return int(m.group(1)) if m else len(re.findall(r"(?:\d[\w.%]*|minmax\([^)]*\)|auto)\s*", g))

    def heading_parts(self, n, f, color):
        """(plain text, the text with <em> around the coloured word, the colour of that word) of a heading. The text of the parts is joined the way the browser shows it: no space is added before a comma."""
        up = f.get("text-transform") == "uppercase"
        plain = " ".join("".join(k if isinstance(k, str) else text_of(k) for k in n.kids).split()) or text_of(n)
        title = plain.upper() if up else plain
        accent, marked = "", ""
        ACC = ("em", "i", "strong", "span", "b")
        for k in n.walk():  # a word in <em> that has its own colour in the css (h2 em { color: ... }): the heading keeps it as an accent
            if k is not n and k.tag in ACC and text_of(k):
                ec = hexc(self.f(k).get("color"), self.bg)
                if ec and ec != color:
                    accent = ec
                    break
        if accent:
            parts = []
            for k in n.kids:
                if isinstance(k, str):
                    parts.append(htmllib.escape(k))
                elif k.tag in ACC and text_of(k) and hexc(self.f(k).get("color"), self.bg) == accent:
                    parts.append(f"<em>{htmllib.escape(text_of(k))}</em>")
                else:
                    parts.append(htmllib.escape(text_of(k)))
            marked = " ".join("".join(parts).split())
            if up:
                marked = re.sub(r">([^<]+)<", lambda m: ">" + m.group(1).upper() + "<", f">{marked}<")[1:-1]
        return title, marked, accent

    # ── one element as items ──
    def items(self, n, last_margin=None):
        """[item dicts in the answer format of the AI] for an element, or None when it is not part of the vocabulary."""
        f = self.f(n)
        t = n.tag
        mt, mb = margins(f)
        base = {}
        if mt:
            base["mt"] = round(mt, 2)
        base["mb"] = round(mb, 2)
        color = hexc(f.get("color"), self.bg)
        align = f.get("text-align") if f.get("text-align") in ("left", "center", "right") else None
        if n.attrs.get("data-sysobject"):
            return [{"type": "sysobject", "slug": n.attrs["data-sysobject"]}]
        if n.attrs.get("data-easy2edit-tag"):  # a component of the UI-kit: one block, drawn by the kit with the colours of the theme
            return [component_item(n, self.imgs)] if component_item(n, self.imgs) else None
        if t in UNSUPPORTED:
            return None
        if t in ("h1", "h2", "h3", "h4", "h5", "h6"):
            size = rem(f.get("font-size")) or {"h1": 2.4, "h2": 1.8, "h3": 1.25}.get(t, 1.1)
            wt = rem(f.get("font-weight"))
            w = "800" if wt and wt >= 750 else "700" if wt and wt >= 650 else "600" if wt and wt >= 550 else "500" if wt and wt >= 450 else "400"
            title, marked, accent = self.heading_parts(n, f, color)
            return [{"type": "heading", "html": title, **({"rich": marked, "accent": accent} if marked else {}), "size": round(min(max(size, 0.8), 6), 2), "weight": w, "color": color, "align": align or "left", "pad": dict(NOPAD), **base}] if text_of(n) else []
        if t == "hr":
            return [{"type": "line"}]
        if t == "img":
            m = self.media(n.attrs.get("src"))
            if m is None:
                return None
            return [{"type": "image", "img": m, "align": align or "left", "radius": round(px(f.get("border-radius")) or 0), "w": "100%", **base}]
        if t == "a" and ("btn" in (n.attrs.get("class") or "") or f.get("display") in ("inline-block", "inline-flex", "inline")) and "btn" in (n.attrs.get("class") or ""):
            bgc = hexc(f.get("bg"), self.bg)
            bm = re.search(r"(#[0-9a-fA-F]{3,8}\b|rgba?\([^)]*\))", f.get("border-color") or f.get("border") or "")
            return [{"type": "button", "label": text_of(n)[:60], "href": n.attrs.get("href", "#"), "style": "primary" if bgc else "outline", "radius": round(px(f.get("border-radius")) or 0),
                     "bg": bgc or "transparent", "color": color, "border": hexc(bm.group(1), self.bg) if bm else "", **base}] if text_of(n) else []
        if t in ("p", "ul", "ol", "blockquote", "li", "a", "span", "small", "strong", "em", "label"):
            if not text_of(n):
                return []
            if t == "span" and kids(n) and any(k.tag in WRAP or k.tag in ("p", "ul", "ol") for k in kids(n)):
                return self.flatten(n)
            html = inline_html(n)
            body = html if t in ("ul", "ol") else f"<p>{html}</p>" if t != "p" else html if html.startswith("<p>") else f"<p>{html}</p>"
            if f.get("text-transform") == "uppercase":  # (only the text between the tags; letters and entities stay valid)
                html = re.sub(r">([^<]+)<", lambda m: ">" + htmllib.escape(htmllib.unescape(m.group(1)).upper(), quote=False) + "<", f">{html}<")[1:-1]
                body = f"<p>{html}</p>"
            it = {"type": "text", "html": f"<{t}>{html}</{t}>" if t in ("ul", "ol") else body if t != "p" else f"<p>{html}</p>", "size": round(min(max(rem(f.get("font-size")) or 1.0, 0.7), 4), 2), "color": color, "align": align or "left", "pad": dict(NOPAD), **base}
            bgc = hexc(f.get("bg"), self.bg)
            if bgc and bgc != self.bg:  # a label in a pill: its own background and rounded corners
                it["bg"] = bgc
            bm = re.search(r"(#[0-9a-fA-F]{3,8}\b|rgba?\([^)]*\))", f.get("border-color") or f.get("border") or "")
            if bm and f.get("border") and not str(f["border"]).startswith(("0", "none")):  # a label with a line around it (a pill)
                it["border"] = hexc(bm.group(1), bgc or self.bg)
            if (bgc and bgc != self.bg) or f.get("border"):
                it["radius"] = round(px(f.get("border-radius")) or 0)
                pt, pb = f.get("pad_top_px"), f.get("pad_bottom_px")
                pl = px((f.get("padding-left") or (f.get("padding") or "").split()[1] if len((f.get("padding") or "").split()) > 1 else None)) if (f.get("padding-left") or f.get("padding")) else None
                it["pad"] = {"t": int(pt or 0), "b": int(pb or 0), "l": int(pl or 0), "r": int(pl or 0)}
                if px(f.get("min-width")):  # a round number badge: the width of the css (min-width), so a pill with radius 999px becomes a circle
                    it["minw"] = int(px(f["min-width"]))
            return [it]
        if t in WRAP or t == "ul":
            return self.flatten(n)
        return None

    def flatten(self, n):
        """A plain wrapper (no box of its own): the items of its children; its bottom margin goes to the last item."""
        f = self.f(n)
        if self.is_box(f) or self.grid_cols(f) >= 2:
            return None
        out = []
        for k in kids(n):
            got = self.items(k)
            if got is None:
                return None
            out += got
        if not out and not text_of(n):
            return []
        _mt, mb = margins(f)
        if out and mb:
            out[-1]["mb"] = round(max(out[-1].get("mb", 0), mb), 2)
        # loose text in the wrapper (not inside an element): one text
        if not out and text_of(n):
            return [{"type": "text", "html": f"<p>{inline_html(n)}</p>", "size": round(rem(f.get("font-size")) or 1.0, 2), "color": hexc(f.get("color"), self.bg), "align": "left", "mb": round(mb, 2)}]
        return out

    # ── rows ──
    def card(self, f):
        c = {"radius": round(px(f.get("border-radius")) or 0), "pad": round(f.get("pad_top_px") or 0)}
        if hexc(f.get("bg"), self.bg):
            c["bg"] = hexc(f.get("bg"), self.bg)
        bm = re.search(r"(#[0-9a-fA-F]{3,8}\b|rgba?\([^)]*\))", f.get("border-color") or f.get("border") or "")
        if bm and f.get("border") and not str(f["border"]).startswith(("0", "none")):
            c["border"] = hexc(bm.group(1), c.get("bg") or self.bg)
        if f.get("box-shadow") and f["box-shadow"] != "none":
            c["shadow"] = True
        return c

    def cell_items(self, child):
        f = self.f(child)
        if self.is_box(f):
            its = []
            for k in kids(child):
                got = self.items(k)
                if got is None:
                    return None
                its += got
            if not its and text_of(child):
                its = [{"type": "text", "html": f"<p>{inline_html(child)}</p>", "size": 1.0, "color": hexc(f.get("color"), self.bg), "align": "left", "mb": 0}]
            if its:
                its[0].pop("mt", None)
                its[-1]["mb"] = 0  # the padding of the card is the space below its last item (the css: .card p:last-child {margin-bottom: 0})
            return {"card": self.card(f), "items": its, "align": f.get("text-align")}
        got = self.items(child)
        return None if got is None else {"card": None, "items": got, "align": f.get("text-align")}

    def rows(self):
        parent = self.section
        for k in kids(self.section):  # the container of the band
            if k.tag == "div" and "container" in (k.attrs.get("class") or "") and len(kids(self.section)) == 1:
                parent = k
        rows, intro = [], []

        def flush():
            nonlocal intro
            if intro:
                rows.append({"cells": [{"width": "auto", "halign": "left", "valign": "top", "gap": 0, "card": None, "items": intro}], "gap": "md"})
                intro = []

        for k in kids(parent):
            if k.attrs.get("data-easy2edit-tag"):  # a component: its own row, full width
                flush()
                native = native_component_rows(k, self.imgs)  # the hero and the split become real blocks of the page editor
                if native:
                    rows += native
                    continue
                it = component_item(k, self.imgs)
                if it is None:
                    return None
                rows.append({"cells": [{"width": "auto", "halign": "left", "valign": "top", "gap": 0, "card": None, "items": [it]}], "gap": "md"})
                continue
            f = self.f(k)
            n = self.grid_cols(f)
            if n >= 2:
                flush()
                n = min(n, 4)
                gap = px((f.get("gap") or "").split()[0]) if f.get("gap") else 24
                gmap = "sm" if (gap or 0) <= 16 else "md" if (gap or 0) <= 32 else "lg"
                children = kids(k)
                mt, _mb = margins(f)
                for i in range(0, len(children), n):
                    cells = []
                    for ch in children[i:i + n]:
                        c = self.cell_items(ch)
                        if c is None:
                            return None
                        if c["items"]:
                            cells.append({"width": "auto", "halign": c["align"] if c["align"] in ("left", "center", "right") else "left", "valign": "center" if f.get("align-items") == "center" else "top", "gap": 0, "card": c["card"], "items": c["items"]})
                    if cells:
                        rows.append({"cells": cells, "gap": gmap, "_mt": mt if i == 0 else 0})
                continue
            if self.is_box(f) and not (k.tag == "a" and "btn" in (k.attrs.get("class") or "")):  # a box of its own (a call to action, a callout): one row with a card (a button is no box: it has its own item)
                flush()
                c = self.cell_items(k)
                if c is None:
                    return None
                rows.append({"cells": [{"width": "auto", "halign": "left", "valign": "top", "gap": 0, "card": c["card"], "items": c["items"]}], "gap": "md"})
                continue
            got = self.items(k)
            if got is None:
                return None
            intro += got
        flush()
        if not rows:
            return None
        sec = self.sec
        for i, r in enumerate(rows):
            last = i == len(rows) - 1
            for c in r["cells"]:
                if c["items"]:
                    c["items"][-1]["mb"] = 0 if last else c["items"][-1].get("mb", 0)
            r["pad_top"] = sec.get("pad_top_px", 0) if i == 0 else round((r.pop("_mt", 0) or 0) * 16)
            r["pad_bottom"] = sec.get("pad_bottom_px", 0) if last else 0
            r.pop("_mt", None)
            r.update({"title": str(self.section.attrs.get("id") or "Sectie")[:60], "anchor": "", "full": True, "bg": sec.get("bg", ""), "bg_image": None, "overlay": 0, "color": sec.get("color", ""), "radius": 0, "min_height": 0})
        if sec.get("image") and self.media(sec["image"]) is not None:
            rows[0]["bg_image"] = self.media(sec["image"])
            rows[0]["overlay"] = round(min(max(float(sec.get("overlay_opacity") or 0.4), 0), 0.9), 2)
            if sec.get("overlay"):
                rows[0]["bg"] = sec["overlay"]
        return rows


def component_html(node, imgs):
    """The html of an element with a data-easy2edit-tag (a component of the easy2edit UI-kit), with the pictures as IMG:n; the kit draws it with the colours of the theme."""
    from . import importer

    at = "".join(f' {a}="{htmllib.escape(str(v), quote=True)}"' for a, v in node.attrs.items() if not a.lower().startswith("on"))
    return f"<{node.tag}{at}>{importer._outer(node, imgs)}</{node.tag}>"


def component_item(node, imgs):
    tag = str(node.attrs.get("data-easy2edit-tag") or "").strip()
    if not re.fullmatch(r"[a-z0-9][a-z0-9_-]{0,59}", tag):
        return None
    html = component_html(node, imgs)
    kit_set = str(node.attrs.get("data-easy2edit-set") or "").strip()  # the component set that the design was made with (the prompt asks for it); empty = the set in use
    kit_set = kit_set if re.fullmatch(r"[a-z0-9][a-z0-9_-]{1,59}", kit_set) else ""
    return {"type": "code", "html": html, "css": "", "kit": True, "tag": tag, **({"set": kit_set} if kit_set else {})} if len(html) <= 50000 else None


def component_notes(html_texts):
    """What the import found of the UI-kit in the html files of a design: the components that it recognises (by their easy2edit_tag) and the tags that do not exist in the set. [note]"""
    tags, sets = {}, set()
    for t in html_texts:
        for m in re.finditer(r'data-easy2edit-tag\s*=\s*["\']([^"\']{1,60})["\']', t or ""):
            tags[m.group(1)] = tags.get(m.group(1), 0) + 1
        sets.update(m.group(1) for m in re.finditer(r'data-easy2edit-set\s*=\s*["\']([^"\']{1,60})["\']', t or ""))
    if not tags:
        return []
    try:
        from apps.core import componentpacks as cp

        known = {c["easy2edit_tag"] for c in cp.get(sorted(sets)[0] if len(sets) == 1 else None)["components"]}
    except Exception:  # noqa: BLE001 - only a report
        known = set(tags)
    ok = {k: v for k, v in tags.items() if k in known}
    bad = sorted(k for k in tags if k not in known)
    native = sum(v for k, v in ok.items() if k in ("ui-hero-split", "ui-split"))
    notes = [f"INFO: Componenten van de UI-kit herkend: {sum(ok.values())} ({', '.join(f'{k} x{v}' for k, v in sorted(ok.items()))}). "
             + (f"{native} daarvan (hero en tekst met afbeelding) worden blokken van de pagina-editor; " if native else "")
             + "de andere blijven componenten van de UI-kit en volgen de kleuren en lettertypen van het thema."]
    if sets:
        notes.append("INFO: Componentenset van het ontwerp: " + ", ".join(sorted(sets)) + ".")
    if bad:
        notes.append("Onbekende easy2edit_tags (staan niet in de componentenset, worden als gewone code getoond): " + ", ".join(bad) + ".")
    return notes


def fill_components(rows, section, imgs):
    """An answer of the AI with {"type": "code", "kit": true, "tag": ...} items: the html of the component comes from the file (the AI does not repeat it)."""
    try:
        by_tag = {}  # the components of one kind in the order of the file: two of the same kind in a section (two call to action boxes) each get their OWN html
        for n in section.walk():
            if n.attrs.get("data-easy2edit-tag"):
                by_tag.setdefault(str(n.attrs.get("data-easy2edit-tag")), []).append(n)
        used = {}
        for r in rows or []:
            for c in (r.get("cells") or []) if isinstance(r, dict) else []:
                for it in (c.get("items") or []) if isinstance(c, dict) else []:
                    if isinstance(it, dict) and it.get("type") == "code" and it.get("kit") and not it.get("html"):
                        tag = str(it.get("tag") or "")
                        lst = by_tag.get(tag) or []
                        k = used.get(tag, 0)
                        used[tag] = k + 1
                        n = lst[k] if k < len(lst) else (lst[-1] if lst else None)
                        got = component_item(n, imgs) if n is not None else None
                        if got:
                            it.update(got)
    except Exception:  # noqa: BLE001 - only an improvement
        pass
    return rows


def rows_for(section, rules, imgs):
    """The rows of one section from the css, or None when the section is not part of the vocabulary."""
    try:
        return Convert(section, rules, imgs).rows()
    except Exception:  # noqa: BLE001 - never stop the import for this: the AI builds the section
        return None


def fix_headings(rows, section, rules, imgs):
    """The headings of an answer of the AI get the exact text (no space before a comma) and the coloured word of the original (<em> with its own colour in the css): the AI does not see that."""
    try:
        cv = Convert(section, rules, imgs)
        heads = [n for n in section.walk() if n.tag in ("h1", "h2", "h3", "h4", "h5", "h6")]
        norm = lambda t: re.sub(r"[\W_]+", "", str(t or "")).lower()  # noqa: E731
        for r in rows or []:
            for c in (r.get("cells") or []) if isinstance(r, dict) else []:
                for it in (c.get("items") or []) if isinstance(c, dict) else []:
                    if not isinstance(it, dict) or it.get("type") != "heading":
                        continue
                    key = norm(re.sub(r"<[^>]+>", "", str(it.get("html") or it.get("text") or "")))
                    n = next((h for h in heads if norm(text_of(h)) == key), None)
                    if n is None or not key:
                        continue
                    f = cv.f(n)
                    title, marked, accent = cv.heading_parts(n, f, hexc(f.get("color"), cv.bg))
                    it["html"] = title
                    if marked and accent:
                        it["rich"], it["accent"] = marked, accent
    except Exception:  # noqa: BLE001 - only an improvement
        pass
    return rows

# ── components of the UI-kit as blocks of the page editor (no html/css block) ──
# The hero and the split are rebuilt as real blocks: a row with a text cell (label, heading, text, buttons) and a picture cell. The picture then fills its cell and everything can be edited with the page editor.
def _has_class(n, name):
    return name in (n.attrs.get("class") or "").split()


def _find_class(node, name):
    return [n for n in node.walk() if _has_class(n, name)]


def _img_number(node, imgs):
    for i in node.walk():
        if i.tag == "img":
            src = str(i.attrs.get("src") or "").replace("__MEDIA__/", "")
            if src in imgs:
                return imgs[src]
    return None


def _text_items(node):
    """The label, heading, text, list and buttons of a component in the order of the html, as items of the page editor."""
    items, seen = [], set()
    for n in node.walk():
        if id(n) in seen:
            continue
        t, cls = n.tag, (n.attrs.get("class") or "").split()
        txt = text_of(n)
        if not txt:
            continue
        if t in ("h1", "h2", "h3"):
            items.append({"type": "heading", "html": htmllib.escape(txt), "size": {"h1": 3.2, "h2": 2.3, "h3": 1.35}[t], "weight": "600", "align": "left"})
            seen.update(id(x) for x in n.walk())
        elif "e2e-eyebrow" in cls:
            items.append({"type": "text", "html": f"<p><strong>{htmllib.escape(txt.upper())}</strong></p>", "size": 0.8, "align": "left"})
            seen.update(id(x) for x in n.walk())
        elif t == "p":
            items.append({"type": "text", "html": f"<p>{inline_html(n)}</p>", "size": 1.1 if "e2e-lead" in cls else 1, "align": "left"})
            seen.update(id(x) for x in n.walk())
        elif t in ("ul", "ol"):
            items.append({"type": "text", "html": f"<{t}>" + "".join(f"<li>{inline_html(li)}</li>" for li in n.kids if not isinstance(li, str) and li.tag == "li" and text_of(li)) + f"</{t}>", "size": 1, "align": "left"})
            seen.update(id(x) for x in n.walk())
        elif t == "a" and "e2e-btn" in cls:
            items.append({"type": "button", "label": txt[:60], "href": n.attrs.get("href", "#"), "style": "outline" if "e2e-btn--outline" in cls else "primary"})
            seen.update(id(x) for x in n.walk())
    return items


def galleries(rows, minimum=3):
    """Photos that stand next to or under each other (3 or more) are ONE photo carousel, the media system object: a row of cells that each hold only a picture, or a run of pictures in one cell, becomes {"type": "gallery", "imgs": [numbers]}."""
    def pic(it):
        return isinstance(it, dict) and it.get("type") == "image" and it.get("img") is not None

    try:
        for r in rows or []:
            if not isinstance(r, dict):
                continue
            cells = [c for c in (r.get("cells") or []) if isinstance(c, dict)]
            if len(cells) >= minimum and all(len(c.get("items") or []) == 1 and pic(c["items"][0]) for c in cells):
                r["cells"] = [{**cells[0], "width": "auto", "card": None, "items": [{"type": "gallery", "imgs": [c["items"][0]["img"] for c in cells]}]}]
                continue
            for c in cells:
                out, run = [], []
                for it in [*(c.get("items") or []), None]:
                    if pic(it):
                        run.append(it)
                        continue
                    if len(run) >= minimum:
                        out.append({"type": "gallery", "imgs": [x["img"] for x in run]})
                    else:
                        out += run
                    run = []
                    if it is not None:
                        out.append(it)
                c["items"] = out
    except Exception:  # noqa: BLE001 - only an improvement
        pass
    return rows


# ── components that become blocks of the page editor: every text, icon, box and button is an object of its own ──
ALLOWED_SVG = {"d", "cx", "cy", "r", "x", "y", "width", "height", "rx", "ry", "points", "x1", "y1", "x2", "y2", "transform", "fill", "stroke", "stroke-width", "stroke-linecap", "stroke-linejoin", "opacity"}


def _svg_inner(node):
    """The drawing parts (path, circle, rect, line ...) inside an <svg>, as safe markup."""
    out = []
    for k in node.kids:
        if isinstance(k, str):
            continue
        if k.tag in ("path", "circle", "rect", "line", "polyline", "polygon", "ellipse", "g"):
            attrs = "".join(f' {a}="{htmllib.escape(str(v), quote=True)}"' for a, v in k.attrs.items() if a.lower() in ALLOWED_SVG)
            out.append(f"<{k.tag}{attrs}>{_svg_inner(k) if k.tag == 'g' else ''}</{k.tag}>")
    return "".join(out)


def _icon_item(box, colors, size=44):
    svg = next((n for n in box.walk() if n.tag == "svg"), None) if box is not None else None
    inner = _svg_inner(svg) if svg is not None else ""
    return {"type": "icon", "svg": inner, "color": colors.get("primary") or "#1b97d3", "size": size} if inner else None


def _heading(txt, size, align="left", weight="600", mb=None):
    it = {"type": "heading", "html": htmllib.escape(txt), "size": size, "weight": weight, "align": align}
    if mb is not None:
        it["mb"] = mb
    return it


def _paragraph(html_, size=1.0, align="left", color=None):
    it = {"type": "text", "html": f"<p>{html_}</p>", "size": size, "align": align}
    if color:
        it["color"] = color
    return it


def _intro_items(div):
    """The eyebrow, heading and lead text above a grid (the first block of a section component), centred or left as in the design."""
    if div is None:
        return []
    centred = "center" in str(div.attrs.get("style") or "")
    al = "center" if centred else "left"
    items = []
    for n in div.walk():
        cls = (n.attrs.get("class") or "").split()
        txt = text_of(n)
        if not txt:
            continue
        if "e2e-eyebrow" in cls:
            items.append({"type": "text", "html": f"<p><strong>{htmllib.escape(txt.upper())}</strong></p>", "size": 0.8, "align": al})
        elif n.tag in ("h1", "h2", "h3"):
            items.append(_heading(txt, {"h1": 3.2, "h2": 2.3, "h3": 1.35}[n.tag], al))
        elif n.tag == "p":
            items.append(_paragraph(inline_html(n), 1.1 if "e2e-lead" in cls else 1, al))
    return items


def _chunks(seq, n):
    return [seq[i:i + n] for i in range(0, len(seq), n)]


def _native_features(node, imgs, colors):
    sec = next((k for k in node.walk() if k.tag == "section"), node)
    grid = (_find_class(sec, "e2e-grid") or [None])[0]
    if grid is None:
        return None
    intro = next((k for k in kids(sec) if k is not grid and not _has_class(k, "e2e-grid")), None)
    cards = [k for k in kids(grid)]
    if not cards:
        return None
    rows = []
    items = _intro_items(intro)
    if items:
        rows.append({"title": "services", "full": False, "bg": "", "pad_top": 24, "pad_bottom": 8, "cells": [{"width": "auto", "halign": "center" if "center" in str(intro.attrs.get("style") or "") else "left", "valign": "top", "card": None, "items": items}], "gap": "md"})
    per = 4 if len(cards) % 4 == 0 or len(cards) > 6 else 3 if len(cards) % 3 == 0 else min(4, len(cards))
    for chunk in _chunks(cards, per):
        cells = []
        for c in chunk:
            it = []
            icon = _icon_item((_find_class(c, "e2e-icon-box") or [None])[0], colors)
            if icon:
                it.append(icon)
            h = next((x for x in c.walk() if x.tag in ("h2", "h3", "h4")), None)
            if h is not None and text_of(h):
                it.append(_heading(text_of(h), 1.35, "left"))
            for p_ in [x for x in c.walk() if x.tag == "p" and text_of(x)]:
                it.append(_paragraph(inline_html(p_), 1.0, "left", colors.get("muted")))
            if it:
                cells.append({"width": "auto", "halign": "left", "valign": "top", "card": None, "items": it})
        if cells:
            rows.append({"title": "", "full": False, "bg": "", "pad_top": 16, "pad_bottom": 24, "cells": cells, "gap": "lg"})
    return rows or None


def _native_testimonials(node, imgs, colors):
    quotes = [q for q in node.walk() if _has_class(q, "e2e-quote")]
    if not quotes:
        return None
    rows = []
    for chunk in _chunks(quotes, 2):
        cells = []
        for q in chunk:
            bq = next((x for x in q.walk() if x.tag == "blockquote"), None)
            it = []
            if bq is not None and text_of(bq):
                it.append(_paragraph(inline_html(bq), 1.15, "left"))
            av = (_find_class(q, "e2e-avatar") or [None])[0]
            if av is not None and text_of(av):
                it.append({"type": "text", "html": f"<p><strong>{htmllib.escape(text_of(av))}</strong></p>", "size": 0.85, "align": "left", "bg": colors.get("primary_soft") or "#e6f3fb", "color": colors.get("primary") or "#1b97d3", "radius": 999, "pad": {"t": 6, "r": 12, "b": 6, "l": 12}})
            strong = next((x for x in q.walk() if x.tag == "strong"), None)
            small = next((x for x in q.walk() if x.tag == "small"), None)
            if strong is not None and text_of(strong):
                it.append({"type": "text", "html": f"<p><strong>{htmllib.escape(text_of(strong))}</strong></p>", "size": 1.0, "align": "left"})
            if small is not None and text_of(small):
                it.append(_paragraph(htmllib.escape(text_of(small)), 0.85, "left", colors.get("muted")))
            if it:
                cells.append({"width": "auto", "halign": "left", "valign": "top", "card": {"bg": colors.get("card") or "#f5f6f8", "radius": 16, "pad": 24}, "items": it})
        if cells:
            rows.append({"title": "reviews" if not rows else "", "full": False, "bg": "", "pad_top": 16, "pad_bottom": 16, "cells": cells, "gap": "lg"})
    return rows or None


def _native_faq(node, imgs, colors):
    qa = []
    for d in node.walk():
        if d.tag == "details":
            q = next((x for x in d.walk() if x.tag == "summary"), None)
            a = next((x for x in d.walk() if _has_class(x, "e2e-accordion__content")), None)
            if q is not None and a is not None and text_of(q) and text_of(a):
                qa.append({"q": text_of(q), "a": f"<p>{inline_html(a)}</p>"})
    if not qa:
        return None
    return [{"title": "faq", "full": False, "bg": "", "pad_top": 16, "pad_bottom": 24, "cells": [{"width": "auto", "halign": "left", "valign": "top", "card": None, "items": [{"type": "faq", "heading": "", "items": qa}]}], "gap": "md"}]


def _native_stats(node, imgs, colors):
    st = [{"value": text_of((_find_class(x, "e2e-stat__value") or [x])[0]), "label": text_of((_find_class(x, "e2e-stat__label") or [x])[0])} for x in node.walk() if _has_class(x, "e2e-stat")]
    st = [x for x in st if x["value"] or x["label"]]
    if not st:
        return None
    return [{"title": "stats", "full": False, "bg": "", "pad_top": 24, "pad_bottom": 24, "cells": [{"width": "auto", "halign": "center", "valign": "top", "card": None, "items": [{"type": "widget", "widget": "stats", "items": st}]}], "gap": "md"}]


def _native_cta(node, imgs, colors):
    rows = []
    for box in [x for x in node.walk() if _has_class(x, "e2e-cta")]:
        accent = _has_class(box, "e2e-cta--accent")
        bg = (colors.get("secondary") if accent else colors.get("primary")) or "#1b97d3"
        h = next((x for x in box.walk() if x.tag in ("h1", "h2", "h3")), None)
        p_ = next((x for x in box.walk() if x.tag == "p"), None)
        a = next((x for x in box.walk() if x.tag == "a"), None)
        left = []
        if h is not None and text_of(h):
            left.append(_heading(text_of(h), 2.0, "left"))
        if p_ is not None and text_of(p_):
            left.append(_paragraph(inline_html(p_), 1.05, "left"))
        cells = [{"width": "66" if a is not None else "auto", "halign": "left", "valign": "center", "card": None, "items": left}]
        if a is not None and text_of(a):
            cells.append({"width": "33", "halign": "right", "valign": "center", "card": None, "items": [{"type": "button", "label": text_of(a)[:60], "href": a.attrs.get("href", "#"), "style": "primary", "bg": "#ffffff", "color": bg, "border": "#ffffff"}]})
        if left:
            rows.append({"title": "cta" if not rows else "", "full": True, "bg": bg, "color": "#ffffff", "radius": 16, "pad_top": 40, "pad_bottom": 40, "cells": cells, "gap": "lg"})
    return rows or None


def _native_pricing(node, imgs, colors):
    plans = [x for x in node.walk() if _has_class(x, "e2e-price")]
    if not plans:
        return None
    cells = []
    for pl in plans:
        feat = _has_class(pl, "e2e-price--featured")
        it = []
        badge = (_find_class(pl, "e2e-badge") or [None])[0]
        if badge is not None and text_of(badge):
            it.append({"type": "text", "html": f"<p><strong>{htmllib.escape(text_of(badge))}</strong></p>", "size": 0.8, "align": "left", "bg": colors.get("primary") or "#1b97d3", "color": "#ffffff", "radius": 999, "pad": {"t": 4, "r": 10, "b": 4, "l": 10}})
        h = next((x for x in pl.walk() if x.tag == "h3"), None)
        if h is not None:
            it.append(_heading(text_of(h), 1.35, "left"))
        amt = (_find_class(pl, "e2e-price__amount") or [None])[0]
        if amt is not None:
            it.append(_heading(text_of(amt), 2.2, "left", "700"))
        p_ = next((x for x in pl.walk() if x.tag == "p"), None)
        if p_ is not None and text_of(p_):
            it.append(_paragraph(inline_html(p_), 1.0, "left", colors.get("muted")))
        ul = next((x for x in pl.walk() if x.tag == "ul"), None)
        if ul is not None:
            it.append({"type": "text", "html": "<ul>" + "".join(f"<li>{inline_html(li)}</li>" for li in ul.kids if not isinstance(li, str) and li.tag == "li") + "</ul>", "size": 1, "align": "left"})
        a = next((x for x in pl.walk() if x.tag == "a"), None)
        if a is not None and text_of(a):
            it.append({"type": "button", "label": text_of(a)[:60], "href": a.attrs.get("href", "#"), "style": "primary" if feat else "outline"})
        cells.append({"width": "auto", "halign": "left", "valign": "top", "card": {"bg": colors.get("card") or "#f5f6f8", "border": colors.get("primary") if feat else colors.get("line") or "#e0e1e3", "radius": 16, "pad": 24}, "items": it})
    return [{"title": "pricing", "full": False, "bg": "", "pad_top": 16, "pad_bottom": 24, "cells": cells[:4], "gap": "lg"}]


def _native_gallery(node, imgs, colors):
    """Photos together: the photo carousel of easy2edit (a media system object), not pictures under each other."""
    nums = []
    for i in node.walk():
        if i.tag == "img":
            src = str(i.attrs.get("src") or "").replace("__MEDIA__/", "")
            if src in imgs and imgs[src] not in nums:
                nums.append(imgs[src])
    if len(nums) < 2:
        return None
    return [{"title": "gallery", "full": False, "bg": "", "pad_top": 16, "pad_bottom": 24, "cells": [{"width": "auto", "halign": "left", "valign": "top", "card": None, "items": [{"type": "gallery", "imgs": nums}]}], "gap": "md"}]


NATIVE_BUILDERS = {"ui-gallery": _native_gallery, "ui-features": _native_features, "ui-testimonials": _native_testimonials, "ui-faq": _native_faq, "ui-stats": _native_stats, "ui-cta": _native_cta, "ui-pricing": _native_pricing}


# A component of the UI-kit that the creator used (features, reviews, questions, figures, call to action, prices) stays that component, so the page looks EXACTLY like the design (the card of a review with
# its avatar, the accordion of the questions, the figures, the coloured call to action boxes). Only the hero and the text with a picture become blocks (see native_component_rows).
# Set to False to have them taken apart into separate blocks of the page editor (text, heading, icon, button): editable one by one, but never exactly like the design.
KEEP_KIT_COMPONENTS = True


def expand_native(rows, section, imgs, colors=None):
    """A section that is ONE component of the UI-kit (features, reviews, questions, figures, call to action, prices) becomes real blocks of the page editor: every heading, text, icon, box and button is an object of its own. Only when the row holds nothing else; otherwise (or when the component cannot be read) it stays a component."""
    colors = colors or {}
    if KEEP_KIT_COMPONENTS:
        return rows
    try:
        nodes = {str(n.attrs.get("data-easy2edit-tag")): n for n in reversed(list(section.walk())) if n.attrs.get("data-easy2edit-tag")}
        out = []
        for r in rows or []:
            items = [it for c in (r.get("cells") or []) if isinstance(c, dict) for it in (c.get("items") or [])] if isinstance(r, dict) else []
            one = items[0] if len(items) == 1 else None
            tag = str(one.get("tag") or "") if isinstance(one, dict) and one.get("type") == "code" and one.get("kit") else ""
            built = None
            if tag in NATIVE_BUILDERS and nodes.get(tag) is not None:
                try:
                    built = NATIVE_BUILDERS[tag](nodes[tag], imgs, colors)
                except Exception:  # noqa: BLE001 - the component stays a component
                    built = None
            if built:
                if r.get("anchor") and not built[0].get("anchor"):
                    built[0]["anchor"] = r["anchor"]
                if r.get("title") and not built[0].get("title"):
                    built[0]["title"] = r["title"]
                out.extend(built)
            else:
                out.append(r)
        return out
    except Exception:  # noqa: BLE001 - only an improvement
        return rows


def native_component_rows(node, imgs):
    """Rows (the format of the AI answer) for a component that is rebuilt as blocks, or None (then it stays a component of the UI-kit)."""
    tag = str(node.attrs.get("data-easy2edit-tag") or "")
    try:
        if tag == "ui-hero-split":
            media = (_find_class(node, "e2e-hero__visual") or [None])[0]
            imgn = _img_number(media, imgs) if media is not None else None
            items = _text_items(node)
            if not items:
                return None
            cells = [{"width": "55" if imgn is not None else "auto", "halign": "left", "valign": "center", "card": None, "items": items}]
            if imgn is not None:
                cells.append({"width": "45", "halign": "center", "valign": "center", "card": None, "items": [{"type": "image", "img": imgn, "align": "center", "radius": 16, "w": "100%"}]})
            return [{"title": "hero", "full": True, "bg": "", "pad_top": 64, "pad_bottom": 64, "cells": cells, "gap": "lg"}]
        if tag == "ui-split":
            split = (_find_class(node, "e2e-split") or [None])[0]
            media = (_find_class(node, "e2e-split__media") or [None])[0]
            if split is None or media is None:
                return None
            imgn = _img_number(media, imgs)
            items = []
            for k in kids(split):
                if k is not media:
                    items += _text_items(k)
            if not items or imgn is None:
                return None
            pic = {"width": "45", "halign": "center", "valign": "center", "card": None, "items": [{"type": "image", "img": imgn, "align": "center", "radius": 16, "w": "100%"}]}
            txt = {"width": "55", "halign": "left", "valign": "center", "card": None, "items": items}
            first_is_media = bool(kids(split)) and kids(split)[0] is media
            return [{"title": "split", "full": False, "bg": "", "pad_top": 40, "pad_bottom": 40, "cells": [pic, txt] if first_is_media else [txt, pic], "gap": "lg"}]
    except Exception:  # noqa: BLE001 - never stop the import: the component stays a component
        return None
    return None

